class_name Media
extends RefCounted
## Coletiva pós-jogo e redes sociais (técnico e jogador).
##
## Estado salvo em Game.S["media"]. Medidores de 0 a 100:
##   diretoria = confiança da diretoria (modo jogador: confiança do técnico, Pro.P()["coach"])
##   torcida   = humor da torcida (técnico: Game.S["support"], que mexe na bilheteria;
##               jogador: Pro.P()["fans"])
##   moral     = moral do elenco (mexe na energia dos jogadores, que entra na força do time)
##   imprensa  = relação com a imprensa (manchetes mais duras ou mais leves)
## Os textos ficam em assets/data/media_texts.json.

const TEXTS := "res://assets/data/media_texts.json"
const TONES := ["humilde", "confiante", "provocar", "desviar"]
const FEED_MAX := 60

static var _cfg: Dictionary = {}
## Sorteio próprio da mídia: posts e perguntas não mexem na sequência do Game.rng
## (os resultados das partidas continuam os mesmos com ou sem coletiva).
static var R := RandomNumberGenerator.new()


static func cfg() -> Dictionary:
	if _cfg.is_empty() and FileAccess.file_exists(TEXTS):
		var d = JSON.parse_string(FileAccess.get_file_as_string(TEXTS))
		if typeof(d) == TYPE_DICTIONARY:
			_cfg = d
	return _cfg


static func _pick(arr: Array):
	if arr.is_empty():
		return ""
	return arr[R.randi_range(0, arr.size() - 1)]


## Estado da mídia da carreira atual (criado na primeira vez).
static func st() -> Dictionary:
	if Game.S.is_empty():
		return {}
	if not Game.S.has("media") or typeof(Game.S["media"]) != TYPE_DICTIONARY:
		Game.S["media"] = {"v": 1, "diretoria": 60.0, "moral": 60.0, "imprensa": 50.0, "seguidores": 1200 + int(float(Game.my_club()["str"]) * 40.0),
			"aprovacao": 55.0, "feed": [], "next": 1, "trending": [], "streak": 0, "pending": {}, "log": [], "news_seen": 0,
			"interviews": 0, "skipped": 0}
	return Game.S["media"]


static func is_pro() -> bool:
	return Pro.is_pro() and str(Pro.P().get("stage", "")) == "carreira"


# ------------------------------------------------------------ medidores
static func meter(key: String) -> float:
	var s := st()
	if key == "torcida":
		return float(Pro.P()["fans"]) if is_pro() else float(Game.S.get("support", 50))
	if key == "diretoria" and is_pro():
		return float(Pro.P().get("coach", 50.0))
	return float(s.get(key, 50.0))


static func _add_meter(key: String, d: float) -> void:
	if d == 0.0:
		return
	var s := st()
	match key:
		"torcida":
			if is_pro():
				Pro.P()["fans"] = clampf(float(Pro.P()["fans"]) + d, 0.0, 100.0)
			else:
				Game.S["support"] = clampi(int(Game.S["support"]) + int(round(d)), 0, 100)
		"diretoria":
			if is_pro():
				Pro.P()["coach"] = clampf(float(Pro.P().get("coach", 50.0)) + d, 0.0, 100.0)
			else:
				s["diretoria"] = clampf(float(s["diretoria"]) + d, 0.0, 100.0)
		"moral":
			s["moral"] = clampf(float(s["moral"]) + d, 0.0, 100.0)
			# moral mexe na energia do elenco (e a energia entra na força do time)
			if not is_pro():
				for p in Game.squad(Game.S["club"]):
					p["energy"] = clampf(float(p["energy"]) + d * 0.6, 20.0, 100.0)
		_:
			s[key] = clampf(float(s.get(key, 50.0)) + d, 0.0, 100.0)


## Aprovação geral (o termômetro que aparece no perfil): resultados, torcida, diretoria e imprensa.
static func approval() -> float:
	var s := st()
	return clampf(meter("torcida") * 0.4 + meter("diretoria") * 0.3 + float(s["imprensa"]) * 0.15 + float(s["moral"]) * 0.15, 0.0, 100.0)


# ------------------------------------------------------------ contexto do jogo
## Visão do último jogo do usuário: {mine, opp, gf, ga, won, lost, draw, margin, cards, red, kind, cup, stage}
static func last_view() -> Dictionary:
	var lu: Dictionary = Game.S.get("last_user", {})
	if lu.is_empty():
		return {}
	var me: int = Game.S["club"]
	var home: bool = int(lu["h"]) == me
	var gf: int = int(lu["hg"]) if home else int(lu["ag"])
	var ga: int = int(lu["ag"]) if home else int(lu["hg"])
	var pens: Array = lu.get("pens", [])
	var won := gf > ga
	var lost := gf < ga
	if gf == ga and pens.size() == 2:
		var pf: int = int(pens[0]) if home else int(pens[1])
		var pa: int = int(pens[1]) if home else int(pens[0])
		won = pf > pa
		lost = pf < pa
	var side := 0 if home else 1
	var cards := 0
	var red := 0
	var st_arr: Array = lu.get("st", [])
	if st_arr.size() >= 6:
		cards = int(st_arr[4][side]) + int(st_arr[5][side]) + int(st_arr[4][1 - side]) + int(st_arr[5][1 - side])
		red = int(st_arr[5][0]) + int(st_arr[5][1])
	var top := ""
	var top_g := 0
	var count := {}
	for s in lu.get("sc", []):
		if int(s["side"]) == side:
			var nm: String = str(s["name"])
			count[nm] = int(count.get(nm, 0)) + 1
			if count[nm] > top_g:
				top_g = count[nm]
				top = nm
	return {"mine": me, "opp": int(lu["a"]) if home else int(lu["h"]), "gf": gf, "ga": ga, "won": won, "lost": lost,
		"draw": not won and not lost, "margin": gf - ga, "cards": cards, "red": red, "kind": str(lu.get("kind", "league")),
		"comp": str(lu.get("comp", "")), "stage": str(lu.get("label", "")), "top": top, "top_g": top_g,
		"placar": "%d x %d" % [gf, ga], "day": int(lu.get("day", Game.S["day"]))}


static func _fill(t: String, v: Dictionary, extra: Dictionary = {}) -> String:
	var who := str(Pro.me()["name"]) if is_pro() else str(Game.S["coach"]["name"])
	var out := t.replace("{t}", who).replace("{c}", Game.club_name(Game.S["club"]))
	if not v.is_empty():
		out = out.replace("{r}", Game.club_name(int(v["opp"]))).replace("{placar}", str(v["placar"]))
		out = out.replace("{fase}", str(v["stage"])).replace("{copa}", str(v["comp"])).replace("{cartoes}", str(v["cards"]))
		out = out.replace("{p}", str(v["top"]) if str(v["top"]) != "" else Game.club_name(Game.S["club"]))
		out = out.replace("{pos}", str(Game.position_of(Game.S["club"])))
	for k in extra:
		out = out.replace("{" + str(k) + "}", str(extra[k]))
	return out


## Monta as perguntas da coletiva para o último jogo (2 ou 3).
static func build_interview() -> Array:
	var v := last_view()
	if v.is_empty():
		return []
	var P: Dictionary = cfg().get("perguntas", {})
	var cats: Array = []
	if is_pro():
		var last: Dictionary = Pro.P().get("last", {})
		var r: float = float(last.get("rating", -1.0))
		if int(last.get("min", 0)) < 30:
			cats.append("pro_banco")
		elif r >= 7.3:
			cats.append("pro_nota_boa")
		elif r >= 0.0 and r < 6.0:
			cats.append("pro_nota_ruim")
		else:
			cats.append("pro_regular")
		if int(last.get("gol", 0)) > 0:
			cats.append("pro_gol")
	# resultado
	if v["won"]:
		cats.append("goleada" if v["margin"] >= 3 else "vitoria")
	elif v["lost"]:
		cats.append("derrota_pesada" if v["margin"] <= -3 else "derrota")
	else:
		cats.append("empate")
	if not is_pro() and str(v["top"]) != "" and (v["top_g"] >= 2 or v["won"]):
		cats.append("destaque")
	if v["cards"] >= 5 or v["red"] > 0:
		cats.append("arbitragem")
	if v["kind"] == "cup":
		cats.append("copa")
	elif not is_pro():
		var pos := Game.position_of(Game.S["club"])
		var opp_pos := Game.position_of(int(v["opp"])) if int(v["opp"]) < Game.n_league() else 99
		var n := Game.n_league()
		if absi(pos - opp_pos) <= 2:
			cats.append("confronto_direto")
		if pos <= 3 and int(Game.my_club().get("j", 0)) >= 5:
			cats.append("topo")
		elif pos > n - 4 and int(Game.my_club().get("j", 0)) >= 5:
			cats.append("rebaixamento")
	var out: Array = []
	var seen := {}
	for c in cats:
		if seen.has(c) or not P.has(c):
			continue
		seen[c] = true
		var q: Dictionary = _pick(P[c])
		var answers := {}
		for tone in TONES:
			answers[tone] = _fill(str(q["respostas"].get(tone, "...")), v)
		out.append({"cat": c, "q": _fill(str(q["texto"]), v), "a": answers})
		if out.size() >= 3:
			break
	return out


## Efeitos de um tom de resposta no contexto do último jogo.
static func effects(tone: String, v: Dictionary) -> Dictionary:
	var C := cfg()
	var e: Dictionary = C.get("tons", {}).get(tone, {}).get("efeitos", {}).duplicate()
	if v.get("lost", false):
		var adj: Dictionary = C.get("derrota_ajuste", {}).get(tone, {})
		for k in adj:
			e[k] = float(e.get(k, 0.0)) + float(adj[k])
	if tone == "provocar" and v.get("won", false):
		e["torcida"] = float(e.get("torcida", 0.0)) + 2.0   # provocar depois de vencer empolga
	return e


# ------------------------------------------------------------ coletiva
static func pending() -> Dictionary:
	return st().get("pending", {}) if not Game.S.is_empty() else {}


static func has_interview() -> bool:
	var p := pending()
	return not p.is_empty() and int(p.get("i", 0)) < p.get("qs", []).size()


## Responde a pergunta atual. Devolve {"efeitos": {...}, "texto": resumo}.
static func answer(tone: String) -> Dictionary:
	if not has_interview() or not (tone in TONES):
		return {}
	var s := st()
	var p: Dictionary = s["pending"]
	var q: Dictionary = p["qs"][int(p["i"])]
	var v := last_view()
	var e := effects(tone, v)
	var applied := {}
	for k in ["diretoria", "torcida", "moral", "imprensa"]:
		var d := float(e.get(k, 0.0))
		if is_pro() and k == "moral":
			continue   # no modo jogador a moral do elenco não é sua
		_add_meter(k, d)
		if d != 0.0:
			applied[k] = d
	var gain := int(float(e.get("seguidores", 1.0)) * (40.0 + float(s["seguidores"]) * 0.004) * (1.6 if v.get("won", false) else 1.0))
	_add_followers(gain)
	applied["seguidores"] = gain
	s["log"].push_front({"day": Game.S["day"], "cat": q["cat"], "tone": tone, "q": q["q"], "a": q["a"][tone]})
	while s["log"].size() > 20:
		s["log"].pop_back()
	p["i"] = int(p["i"]) + 1
	p["tones"].append(tone)
	# a resposta repercute nas redes
	var RX: Dictionary = cfg().get("social", {}).get("reacao", {})
	var nreact := 2 if tone == "provocar" else 1
	for k2 in nreact:
		var kind := "fa"
		if tone == "provocar":
			kind = "rival" if k2 == 1 else ("fa" if R.randf() < 0.6 else "hater")
		elif tone == "desviar":
			kind = "hater"
		_post(kind, _fill(str(_pick(RX.get(tone, ["..."]))), v))
	if tone == "provocar":
		_add_tag(_fill(str(cfg().get("social", {}).get("tags_coletiva", {}).get("provocar", "Coletiva")), v))
	if p["i"] >= p["qs"].size():
		_close_interview()
	return {"efeitos": applied, "texto": _summary(applied)}


static func skip_interview() -> void:
	if not has_interview():
		return
	var s := st()
	s["skipped"] = int(s["skipped"]) + 1
	_add_meter("imprensa", -2.0)
	_post("jornalista", _fill(str(_pick(cfg().get("social", {}).get("reacao", {}).get("pulou", ["..."]))), last_view()))
	s["pending"] = {}
	Game.save()


static func _close_interview() -> void:
	var s := st()
	var tones: Array = s["pending"].get("tones", [])
	s["interviews"] = int(s["interviews"]) + 1
	# a manchete da coletiva segue o tom que mais apareceu
	var best := ""
	var bc := 0
	for t in TONES:
		var c := tones.count(t)
		if c > bc:
			bc = c
			best = t
	if best != "":
		var heads := {"humilde": "{t} assume responsabilidade e elogia o grupo", "confiante": "{t} confiante: 'esse time sabe o que quer'",
			"provocar": "{t} provoca o {r} e esquenta a semana", "desviar": "{t} evita polêmica na coletiva"}
		_post("jornalista", _fill(heads[best], last_view()))
	s["pending"] = {}
	Game.save()


static func _summary(applied: Dictionary) -> String:
	var names := {"diretoria": "Diretoria" if not is_pro() else "Técnico", "torcida": "Torcida", "moral": "Elenco", "imprensa": "Imprensa"}
	var parts: Array = []
	for k in ["diretoria", "torcida", "moral", "imprensa"]:
		if applied.has(k):
			parts.append("%s %s%d" % [names[k], "+" if applied[k] > 0 else "", int(applied[k])])
	parts.append("+%d seguidores" % int(applied.get("seguidores", 0)))
	return "  •  ".join(parts)


# ------------------------------------------------------------ redes sociais
static func feed() -> Array:
	if is_pro():
		return Pro.P().get("feed", [])
	return st().get("feed", [])


static func _handle(kind: String, v: Dictionary) -> String:
	var S: Dictionary = cfg().get("social", {})
	var pool: Array = S.get({"fa": "torcedores", "hater": "haters", "jornalista": "jornalistas", "rival": "rivais"}.get(kind, "torcedores"), ["torcedor"])
	var u := str(_pick(pool))
	var cs := str(Game.my_club()["short"]).to_lower()
	var rs := cs
	if not v.is_empty():
		rs = str(Game.club(int(v["opp"]))["short"]).to_lower() if int(v["opp"]) >= 0 and int(v["opp"]) < Game.S["clubs"].size() else "rival"
	u = u.replace("{c}", cs).replace("{r}", rs)
	if kind != "jornalista" and R.randf() < 0.35:
		u += str(R.randi_range(2, 99))
	return "@" + u


## Publica no feed. kind: fa, hater, jornalista, rival.
static func _post(kind: String, text: String) -> void:
	# o mesmo texto não se repete na mesma leva de comentários
	for recent in feed().slice(0, 6):
		if str(recent.get("text", "")) == text:
			return
	if is_pro():
		# modo jogador: usa o feed que já existe (Pro), com o tipo de post dele
		var pk: String = {"fa": "elogio", "hater": "xingamento", "jornalista": "manchete", "rival": "zoeira"}.get(kind, "neutro")
		Pro._new_post(_handle(kind, last_view()), text, pk, Pro._likes(1.2 if kind == "hater" else 1.0))
		return
	var s := st()
	var likes := int((15.0 + float(s["seguidores"]) * R.randf_range(0.004, 0.03)) * (1.5 if kind in ["hater", "rival"] else 1.0))
	s["feed"].push_front({"id": int(s["next"]), "user": _handle(kind, last_view()), "kind": kind, "text": text, "likes": likes, "day": Game.S["day"]})
	s["next"] = int(s["next"]) + 1
	while s["feed"].size() > FEED_MAX:
		s["feed"].pop_back()


static func _add_followers(n: int) -> void:
	if is_pro():
		Pro.P()["followers"] = maxi(int(Pro.P()["followers"]) + n, 0)
	else:
		st()["seguidores"] = maxi(int(st()["seguidores"]) + n, 0)


static func followers() -> int:
	return int(Pro.P()["followers"]) if is_pro() else int(st()["seguidores"])


static func _add_tag(tag: String) -> void:
	var s := st()
	tag = tag.replace(" ", "").replace(".", "").replace("-", "")
	s["trending"].erase(tag)
	s["trending"].push_front(tag)
	while s["trending"].size() > 5:
		s["trending"].pop_back()


## Depois de cada jogo do usuário (chamado por Game.play_next): sequência, seguidores,
## posts de torcedores/haters/imprensa/rivais, assuntos do momento e a coletiva pendente.
static func after_match() -> void:
	if Game.S.is_empty():
		return
	if Pro.is_pro() and not is_pro():
		return   # peneira: o modo jogador cuida sozinho
	var v := last_view()
	if v.is_empty():
		return
	var s := st()
	var S: Dictionary = cfg().get("social", {})
	# sequência: positiva = vitórias seguidas, negativa = jogos sem vencer
	var stk: int = int(s["streak"])
	if v["won"]:
		stk = maxi(stk, 0) + 1
	else:
		stk = mini(stk, 0) - 1
	s["streak"] = stk
	var bad := maxi(-stk, 0)
	# seguidores crescem com vitória e com polêmica
	_add_followers(int((30.0 + float(followers()) * 0.006) * (2.0 if v["won"] else (0.6 if v["draw"] else 0.3))))
	# diretoria acompanha os resultados (técnico); a moral do elenco também
	if not is_pro():
		_add_meter("diretoria", 2.0 if v["won"] else (-0.5 if v["draw"] else -3.0 - (2.0 if v["margin"] <= -3 else 0.0)))
		s["moral"] = clampf(float(s["moral"]) + (3.0 if v["won"] else (0.0 if v["draw"] else -3.0)), 0.0, 100.0)
		if float(s["diretoria"]) < 20.0 and R.randf() < 0.5:
			Game.add_news("Diretoria impaciente", "A confiança no trabalho de %s está baixa. Os próximos jogos serão decisivos." % Game.S["coach"]["name"])
		# imprensa: manchete do jogo (técnico; o modo jogador já tem as dele)
		var jk := "jornalista_vitoria" if v["won"] else ("jornalista_empate" if v["draw"] else "jornalista_derrota")
		_post("jornalista", _fill(str(_pick(S.get(jk, ["..."]))), v))
		# torcedores e haters: quanto pior a sequência, mais haters
		var n_posts := 3 + mini(bad, 3)
		var hater_share := 0.15 if v["won"] else (0.4 if v["draw"] else 0.55)
		hater_share = clampf(hater_share + 0.08 * bad - (float(s["imprensa"]) - 50.0) * 0.002, 0.05, 0.9)
		for k in n_posts:
			if R.randf() < hater_share:
				var pool: Array = S.get("hater_sequencia", []) if bad >= 3 and R.randf() < 0.5 else \
					S.get("hater_geral" if v["won"] else "hater_derrota", ["..."])
				var tag := _fill(str(_pick(S.get("tags_ruins", ["Crise"]))), v)
				_post("hater", _fill(str(_pick(pool)), v, {"n": bad, "tag": tag}))
			else:
				_post("fa", _fill(str(_pick(S.get("fa_vitoria" if v["won"] else ("fa_empate" if v["draw"] else "fa_derrota"), ["..."]))), v))
		if stk >= 3:
			_post("fa", _fill(str(_pick(S.get("sequencia_vitorias", ["..."]))), v, {"n": stk}))
	# rivais zoam quando você perde e reclamam quando você ganha
	if v["lost"] or (v["won"] and R.randf() < 0.5):
		_post("rival", _fill(str(_pick(S.get("rival_zoeira" if v["lost"] else "rival_choro", ["..."]))), v))
	# assuntos do momento
	if stk >= 2:
		_add_tag(_fill(str(_pick(S.get("tags_boas", ["Embalado"]))), v))
	elif bad >= 3:
		_add_tag(_fill(str(_pick(S.get("tags_ruins", ["Crise"]))), v))
	_react_transfers(v)
	s["aprovacao"] = approval()
	s["pending"] = {"qs": build_interview(), "i": 0, "tones": [], "day": v["day"]}
	Game.save()


## Reação a contratações e vendas que entraram nas notícias desde o último jogo.
static func _react_transfers(_v: Dictionary) -> void:
	if is_pro():
		return
	var s := st()
	var S: Dictionary = cfg().get("social", {})
	var seen: int = int(s.get("news_seen", 0))
	var newest := seen
	var made := 0
	var cn := Game.club_name(Game.S["club"])
	for n in Game.S.get("news", []):
		var day: int = int(n.get("day", 0))
		if day <= seen:
			break   # as notícias ficam da mais nova para a mais velha
		newest = maxi(newest, day)
		if made >= 2:
			continue
		var t: String = str(n.get("t", ""))
		var x: String = str(n.get("x", ""))
		if t == "Reforço confirmado":
			_post("fa", str(_pick(S.get("contratacao", ["..."]))).replace("{p}", x.split(" (")[0]).replace("{c}", cn))
			made += 1
		elif t == "Venda concluída":
			_post("hater" if R.randf() < 0.5 else "fa", str(_pick(S.get("venda", ["..."]))).replace("{p}", x.split(" foi vendido")[0]).replace("{c}", cn))
			made += 1
	s["news_seen"] = newest
