extends RefCounted
# Coletiva de imprensa pós-jogo e redes sociais do técnico (dados em src/media.gd).

var m
var filter: String = ""        ## filtro do feed: "", "fa", "hater", "jornalista", "rival"
var last_effect: String = ""   ## resumo da última resposta (aparece em cima da próxima pergunta)

const KIND_COLOR := {"fa": Color("8fe0a8"), "hater": Color("ff8b8b"), "jornalista": Color("8fc0ff"), "rival": Color("f0a05e"),
	"elogio": Color("8fe0a8"), "xingamento": Color("ff8b8b"), "manchete": Color("8fc0ff"), "zoeira": Color("f0a05e"), "meu": Color("e6c56a")}
const KIND_NAME := {"fa": "TORCEDOR", "hater": "CORNETA", "jornalista": "IMPRENSA", "rival": "RIVAL",
	"elogio": "TORCEDOR", "xingamento": "CORNETA", "manchete": "IMPRENSA", "zoeira": "RIVAL", "meu": "VOCÊ", "neutro": "TORCEDOR"}
const TONE_COLOR := {"humilde": Color("237a47"), "confiante": Color("2463b8"), "provocar": Color("ad3450"), "desviar": Color("33463d")}


func _init(main) -> void:
	m = main


# ============================================================ coletiva
func interview(root: Control, _arg) -> void:
	var v := Media.last_view()
	m.head("Coletiva de imprensa", "%s • %s" % [v.get("comp", ""), v.get("stage", "")] if not v.is_empty() else "", false)
	var col := UI.vbox(UI.SP_M)
	UI.vexpand(col)
	root.add_child(col)
	col.add_child(_hero(v))
	if not Media.has_interview():
		_interview_done(col)
		return
	var p: Dictionary = Media.pending()
	var i: int = int(p["i"])
	var q: Dictionary = p["qs"][i]
	# fala do repórter (balão)
	var bubble := UI.panel(Color("f4f6fa"), 16, 18)
	var bh0 := UI.hbox(UI.SP_M)
	bubble.add_child(bh0)
	var rep := UI.vbox(2)
	rep.add_child(ChibiPortrait.make(ChibiPortrait.for_handle("@reporter_tv1", "serious", Color("2a4d8f")), 48.0, "head"))
	rep.add_child(UI.chip("REPÓRTER", UI.RED, UI.TXT, 10))
	bh0.add_child(rep)
	bh0.add_child(UI.wrap(UI.label("“%s”" % q["q"], UI.FS_H2, UI.DARKTXT, true)))
	bh0.add_child(UI.label("%d/%d" % [i + 1, p["qs"].size()], UI.FS_SMALL, Color(UI.DARKTXT, 0.6), true))
	col.add_child(UI.appear(bubble))
	var grid := UI.grid(2, UI.SP_M)
	UI.expand(grid)
	UI.vexpand(grid)
	col.add_child(grid)
	var tons: Dictionary = Media.cfg().get("tons", {})
	var k := 0
	for tone in Media.TONES:
		var hv := UI.hbox(UI.SP_M)
		hv.add_child(UI.chip(str(tons.get(tone, {}).get("rotulo", tone)).to_upper(), TONE_COLOR[tone], UI.TXT, UI.FS_CAPTION))
		hv.add_child(UI.wrap(UI.label(str(q["a"][tone]), UI.FS_BODY, UI.TXT)))
		var b := UI.row_button(hv, _answer.bind(tone), 64, "dark", 14)
		UI.expand(b)
		UI.vexpand(b)
		grid.add_child(UI.appear(b, 0.06 * k))
		k += 1
	var bh := UI.hbox(UI.SP_S)
	bh.add_child(UI.wrap(UI.label("O tom da resposta mexe com diretoria, torcida, elenco e imprensa, e repercute nas redes.", UI.FS_CAPTION, UI.MUTED)))
	if last_effect != "":
		bh.add_child(UI.chip(last_effect, UI.SURFACE, UI.GOLD, UI.FS_CAPTION))
	bh.add_child(UI.fixed(UI.button("Pular coletiva", "flat", _skip, UI.FS_SMALL), 190))
	col.add_child(bh)


## Faixa de cima: a sala de imprensa com placar e medidores por cima.
func _hero(v: Dictionary) -> Control:
	var box := Control.new()
	box.custom_minimum_size = Vector2(0, clampf(m.get_viewport_rect().size.y * 0.32, 230.0, 360.0))
	var pr := PressRoom.new()
	pr.club_short = str(Game.my_club()["short"])
	if Media.is_pro():
		var lk := ChibiPortrait.for_player(Pro.me(), ChibiPortrait.club_kit(Game.S["club"]))
		var cp := ChibiPortrait.make(lk, 100.0, "bust")
		cp.custom_minimum_size = Vector2.ZERO
		pr.person = cp
		pr.plate = str(Pro.me()["name"])
	else:
		var av := CoachAvatar.new()
		av.coach = Game.S["coach"]
		av.mouse_filter = Control.MOUSE_FILTER_IGNORE
		pr.person = av
		pr.plate = str(Game.S["coach"]["name"])
	box.add_child(pr)
	pr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	# placar (esquerda)
	if not v.is_empty():
		var sp2 := UI.panel(Color(0, 0, 0, 0.55), 10, 14)
		var sv := UI.vbox(2)
		sp2.add_child(sv)
		var sh := UI.hbox(UI.SP_S)
		sh.add_child(Crest.make(int(v["mine"]), 34))
		sh.add_child(UI.label("%d × %d" % [v["gf"], v["ga"]], UI.FS_H1, UI.TXT, true))
		sh.add_child(Crest.make(int(v["opp"]), 34))
		sv.add_child(sh)
		var res := "VITÓRIA" if v["won"] else ("DERROTA" if v["lost"] else "EMPATE")
		sv.add_child(UI.center(UI.label(res, UI.FS_CAPTION, UI.GREEN_TXT if v["won"] else (UI.RED_TXT if v["lost"] else UI.GOLD), true)))
		box.add_child(sp2)
		sp2.position = Vector2(12, 12)
	# medidores (direita)
	var mp := UI.panel(Color(0, 0, 0, 0.55), 12, 14)
	mp.custom_minimum_size = Vector2(230, 0)
	var mv := UI.vbox(6)
	mp.add_child(mv)
	mv.add_child(UI.meter("Técnico confia" if Media.is_pro() else "Diretoria", Media.meter("diretoria")))
	mv.add_child(UI.meter("Torcida", Media.meter("torcida")))
	if not Media.is_pro():
		mv.add_child(UI.meter("Moral do elenco", Media.meter("moral")))
	mv.add_child(UI.meter("Imprensa", Media.meter("imprensa")))
	box.add_child(mp)
	mp.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	mp.position = Vector2(-242, 12)
	mp.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	return box


func _interview_done(right: Control) -> void:
	right.add_child(UI.section("COLETIVA ENCERRADA  •  %s seguidores" % _fmt_n(Media.followers())))
	var lp := UI.panel(UI.PANEL, 16)
	UI.vexpand(lp)
	var lv := UI.vbox(UI.SP_S)
	lp.add_child(lv)
	var log: Array = Media.st().get("log", [])
	var shown := 0
	for e in log:
		if shown >= 3:
			break
		var h := UI.hbox(UI.SP_S)
		h.add_child(UI.chip(str(Media.cfg().get("tons", {}).get(e["tone"], {}).get("rotulo", e["tone"])), TONE_COLOR.get(e["tone"], UI.PANEL2), UI.TXT, UI.FS_CAPTION))
		h.add_child(UI.wrap(UI.label(str(e["a"]), UI.FS_SMALL, UI.TXT)))
		lv.add_child(h)
		shown += 1
	if shown == 0:
		lv.add_child(UI.label("Nenhuma pergunta pendente.", UI.FS_BODY, UI.MUTED))
	if last_effect != "":
		lv.add_child(UI.label("Última resposta: " + last_effect, UI.FS_SMALL, UI.GOLD, true))
	right.add_child(lp)
	var bh := UI.hbox(UI.SP_M)
	bh.add_child(UI.expand(UI.button("Ver redes sociais", "dark", _open_social)))
	bh.add_child(UI.expand(UI.button("Continuar  ›", "gold", func():
		last_effect = ""
		m.back(), 19)))
	right.add_child(bh)


func _answer(tone: String) -> void:
	var r := Media.answer(tone)
	last_effect = str(r.get("texto", ""))
	m.refresh()


func _skip() -> void:
	Media.skip_interview()
	last_effect = ""
	m.back()


func _open_social() -> void:
	last_effect = ""
	if Media.is_pro():
		m.home()
	else:
		m.replace("social")


# ============================================================ redes sociais (técnico)
func social(root: Control, _arg) -> void:
	m.head("Redes sociais", "O que torcida, cornetas, imprensa e rivais estão falando", true)
	var row := UI.hbox(UI.SP_L)
	UI.vexpand(row)
	root.add_child(row)
	social_body(row)


## Conteúdo da rede (usado na tela própria e na aba MÍDIA do hub): perfil, feed e assuntos em alta.
func social_body(row: Control) -> void:
	var s := Media.st()
	# --- perfil
	var lp := UI.panel(UI.PANEL, 16)
	lp.custom_minimum_size = Vector2(270, 0)
	var lv := UI.vbox(UI.SP_S)
	lp.add_child(lv)
	var who := str(Game.S["coach"]["name"]) if not Media.is_pro() else str(Pro.me()["name"])
	var ph := UI.hbox(UI.SP_S)
	var mylook := ChibiPortrait.for_player(Pro.me(), ChibiPortrait.club_kit(Game.S["club"])) if Media.is_pro() else ChibiPortrait.for_coach(Game.S["coach"])
	ph.add_child(_ring(ChibiPortrait.make(mylook, 56.0, "head")))
	var nv := UI.vbox(0)
	var nh := UI.hbox(4)
	nh.add_child(UI.label(who, UI.FS_BODY, UI.TXT, true))
	nh.add_child(_verified())
	nv.add_child(nh)
	nv.add_child(UI.label("@" + who.to_lower().replace(" ", "_"), UI.FS_SMALL, UI.MUTED))
	ph.add_child(nv)
	lv.add_child(ph)
	lv.add_child(UI.label("%s seguidores" % _fmt_n(Media.followers()), UI.FS_BODY, UI.TXT, true))
	var ap := Media.approval()
	var ah := UI.hbox(UI.SP_S)
	ah.add_child(UI.label("%d%%" % int(round(ap)), UI.FS_DISPLAY, UI.GREEN_TXT if ap >= 60.0 else (UI.GOLD if ap >= 40.0 else UI.RED_TXT), true))
	var al := UI.vbox(0)
	al.add_child(UI.label("aprovação", UI.FS_SMALL, UI.MUTED, true))
	var stk: int = int(s.get("streak", 0))
	if stk >= 2:
		al.add_child(UI.label("%d vitórias seguidas" % stk, UI.FS_CAPTION, UI.GREEN_TXT, true))
	elif stk <= -2:
		al.add_child(UI.label("%d jogos sem vencer" % -stk, UI.FS_CAPTION, UI.RED_TXT, true))
	ah.add_child(al)
	lv.add_child(ah)
	lv.add_child(UI.meter("Técnico confia" if Media.is_pro() else "Diretoria", Media.meter("diretoria")))
	lv.add_child(UI.meter("Torcida", Media.meter("torcida")))
	if not Media.is_pro():
		lv.add_child(UI.meter("Moral do elenco", Media.meter("moral")))
	lv.add_child(UI.meter("Imprensa", Media.meter("imprensa")))
	lv.add_child(UI.spacer())
	if Media.has_interview():
		lv.add_child(UI.button("Coletiva pendente  ›", "gold", func(): m.go("interview"), UI.FS_SMALL))
	row.add_child(lp)

	# --- feed
	var fp := UI.panel(UI.SURFACE, 0, 18)
	UI.expand(fp, 1.6)
	var rv := UI.vbox(0)
	fp.add_child(rv)
	var tabs := UI.hbox(0)
	for f in [["", "Para você"], ["fa", "Torcida"], ["hater", "Cornetas"], ["jornalista", "Imprensa"], ["rival", "Rivais"]]:
		var on: bool = filter == f[0]
		var tb := UI.button(f[1], "flat", func():
			filter = f[0]
			m.refresh(), UI.FS_SMALL)
		tb.add_theme_color_override("font_color", UI.TXT if on else UI.MUTED)
		var tv := UI.vbox(0)
		UI.expand(tv)
		tv.add_child(tb)
		var ul := ColorRect.new()
		ul.color = UI.GOLD if on else Color(1, 1, 1, 0.06)
		ul.custom_minimum_size = Vector2(0, 3 if on else 1)
		ul.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tv.add_child(ul)
		tabs.add_child(tv)
	rv.add_child(tabs)
	var sc := UI.scroll()
	UI.vexpand(sc)
	var mc := MarginContainer.new()
	UI.expand(mc)
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		mc.add_theme_constant_override(side, 10)
	var fv := UI.vbox(UI.SP_S)
	UI.expand(fv)
	mc.add_child(fv)
	sc.add_child(mc)
	rv.add_child(sc)
	var n := 0
	for post in Media.feed():
		if filter != "" and _kind_group(str(post.get("kind", ""))) != filter:
			continue
		fv.add_child(post_row(post))
		n += 1
		if n >= 30:
			break   # lista curta: menos nós na tela do celular
	if n == 0:
		fv.add_child(UI.label("Nada por aqui ainda. Jogue uma partida!", UI.FS_BODY, UI.MUTED))
	row.add_child(fp)

	# --- em alta
	var tp := UI.panel(UI.PANEL, 14)
	tp.custom_minimum_size = Vector2(220, 0)
	var tv2 := UI.vbox(UI.SP_S)
	tp.add_child(tv2)
	tv2.add_child(UI.label("Em alta", UI.FS_H2, UI.TXT, true))
	var tags: Array = trending_view()
	for i in mini(tags.size(), 5):
		var tg := str(tags[i])
		var tvv := UI.vbox(0)
		tvv.add_child(UI.label("%d • Futebol • Em alta" % (i + 1), UI.FS_CAPTION, UI.MUTED))
		var tl := UI.label("#" + tg, UI.FS_BODY, UI.GOLD, true)
		tl.clip_text = true
		tl.custom_minimum_size = Vector2(180, 0)
		tvv.add_child(tl)
		tvv.add_child(UI.label("%s posts" % _fmt_n(int(Media.followers() * (0.4 - i * 0.06)) + 120), UI.FS_CAPTION, UI.MUTED))
		tv2.add_child(tvv)
	row.add_child(tp)


## Assuntos em alta: os da carreira e, para completar a lista, os do campeonato e do clube.
static func trending_view() -> Array:
	var out: Array = Media.st().get("trending", []).duplicate()
	for extra in [Game.LEAGUE.replace(" ", "").replace("é", "e").replace("ã", "a"), "Rodada%d" % (int(Game.S.get("round", 0)) + 1),
			str(Game.my_club()["name"]).replace(" ", "").replace("-", "")]:
		if out.size() >= 5:
			break
		if not (extra in out):
			out.append(extra)
	return out


## Cabecinha no estilo da marca para quem posta: torcedor sorri, corneta fica bravo,
## rival grita e a imprensa fica séria (camisa azul de credenciado).
static func handle_avatar(user: String, kind: String, px: float) -> Control:
	var expr: String = {"fa": "smile", "hater": "angry", "rival": "shouting", "jornalista": "serious"}.get(_kind_group(kind), "smile")
	var shirt: Color = {"jornalista": Color("2a4d8f"), "rival": Color("8f2a2a"), "hater": Color("3a3a3a")}.get(_kind_group(kind), UI.NEON_DARK)
	var c := ChibiPortrait.make(ChibiPortrait.for_handle(user, expr, shirt), px, "head")
	c.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	return c


## Moldura redonda com anel verde neon (avatar do perfil).
func _ring(c: Control) -> Control:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UI.sbox(UI.PANEL2, 40, 4, UI.NEON, 2))
	p.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	p.add_child(c)
	return p


static func _kind_group(kind: String) -> String:
	return {"elogio": "fa", "neutro": "fa", "meu": "fa", "xingamento": "hater", "manchete": "jornalista", "zoeira": "rival"}.get(kind, kind)


func _verified() -> Control:
	var b := PanelContainer.new()
	b.add_theme_stylebox_override("panel", UI.sbox(Color("2f8fe0"), 8, 0))
	b.custom_minimum_size = Vector2(16, 16)
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	b.add_child(UI.center(UI.label("✓", 11, Color.WHITE, true)))
	return b


## Um post como nos apps: avatar, nome, selo (imprensa), tipo, há quanto tempo, texto e interações.
func post_row(post: Dictionary) -> Control:
	var kind := _kind_group(str(post.get("kind", "fa")))
	var col: Color = KIND_COLOR.get(kind, UI.TXT)
	var p := UI.panel(UI.PANEL, 12, 14)
	var h := UI.hbox(UI.SP_M)
	p.add_child(h)
	var user := str(post.get("user", "@?"))
	h.add_child(handle_avatar(user, kind, 44.0))
	var v := UI.vbox(3)
	UI.expand(v)
	var top := UI.hbox(6)
	top.add_child(UI.label(user.substr(1), UI.FS_SMALL, UI.TXT, true))
	if kind == "jornalista":
		top.add_child(_verified())
	top.add_child(UI.label("· " + _ago(int(post.get("day", Game.S["day"]))), UI.FS_CAPTION, UI.MUTED))
	top.add_child(UI.spacer())
	top.add_child(UI.chip(KIND_NAME.get(kind, "TORCEDOR"), Color(col, 0.16), col, 10))
	v.add_child(top)
	v.add_child(UI.wrap(UI.label(str(post.get("text", "")), UI.FS_BODY, UI.TXT)))
	var likes := int(post.get("likes", 0))
	var acts := UI.hbox(UI.SP_XL)
	acts.add_child(UI.label("♥ %s" % _fmt_n(likes), UI.FS_CAPTION, Color("ff7a90") if likes > 500 else UI.MUTED, true))
	acts.add_child(UI.label("%s respostas" % _fmt_n(int(likes / 9.0) + 1), UI.FS_CAPTION, UI.MUTED))
	acts.add_child(UI.label("%s compartilhamentos" % _fmt_n(int(likes / 5.0)), UI.FS_CAPTION, UI.MUTED))
	v.add_child(acts)
	h.add_child(v)
	return p


func _ago(day: int) -> String:
	var d: int = int(Game.S.get("day", day)) - day
	if d <= 0:
		return "hoje"
	if d == 1:
		return "ontem"
	return "há %d dias" % d


func _fmt_n(n: int) -> String:
	if n >= 1000000:
		return "%.1f mi" % (n / 1000000.0)
	if n >= 1000:
		return "%.1f mil" % (n / 1000.0)
	return str(n)
