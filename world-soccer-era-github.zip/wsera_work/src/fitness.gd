class_name Fitness
extends RefCounted
## Sistema de energia (condição física) dos jogadores.
##
## p["energy"] (0..100) = como o jogador chega ao jogo. Durante a partida a energia cai por minuto conforme
## a posição, a idade e a intensidade do time; quem cansa rende menos (força no MatchSim e, nos lances,
## velocidade/precisão via Game.stamina_factor). Depois do jogo sobra parte do desgaste; entre as datas o
## jogador recupera conforme os dias de descanso, a idade e a intensidade do treino (leve/normal/forte).
## Cansado demais, o risco de lesão sobe. Números em assets/data/match_tuning.json, seção "energia".

const POS_DRAIN := {"GOL": 0.35, "ZAG": 0.85, "LD": 1.15, "LE": 1.15, "VOL": 1.1, "MEI": 1.05, "PD": 1.1, "PE": 1.1, "AC": 0.95}
const TRAINING := {"leve": {"rec": 1.3, "grow": 0.0}, "normal": {"rec": 1.0, "grow": 0.015}, "forte": {"rec": 0.72, "grow": 0.05}}
const TRAINING_NAMES := {"leve": "Leve", "normal": "Normal", "forte": "Forte"}

static var _inj_rng := RandomNumberGenerator.new()


static func f(key: String, fallback: float) -> float:
	return Tuning.f("energia", key, fallback)


static func age_drain(age: int) -> float:
	if age <= 21:
		return 0.95
	return 1.0 + maxf(0.0, float(age) - 28.0) * f("cansaco_por_ano_acima_28", 0.035)


static func age_recovery(age: int) -> float:
	return clampf(1.0 + (26.0 - float(age)) * f("recuperacao_por_ano", 0.025), 0.72, 1.18)


## Desgaste por minuto em campo.
static func drain_per_min(p: Dictionary, slot_pos: String = "", press: float = 1.0) -> float:
	var pos: String = slot_pos if slot_pos != "" else str(p.get("pos", "MEI"))
	return f("cansaco_por_minuto", 0.30) * float(POS_DRAIN.get(pos, 1.0)) * age_drain(int(p.get("age", 26))) * press


## Energia agora, durante a partida, depois de jogar `mins` minutos.
static func live(p: Dictionary, mins: int, slot_pos: String = "", press: float = 1.0) -> float:
	return clampf(float(p["energy"]) - float(mins) * drain_per_min(p, slot_pos, press), 0.0, 100.0)


## Rendimento pela energia (1.0 descansado, cai devagar até ~0.84 no fim das forças).
static func factor(energy: float) -> float:
	var e := clampf(energy / 100.0, 0.0, 1.0)
	return 1.0 - f("perda_rendimento_max", 0.16) * pow(1.0 - e, 1.4)


## Desgaste que sobra para os próximos dias depois de jogar `mins` minutos.
static func after_match(p: Dictionary, mins: int, slot_pos: String = "") -> float:
	var used := float(mins) * drain_per_min(p, slot_pos)
	var left := float(p["energy"]) - (f("desgaste_fixo_jogo", 4.0) * float(mins) / 90.0 + used * f("desgaste_que_fica", 0.6))
	return clampf(left, f("energia_minima", 15.0), 100.0)


static func training_mode() -> String:
	var t := str(Game.S.get("training", "normal"))
	return t if TRAINING.has(t) else "normal"


## Recuperação em `days` dias para p (treino só vale para o seu clube).
static func recover(p: Dictionary, days: int, mine: bool) -> float:
	var tr: float = float(TRAINING[training_mode()]["rec"]) if mine else 1.0
	var gain := float(days) * f("recuperacao_por_dia", 4.6) * age_recovery(int(p.get("age", 26))) * tr
	if int(p.get("susp", 0)) > 0 and str(p.get("injury", "")) != "":
		gain *= 0.6   # lesionado se recupera, mas devagar
	return minf(float(p["energy"]) + gain, 100.0)


## Chance de lesão de quem jogou `mins` minutos e terminou com `end_energy`.
static func injury_chance(p: Dictionary, mins: int, end_energy: float) -> float:
	if mins <= 0:
		return 0.0
	var tired := maxf(0.0, f("energia_risco", 55.0) - end_energy) / 12.0
	var age_k := 1.0 + maxf(0.0, float(int(p.get("age", 26))) - 30.0) * 0.06
	var train_k := 1.15 if training_mode() == "forte" and int(p.get("club", -9)) == int(Game.S.get("club", -1)) else 1.0
	return f("lesao_base", 0.006) * float(mins) / 90.0 * pow(1.0 + tired, 2.0) * age_k * train_k


const INJURIES := ["lesão muscular na coxa", "entorse no tornozelo", "contusão no joelho", "estiramento na panturrilha", "dores nas costas", "lesão no adutor"]


## Sorteia lesões depois de um jogo (sorteio próprio: não mexe na sequência da partida). Devolve os lesionados.
static func roll_injuries(sim: MatchSim) -> Array:
	var hurt: Array = []
	_inj_rng.seed = hash([int(Game.S.get("day", 0)), sim.h, sim.a, int(Game.S.get("season", 1))])
	for pid in sim.mins.keys():
		if not Game.S["players"].has(pid):
			continue
		var p: Dictionary = Game.S["players"][pid]
		if p.get("me", false):
			continue   # o seu jogador (modo jogador) tem o sorteio próprio do Pro
		var mn: int = int(sim.mins[pid])
		var end_e := live(p, mn)
		if _inj_rng.randf() < injury_chance(p, mn, end_e):
			var games: int = [1, 1, 2, 2, 3, 4, 6][_inj_rng.randi_range(0, 6)]
			p["susp"] = maxi(int(p.get("susp", 0)), games + 1)
			p["injury"] = INJURIES[_inj_rng.randi_range(0, INJURIES.size() - 1)]
			hurt.append(p)
	return hurt


## Titulares do clube chegando cansados ao próximo jogo.
static func tired_starters(cid: int, limit: float = 65.0) -> Array:
	var out: Array = []
	for pid in Game.S["clubs"][cid]["xi"]:
		if Game.S["players"].has(pid) and float(Game.S["players"][pid]["energy"]) < limit:
			out.append(Game.S["players"][pid])
	return out


## Cor da barra de energia: verde, amarela, vermelha.
static func color(energy: float) -> Color:
	if energy >= 75.0:
		return Color("39e33f")
	if energy >= 55.0:
		return Color("f2c94c")
	return Color("ff5a5a")


static func label(p: Dictionary) -> String:
	if int(p.get("susp", 0)) > 0 and str(p.get("injury", "")) != "":
		return "LESIONADO"
	var e := float(p["energy"])
	if e >= 85.0:
		return "Descansado"
	if e >= 70.0:
		return "Bem"
	if e >= 55.0:
		return "Cansado"
	return "Exausto"


## Coluna de energia: número colorido + barra (verde / amarela / vermelha); lesionado aparece em vermelho.
static func energy_cell(p: Dictionary, show_label: bool = false) -> Control:
	var v := UI.vbox(2)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var e := float(p["energy"])
	var col := Fitness.color(e)
	var hurt: bool = int(p.get("susp", 0)) > 0 and str(p.get("injury", "")) != ""
	var txt := "LESÃO" if hurt else ("%d%%" % int(e) + ("  " + Fitness.label(p) if show_label else ""))
	var l := UI.label(txt, 15, Color("ff5a5a") if hurt else col, true)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(l)
	var b := UI.bar(e / 100.0, col, 5)
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(b)
	return v
