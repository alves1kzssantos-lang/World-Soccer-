class_name BallPhysics
extends RefCounted
## Física da bola usada nos lances e no campo ao vivo.
## Plano do campo: x = largura (0 no meio), y = distância até o gol que está
## sendo atacado (gol em y = 0). z = altura em metros.
## Todos os números vêm de assets/data/match_tuning.json (seção "bola").
##
## Modelo: no ar, gravidade + arrasto quadrático (k·|v|·v) + efeito (aceleração lateral);
## no chão, resistência ao rolamento constante + arrasto quadrático da grama;
## no quique, a bola perde altura (coeficiente de restituição) e velocidade (derrapagem).
## A mira (kick_lofted / aim_shot) resolve a trajetória com a mesma física, então a bola
## chega onde foi mirada mesmo com arrasto e curva.

const GOAL_HALF := 3.66     ## meia largura do gol (regra do futebol)
const CROSSBAR := 2.44      ## altura do travessão (regra do futebol)
const PRED_DT := 1.0 / 120.0

var pos: Vector2 = Vector2.ZERO
var z: float = 0.0
var vel: Vector2 = Vector2.ZERO
var vz: float = 0.0
var spin: float = 0.0       ## giro visual da bola (radianos)
var curve: Vector2 = Vector2.ZERO   ## efeito: aceleração lateral (m/s²) enquanto a bola está no ar

var gravity: float
var roll: float             ## resistência ao rolamento (m/s²)
var ground_drag: float      ## arrasto quadrático no chão (1/m)
var air_drag: float         ## arrasto quadrático no ar (1/m)
var bounce: float           ## restituição vertical no quique
var skid: float             ## fração da velocidade perdida no quique
var radius: float


func _init() -> void:
	gravity = Tuning.f("bola", "gravidade", 9.8)
	roll = Tuning.f("bola", "rolamento", 1.8)
	ground_drag = Tuning.f("bola", "arrasto_chao", 0.018)
	air_drag = Tuning.f("bola", "arrasto_ar_quadratico", 0.013)
	bounce = Tuning.f("bola", "quique", 0.45)
	skid = Tuning.f("bola", "perda_no_quique", 0.16)
	radius = Tuning.f("bola", "raio", 0.11)


## Coloca a bola parada num ponto (nos pés de alguém, na marca do pênalti...).
func place(p: Vector2) -> void:
	pos = p
	z = 0.0
	vel = Vector2.ZERO
	vz = 0.0
	curve = Vector2.ZERO


func in_air() -> bool:
	return z > 0.0005 or vz > 0.0005


func speed() -> float:
	return vel.length()


## Passe rasteiro: a bola rola no chão a partir da velocidade spd, na direção do alvo.
## Devolve o tempo estimado até chegar (ou até parar, se não chegar).
func kick_ground(target: Vector2, spd: float) -> float:
	var d := target - pos
	vel = d.normalized() * spd if d.length() > 0.001 else Vector2.ZERO
	z = 0.0
	vz = 0.0
	curve = Vector2.ZERO
	return time_to_travel(d.length(), spd)


## Velocidade de saída para a bola rolar dist metros e chegar com v_end.
## (de v·dv/ds = -(a + k·v²): a + k·v0² = (a + k·v1²)·e^(2·k·s))
func ground_speed_for(dist: float, v_end: float) -> float:
	var a := roll
	var k := ground_drag
	return sqrt(maxf(((a + k * v_end * v_end) * exp(2.0 * k * dist) - a) / k, 0.0))


## Distância que a bola rola até parar saindo com spd.
func ground_reach(spd: float) -> float:
	return log((roll + ground_drag * spd * spd) / roll) / (2.0 * ground_drag)


## Tempo para a bola rasteira percorrer dist saindo com spd (ou o tempo até parar).
func time_to_travel(dist: float, spd: float) -> float:
	var a := roll
	var k := ground_drag
	var q := sqrt(a * k)
	var c := sqrt(k / a)
	var v1sq := ((a + k * spd * spd) * exp(-2.0 * k * dist) - a) / k
	var v1 := sqrt(maxf(v1sq, 0.0))
	return (atan(spd * c) - atan(v1 * c)) / q


## Passe alto / cruzamento: a bola sobe até apex e cai no alvo.
## A velocidade é ajustada simulando o voo (arrasto incluído). Devolve o tempo de voo.
func kick_lofted(target: Vector2, apex: float) -> float:
	var start := pos
	var d := target - start
	var dist := d.length()
	var dirv := d / dist if dist > 0.001 else Vector2(0, -1)
	var vz0 := sqrt(2.0 * gravity * maxf(apex, 0.3))
	var tf := 2.0 * vz0 / gravity
	var vh := dist / maxf(tf, 0.05)
	for it in 4:
		var res := _simulate_flight(start, dirv * vh, vz0)
		tf = res.z
		if res.x > 0.01:
			vh *= dist / res.x
		if res.y > 0.05:
			vz0 *= sqrt(maxf(apex, 0.3) / res.y)
	pos = start
	z = 0.0
	vel = dirv * vh
	vz = vz0
	curve = Vector2.ZERO
	return tf


## Voo sem quique a partir do chão: devolve (distância até tocar o chão, altura máxima, tempo).
func _simulate_flight(start: Vector2, v: Vector2, w: float) -> Vector3:
	var p := start
	var h := 0.0
	var top := 0.0
	var t := 0.0
	var dt := PRED_DT
	while t < 6.0:
		var sp := sqrt(v.length_squared() + w * w)
		v -= v * (air_drag * sp * dt)
		w -= (gravity + air_drag * sp * w) * dt
		p += v * dt
		h += w * dt
		t += dt
		top = maxf(top, h)
		if h <= 0.0 and w < 0.0:
			break
	return Vector3(p.distance_to(start), top, t)


## Chute: velocidade no chão + velocidade de subida (sem correção de mira).
func kick_shot(dir: Vector2, spd: float, lift: float) -> void:
	vel = dir.normalized() * spd
	vz = lift
	z = maxf(z, 0.05)
	curve = Vector2.ZERO


## Chute mirado: a bola cruza a linha do gol (y = 0) em x = tx, na altura h, com
## velocidade de saída spd e efeito curl (aceleração lateral). Resolve a trajetória com
## a física real (tiro iterativo). start_z = altura do contato (cabeceio ~1,6 m).
func aim_shot(tx: float, h: float, spd: float, curl: float, start_z: float = 0.05) -> void:
	var start := pos
	var d := Vector2(tx, 0.0) - start
	var tt := d.length() / maxf(spd, 1.0)
	var w := (h - start_z + 0.5 * gravity * tt * tt) / maxf(tt, 0.05)
	for it in 6:
		pos = start
		z = start_z
		vel = d.normalized() * spd
		vz = w
		curve = Vector2(curl, 0.0)
		var cr := goal_line_crossing()
		if cr.is_empty():
			break
		var ex: float = float(cr["x"]) - tx
		var ez: float = float(cr["z"]) - h
		var tc: float = maxf(float(cr["t"]), 0.05)
		d.x -= ex
		w -= ez / tc
		if absf(ex) < 0.02 and absf(ez) < 0.02:
			break
	pos = start
	z = start_z
	vel = d.normalized() * spd
	vz = w
	curve = Vector2(curl, 0.0)


## Avança a simulação. Chame com o passo fixo da física.
func step(delta: float) -> void:
	if in_air():
		var sp := sqrt(vel.length_squared() + vz * vz)
		vel -= vel * (air_drag * sp * delta)
		vel += curve * delta
		vz -= (gravity + air_drag * sp * vz) * delta
		pos += vel * delta
		z += vz * delta
		if z <= 0.0:
			z = 0.0
			curve = Vector2.ZERO   # o efeito acaba no primeiro quique
			if absf(vz) > 1.6:
				vz = -vz * bounce
				vel *= 1.0 - skid
			else:
				vz = 0.0
	else:
		var s := vel.length()
		if s > 0.0:
			var ns := maxf(s - (roll + ground_drag * s * s) * delta, 0.0)
			vel = vel * (ns / s)
			pos += vel * delta
	spin += vel.length() * delta * 1.6


## Onde e quando a bola cruza a linha do gol (y = 0) mantendo o movimento atual.
## Usa exatamente a mesma física de step(). Devolve {} se não for cruzar; senão {x, z, t}.
func goal_line_crossing() -> Dictionary:
	if vel.y >= -0.01 or pos.y <= 0.0:
		return {}
	var sp0 := pos
	var sz := z
	var sv := vel
	var svz := vz
	var sc := curve
	var ssp := spin
	var out := {}
	var t := 0.0
	while t < 4.0:
		var py := pos.y
		var px := pos.x
		var pz := z
		step(PRED_DT)
		t += PRED_DT
		if pos.y <= 0.0:
			var k := py / maxf(py - pos.y, 0.0001)
			out = {"x": lerpf(px, pos.x, k), "z": lerpf(pz, z, k), "t": t - PRED_DT + PRED_DT * k}
			break
		if not in_air() and vel.length() < 0.01:
			break
	pos = sp0
	z = sz
	vel = sv
	vz = svz
	curve = sc
	spin = ssp
	return out


## Classifica onde a bola cruzou a linha de fundo.
## "gol", "trave", "travessao", "fora" ou "por_cima".
static func classify_crossing(x: float, h: float) -> String:
	var ax := absf(x)
	if ax < GOAL_HALF - 0.12 and h < CROSSBAR - 0.11:
		return "gol"
	if ax < GOAL_HALF + 0.12 and h < CROSSBAR + 0.12:
		if h >= CROSSBAR - 0.11 and ax < GOAL_HALF - 0.12:
			return "travessao"
		return "trave"
	if ax < GOAL_HALF + 0.12:
		return "por_cima"
	return "fora"
