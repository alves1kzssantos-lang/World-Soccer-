class_name CompTheme
extends RefCounted
## Identidade visual por competição (liga ou copa): cores, fundo, estilo do placar,
## do título e da taça. Os dados ficam em assets/data/temas.json; competição sem tema
## usa a marca do jogo (grafite + verde neon).
##
## Uso:
##   CompTheme.for_league(li)       tema da liga (World.LEAGUES[li])
##   CompTheme.for_comp("FA Cup")   tema pelo nome da competição (liga ou copa)
##   CompTheme.for_match(mt)        tema da partida (Game.next_user_match())
##   CompTheme.current()            tema da liga da carreira aberta
##   CompTheme.draw_pattern(ci, rect, th, alpha)  fundo temático (geometria em cache)
##
## Cada tema é um Dictionary com Colors já convertidas e campos derivados
## (text_acc = destaque com contraste garantido sobre a faixa do placar).

const PATH := "res://assets/data/temas.json"
const PATTERNS := ["diagonal", "listras", "estrelas", "hex", "ondas", "chuva", "xadrez"]
const SCORE_STYLES := ["inclinado", "bloco", "pilula"]
const TITLE_STYLES := ["inclinado", "caixa", "espacado"]
const MIN_CONTRAST := 4.5

static var _raw: Dictionary = {}
static var _cache: Dictionary = {}       ## id -> tema montado
static var _geo: Dictionary = {}         ## geometria dos fundos por (padrão, tamanho)


static func _load() -> void:
	if not _raw.is_empty():
		return
	var txt := FileAccess.get_file_as_string(PATH)
	var d = JSON.parse_string(txt) if txt != "" else null
	_raw = d if typeof(d) == TYPE_DICTIONARY else {"default": {}, "themes": {}, "comps": {}}


## Todos os ids de tema (sem o padrão).
static func ids() -> Array:
	_load()
	return Dictionary(_raw.get("themes", {})).keys()


## Id do tema de uma competição pelo nome (vazio = usa o padrão da marca).
static func id_for(comp_name: String) -> String:
	_load()
	var comps: Dictionary = _raw.get("comps", {})
	if comps.has(comp_name):
		return str(comps[comp_name])
	var n := DataPack.norm(comp_name)
	for k in comps.keys():
		if DataPack.norm(str(k)) == n:
			return str(comps[k])
	return ""


static func for_comp(comp_name: String) -> Dictionary:
	return by_id(id_for(comp_name))


static func for_league(li: int) -> Dictionary:
	if li < 0 or li >= World.LEAGUES.size():
		return by_id("")
	return for_comp(str(World.LEAGUES[li]["name"]))


static func for_cup_def(d: int) -> Dictionary:
	if d < 0 or d >= World.CUPS.size():
		return by_id("")
	return for_comp(str(World.CUPS[d]["name"]))


## Tema da liga da carreira aberta.
static func current() -> Dictionary:
	if Game.S.is_empty():
		return by_id("")
	return for_league(int(Game.S.get("league", 0)))


## Tema de uma partida: copa usa o da copa; liga, o da liga; peneira, o padrão.
static func for_match(mt: Dictionary) -> Dictionary:
	match str(mt.get("kind", "")):
		"cup":
			if mt.has("cup") and not Game.S.is_empty():
				var cups: Array = Game.S.get("cups", [])
				var ci: int = int(mt["cup"])
				if ci >= 0 and ci < cups.size():
					return for_cup_def(int(cups[ci]["def"]))
			return for_comp(str(mt.get("comp", "")))
		"trial":
			return by_id("")
	return current()


## Tema montado pelo id ("" = padrão da marca).
static func by_id(id: String) -> Dictionary:
	_load()
	var key := id if Dictionary(_raw.get("themes", {})).has(id) else ""
	if _cache.has(key):
		return _cache[key]
	var base: Dictionary = _raw.get("default", {})
	var src: Dictionary = base.duplicate()
	if key != "":
		src.merge(Dictionary(_raw["themes"][key]), true)
	var th := _build(src)
	th["id"] = key if key != "" else "default"
	_cache[key] = th
	return th


static func _col(v, fallback: Color) -> Color:
	var s := str(v)
	return Color(s) if s != "" and Color.html_is_valid(s) else fallback


static func _build(src: Dictionary) -> Dictionary:
	var th := {}
	th["name"] = str(src.get("name", "World Soccer"))
	th["accent"] = _col(src.get("accent"), UI.NEON)
	th["accent2"] = _col(src.get("accent2"), Color.WHITE)
	th["bg1"] = _col(src.get("bg1"), UI.BG)
	th["bg2"] = _col(src.get("bg2"), UI.BG2)
	th["bar"] = _col(src.get("bar"), Color("090b0a"))
	th["score"] = _col(src.get("score"), Color("050706"))
	var pat := str(src.get("pattern", "diagonal"))
	th["pattern"] = pat if pat in PATTERNS else "diagonal"
	var ss := str(src.get("score_style", "inclinado"))
	th["score_style"] = ss if ss in SCORE_STYLES else "inclinado"
	var ts := str(src.get("title_style", "inclinado"))
	th["title_style"] = ts if ts in TITLE_STYLES else "inclinado"
	th["trophy"] = "prata" if str(src.get("trophy", "ouro")) == "prata" else "ouro"
	var bar: Color = th["bar"]
	# destaque usado como texto: clareia até ter contraste com a faixa do placar
	th["text_acc"] = readable(th["accent"], bar)
	# texto sobre o destaque (botões, chips cheios): escuro ou branco, o que contrastar mais
	var acc: Color = th["accent"]
	th["on_accent"] = Color("0b0d0c") if contrast(Color("0b0d0c"), acc) >= contrast(Color.WHITE, acc) else Color.WHITE
	# glass dos painéis do HUD tingido com o fundo do tema
	var bg1: Color = th["bg1"]
	th["glass"] = Color(bg1.r, bg1.g, bg1.b, 0.88)
	return th


## Chaves antigas usadas pelas telas de copa (CupScreens.theme_for).
static func cup_dict(th: Dictionary) -> Dictionary:
	var acc: Color = th["accent"]
	var bg_kind := "gramado"
	match str(th["pattern"]):
		"listras": bg_kind = "listras"
		"chuva": bg_kind = "chuva"
		"estrelas": bg_kind = "estrelas"
	return {"bg": bg_kind, "bg1": th["bg1"], "bg2": th["bg2"],
		"head": th["bar"], "head2": Color(th["bar"]).darkened(0.25), "title": th["text_acc"], "sub": Color(th["text_acc"]).lerp(Color.WHITE, 0.35),
		"btn": acc, "btn2": acc.darkened(0.25), "btn_txt": th["on_accent"],
		"tab": th["bar"], "tab_txt": th["text_acc"], "accent": acc, "icon": Color(th["bg2"]).lightened(0.1),
		"pattern": th["pattern"], "theme": th}


# ------------------------------------------------------------ contraste (WCAG)
static func _lin(c: float) -> float:
	return c / 12.92 if c <= 0.04045 else pow((c + 0.055) / 1.055, 2.4)


static func luminance(c: Color) -> float:
	return 0.2126 * _lin(c.r) + 0.7152 * _lin(c.g) + 0.0722 * _lin(c.b)


static func contrast(a: Color, b: Color) -> float:
	var la := luminance(a)
	var lb := luminance(b)
	return (maxf(la, lb) + 0.05) / (minf(la, lb) + 0.05)


## A cor clareada (ou escurecida, sobre fundo claro) até ter contraste mínimo com o fundo.
static func readable(fg: Color, bg: Color, min_ratio: float = MIN_CONTRAST) -> Color:
	var c := fg
	var lighten := luminance(bg) < 0.4
	for i in 20:
		if contrast(c, bg) >= min_ratio:
			return c
		c = c.lightened(0.08) if lighten else c.darkened(0.08)
	return Color.WHITE if lighten else Color.BLACK


# ------------------------------------------------------------ fundos temáticos
## Desenha o padrão do tema em rect (linhas em cache por tamanho: sem alocar a cada quadro).
## offset desloca o desenho (animação lenta); alpha controla a força.
static func draw_pattern(ci: CanvasItem, rect: Rect2, th: Dictionary, alpha: float = 0.08, offset: float = 0.0, col_override: Variant = null) -> void:
	var pat: String = th.get("pattern", "diagonal")
	var geo: Array = pattern_geo(pat, rect.size)
	var col: Color = col_override if col_override != null else Color(th.get("accent", UI.NEON))
	col.a = alpha
	ci.draw_set_transform(rect.position + Vector2(fposmod(offset, float(geo[2])), 0.0))
	ci.draw_multiline(geo[0], col, geo[1])
	ci.draw_set_transform(Vector2.ZERO)


## [linhas, largura, período horizontal] do padrão para um tamanho (em cache).
static func pattern_geo(pat: String, sz: Vector2) -> Array:
	var key := "%s|%d|%d" % [pat, int(sz.x), int(sz.y)]
	if _geo.has(key):
		return _geo[key]
	if _geo.size() > 64:
		_geo.clear()
	var L := PackedVector2Array()
	var w := 2.0
	var period := 40.0
	var W := sz.x + 80.0
	var H := sz.y
	match pat:
		"listras":
			period = 56.0
			w = 22.0
			var x := -80.0
			while x < W:
				L.append(Vector2(x, 0))
				L.append(Vector2(x + H * 0.12, H))
				x += period
		"estrelas":
			period = 64.0
			w = 2.0
			var rng := RandomNumberGenerator.new()
			rng.seed = 7
			var n := int(W * H / 2600.0) + 8
			for i in n:
				var p := Vector2(rng.randf_range(-80.0, W), rng.randf_range(0.0, H))
				var r := rng.randf_range(2.0, 5.0)
				L.append(p + Vector2(-r, 0))
				L.append(p + Vector2(r, 0))
				L.append(p + Vector2(0, -r))
				L.append(p + Vector2(0, r))
		"hex":
			period = 52.0
			w = 1.5
			var hr := 15.0
			var dx := hr * 1.732
			var row := 0
			var y := 0.0
			while y < H + hr:
				var xo := -80.0 + (dx * 0.5 if row % 2 == 1 else 0.0)
				var x2 := xo
				while x2 < W:
					for k in 6:
						var a0 := PI / 6.0 + TAU * k / 6.0
						var a1 := PI / 6.0 + TAU * (k + 1) / 6.0
						L.append(Vector2(x2, y) + Vector2(cos(a0), sin(a0)) * hr)
						L.append(Vector2(x2, y) + Vector2(cos(a1), sin(a1)) * hr)
					x2 += dx
				y += hr * 1.5
				row += 1
			period = dx
		"ondas":
			period = 120.0
			w = 2.0
			var yy := 10.0
			while yy < H:
				var px := -80.0
				var prev := Vector2(px, yy)
				while px < W:
					px += 12.0
					var cur := Vector2(px, yy + sin(px / 120.0 * TAU) * 7.0)
					L.append(prev)
					L.append(cur)
					prev = cur
				yy += 22.0
		"chuva":
			period = 36.0
			w = 2.0
			var rng2 := RandomNumberGenerator.new()
			rng2.seed = 11
			var n2 := int(W * H / 900.0) + 10
			for i in n2:
				var p2 := Vector2(rng2.randf_range(-80.0, W), rng2.randf_range(0.0, H))
				L.append(p2)
				L.append(p2 + Vector2(-5, 14))
		"xadrez":
			period = 48.0
			w = 1.5
			var gx := -80.0
			while gx < W:
				L.append(Vector2(gx, 0))
				L.append(Vector2(gx, H))
				gx += 24.0
			var gy := 0.0
			while gy < H:
				L.append(Vector2(-80, gy))
				L.append(Vector2(W, gy))
				gy += 24.0
		_:   # diagonal
			period = 64.0
			w = 10.0
			var x3 := -80.0 - H
			while x3 < W:
				L.append(Vector2(x3, H))
				L.append(Vector2(x3 + H * 0.9, 0))
				x3 += 32.0
	var g := [L, w, period]
	_geo[key] = g
	return g


# ------------------------------------------------------------ faixa da competição
## Faixa com a logo, o nome e o padrão da competição, para o topo das telas
## (classificação, calendário, resultados). altura h.
static func band(th: Dictionary, logo: Texture2D, title: String, sub: String = "", h: float = 60.0) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.clip_contents = true
	c.draw.connect(func():
		var sz := c.size
		var bar: Color = th["bar"]
		c.draw_rect(Rect2(Vector2.ZERO, sz), Color(bar, 0.94))
		draw_pattern(c, Rect2(Vector2.ZERO, sz), th, 0.08)
		var acc: Color = th["accent"]
		c.draw_rect(Rect2(0, 0, 6, sz.y), acc)
		c.draw_rect(Rect2(0, sz.y - 2, sz.x, 2), acc)
		c.draw_rect(Rect2(10, 0, 3, sz.y), Color(th["accent2"], 0.8))
		var x := 24.0
		if logo != null:
			var ts := logo.get_size()
			var k: float = (sz.y - 12.0) / maxf(ts.x, ts.y)
			c.draw_texture_rect(logo, Rect2(Vector2(x, (sz.y - ts.y * k) * 0.5), ts * k), false)
			x += ts.x * k + 14.0
		var f := UI.display()
		var t := title.to_upper()
		if str(th.get("title_style", "")) == "espacado":
			t = " ".join(PackedStringArray(Array(t.split(""))))
		c.draw_string(f, Vector2(x, (sz.y * 0.5 + 9.0) if sub == "" else 29.0), t, HORIZONTAL_ALIGNMENT_LEFT, sz.x - x - 12.0, 22, Color.WHITE)
		if sub != "":
			c.draw_string(UI.bold(), Vector2(x, 49.0), sub, HORIZONTAL_ALIGNMENT_LEFT, sz.x - x - 12.0, 12, th["text_acc"]))
	return c


## Faixa da liga da carreira aberta.
static func league_band(sub: String = "") -> Control:
	var li := int(Game.S.get("league", 0))
	return band(for_league(li), DataPack.comp_logo_or_badge(DataPack.comp_id(li)), Game.LEAGUE, sub)
