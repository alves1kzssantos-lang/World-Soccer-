class_name Contracts
extends RefCounted
## Renovação de contratos da carreira de técnico.
##
## Convenção: p["contract"] = temporadas restantes CONTANDO a atual.
##   contract <= 1  -> contrato termina no fim desta temporada ("a vencer").
##   Renovar por N anos deixa contract = N + 1 (a temporada atual + N novas).
## No fim da temporada (Game.new_season -> season_end), quem está a vencer e não renovou
## sai de graça (lei Bosman); os clubes da máquina renovam ou liberam os seus.
##
## Estado salvo no jogador:
##   p["renew"]  = {"tries": n, "refused": bool, "role": "titular|rodizio|reserva", "last": {wage, years}}
##   p["role"]   = papel prometido no último contrato (padrão "rodizio")
## Números em assets/data/career_rules.json (seção "contrato").

const PATH := "res://assets/data/career_rules.json"
const ROLES := ["titular", "rodizio", "reserva"]
const ROLE_NAMES := {"titular": "Titular", "rodizio": "Rodízio", "reserva": "Reserva"}

static var _cfg: Dictionary = {}


static func cfg(section: String, key: String, fallback: Variant) -> Variant:
	if _cfg.is_empty():
		if FileAccess.file_exists(PATH):
			var d = JSON.parse_string(FileAccess.get_file_as_string(PATH))
			if typeof(d) == TYPE_DICTIONARY:
				_cfg = d
		if _cfg.is_empty():
			_cfg = {"_": true}
	var sec = _cfg.get(section, {})
	if typeof(sec) == TYPE_DICTIONARY and sec.has(key):
		return sec[key]
	return fallback


static func c(key: String, fallback: float) -> float:
	return float(cfg("contrato", key, fallback))


## Salário de mercado (mesma fórmula de Game._price), em mil por semana.
static func market_wage(p: Dictionary) -> float:
	return snappedf(maxf(pow(maxf(float(p["ovr"]) - 55.0, 1.0), 2.0) * 0.07, 1.5), 0.1)


## Contrato termina nesta temporada?
static func expiring(p: Dictionary) -> bool:
	return int(p.get("contract", 1)) <= 1 and not p.has("loan") and not p.get("me", false)


## Jogadores do clube com contrato a vencer (sem os emprestados ao clube).
static func expiring_list(cid: int) -> Array:
	return Game.squad(cid).filter(func(p): return expiring(p))


## Papel natural do jogador no elenco: titular se joga, reserva se quase não entra.
static func natural_role(p: Dictionary) -> String:
	var cid: int = int(p["club"])
	if cid >= 0 and cid < Game.S["clubs"].size() and p["id"] in Game.S["clubs"][cid]["xi"]:
		return "titular"
	var sq := Game.squad(cid) if cid >= 0 else []
	var better := 0
	for q in sq:
		if q["pos"] == p["pos"] and int(q["ovr"]) > int(p["ovr"]):
			better += 1
	if better == 0:
		return "titular"
	return "rodizio" if better <= 1 else "reserva"


static func morale() -> float:
	return float(Game.S.get("media", {}).get("moral", 60.0))


## O que o jogador pede para renovar: {wage, years, role}.
static func demand(p: Dictionary) -> Dictionary:
	var w: float = maxf(market_wage(p), float(p["wage"]))
	var age: int = int(p["age"])
	if age <= 23:
		w *= c("ajuste_salario_jovem", 1.08)
	elif age >= 32:
		w *= c("ajuste_salario_veterano", 0.9)
	var club_str: float = float(Game.club(int(p["club"]))["str"]) if int(p["club"]) >= 0 else 70.0
	if float(p["ovr"]) > club_str + 5.0:
		w *= 1.0 + c("ajuste_craque_acima_do_clube", 0.12)
	# moral alta = elenco feliz, pede menos; moral baixa pede mais
	w *= 1.0 - (morale() - 60.0) * c("ajuste_moral_por_ponto", 0.003)
	if Game.status(p) == "ÍDOLO":
		w *= c("ajuste_idolo", 0.9)
	var years: int = int(c("anos_pedidos_ate_27", 4))
	if age >= 32:
		years = int(c("anos_pedidos_32_mais", 1))
	elif age >= 28:
		years = int(c("anos_pedidos_28_31", 3))
	# cada recusa/contraproposta deixa o pedido um pouco mais baixo (ele quer ficar)
	var tries: int = int(p.get("renew", {}).get("tries", 0))
	w *= 1.0 - c("desconto_contraproposta", 0.03) * tries
	return {"wage": snappedf(maxf(w, 1.5), 0.1), "years": years, "role": natural_role(p)}


## Nota da proposta (1.0 = exatamente o que ele pede).
static func score(p: Dictionary, wage: float, years: int, role: String) -> float:
	var d := demand(p)
	var need: float = float(d["wage"])
	if role == "reserva" and d["role"] != "reserva":
		need *= c("exigencia_reserva", 1.15)
	elif role == "rodizio" and d["role"] == "titular":
		need *= c("exigencia_rodizio", 1.05)
	var sc: float = wage / maxf(need, 0.1)
	sc -= absf(float(years - int(d["years"]))) * c("penalidade_por_ano_de_diferenca", 0.04)
	return sc


## Proposta de renovação do seu clube. Devolve {result: "aceita"|"contraproposta"|"recusa", text, wage, years}.
static func propose(pid: int, wage: float, years: int, role: String) -> Dictionary:
	var p: Dictionary = Game.player(pid)
	if int(p["club"]) != int(Game.S["club"]) or p.has("loan") or int(p["contract"]) > 2:
		return {"result": "recusa", "text": "Só dá para renovar contratos que terminam nesta ou na próxima temporada."}
	var rn: Dictionary = p.get("renew", {})
	if rn.get("refused", false):
		return {"result": "recusa", "text": "%s já decidiu sair no fim do contrato." % p["name"]}
	years = clampi(years, 1, 5)
	var sc := score(p, wage, years, role)
	var tries: int = int(rn.get("tries", 0))
	if sc >= c("aceita_a_partir", 0.98):
		_apply_renewal(p, wage, years, role)
		Game.add_news("Contrato renovado", "%s renovou por %d ano(s) recebendo $ %.1fk por semana (%s)." % [p["name"], years, wage, ROLE_NAMES.get(role, role)])
		Game.save()
		return {"result": "aceita", "text": "%s aceitou! Contrato renovado por %d ano(s)." % [p["name"], years], "wage": wage, "years": years}
	tries += 1
	rn["tries"] = tries
	p["renew"] = rn
	if sc >= c("contraproposta_a_partir", 0.85) and tries < int(c("tentativas_maximas", 3)):
		var d := demand(p)
		Game.save()
		return {"result": "contraproposta", "text": "%s pede $ %.1fk por semana e %d ano(s) para assinar." % [p["name"], d["wage"], d["years"]],
			"wage": d["wage"], "years": d["years"]}
	rn["refused"] = true
	p["renew"] = rn
	Game.add_news("Renovação recusada", "%s não aceitou renovar e deve sair de graça no fim da temporada." % p["name"])
	Game.save()
	return {"result": "recusa", "text": "%s recusou e vai sair no fim do contrato." % p["name"]}


static func _apply_renewal(p: Dictionary, wage: float, years: int, role: String) -> void:
	p["wage"] = snappedf(wage, 0.1)
	p["contract"] = years + 1
	p["role"] = role
	p.erase("renew")


## Custo de rescindir agora (metade do que falta pagar), em milhões.
static func release_cost(p: Dictionary) -> float:
	var weeks: float = float(maxi(int(p["contract"]), 1)) * 52.0
	return snappedf(float(p["wage"]) * weeks / 1000.0 * c("multa_rescisao_fracao", 0.5), 0.01)


## Rescinde o contrato: paga a multa e o jogador vira livre.
static func release(pid: int) -> String:
	var p: Dictionary = Game.player(pid)
	if int(p["club"]) != int(Game.S["club"]) or p.has("loan"):
		return "Esse jogador não tem contrato com o seu clube."
	if Game.squad(Game.S["club"]).size() <= int(c("elenco_minimo", 16)):
		return "Elenco muito curto para dispensar (mínimo %d)." % int(c("elenco_minimo", 16))
	var cost := release_cost(p)
	if cost > float(Game.S["money"]) + 0.001:
		return "Caixa insuficiente para pagar a rescisão (%s)." % Game.money(cost)
	Game.S["money"] -= cost
	Game.S["fin"]["salarios"] = float(Game.S["fin"].get("salarios", 0.0)) + cost
	Game._log_transfer(p, Game.S["club"], Game.FREE, 0.0)
	_to_free(p)
	Game.validate_xi(Game.S["club"])
	Game.add_news("Contrato rescindido", "%s foi dispensado. Multa paga: %s." % [p["name"], Game.money(cost)])
	Game.save()
	return ""


static func _to_free(p: Dictionary) -> void:
	p["club"] = Game.FREE
	p["listed"] = false
	p["contract"] = 1
	p.erase("renew")
	p["joined"] = Game.S["season"]
	p["cmin"] = 0
	p["cgol"] = 0
	p["cass"] = 0
	p["titles"] = []
	for c2 in Game.S["clubs"]:
		c2["xi"].erase(p["id"])
		if c2.has("bench"):
			c2["bench"].erase(p["id"])


## Avisos na Central sobre contratos a vencer (algumas rodadas da temporada).
static func round_notice() -> void:
	if Pro.is_pro():
		return
	var rounds: Array = []
	for x in cfg("contrato", "aviso_rodadas", [0, 10, 20, 30]):
		rounds.append(int(x))   # o JSON traz números como float
	if not (int(Game.S["round"]) in rounds):
		return
	var exp := expiring_list(Game.S["club"]).filter(func(p): return not p.get("renew", {}).get("refused", false))
	if exp.is_empty():
		return
	var names: Array = []
	for p in exp.slice(0, 4):
		names.append(str(p["name"]))
	var more := "" if exp.size() <= 4 else " e mais %d" % (exp.size() - 4)
	Game.add_news("Contratos a vencer", "%d jogador(es) com contrato até o fim da temporada: %s%s. Renove em Elenco > perfil." % [exp.size(), ", ".join(names), more])


## Fim de temporada, ANTES de os contratos andarem: Bosman do seu clube e renovações da máquina.
## Devolve a lista de nomes que saíram do seu clube.
static func season_end() -> Array:
	var left: Array = []
	var me: int = Game.S["club"]
	var pro := Pro.is_pro()
	for p in Game.S["players"].values():
		if p.get("me", false) or p.has("loan") or int(p["club"]) < 0:
			continue
		if int(p["contract"]) > 1:
			continue
		var cid: int = int(p["club"])
		if cid == me and not pro:
			left.append(str(p["name"]))
			Game._log_transfer(p, cid, Game.FREE, 0.0)
			_to_free(p)
			continue
		# clube da máquina (ou o seu no modo jogador): renova quem vale a pena
		var st: float = float(Game.S["clubs"][cid]["str"]) if cid < Game.S["clubs"].size() else 70.0
		var key: bool = float(p["ovr"]) >= st - 6.0 and int(p["age"]) <= 31
		var ch: float = c("ia_renova_chance_titular", 0.85) if key else c("ia_renova_chance_reserva", 0.45)
		if Game.rng.randf() < ch:
			var d := demand(p)
			_apply_renewal(p, float(d["wage"]), int(d["years"]), str(d["role"]))
		else:
			_to_free(p)
	if not left.is_empty():
		Game.add_news("Saídas de fim de contrato", "Sem renovação, deixaram o clube de graça: %s." % ", ".join(left))
	# ninguém fica com elenco curto demais
	for cid in Game.S["clubs"].size():
		var n := Game.squad(cid).size()
		var minimum: int = int(c("elenco_minimo", 16)) if cid == me else 20
		while n < minimum:
			var pos: String = Game.POS_ORDER[Game.rng.randi_range(0, 8)]
			var np := Game.make_player(pos, int(Game.S["clubs"][cid]["str"]) - Game.rng.randi_range(3, 9), cid, Game.rng.randi_range(19, 30))
			np["contract"] = 3
			n += 1
			if cid == me:
				Game.add_news("Reforço de emergência", "Para completar o elenco, a diretoria contratou %s (%s, GER %d)." % [np["name"], np["pos"], np["ovr"]])
	return left
