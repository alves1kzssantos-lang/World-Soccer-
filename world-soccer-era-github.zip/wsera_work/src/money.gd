class_name Money
extends RefCounted
## Formatação única de dinheiro do jogo (padrão brasileiro: vírgula decimal).
## Valores do jogo: caixa, taxas e prêmios em MILHÕES (float); salários em MIL por semana.
##   Money.fmt(12.4)        -> "$ 12,4 mi"
##   Money.fmt(0.85)        -> "$ 850 mil"
##   Money.fmt(-3.25)       -> "−$ 3,3 mi"
##   Money.wage(43.8)       -> "$ 43,8 mil/sem"
##   Money.signed(1.5)      -> "+ $ 1,5 mi"

const MINUS := "−"


static func _num(v: float, decimals: int) -> String:
	var s := ("%." + str(decimals) + "f") % v
	if decimals > 0:
		s = s.replace(".", ",")
	# milhar com ponto: 1.250 mi
	var parts := s.split(",")
	var ip: String = parts[0]
	var out := ""
	var cnt := 0
	for i in range(ip.length() - 1, -1, -1):
		out = ip[i] + out
		cnt += 1
		if cnt % 3 == 0 and i > 0:
			out = "." + out
	return out + ("," + parts[1] if parts.size() > 1 else "")


## Valor em milhões.
static func fmt(v_mi: float) -> String:
	if is_nan(v_mi) or is_inf(v_mi):
		return "$ —"
	var neg := v_mi < 0.0
	var a := absf(v_mi)
	var body := ""
	if a < 0.0005:
		body = "$ 0"
		neg = false
	elif a < 1.0:
		body = "$ %s mil" % _num(roundf(a * 1000.0), 0)
	elif a < 100.0:
		body = "$ %s mi" % _num(a, 1)
	else:
		body = "$ %s mi" % _num(roundf(a), 0)
	return (MINUS + body) if neg else body


## Valor com sinal explícito (entradas e saídas).
static func signed(v_mi: float) -> String:
	if absf(v_mi) < 0.0005:
		return fmt(0.0)
	return ("+ " if v_mi > 0.0 else MINUS + " ") + fmt(absf(v_mi))


## Salário em MIL por semana (unidade guardada nos jogadores).
static func wage(k_week: float) -> String:
	var a := absf(k_week)
	if a >= 1000.0:
		return "$ %s mi/sem" % _num(a / 1000.0, 2)
	if a >= 100.0:
		return "$ %s mil/sem" % _num(roundf(a), 0)
	return "$ %s mil/sem" % _num(a, 1)


## Salário curto para tabelas (sem "/sem").
static func wage_short(k_week: float) -> String:
	return wage(k_week).trim_suffix("/sem")
