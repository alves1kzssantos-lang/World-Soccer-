class_name Loans
extends RefCounted
## Empréstimos da carreira de técnico.
##
## Um jogador emprestado fica com p["club"] = clube que recebeu (então ele joga, aparece no
## elenco e soma minutos/gols por lá) e guarda o vínculo em p["loan"]:
##   from      clube dono do contrato
##   to        clube que recebeu
##   season    temporada em que começou
##   end_round rodada em que volta (meia temporada) ou -1 = volta no fim da temporada
##   pct       % do salário pago por quem recebeu (o resto continua com o dono)
##   buy       opção de compra em $ mi (0 = sem opção)
##   fee       taxa paga pelo empréstimo
##   start     números da temporada no início do empréstimo {g, min, gol, ass}
## O contrato (p["contract"]) continua sendo com o dono.
## Pedidos da máquina pelos seus jogadores ficam em S["loan_offers"].
## Números em assets/data/career_rules.json (seção "emprestimo").


static func e(key: String, fallback: float) -> float:
	return float(Contracts.cfg("emprestimo", key, fallback))


static func is_loaned(p: Dictionary) -> bool:
	return p.has("loan")


static func offers() -> Array:
	if not Game.S.has("loan_offers"):
		Game.S["loan_offers"] = []
	return Game.S["loan_offers"]


## Seus jogadores emprestados a outros clubes.
static func loaned_out(cid: int) -> Array:
	var out: Array = []
	for p in Game.S["players"].values():
		if p.has("loan") and int(p["loan"]["from"]) == cid:
			out.append(p)
	return out


## Jogadores que o clube recebeu por empréstimo.
static func loaned_in(cid: int) -> Array:
	return Game.squad(cid).filter(func(p): return p.has("loan"))


static func _half_round() -> int:
	return int(Game.S["fixtures"].size() / 2.0)


static func _snap(p: Dictionary) -> Dictionary:
	return {"g": int(p["g"]), "min": int(p["min"]), "gol": int(p["gol"]), "ass": int(p["ass"])}


## Jogos, minutos e gols desde que o empréstimo começou.
static func stats(p: Dictionary) -> Dictionary:
	if not p.has("loan"):
		return {"g": 0, "min": 0, "gol": 0, "ass": 0}
	var st: Dictionary = p["loan"].get("start", {})
	return {"g": int(p["g"]) - int(st.get("g", 0)), "min": int(p["min"]) - int(st.get("min", 0)),
		"gol": int(p["gol"]) - int(st.get("gol", 0)), "ass": int(p["ass"]) - int(st.get("ass", 0))}


static func ends_text(p: Dictionary) -> String:
	if not p.has("loan"):
		return ""
	return "até a metade da temporada" if int(p["loan"]["end_round"]) >= 0 else "até o fim da temporada"


## Cria o empréstimo (sem checar regras).
static func _start(p: Dictionary, to: int, half: bool, pct: int, buy: float, fee: float) -> void:
	var from: int = int(p["club"])
	for c in Game.S["clubs"]:
		c["xi"].erase(p["id"])
		if c.has("bench"):
			c["bench"].erase(p["id"])
	var end_round := -1
	if half and int(Game.S["round"]) < _half_round():
		end_round = _half_round()
	p["loan"] = {"from": from, "to": to, "season": int(Game.S["season"]), "end_round": end_round,
		"pct": clampi(pct, 0, 100), "buy": snappedf(buy, 0.01), "fee": snappedf(fee, 0.01), "start": _snap(p)}
	p["club"] = to
	p["listed"] = false
	Game.S["transfers"].push_front({"name": p["name"], "pos": p["pos"], "nat": p["nat"], "from": from, "to": to,
		"value": fee, "day": Game.S["day"], "loan": true})
	if Game.S["transfers"].size() > 60:
		Game.S["transfers"].pop_back()
	if from != Game.S["club"] and from >= 0:
		Game.auto_lineup(from)
	if to != Game.S["club"]:
		Game.auto_lineup(to)
	else:
		Game.validate_xi(to)


## Termina o empréstimo: o jogador volta ao dono.
static func end(p: Dictionary, why: String = "") -> void:
	if not p.has("loan"):
		return
	var ln: Dictionary = p["loan"]
	var from: int = int(ln["from"])
	var to: int = int(ln["to"])
	var st := stats(p)
	if not p.has("loan_hist"):
		p["loan_hist"] = []
	p["loan_hist"].append({"club": to, "season": int(ln["season"]), "g": st["g"], "min": st["min"], "gol": st["gol"], "ass": st["ass"]})
	p.erase("loan")
	p["club"] = from
	for c in Game.S["clubs"]:
		c["xi"].erase(p["id"])
		if c.has("bench"):
			c["bench"].erase(p["id"])
	var me: int = Game.S["club"]
	if to >= 0 and to != me:
		Game.auto_lineup(to)
	if from >= 0 and from != me:
		Game.auto_lineup(from)
	if from == me or to == me:
		Game.validate_xi(me)
		Game.add_news("Fim de empréstimo", "%s voltou ao %s%s (%d jogos, %d gols pelo %s)." % [p["name"], Game.club_name(from),
			(" — " + why) if why != "" else "", st["g"], st["gol"], Game.club_name(to)])


## Exige do clube dono: % mínimo do salário, taxa e opção de compra para levar o jogador.
static func terms_in(p: Dictionary) -> Dictionary:
	var owner: int = int(p["club"])
	var st: float = float(Game.club(owner)["str"]) if owner >= 0 else 70.0
	var pct: int = clampi(int(round((50.0 + (float(p["ovr"]) - (st - 10.0)) * 3.0) / 10.0)) * 10, int(e("aceita_ceder_minimo_pct", 50)), 100)
	return {"pct": pct, "fee": snappedf(float(p["value"]) * e("taxa_emprestimo_fracao_valor", 0.04), 0.01),
		"buy": snappedf(float(p["value"]) * e("opcao_compra_fracao_valor", 1.1), 0.01)}


## Jogadores de outros clubes que podem vir emprestados (sobram no elenco deles).
static func available_in() -> Array:
	var me: int = Game.S["club"]
	var out: Array = []
	for cid in Game.n_league():
		if cid == me:
			continue
		var sq := Game.squad(cid)
		if sq.size() <= int(e("elenco_minimo_cedente", 20)):
			continue
		var xi: Array = Game.S["clubs"][cid]["xi"]
		for p in sq:
			if p.has("loan") or p.get("me", false) or p["id"] in xi:
				continue
			out.append(p)
	out.sort_custom(func(a, b):
		if a["ovr"] != b["ovr"]:
			return a["ovr"] > b["ovr"]
		return a["id"] < b["id"])
	return out


## Pede um jogador emprestado. pct = % do salário que você paga. Devolve "" ou o motivo da recusa.
static func loan_in(pid: int, half: bool, pct: int, with_buy: bool) -> String:
	if Pro.is_pro():
		return "No modo jogador quem contrata é o clube."
	var p: Dictionary = Game.player(pid)
	var me: int = Game.S["club"]
	var owner: int = int(p["club"])
	if owner < 0 or owner == me or p.has("loan") or p.get("me", false):
		return "Esse jogador não está disponível para empréstimo."
	if owner >= Game.n_league():
		return "Só é possível pedir emprestado a clubes do seu campeonato."
	if Game.squad(me).size() >= 30:
		return "Elenco cheio (máximo 30)."
	if Game.squad(owner).size() <= int(e("elenco_minimo_cedente", 20)):
		return "O %s não tem elenco para ceder ninguém agora." % Game.club_name(owner)
	if p["id"] in Game.S["clubs"][owner]["xi"]:
		return "%s é titular do %s e não será emprestado." % [p["name"], Game.club_name(owner)]
	var t := terms_in(p)
	if pct < int(t["pct"]):
		return "O %s quer que você pague pelo menos %d%% do salário." % [Game.club_name(owner), t["pct"]]
	if float(t["fee"]) > float(Game.S["money"]) + 0.001:
		return "Caixa insuficiente para a taxa de empréstimo (%s)." % Game.money(t["fee"])
	Game.S["money"] -= float(t["fee"])
	Game.S["fin"]["compras"] = float(Game.S["fin"].get("compras", 0.0)) + float(t["fee"])
	_start(p, me, half, pct, float(t["buy"]) if with_buy else 0.0, float(t["fee"]))
	Game.add_news("Empréstimo confirmado", "%s chega emprestado pelo %s %s. Você paga %d%% do salário%s." % [p["name"], Game.club_name(owner),
		ends_text(p), pct, (", com opção de compra de " + Game.money(t["buy"])) if with_buy else ""])
	Game.save()
	return ""


## Clubes da máquina que aceitariam o jogador (onde ele teria minutos).
static func _takers(p: Dictionary) -> Array:
	var out: Array = []
	for cid in Game.n_league():
		if cid == int(p["club"]):
			continue
		var st: float = float(Game.S["clubs"][cid]["str"])
		if float(p["ovr"]) >= st - 12.0 and float(p["ovr"]) <= st + 4.0 and Game.squad(cid).size() < 28:
			out.append(cid)
	return out


## Oferece seu jogador por empréstimo. Devolve {ok, text}.
static func offer_out(pid: int, half: bool) -> Dictionary:
	var p: Dictionary = Game.player(pid)
	var me: int = Game.S["club"]
	if int(p["club"]) != me or p.has("loan") or p.get("me", false):
		return {"ok": false, "text": "Esse jogador não é seu para emprestar."}
	if Game.squad(me).size() <= int(Contracts.c("elenco_minimo", 16)):
		return {"ok": false, "text": "Elenco muito curto para emprestar alguém (mínimo %d)." % int(Contracts.c("elenco_minimo", 16))}
	var takers := _takers(p)
	if takers.is_empty() or Game.rng.randf() > e("oferecer_chance_base", 0.7):
		return {"ok": false, "text": "Nenhum clube se interessou por %s agora. Tente mais tarde." % p["name"]}
	var to: int = takers[Game.rng.randi_range(0, takers.size() - 1)]
	var pct: int = int(round(Game.rng.randf_range(e("fracao_salario_ia_paga_min", 50), e("fracao_salario_ia_paga_max", 100)) / 10.0)) * 10
	var buy: float = snappedf(float(p["value"]) * e("opcao_compra_fracao_valor", 1.1), 0.01) if Game.rng.randf() < 0.5 else 0.0
	_start(p, to, half, pct, buy, 0.0)
	Game.add_news("Jogador emprestado", "%s foi emprestado ao %s %s. O %s paga %d%% do salário%s." % [p["name"], Game.club_name(to), ends_text(p),
		Game.club_name(to), pct, (" e tem opção de compra de " + Game.money(buy)) if buy > 0.0 else ""])
	Game.save()
	return {"ok": true, "text": "%s emprestado ao %s." % [p["name"], Game.club_name(to)]}


static func accept_request(idx: int) -> String:
	var lo := offers()
	if idx < 0 or idx >= lo.size():
		return "Pedido não encontrado."
	var o: Dictionary = lo[idx]
	lo.remove_at(idx)
	if not Game.S["players"].has(o["pid"]):
		return "Esse jogador não está mais no clube."
	var p: Dictionary = Game.player(o["pid"])
	var me: int = Game.S["club"]
	if int(p["club"]) != me or p.has("loan"):
		return "Esse jogador não está mais disponível."
	if Game.squad(me).size() <= int(Contracts.c("elenco_minimo", 16)):
		return "Elenco muito curto para emprestar alguém (mínimo %d)." % int(Contracts.c("elenco_minimo", 16))
	_start(p, int(o["club"]), bool(o.get("half", false)), int(o["pct"]), float(o.get("buy", 0.0)), 0.0)
	Game.add_news("Jogador emprestado", "%s foi emprestado ao %s %s." % [p["name"], Game.club_name(int(o["club"])), ends_text(p)])
	Game.save()
	return ""


static func reject_request(idx: int) -> void:
	var lo := offers()
	if idx >= 0 and idx < lo.size():
		lo.remove_at(idx)


## Chamar de volta um jogador seu emprestado (só depois de metade do período).
static func can_recall(p: Dictionary) -> bool:
	if not p.has("loan") or int(p["loan"]["from"]) != int(Game.S["club"]):
		return false
	var ln: Dictionary = p["loan"]
	if int(ln["season"]) < int(Game.S["season"]):
		return true
	return int(Game.S["round"]) >= _half_round() and int(ln["end_round"]) < 0


static func recall(pid: int) -> String:
	var p: Dictionary = Game.player(pid)
	if not can_recall(p):
		return "Só dá para chamar de volta depois da metade da temporada (empréstimos de temporada inteira)."
	if Game.squad(Game.S["club"]).size() >= 30:
		return "Elenco cheio (máximo 30)."
	end(p, "chamado de volta")
	Game.save()
	return ""


## Exerce a opção de compra de um jogador que você recebeu emprestado.
static func buy_option(pid: int) -> String:
	var p: Dictionary = Game.player(pid)
	if not p.has("loan") or int(p["loan"]["to"]) != int(Game.S["club"]) or float(p["loan"]["buy"]) <= 0.0:
		return "Esse empréstimo não tem opção de compra."
	var fee: float = float(p["loan"]["buy"])
	if fee > float(Game.S["money"]) + 0.001:
		return "Caixa insuficiente para exercer a opção (%s)." % Game.money(fee)
	var from: int = int(p["loan"]["from"])
	Game.S["money"] -= fee
	Game.S["fin"]["compras"] = float(Game.S["fin"].get("compras", 0.0)) + fee
	p.erase("loan")
	p["contract"] = maxi(int(p["contract"]), 3)
	p["joined"] = Game.S["season"]
	p["cmin"] = 0
	p["cgol"] = 0
	p["cass"] = 0
	p["titles"] = []
	Game._log_transfer(p, from, Game.S["club"], fee)
	if from >= 0 and Game.squad(from).size() < 22:
		Game.make_player(p["pos"], int(Game.S["clubs"][from]["str"]) - Game.rng.randi_range(2, 6), from, Game.rng.randi_range(18, 23))
		Game.auto_lineup(from)
	Game.add_news("Opção de compra exercida", "%s agora é do seu clube em definitivo (%s)." % [p["name"], Game.money(fee)])
	Game.save()
	return ""


## Salário semanal (mil) que o clube paga, contando a divisão dos empréstimos.
static func wage_bill(cid: int) -> float:
	var w := 0.0
	for p in Game.squad(cid):
		if p.has("loan"):
			w += float(p["wage"]) * float(p["loan"]["pct"]) / 100.0
		else:
			w += float(p["wage"])
	for p in loaned_out(cid):
		w += float(p["wage"]) * (1.0 - float(p["loan"]["pct"]) / 100.0)
	return w


## Uma rodada passou: pedidos da máquina, empréstimos entre clubes da máquina e voltas no meio da temporada.
static func round_tick() -> void:
	var me: int = Game.S["club"]
	# voltas no meio da temporada
	for p in Game.S["players"].values().duplicate():
		if p.has("loan") and int(p["loan"]["end_round"]) >= 0 and int(Game.S["round"]) >= int(p["loan"]["end_round"]):
			end(p, "fim do empréstimo de meia temporada")
	if not Pro.is_pro():
		# clubes da máquina pedem seus jovens/reservas sem minutos
		if Game.rng.randf() < e("pedido_chance_por_rodada", 0.06):
			var cand: Array = []
			var xi: Array = Game.my_club()["xi"]
			for p in Game.squad(me):
				if p.has("loan") or p["id"] in xi:
					continue
				if int(p["age"]) <= int(e("idade_maxima_pedido", 23)) or int(p["min"]) <= int(e("minutos_maximos_pedido", 450)):
					cand.append(p)
			if not cand.is_empty():
				var p: Dictionary = cand[Game.rng.randi_range(0, cand.size() - 1)]
				var takers := _takers(p)
				var dup := false
				for o in offers():
					if int(o["pid"]) == int(p["id"]):
						dup = true
				if not takers.is_empty() and not dup:
					var to: int = takers[Game.rng.randi_range(0, takers.size() - 1)]
					var pct: int = int(round(Game.rng.randf_range(e("fracao_salario_ia_paga_min", 50), e("fracao_salario_ia_paga_max", 100)) / 10.0)) * 10
					var half: bool = Game.rng.randf() < 0.35 and int(Game.S["round"]) < _half_round()
					var buy: float = snappedf(float(p["value"]) * e("opcao_compra_fracao_valor", 1.1), 0.01) if Game.rng.randf() < 0.4 else 0.0
					offers().append({"pid": p["id"], "club": to, "pct": pct, "half": half, "buy": buy})
					if offers().size() > 6:
						offers().pop_front()
					Game.add_news("Pedido de empréstimo", "%s quer %s emprestado %s, pagando %d%% do salário. Veja Propostas." % [Game.club_name(to), p["name"],
						"por meia temporada" if half else "até o fim da temporada", pct])
	# empréstimos entre clubes da máquina
	if Game.rng.randf() < e("ia_entre_si_chance_por_rodada", 0.15):
		var n: int = Game.n_league()
		var a: int = Game.rng.randi_range(0, n - 1)
		var b: int = Game.rng.randi_range(0, n - 1)
		if a != b and a != me and b != me and float(Game.S["clubs"][a]["str"]) > float(Game.S["clubs"][b]["str"]) \
				and Game.squad(a).size() > int(e("elenco_minimo_cedente", 20)) and Game.squad(b).size() < 28:
			var xi_a: Array = Game.S["clubs"][a]["xi"]
			var young: Array = Game.squad(a).filter(func(q): return int(q["age"]) <= 22 and not q.has("loan") and not q.get("me", false) and not (q["id"] in xi_a))
			if not young.is_empty():
				_start(young[Game.rng.randi_range(0, young.size() - 1)], b, false, 100, 0.0, 0.0)


## Fim de temporada (antes dos contratos andarem): opções de compra da máquina e voltas.
static func season_end() -> void:
	var me: int = Game.S["club"]
	for p in Game.S["players"].values().duplicate():
		if not p.has("loan"):
			continue
		var ln: Dictionary = p["loan"]
		var to: int = int(ln["to"])
		var from: int = int(ln["from"])
		# a máquina compra quem jogou bem e tem opção de compra
		if to != me and float(ln["buy"]) > 0.0 and stats(p)["min"] >= 900 and Game.rng.randf() < e("ia_exerce_opcao_chance", 0.35):
			var fee: float = float(ln["buy"])
			p.erase("loan")
			p["contract"] = maxi(int(p["contract"]), 3)
			p["joined"] = Game.S["season"]
			Game._log_transfer(p, from, to, fee)
			if from == me:
				Game.S["money"] += fee
				Game.S["fin"]["vendas"] = float(Game.S["fin"].get("vendas", 0.0)) + fee
				Game.add_news("Opção de compra exercida", "O %s comprou %s em definitivo por %s." % [Game.club_name(to), p["name"], Game.money(fee)])
			continue
		end(p)
	offers().clear()
