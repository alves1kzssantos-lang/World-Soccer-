class_name FinanceCharts
extends RefCounted
## Gráficos desenhados por código da tela de Finanças (sem alocar por quadro: só redesenham ao mudar de tamanho).


## Barras horizontais: receitas (verde) e despesas (vermelho) da temporada, por linha do balanço.
class Bars extends Control:
	var rows: Array = []   # [rótulo, valor (+/−)]

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		resized.connect(queue_redraw)

	func _draw() -> void:
		if rows.is_empty() or size.x < 40.0:
			return
		var f := UI.bold()
		var mx := 0.001
		for r in rows:
			mx = maxf(mx, absf(float(r[1])))
		var rh: float = minf(34.0, size.y / float(rows.size()))
		var label_w: float = minf(190.0, size.x * 0.42)
		var val_w := 92.0
		var bar_w: float = maxf(size.x - label_w - val_w - 12.0, 20.0)
		for i in rows.size():
			var y := i * rh
			var v := float(rows[i][1])
			var col: Color = UI.NEON if v > 0.0 else Color("ff5a5a")
			draw_string(f, Vector2(0, y + rh * 0.62), str(rows[i][0]), HORIZONTAL_ALIGNMENT_LEFT, label_w - 6.0, 13, UI.MUTED)
			var bx := label_w
			draw_rect(Rect2(bx, y + rh * 0.28, bar_w, rh * 0.44), Color(1, 1, 1, 0.05))
			var w: float = bar_w * absf(v) / mx
			if absf(v) > 0.0005:
				w = maxf(w, 3.0)
			draw_rect(Rect2(bx, y + rh * 0.28, w, rh * 0.44), Color(col, 0.85))
			draw_rect(Rect2(bx, y + rh * 0.28, w, 2.0), Color(1, 1, 1, 0.18))
			draw_string(f, Vector2(bx + bar_w + 6.0, y + rh * 0.62), Money.fmt(absf(v)), HORIZONTAL_ALIGNMENT_RIGHT, val_w, 13,
				UI.GREEN_TXT if v > 0.0 else (UI.RED_TXT if v < 0.0 else UI.MUTED))


## Linha da evolução do caixa ao longo da temporada (com o zero marcado).
class Trend extends Control:
	var pts: Array = []   # [[dia, caixa], ...]

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		resized.connect(queue_redraw)

	func _draw() -> void:
		var f := UI.bold()
		var pad := Vector2(8, 10)
		var area := Rect2(pad, size - pad * 2.0 - Vector2(0, 14))
		draw_rect(area, Color(1, 1, 1, 0.03))
		if pts.size() < 2 or area.size.x < 20.0:
			draw_string(f, area.position + Vector2(10, area.size.y * 0.5), "O gráfico aparece depois das primeiras rodadas.", HORIZONTAL_ALIGNMENT_LEFT, area.size.x - 20.0, 13, UI.MUTED)
			return
		var lo := INF
		var hi := -INF
		for p in pts:
			lo = minf(lo, float(p[1]))
			hi = maxf(hi, float(p[1]))
		# escala só nos valores do caixa (o zero aparece quando a linha passa por ele)
		if hi - lo < 1.0:
			var c := (hi + lo) * 0.5
			lo = c - 0.5
			hi = c + 0.5
		var span := hi - lo
		lo -= span * 0.08
		hi += span * 0.08
		var x0 := float(pts[0][0])
		var x1 := maxf(float(pts[pts.size() - 1][0]), x0 + 1.0)
		var line := PackedVector2Array()
		for p in pts:
			var x := area.position.x + (float(p[0]) - x0) / (x1 - x0) * area.size.x
			var y := area.end.y - (float(p[1]) - lo) / (hi - lo) * area.size.y
			line.append(Vector2(x, y))
		var zy := area.end.y - (0.0 - lo) / (hi - lo) * area.size.y
		if zy > area.position.y and zy < area.end.y:
			draw_line(Vector2(area.position.x, zy), Vector2(area.end.x, zy), Color(1, 1, 1, 0.25), 1.0)
			draw_string(f, Vector2(area.position.x + 4, zy - 4), "0", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, UI.MUTED)
		# área sob a linha
		var poly := line.duplicate()
		poly.append(Vector2(line[line.size() - 1].x, area.end.y))
		poly.append(Vector2(line[0].x, area.end.y))
		draw_colored_polygon(poly, Color(UI.NEON, 0.10))
		draw_polyline(line, Color(UI.NEON, 0.35), 6.0, true)
		draw_polyline(line, UI.NEON, 2.5, true)
		var last := line[line.size() - 1]
		draw_circle(last, 5.0, UI.NEON)
		draw_string(f, Vector2(area.position.x, size.y - 4.0), "máx %s" % Money.fmt(hi - span * 0.08), HORIZONTAL_ALIGNMENT_LEFT, area.size.x * 0.5, 11, UI.MUTED)
		draw_string(f, Vector2(area.position.x + area.size.x * 0.5, size.y - 4.0), "mín %s" % Money.fmt(lo + span * 0.08), HORIZONTAL_ALIGNMENT_RIGHT, area.size.x * 0.5, 11, UI.MUTED)
