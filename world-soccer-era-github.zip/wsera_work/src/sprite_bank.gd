class_name SpriteBank
extends Node
## Banco de sprites dos bonecos da partida.
##
## As poses comuns (parado, caminhada, trote e corrida, nas vistas de frente, de costas e de
## lado) são desenhadas UMA vez pelo próprio código do boneco (LanceView._draw_player) num
## SubViewport em 2x e reduzidas pela metade (suaviza as bordas: o GLES3 não tem MSAA 2D).
## Cada lote assado vira uma textura pequena com mipmaps. Na partida cada jogador vira
## 2 retângulos de textura (corpo + cabeça) em vez de ~900 triângulos montados em GDScript.
##   corpo  : por (uniforme, cor da pele)  -> 3 vistas x 25 estados (1 parado + 3 andares x 8 fases)
##   cabeça : por jogador (pele, cabelo, estilo, barba, faixa) -> 3 vistas
## Enquanto a imagem não fica pronta o boneco é desenhado do jeito antigo (sem "buraco").
## Assa sozinho a partir do 1º desenho: no começo da partida isso acontece por baixo da tela
## de carregamento. Sem tela (testes headless) o banco fica desligado.

const BAKE_KU := 0.5                       ## px por unidade do corpo (100 = altura toda): ~nítido a 1:1 num celular 1920
const SS := 2                              ## superamostragem ao assar
const BODY_CELL := Vector2(32, 42)         ## célula (px) — 64 x 84 unidades
const BODY_ANCHOR := Vector2(16, 39)       ## pés dentro da célula
const HEAD_CELL := Vector2(24, 24)         ## 48 x 48 unidades
const HEAD_ANCHOR := Vector2(12, 12)       ## centro da cabeça
const STATES := 25                         ## 1 parado + 3 andares x 8 fases
const VP_COLS := 16                        ## lote: 16 x 6 células por renderização
const VP_ROWS := 6
const SHADOW_OFF := Vector2(-12, -6)       ## sombra (em unidades do corpo, relativa aos pés)
const SHADOW_SIZE := Vector2(50, 14)

static var _inst: SpriteBank = null
static var _enabled: int = -1

var _bodies: Dictionary = {}     ## chave -> Array de [textura, Rect2] por célula
var _heads: Dictionary = {}
var _left: Dictionary = {}       ## chave -> células que faltam (presente = ainda não pronto)
var _queue: Array = []           ## [parte, andar, fase, entidade falsa, kit, goleiro, juiz, índice, vista, chave, view(weakref)]
var _busy: bool = false
var _vp: SubViewport
var _baker: Node2D
var bake_ms: float = 0.0         ## tempo de CPU gasto assando (para medir)
var bake_max_ms: float = 0.0     ## maior lote
var textures: int = 0
var shadow: ImageTexture          ## sombra suave: contato sob os pés + sombra do sol na diagonal


static func enabled() -> bool:
	if _enabled < 0:
		_enabled = 0 if DisplayServer.get_name() == "headless" else 1
	return _enabled == 1


static func inst() -> SpriteBank:
	if _inst != null and is_instance_valid(_inst):
		return _inst
	if not enabled():
		return null
	var tree := Engine.get_main_loop() as SceneTree
	if tree == null:
		return null
	_inst = SpriteBank.new()
	tree.root.add_child.call_deferred(_inst)
	return _inst


## Velocidade usada ao assar cada andar (a mesma faixa que o boneco usa para escolher a pose).
static func gait_speed(gait: int, walk: float) -> float:
	return [0.0, walk * 0.9, walk + 1.8, walk + 3.6][gait]


func _init() -> void:
	# mesma sombra do boneco desenhado (elipse de contato + sol para a direita), suavizada
	var w := 100
	var h := 28
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	for y in h:
		for x in w:
			var u: float = SHADOW_OFF.x + (x + 0.5) / w * SHADOW_SIZE.x
			var v: float = SHADOW_OFF.y + (y + 0.5) / h * SHADOW_SIZE.y
			var d1: float = Vector2((u - 15.0) / 20.0, (v - 4.0) / 5.0).length()
			var d2: float = Vector2((u - 1.0) / 11.0, (v - 0.5) / 3.6).length()
			var a1: float = 0.16 * clampf((1.0 - d1) / 0.25, 0.0, 1.0)
			var a2: float = 0.30 * clampf((1.0 - d2) / 0.25, 0.0, 1.0)
			img.set_pixel(x, y, Color(0, 0, 0, 1.0 - (1.0 - a1) * (1.0 - a2)))
	img.generate_mipmaps()
	shadow = ImageTexture.create_from_image(img)


func _ready() -> void:
	_vp = SubViewport.new()
	_vp.size = Vector2i(int(BODY_CELL.x) * SS * VP_COLS, int(BODY_CELL.y) * SS * VP_ROWS)
	_vp.transparent_bg = true
	_vp.disable_3d = true
	_vp.render_target_update_mode = SubViewport.UPDATE_DISABLED
	_vp.render_target_clear_mode = SubViewport.CLEAR_MODE_ALWAYS
	add_child(_vp)
	_baker = Node2D.new()
	_vp.add_child(_baker)


## [textura, região] do corpo nesta vista/estado, ou [] se ainda não assou.
func body_cell(key: String, view: int, st: int) -> Array:
	if _left.has(key) or not _bodies.has(key):
		return []
	return _bodies[key][view * STATES + st]


func head_cell(key: String, view: int) -> Array:
	if _left.has(key) or not _heads.has(key):
		return []
	return _heads[key][view]


## Pede o corpo e a cabeça deste boneco (se ainda não existem). Barato quando já pedidos.
func request(view: Node, e: Dictionary, kit: Array, keeper: bool, ref_kit: bool) -> void:
	var bkey: String = e["_skey"]
	var hkey: String = e["_hkey"]
	var wr: WeakRef = weakref(view)
	if not _heads.has(hkey):
		var arr2: Array = []
		arr2.resize(3)
		_heads[hkey] = arr2
		_left[hkey] = 3
		for v in 3:
			# cabeças antes dos corpos: são poucas e liberam o boneco mais cedo
			_queue.push_front([2, 1, 0, _fake(e, v, 1), kit, keeper, ref_kit, v, v, hkey, wr])
	if not _bodies.has(bkey):
		var arr: Array = []
		arr.resize(3 * STATES)
		_bodies[bkey] = arr
		_left[bkey] = 3 * STATES
		for v in 3:
			for st in STATES:
				var gait: int = 0 if st == 0 else 1 + (st - 1) / 8
				var ph: int = 0 if st == 0 else (st - 1) % 8
				_queue.append([1, gait, ph, _fake(e, v, gait), kit, keeper, ref_kit, v * STATES + st, v, bkey, wr])


## Entidade só com o que o desenho do boneco lê, numa vista (0 frente, 1 costas, 2 lado).
func _fake(e: Dictionary, view: int, gait: int) -> Dictionary:
	var f := {"p": e.get("p", {"id": 0}), "num": e.get("num", 0), "skin": e["skin"], "hair": e["hair"],
		"pos": Vector2.ZERO, "ph": 0.0, "moving": gait > 0 or view == 2, "spd": 0.0,
		"face": 1.0 if view != 1 else -1.0}
	if e.has("_look"):
		f["_look"] = e["_look"]
	return f


func _process(_delta: float) -> void:
	if _busy or _queue.is_empty():
		return
	_bake_chunk()


func _bake_chunk() -> void:
	_busy = true
	var t0 := Time.get_ticks_usec()
	var cells: Array = []
	var placed: Array = []
	var view: Node = null
	var n: int = VP_COLS * VP_ROWS
	while placed.size() < n and not _queue.is_empty():
		var q: Array = _queue.pop_front()
		var v: Node = (q[10] as WeakRef).get_ref()
		if v == null or not is_instance_valid(v):
			# quem pediu saiu de cena: esquece a chave (a próxima tela que precisar pede de novo)
			_bodies.erase(q[9])
			_heads.erase(q[9])
			_left.erase(q[9])
			continue
		if not _left.has(q[9]):
			continue
		if view == null:
			view = v
		var k: int = placed.size()
		var origin := Vector2((k % VP_COLS) * BODY_CELL.x, (k / VP_COLS) * BODY_CELL.y)
		var f: Dictionary = (q[3] as Dictionary).duplicate()
		var ys: float = float(view.get("y_sign"))
		var walk: float = float(view.get("_b_walk"))
		var vi: int = int(q[8])
		var gait: int = int(q[1])
		f["dir"] = [Vector2(0, ys), Vector2(0, -ys), Vector2(1, 0)][vi]
		f["spd"] = SpriteBank.gait_speed(maxi(gait, 1 if vi == 2 else 0), walk)
		f["screen"] = (origin + (BODY_ANCHOR if int(q[0]) == 1 else HEAD_ANCHOR)) * SS
		cells.append([q[0], gait, q[2], f, q[4], q[5], q[6]])
		placed.append([origin, q[0], q[7], q[9]])
	if cells.is_empty():
		_busy = false
		return
	var rid := _baker.get_canvas_item()
	RenderingServer.canvas_item_clear(rid)
	view.call("bake_emit", rid, cells, BAKE_KU * SS)
	_vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	var cpu: float = (Time.get_ticks_usec() - t0) / 1000.0
	await RenderingServer.frame_post_draw
	t0 = Time.get_ticks_usec()
	var img: Image = _vp.get_texture().get_image()
	if img != null and not img.is_empty():
		img.convert(Image.FORMAT_RGBA8)
		img.resize(img.get_width() / SS, img.get_height() / SS, Image.INTERPOLATE_CUBIC)
		img.generate_mipmaps()
		var tex := ImageTexture.create_from_image(img)
		textures += 1
		for pl in placed:
			var key: String = pl[3]
			if not _left.has(key):
				continue
			var sz: Vector2 = BODY_CELL if int(pl[1]) == 1 else HEAD_CELL
			var arr: Array = _bodies[key] if int(pl[1]) == 1 else _heads[key]
			arr[int(pl[2])] = [tex, Rect2(pl[0], sz)]
			_left[key] = int(_left[key]) - 1
			if int(_left[key]) <= 0:
				_left.erase(key)
	RenderingServer.canvas_item_clear(rid)
	cpu += (Time.get_ticks_usec() - t0) / 1000.0
	bake_ms += cpu
	bake_max_ms = maxf(bake_max_ms, cpu)
	_busy = false
	if _queue.is_empty() and OS.get_environment("SPRITE_DEBUG") != "":
		print("SPRITES prontos: corpos %d, cabeças %d, texturas %d, assar %.0f ms (maior lote %.0f ms)" % [
			_bodies.size(), _heads.size(), textures, bake_ms, bake_max_ms])
