extends RefCounted
# Escalação, elenco, perfil do jogador, base, mercado, contrato e vendas.

var m
var sel_slot: int = -1
var mk_tab: int = 0
var mk_pos: int = -1
var c_pid: int = -1
var c_fee: float = 0.0
var c_wage: float = 0.0
var c_years: int = 3
var r_pid: int = -1      ## renovação em negociação
var r_wage: float = 0.0
var r_years: int = 3
var r_role: String = "rodizio"
var r_msg: String = ""
var l_pid: int = -1      ## pedido de empréstimo
var l_half: bool = false
var l_pct: int = 50
var l_buy: bool = false


func _init(main) -> void:
	m = main


# ------------------------------------------------------------ escalação
func lineup(root: Control, _arg) -> void:
	var cid: int = Game.S["club"]
	var me: Dictionary = Game.my_club()
	Game.validate_xi(cid)
	m.head("Escalação", "Toque em um jogador no campo e depois em outro (ou num reserva) para trocar")
	var hb := UI.hbox(16)
	root.add_child(hb)
	var rt: Dictionary = Game.ratings(cid)

	var left := UI.vbox(8)
	UI.expand(left, 1.0)
	hb.add_child(left)
	var fh := UI.hbox(8)
	fh.add_child(UI.fixed(UI.button("‹", "dark", _formation.bind(-1), 22, 40), 50))
	fh.add_child(UI.fixed(UI.center(UI.label(me["formation"], 21, UI.TXT, true)), 110))
	fh.add_child(UI.fixed(UI.button("›", "dark", _formation.bind(1), 22, 40), 50))
	fh.add_child(UI.spacer())
	fh.add_child(UI.label("GER %d" % rt["ger"], 21, UI.GOLD, true))
	left.add_child(fh)
	var pitch := PitchView.new()
	pitch.mode = "lineup"
	pitch.cid = cid
	pitch.selected = sel_slot
	UI.vexpand(pitch)
	pitch.slot_pressed.connect(_slot)
	left.add_child(pitch)

	var right := UI.vbox(8)
	UI.expand(right, 1.0)
	hb.add_child(right)
	right.add_child(_fitness_bar(cid))
	var bench_l := Game.bench(cid)
	var bh0 := UI.hbox(8)
	bh0.add_child(UI.expand(UI.section("BANCO (%d/%d)" % [bench_l.size(), Game.bench_max()])))
	bh0.add_child(UI.fixed(UI.button("Banco automático" if me.get("bench_manual", false) else "Banco: automático", "dark", func():
		Game.bench_auto()
		Game.save()
		m.refresh(), 13, 36), 170))
	right.add_child(bh0)
	var sc := UI.scroll()
	UI.vexpand(sc)
	right.add_child(sc)
	var lv0 := UI.vbox(8)
	UI.expand(lv0)
	sc.add_child(lv0)
	var g := UI.grid(3, 8)
	UI.expand(g)
	lv0.add_child(g)
	for p in bench_l:
		g.add_child(_reserve_card(p, cid, true))
	var others := Game.not_listed(cid)
	if not others.is_empty():
		lv0.add_child(UI.section("NÃO RELACIONADOS (%d)" % others.size()))
		var g2 := UI.grid(3, 8)
		UI.expand(g2)
		lv0.add_child(g2)
		for p in others:
			g2.add_child(_reserve_card(p, cid, false))
	right.add_child(UI.label("DEF %d    MEI %d    ATQ %d" % [rt["def"], rt["mei"], rt["atq"]], 18, UI.TXT, true))
	var bh := UI.hbox(8)
	if sel_slot >= 0 and sel_slot < me["xi"].size():
		var sp: Dictionary = Game.player(me["xi"][sel_slot])
		bh.add_child(UI.expand(UI.label("Selecionado: %s" % sp["name"], 15, UI.GOLD, true)))
		bh.add_child(UI.fixed(UI.button("Perfil", "dark", func(): m.go("player", sp["id"]), 16, 44), 110))
	else:
		bh.add_child(UI.expand(UI.label("Borda vermelha = fora de posição", 14, UI.MUTED)))
	bh.add_child(UI.fixed(UI.button("Escalar melhor", "blue", func():
		Game.auto_lineup(Game.S["club"])
		sel_slot = -1
		Game.save()
		m.refresh(), 16, 44), 170))
	right.add_child(bh)


## Treino da semana (leve / normal / forte) e aviso de titulares cansados.
func _fitness_bar(cid: int) -> Control:
	var v := UI.vbox(6)
	var th := UI.hbox(6)
	th.add_child(UI.fixed(UI.label("TREINO", 13, UI.MUTED, true), 64))
	var cur := Fitness.training_mode()
	for k in ["leve", "normal", "forte"]:
		var kk: String = k
		var b := UI.button(Fitness.TRAINING_NAMES[k], "gold" if cur == k else "dark", func():
			Game.S["training"] = kk
			Game.save()
			m.refresh(), 14, 34)
		UI.expand(b)
		th.add_child(b)
	v.add_child(th)
	var tip := {"leve": "Recupera mais rápido; ninguém evolui no treino.", "normal": "Equilíbrio entre recuperação e evolução.",
		"forte": "Jovens evoluem mais, mas o elenco recupera menos e o risco de lesão sobe."}
	v.add_child(UI.label(tip[cur], 12, UI.MUTED))
	var tired := Fitness.tired_starters(cid)
	if not tired.is_empty():
		var wp := UI.panel(Color(1.0, 0.35, 0.3, 0.14), 8, 10)
		var names: Array = tired.map(func(x): return "%s %d%%" % [x["name"], int(x["energy"])])
		wp.add_child(UI.wrap(UI.label("⚠ %d titular(es) cansado(s): %s" % [tired.size(), ", ".join(names.slice(0, 4))], 13, Color("ffb3ad"), true)))
		v.add_child(wp)
	return v


func _formation(d: int) -> void:
	var me: Dictionary = Game.my_club()
	var i: int = Game.FORMATION_NAMES.find(me["formation"])
	me["formation"] = Game.FORMATION_NAMES[posmod(i + d, Game.FORMATION_NAMES.size())]
	Game.auto_lineup(Game.S["club"])
	sel_slot = -1
	Game.save()
	m.refresh()


func _slot(i: int) -> void:
	var xi: Array = Game.my_club()["xi"]
	if sel_slot < 0:
		sel_slot = i
	elif sel_slot == i:
		sel_slot = -1
	else:
		var t = xi[sel_slot]
		xi[sel_slot] = xi[i]
		xi[i] = t
		sel_slot = -1
		Game.save()
	m.refresh()


func _bench(pid: int) -> void:
	if sel_slot < 0:
		m.go("player", pid)
		return
	Game.swap_into_xi(sel_slot, pid)
	sel_slot = -1
	Game.save()
	m.refresh()


## Cartão de reserva: toque = entra no lugar do titular selecionado (ou abre o perfil);
## botão ao lado = relacionar / tirar do banco.
func _reserve_card(p: Dictionary, cid: int, on_bench: bool) -> Control:
	var row := UI.hbox(4)
	var v := UI.vbox(2)
	var h := UI.hbox(6)
	h.add_child(ChibiPortrait.make(ChibiPortrait.for_player(p, ChibiPortrait.club_kit(cid)), 30.0, "head"))
	h.add_child(UI.pos_tag(p["pos"], 13))
	h.add_child(UI.label(str(p["ovr"]), 20, UI.TXT if on_bench else UI.MUTED, true))
	v.add_child(h)
	var nl := UI.label(p["name"] + ("  ✎" if Contracts.expiring(p) else ""), 13, UI.MUTED)
	nl.clip_text = true
	v.add_child(nl)
	v.add_child(UI.bar(float(p["energy"]) / 100.0, Fitness.color(float(p["energy"])), 4))
	var b := UI.row_button(v, _bench.bind(p["id"]), 72, "dark" if on_bench else "flat", 8)
	UI.expand(b)
	row.add_child(b)
	var tg := UI.button("−" if on_bench else "+", "flat" if on_bench else "gold", func():
		var res := Game.bench_toggle(p["id"])
		if res != "":
			m.toast(res)
		Game.save()
		m.refresh(), 20, 72)
	tg.tooltip_text = "Tirar do banco" if on_bench else "Relacionar para o banco"
	row.add_child(UI.fixed(tg, 40))
	UI.expand(row)
	return row


# ------------------------------------------------------------ listas de jogadores
func _list_header(cols: Array) -> Control:
	var hh := UI.hbox(8)
	hh.add_child(UI.fixed(Control.new(), 50))
	hh.add_child(UI.expand(UI.label("JOGADOR", 13, UI.MUTED, true)))
	for c in cols:
		hh.add_child(UI.col(c[0], c[1], 13, UI.MUTED, true))
	var hm := MarginContainer.new()
	hm.add_theme_constant_override("margin_left", 10)
	hm.add_theme_constant_override("margin_right", 10)
	hm.add_child(hh)
	return hm


func _player_row(p: Dictionary, cells: Array, cb: Callable, suffix: String = "") -> Button:
	var h := UI.hbox(8)
	h.add_child(UI.pos_tag(p["pos"]))
	h.add_child(ChibiPortrait.make(ChibiPortrait.for_player(p, ChibiPortrait.club_kit(int(p["club"]))), 38.0, "head"))
	var nv := UI.vbox(0)
	UI.expand(nv)
	nv.alignment = BoxContainer.ALIGNMENT_CENTER
	var nl := UI.label(str(p["name"]) + suffix, 17, UI.TXT, true)
	nl.clip_text = true
	nv.add_child(nl)
	h.add_child(nv)
	for c in cells:
		if c[0] is Control:
			var holder := UI.fixed(c[0], c[1])
			holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
			h.add_child(holder)
		else:
			h.add_child(UI.col(c[0], c[1], 16, c[2] if c.size() > 2 else UI.TXT, c.size() > 2))
	return UI.row_button(h, cb, 48, "flat", 10)



func squad(root: Control, _arg) -> void:
	var list := Game.squad(Game.S["club"])
	m.head("Elenco", "%d jogadores • toque para ver o perfil" % list.size())
	var v := UI.vbox(6)
	root.add_child(v)
	v.add_child(_list_header([["PAÍS", 56], ["IDADE", 60], ["GER", 56], ["ENERGIA", 80], ["J", 44], ["G", 44], ["A", 44], ["VALOR", 110]]))
	var sc := UI.scroll()
	v.add_child(sc)
	var lv := UI.vbox(4)
	UI.expand(lv)
	sc.add_child(lv)
	for p in list:
		var nm_extra := "  (à venda)" if p["listed"] else ""
		if p.has("loan"):
			nm_extra += "  (emprestado)"
		elif Contracts.expiring(p):
			nm_extra += "  ✎ contrato a vencer" if not p.get("renew", {}).get("refused", false) else "  ✖ sai no fim do contrato"
		lv.add_child(_player_row(p, [[p["nat"], 56], [str(p["age"]), 60], [str(p["ovr"]), 56, UI.GOLD], [Fitness.energy_cell(p), 80],
			[str(p["g"]), 44], [str(p["gol"]), 44], [str(p["ass"]), 44], [Game.money(p["value"]), 110]], func(): m.go("player", p["id"]), nm_extra))


# ------------------------------------------------------------ perfil
func player(root: Control, arg) -> void:
	var pid: int = int(arg)
	if not Game.S["players"].has(pid):
		m.head("Jogador", "")
		root.add_child(UI.label("Este jogador não está mais disponível.", 18, UI.MUTED))
		return
	var p: Dictionary = Game.player(pid)
	var me_cid: int = Game.S["club"]
	var loan_in: bool = p.has("loan") and int(p["loan"]["to"]) == me_cid
	var loan_out: bool = p.has("loan") and int(p["loan"]["from"]) == me_cid
	var mine: bool = p["club"] == me_cid and not loan_in
	m.head(p["name"], "História, conquistas e vínculo com a torcida")
	var hb := UI.hbox(14)
	root.add_child(hb)

	var lp := UI.panel(UI.PANEL, 20)
	UI.expand(lp, 1.25)
	var lv := UI.vbox(8)
	lp.add_child(lv)
	var st: String = Game.status(p) if p["club"] >= 0 else ("JOVEM DA BASE" if p["club"] == Game.YOUTH else "JOGADOR LIVRE")
	var ph := UI.hbox(14)
	ph.add_child(ChibiPortrait.make(ChibiPortrait.for_player(p, ChibiPortrait.club_kit(int(p["club"]))), 96.0, "bust"))
	var pv := UI.vbox(4)
	pv.alignment = BoxContainer.ALIGNMENT_CENTER
	var sh := UI.hbox(8)
	if int(p["ovr"]) >= 85:
		sh.add_child(UI.crown(24, UI.TROPHY))   # craque: coroa da marca
	sh.add_child(UI.label(st, 32, UI.GOLD, true))
	pv.add_child(sh)
	ph.add_child(pv)
	lv.add_child(ph)
	var th := UI.hbox(8)
	th.add_child(UI.pos_tag(p["pos"]))
	th.add_child(UI.label("%d anos • %s • %s" % [p["age"], p["nat"], Game.club_name(p["club"])], 16, UI.MUTED))
	lv.add_child(th)
	if p["club"] >= 0:
		lv.add_child(UI.label("Tempo de clube: %d ano(s)" % (Game.S["season"] - int(p["joined"])), 20, UI.TXT, true))
		lv.add_child(UI.label("Participação: %d min • %d gols • %d assistências" % [p["cmin"], p["cgol"], p["cass"]], 17))
		lv.add_child(UI.label("%d título(s)" % p["titles"].size(), 19, UI.TXT, true))
	var g := UI.grid(4, 10)
	var pot_txt: String = str(p["pot"])
	if p["age"] < 24:
		pot_txt = "%d–%d" % [int(p["pot"]) - 2, mini(int(p["pot"]) + 2, 99)]
	var attrs := [["GER", str(p["ovr"])], ["POTENCIAL", pot_txt], ["ENERGIA", ("LESIONADO (%s)" % p.get("injury", "")) if int(p.get("susp", 0)) > 0 and str(p.get("injury", "")) != "" else "%d%% • %s" % [int(p["energy"]), Fitness.label(p)]], ["CONTRATO", _contract_txt(p)],
		["VALOR", Game.money(p["value"])], ["SALÁRIO/SEM", Money.wage_short(p["wage"])]]
	for a in attrs:
		var ap := UI.panel(Color(1, 1, 1, 0.05), 8, 8)
		UI.expand(ap)
		var av := UI.vbox(0)
		ap.add_child(av)
		av.add_child(UI.label(a[0], 12, UI.MUTED, true))
		av.add_child(UI.label(a[1], 18, UI.TXT, true))
		g.add_child(ap)
	lv.add_child(g)
	lv.add_child(UI.spacer())
	if mine:
		lv.add_child(UI.label("Ídolos exigem tempo e feitos históricos.", 14, UI.MUTED))
		lv.add_child(UI.label("Vender um ídolo: −25 de apoio da torcida.", 14, Color("f0a57a"), true))
	hb.add_child(lp)

	var rp := UI.panel(UI.PANEL, 20)
	UI.expand(rp, 1.0)
	var rv := UI.vbox(8)
	rp.add_child(rv)
	rv.add_child(UI.label("TÍTULOS", 20, UI.TXT, true))
	if p["titles"].is_empty():
		rv.add_child(UI.label("Nenhum título pelo clube ainda.", 15, UI.MUTED))
	else:
		var cnt := {}
		for t in p["titles"]:
			cnt[t] = int(cnt.get(t, 0)) + 1
		for t in cnt.keys():
			var h := UI.hbox(8)
			h.add_child(UI.label("%d×" % cnt[t], 22, UI.GOLD, true))
			h.add_child(UI.label(t, 17))
			rv.add_child(h)
	rv.add_child(UI.label("NESTA TEMPORADA", 14, UI.MUTED, true))
	rv.add_child(UI.label("%d jogos • %d min • %d gols • %d assistências" % [p["g"], p["min"], p["gol"], p["ass"]], 16))
	if p.has("loan"):
		var ls := Loans.stats(p)
		var ln: Dictionary = p["loan"]
		rv.add_child(UI.section("EMPRÉSTIMO"))
		rv.add_child(UI.label("%s → %s %s" % [Game.club_name(int(ln["from"])), Game.club_name(int(ln["to"])), Loans.ends_text(p)], 15, UI.TXT, true))
		rv.add_child(UI.label("Salário: %d%% pago pelo %s • %d jogos, %d gols, %d assist. no empréstimo" % [ln["pct"], Game.club_name(int(ln["to"])), ls["g"], ls["gol"], ls["ass"]], 13, UI.MUTED))
		if float(ln["buy"]) > 0.0:
			rv.add_child(UI.label("Opção de compra: %s" % Game.money(ln["buy"]), 13, UI.NEON, true))
	rv.add_child(UI.spacer())
	if loan_in:
		if float(p["loan"]["buy"]) > 0.0:
			rv.add_child(UI.button("Exercer opção de compra (%s)" % Game.money(p["loan"]["buy"]), "gold", func():
				var r := Loans.buy_option(pid)
				m.refresh()
				m.toast("Jogador comprado em definitivo!" if r == "" else r)))
	elif loan_out:
		rv.add_child(UI.button("Chamar de volta", "gold" if Loans.can_recall(p) else "dark", func():
			var r := Loans.recall(pid)
			m.refresh()
			m.toast("%s voltou ao elenco." % p["name"] if r == "" else r)))
	elif mine and not p.get("me", false):
		if int(p["contract"]) <= 2:
			var refused: bool = p.get("renew", {}).get("refused", false)
			rv.add_child(UI.button("Renovar contrato  ›" if not refused else "Recusou renovar (sai no fim do contrato)", "gold" if not refused else "dark",
				func(): m.go("contract", {"renew": pid}), 16, 48))
		var lh := UI.hbox(8)
		lh.add_child(UI.expand(UI.button("Emprestar (meia temp.)", "dark", _loan_out.bind(pid, true), 14, 42)))
		lh.add_child(UI.expand(UI.button("Emprestar (temp. inteira)", "dark", _loan_out.bind(pid, false), 14, 42)))
		rv.add_child(lh)
		rv.add_child(UI.button("Rescindir contrato (multa %s)" % Game.money(Contracts.release_cost(p)), "flat", func():
			var r := Contracts.release(pid)
			if r == "":
				m.back()
				m.toast("%s foi dispensado." % p["name"])
			else:
				m.toast(r), 14, 40))
		rv.add_child(UI.button("Retirar da lista de venda" if p["listed"] else "Colocar à venda", "dark" if p["listed"] else "gold", func():
			p["listed"] = not p["listed"]
			Game.save()
			m.refresh()
			m.toast("Os clubes interessados vão mandar propostas nas próximas rodadas." if p["listed"] else "Jogador retirado da lista.")))
	elif p["club"] == Game.YOUTH:
		rv.add_child(UI.button("Promover ao profissional", "gold", _promote.bind(pid)))
	elif p["club"] >= 0 and not p.has("loan") and not mine:
		var bh2 := UI.hbox(8)
		bh2.add_child(UI.expand(UI.button("Negociar compra  ›", "blue", func(): m.go("contract", pid))))
		bh2.add_child(UI.expand(UI.button("Pedir emprestado  ›", "dark", func(): m.go("contract", {"loan": pid}))))
		rv.add_child(bh2)
	elif p["club"] == Game.FREE:
		rv.add_child(UI.button("Negociar  ›", "blue", func(): m.go("contract", pid)))
	hb.add_child(rp)


func _contract_txt(p: Dictionary) -> String:
	if int(p["club"]) < 0:
		return "—"
	var n: int = int(p["contract"])
	if n <= 1:
		return "Fim da temporada"
	return "%d temporada(s)" % n


func _loan_out(pid: int, half: bool) -> void:
	var r := Loans.offer_out(pid, half)
	if r["ok"]:
		m.back()
	else:
		m.refresh()
	m.toast(r["text"])


func _promote(pid: int) -> void:
	var res := Game.promote_youth(pid)
	if res == "":
		m.back()
		m.toast("Jovem promovido ao elenco profissional.")
	else:
		m.toast(res)


# ------------------------------------------------------------ base
func youth(root: Control, _arg) -> void:
	var list := Game.squad(Game.YOUTH)
	m.head("Base do clube", "%s • %d jovens na base" % [Game.my_club()["name"], list.size()])
	var v := UI.vbox(6)
	root.add_child(v)
	v.add_child(UI.label("NOVOS JOVENS A CADA 6 MESES", 14, UI.GOLD, true))
	v.add_child(UI.label("Você decide quem sobe ao profissional. Quem fica continua evoluindo até os 20 anos.", 14, UI.MUTED))
	v.add_child(_list_header([["IDADE", 60], ["GER", 60], ["POTENCIAL", 110], ["EVOLUÇÃO", 130], ["", 130]]))
	var sc := UI.scroll()
	v.add_child(sc)
	var lv := UI.vbox(5)
	UI.expand(lv)
	sc.add_child(lv)
	if list.is_empty():
		lv.add_child(UI.label("Nenhum jovem no momento. A próxima captação traz novos nomes.", 16, UI.MUTED))
	list.sort_custom(func(a, b): return a["pot"] > b["pot"])
	for p in list:
		var pn := UI.panel(Color(1, 1, 1, 0.05), 8, 8)
		var st: StyleBoxFlat = pn.get_theme_stylebox("panel")
		st.content_margin_left = 10
		st.content_margin_right = 10
		var h := UI.hbox(8)
		pn.add_child(h)
		h.add_child(UI.pos_tag(p["pos"]))
		h.add_child(ChibiPortrait.make(ChibiPortrait.for_player(p, ChibiPortrait.club_kit(Game.S["club"])), 38.0, "head"))
		var nv := UI.vbox(0)
		UI.expand(nv)
		nv.add_child(UI.label(p["name"], 17, UI.TXT, true))
		nv.add_child(UI.label(p["nat"], 12, UI.MUTED))
		h.add_child(nv)
		h.add_child(UI.col(str(p["age"]), 60, 16))
		h.add_child(UI.col(str(p["ovr"]), 60, 18, UI.TXT, true))
		h.add_child(UI.col("%d–%d" % [int(p["pot"]) - 2, int(p["pot"]) + 2], 110, 16, UI.GOLD, true))
		var stars := UI.hbox(4)
		stars.custom_minimum_size = Vector2(130, 0)
		stars.alignment = BoxContainer.ALIGNMENT_CENTER
		var n: int = clampi(int((int(p["pot"]) - int(p["ovr"])) / 5.0), 1, 5)
		for i in 5:
			var cr := ColorRect.new()
			cr.color = UI.GOLD if i < n else Color(1, 1, 1, 0.12)
			cr.custom_minimum_size = Vector2(16, 8)
			cr.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
			stars.add_child(cr)
		h.add_child(stars)
		h.add_child(UI.fixed(UI.button("Promover", "blue", _promote_here.bind(p["id"]), 15, 38), 130))
		lv.add_child(pn)


func _promote_here(pid: int) -> void:
	var res := Game.promote_youth(pid)
	if res == "":
		m.refresh()
		m.toast("Jovem promovido ao elenco profissional.")
	else:
		m.toast(res)


# ------------------------------------------------------------ mercado
func market(root: Control, _arg) -> void:
	m.head("Contratar jogadores", "Observe o atleta e envie uma proposta")
	var v := UI.vbox(8)
	root.add_child(v)
	var top := UI.hbox(8)
	var names := ["Livres", "Destaques", "Empréstimos", "Meu elenco"]
	for i in names.size():
		top.add_child(UI.fixed(UI.button(names[i], "gold" if i == mk_tab else "dark", _mk_tab.bind(i), 16, 42), 150))
	top.add_child(UI.spacer())
	var ptxt := "Todas" if mk_pos < 0 else str(Game.POS_ORDER[mk_pos])
	top.add_child(UI.fixed(UI.button("Posição: %s  ›" % ptxt, "dark", func():
		mk_pos += 1
		if mk_pos >= Game.POS_ORDER.size():
			mk_pos = -1
		m.refresh(), 16, 42), 220))
	v.add_child(top)
	v.add_child(_list_header([["PAÍS", 56], ["GER", 56], ["IDADE", 60], ["VALOR", 120], ["CLUBE", 170]]))
	var sc := UI.scroll()
	v.add_child(sc)
	var lv := UI.vbox(4)
	UI.expand(lv)
	sc.add_child(lv)
	var list: Array = []
	if mk_tab == 0:
		list = Game.squad(Game.FREE)
	elif mk_tab == 3:
		list = Game.squad(Game.S["club"])
	elif mk_tab == 2:
		list = Loans.available_in()
	else:
		for p in Game.S["players"].values():
			if p["club"] >= 0 and p["club"] != Game.S["club"]:
				list.append(p)
	if mk_pos >= 0:
		list = list.filter(func(p): return p["pos"] == Game.POS_ORDER[mk_pos])
	list.sort_custom(func(a, b):
		if a["ovr"] != b["ovr"]:
			return a["ovr"] > b["ovr"]
		return a["id"] < b["id"])
	if list.size() > 40:
		list = list.slice(0, 40)
	if list.is_empty():
		lv.add_child(UI.label("Ninguém encontrado com esse filtro.", 16, UI.MUTED))
	for p in list:
		var val := "Livre" if p["club"] == Game.FREE else Game.money(p["value"])
		var target := "player" if mk_tab == 3 else "contract"
		var arg = {"loan": p["id"]} if mk_tab == 2 else p["id"]
		if mk_tab == 2:
			val = "%d%% sal." % int(Loans.terms_in(p)["pct"])
		var sfx := "  (emprestado)" if p.has("loan") else ""
		lv.add_child(_player_row(p, [[p["nat"], 56], [str(p["ovr"]), 56, UI.GOLD], [str(p["age"]), 60], [val, 120], [Game.club_name(p["club"]), 170]],
			func(): m.go(target, arg), sfx))


func _mk_tab(i: int) -> void:
	mk_tab = i
	m.refresh()


# ------------------------------------------------------------ contrato
func contract(root: Control, arg) -> void:
	if typeof(arg) == TYPE_DICTIONARY:
		if arg.has("renew"):
			_renew_screen(root, int(arg["renew"]))
		elif arg.has("loan"):
			_loan_screen(root, int(arg["loan"]))
		return
	var pid: int = int(arg)
	var p: Dictionary = Game.player(pid)
	var free: bool = p["club"] == Game.FREE
	if c_pid != pid:
		c_pid = pid
		c_fee = 0.0 if free else float(p["value"])
		c_wage = float(p["wage"])
		c_years = 3
	m.head("Contrato com o jogador", "Atleta livre • negocie salário e duração direto com ele" if free else "Negocie com o %s e com o atleta" % Game.club_name(p["club"]))
	var v := UI.vbox(12)
	root.add_child(v)
	var hb := UI.hbox(14)
	UI.vexpand(hb)
	v.add_child(hb)

	var lp := UI.panel(UI.PANEL, 18)
	lp.custom_minimum_size = Vector2(330, 0)
	var lv := UI.vbox(6)
	lp.add_child(lv)
	var th := UI.hbox()
	th.add_child(UI.pos_tag(p["pos"]))
	lv.add_child(th)
	lv.add_child(UI.label(p["name"], 22, UI.TXT, true))
	lv.add_child(UI.label("%d anos • %s" % [p["age"], p["nat"]], 15, UI.MUTED))
	lv.add_child(UI.label("GER %d" % p["ovr"], 20, UI.GOLD, true))
	lv.add_child(UI.label(Game.club_name(p["club"]), 15, UI.MUTED))
	lv.add_child(UI.spacer())
	lv.add_child(UI.label("Valor de mercado: %s" % Game.money(p["value"]), 14, UI.MUTED))
	lv.add_child(UI.label("Salário atual: %s" % Money.wage(p["wage"]), 14, UI.MUTED))
	lv.add_child(UI.button("Ver perfil", "dark", func(): m.go("player", pid), 15, 40))
	hb.add_child(lp)

	var rp := UI.panel(UI.PANEL, 18)
	UI.expand(rp)
	var rv := UI.vbox(12)
	rp.add_child(rv)
	if free:
		rv.add_child(UI.label("NEGOCIAÇÃO DIRETA", 15, UI.GOLD, true))
		rv.add_child(UI.label("Sem pagamento a outro clube e sem luvas.", 14, UI.MUTED))
	else:
		var step: float = maxf(snappedf(float(p["value"]) * 0.05, 0.01), 0.01)
		rv.add_child(UI.field("PROPOSTA AO CLUBE", UI.stepper(Game.money(c_fee), _fee.bind(-step), _fee.bind(step), 190)))
	var ws: float = maxf(snappedf(float(p["wage"]) * 0.05, 0.1), 0.1)
	var row := UI.hbox(30)
	row.add_child(UI.field("SALÁRIO / SEMANA", UI.stepper(Money.wage_short(c_wage), _wage.bind(-ws), _wage.bind(ws), 150)))
	row.add_child(UI.field("DURAÇÃO", UI.stepper("%d ano(s)" % c_years, _years.bind(-1), _years.bind(1), 120)))
	rv.add_child(row)
	rv.add_child(UI.spacer())
	rv.add_child(UI.label("Seu caixa: %s" % Game.money(Game.S["money"]), 16, UI.MUTED, true))
	hb.add_child(rp)

	var bh := UI.hbox(12)
	bh.add_child(UI.fixed(UI.button("Cancelar negociação", "dark", func(): m.back()), 280))
	bh.add_child(UI.expand(UI.button("Enviar contrato ao jogador", "blue", _send.bind(pid))))
	v.add_child(bh)


func _fee(d: float) -> void:
	c_fee = maxf(snappedf(c_fee + d, 0.01), 0.0)
	m.refresh()


func _wage(d: float) -> void:
	c_wage = maxf(snappedf(c_wage + d, 0.1), 0.5)
	m.refresh()


func _years(d: int) -> void:
	c_years = clampi(c_years + d, 1, 5)
	m.refresh()


func _send(pid: int) -> void:
	var res := Game.sign_player(pid, c_fee, c_wage, c_years)
	if res == "":
		c_pid = -1
		m.back()
		m.toast("Negócio fechado! O jogador já está no seu elenco.")
	else:
		m.toast(res)


# ------------------------------------------------------------ propostas e vendas
func offers(root: Control, _arg) -> void:
	m.head("Propostas e vendas", "Decida o que fazer com cada proposta")
	var sc := UI.scroll()
	root.add_child(sc)
	var v := UI.vbox(6)
	UI.expand(v)
	sc.add_child(v)
	v.add_child(UI.label("PROPOSTAS NA MESA", 14, UI.GOLD, true))
	if Game.S["offers"].is_empty():
		v.add_child(UI.label("Nenhuma proposta no momento.", 16, UI.MUTED))
	for i in Game.S["offers"].size():
		var o: Dictionary = Game.S["offers"][i]
		if not Game.S["players"].has(o["pid"]):
			continue
		var p: Dictionary = Game.player(o["pid"])
		var pn := UI.panel(Color(1, 1, 1, 0.05), 10, 8)
		var h := UI.hbox(10)
		pn.add_child(h)
		h.add_child(UI.pos_tag(p["pos"]))
		var nv := UI.vbox(0)
		UI.expand(nv)
		nv.add_child(UI.label("%s • GER %d" % [p["name"], p["ovr"]], 17, UI.TXT, true))
		nv.add_child(UI.label("%s • valor de mercado %s" % [Game.status(p), Game.money(p["value"])], 13, UI.MUTED))
		h.add_child(nv)
		h.add_child(Crest.make(o["club"], 30))
		h.add_child(UI.col(Game.money(o["value"]), 130, 18, UI.GOLD, true))
		h.add_child(UI.fixed(UI.button("Aceitar", "green", _accept.bind(i), 15, 40), 110))
		h.add_child(UI.fixed(UI.button("Recusar", "dark", _reject.bind(i), 15, 40), 110))
		v.add_child(pn)
	var lo: Array = Loans.offers()
	v.add_child(UI.label("PEDIDOS DE EMPRÉSTIMO", 14, UI.GOLD, true))
	if lo.is_empty():
		v.add_child(UI.label("Nenhum clube pediu seus jogadores emprestados.", 15, UI.MUTED))
	for i in lo.size():
		var o: Dictionary = lo[i]
		if not Game.S["players"].has(o["pid"]):
			continue
		var p: Dictionary = Game.player(o["pid"])
		var pn := UI.panel(Color(1, 1, 1, 0.05), 10, 8)
		var h := UI.hbox(10)
		pn.add_child(h)
		h.add_child(UI.pos_tag(p["pos"]))
		var nv := UI.vbox(0)
		UI.expand(nv)
		nv.add_child(UI.label("%s • GER %d • %d anos" % [p["name"], p["ovr"], p["age"]], 17, UI.TXT, true))
		nv.add_child(UI.label("%s • paga %d%% do salário%s" % ["meia temporada" if o.get("half", false) else "temporada inteira", o["pct"],
			(" • opção de compra " + Game.money(o["buy"])) if float(o.get("buy", 0.0)) > 0.0 else ""], 13, UI.MUTED))
		h.add_child(nv)
		h.add_child(Crest.make(o["club"], 30))
		h.add_child(UI.fixed(UI.button("Emprestar", "green", func():
			var r := Loans.accept_request(i)
			m.refresh()
			m.toast("Empréstimo fechado." if r == "" else r), 15, 40), 120))
		h.add_child(UI.fixed(UI.button("Recusar", "dark", func():
			Loans.reject_request(i)
			m.refresh(), 15, 40), 110))
		v.add_child(pn)
	var outs := Loans.loaned_out(Game.S["club"])
	var ins := Loans.loaned_in(Game.S["club"])
	if not outs.is_empty() or not ins.is_empty():
		v.add_child(UI.label("EMPRÉSTIMOS EM ANDAMENTO", 14, UI.GOLD, true))
		for p in outs:
			var ls := Loans.stats(p)
			v.add_child(_player_row(p, [["→ " + Game.club(int(p["loan"]["to"]))["short"], 90, UI.NEON], ["%d J" % ls["g"], 60], ["%d G" % ls["gol"], 60],
				["%d%%" % int(p["loan"]["pct"]), 70]], func(): m.go("player", p["id"]), "  (emprestado)"))
		for p in ins:
			v.add_child(_player_row(p, [["← " + Game.club(int(p["loan"]["from"]))["short"], 90, UI.GOLD], ["%d J" % int(Loans.stats(p)["g"]), 60],
				[Game.money(p["loan"]["buy"]) if float(p["loan"]["buy"]) > 0.0 else "sem opção", 120]], func(): m.go("player", p["id"]), "  (chegou emprestado)"))
	var exp := Contracts.expiring_list(Game.S["club"])
	if not exp.is_empty():
		v.add_child(UI.label("CONTRATOS A VENCER", 14, UI.GOLD, true))
		for p in exp:
			var refused: bool = p.get("renew", {}).get("refused", false)
			v.add_child(_player_row(p, [[str(p["ovr"]), 56, UI.GOLD], [str(p["age"]), 60], [Money.wage_short(p["wage"]), 90],
				["vai sair" if refused else "renovar ›", 110, UI.RED_TXT if refused else UI.NEON]], func(): m.go("contract", {"renew": p["id"]}) if not refused else m.go("player", p["id"])))
	v.add_child(UI.label("JOGADORES À VENDA", 14, UI.GOLD, true))
	var any := false
	for p in Game.squad(Game.S["club"]):
		if p["listed"]:
			any = true
			v.add_child(_player_row(p, [[str(p["ovr"]), 56, UI.GOLD], [str(p["age"]), 60], [Game.money(p["value"]), 120]], func(): m.go("player", p["id"])))
	if not any:
		v.add_child(UI.label("Ninguém na lista. Abra o perfil de um jogador no Elenco e toque em \"Colocar à venda\".", 15, UI.MUTED))
	v.add_child(UI.fixed(UI.button("Abrir elenco", "dark", func(): m.go("squad"), 16, 44), 0))


func _accept(i: int) -> void:
	var res := Game.accept_offer(i)
	m.refresh()
	m.toast("Venda concluída." if res == "" else res)


func _reject(i: int) -> void:
	Game.reject_offer(i)
	m.refresh()


# ------------------------------------------------------------ renovação
func _renew_screen(root: Control, pid: int) -> void:
	if not Game.S["players"].has(pid):
		m.back()
		return
	var p: Dictionary = Game.player(pid)
	var d := Contracts.demand(p)
	if r_pid != pid:
		r_pid = pid
		r_wage = float(p["wage"])
		r_years = int(d["years"])
		r_role = str(d["role"])
		r_msg = ""
	m.head("Renovação de contrato", "%s • contrato %s" % [p["name"], _contract_txt(p).to_lower()])
	var v := UI.vbox(12)
	root.add_child(v)
	var hb := UI.hbox(14)
	UI.vexpand(hb)
	v.add_child(hb)
	# jogador e o que ele pede
	var lp := UI.panel(UI.PANEL, 18)
	lp.custom_minimum_size = Vector2(360, 0)
	var lv := UI.vbox(6)
	lp.add_child(lv)
	var ph := UI.hbox(12)
	ph.add_child(ChibiPortrait.make(ChibiPortrait.for_player(p, ChibiPortrait.club_kit(int(p["club"]))), 84.0, "bust"))
	var pv := UI.vbox(2)
	pv.add_child(UI.pos_tag(p["pos"]))
	pv.add_child(UI.label(p["name"], 22, UI.TXT, true))
	pv.add_child(UI.label("%d anos • GER %d • %s" % [p["age"], p["ovr"], Game.status(p)], 14, UI.MUTED))
	ph.add_child(pv)
	lv.add_child(ph)
	lv.add_child(UI.section("O QUE ELE PEDE"))
	lv.add_child(UI.label("Salário: %s" % Money.wage(d["wage"]), 18, UI.NEON, true))
	lv.add_child(UI.label("Duração: %d ano(s) • Papel: %s" % [d["years"], Contracts.ROLE_NAMES[d["role"]]], 16, UI.TXT, true))
	lv.add_child(UI.label("Salário atual: %s • moral do elenco %d" % [Money.wage(p["wage"]), int(Contracts.morale())], 13, UI.MUTED))
	var tries: int = int(p.get("renew", {}).get("tries", 0))
	lv.add_child(UI.label("Tentativas: %d de %d" % [tries, int(Contracts.c("tentativas_maximas", 3))], 13, UI.MUTED))
	lv.add_child(UI.spacer())
	hb.add_child(lp)
	# sua proposta
	var rp := UI.panel(UI.PANEL, 18)
	UI.expand(rp)
	var rv := UI.vbox(12)
	rp.add_child(rv)
	rv.add_child(UI.section("SUA PROPOSTA"))
	var ws: float = maxf(snappedf(float(d["wage"]) * 0.04, 0.1), 0.1)
	var row := UI.hbox(30)
	row.add_child(UI.field("SALÁRIO / SEMANA", UI.stepper(Money.wage_short(r_wage), func():
		r_wage = maxf(snappedf(r_wage - ws, 0.1), 0.5)
		m.refresh(), func():
		r_wage = snappedf(r_wage + ws, 0.1)
		m.refresh(), 160)))
	row.add_child(UI.field("DURAÇÃO", UI.stepper("%d ano(s)" % r_years, func():
		r_years = clampi(r_years - 1, 1, 5)
		m.refresh(), func():
		r_years = clampi(r_years + 1, 1, 5)
		m.refresh(), 130)))
	rv.add_child(row)
	var roles := UI.hbox(8)
	for ro in Contracts.ROLES:
		roles.add_child(UI.expand(UI.button(Contracts.ROLE_NAMES[ro], "gold" if r_role == ro else "dark", func():
			r_role = ro
			m.refresh(), 15, 42)))
	rv.add_child(UI.field("PAPEL PROMETIDO", roles))
	var diff: float = (r_wage - float(p["wage"])) * 52.0 / 1000.0
	rv.add_child(UI.label("Impacto na folha: %s%s por ano • folha atual %s" % ["+" if diff >= 0.0 else "−", Game.money(absf(diff)), Money.wage(Loans.wage_bill(Game.S["club"]))], 14, UI.MUTED))
	var sc := Contracts.score(p, r_wage, r_years, r_role)
	var mood := "Ele deve aceitar." if sc >= Contracts.c("aceita_a_partir", 0.98) else ("Perto do que ele quer." if sc >= Contracts.c("contraproposta_a_partir", 0.85) else "Muito abaixo: risco de recusa.")
	rv.add_child(UI.label(mood, 15, UI.NEON if sc >= 0.98 else (Color("f0c419") if sc >= 0.85 else UI.RED_TXT), true))
	if r_msg != "":
		rv.add_child(UI.wrap(UI.label(r_msg, 16, UI.TXT, true)))
	rv.add_child(UI.spacer())
	hb.add_child(rp)
	var bh := UI.hbox(12)
	bh.add_child(UI.fixed(UI.button("Voltar", "dark", func():
		r_pid = -1
		m.back()), 200))
	bh.add_child(UI.fixed(UI.button("Igualar pedido", "dark", func():
		r_wage = float(d["wage"])
		r_years = int(d["years"])
		r_role = str(d["role"])
		m.refresh()), 220))
	bh.add_child(UI.expand(UI.button("Enviar proposta de renovação", "gold", func():
		var res := Contracts.propose(pid, r_wage, r_years, r_role)
		r_msg = str(res["text"])
		if res["result"] == "aceita":
			r_pid = -1
			m.back()
			m.toast(r_msg)
			return
		if res["result"] == "contraproposta":
			r_wage = float(res["wage"])
			r_years = int(res["years"])
		m.refresh())))
	v.add_child(bh)


# ------------------------------------------------------------ pedir emprestado
func _loan_screen(root: Control, pid: int) -> void:
	if not Game.S["players"].has(pid):
		m.back()
		return
	var p: Dictionary = Game.player(pid)
	var t := Loans.terms_in(p)
	if l_pid != pid:
		l_pid = pid
		l_half = false
		l_pct = int(t["pct"])
		l_buy = false
	m.head("Pedir emprestado", "%s • %s" % [p["name"], Game.club_name(int(p["club"]))])
	var v := UI.vbox(12)
	root.add_child(v)
	var hb := UI.hbox(14)
	UI.vexpand(hb)
	v.add_child(hb)
	var lp := UI.panel(UI.PANEL, 18)
	lp.custom_minimum_size = Vector2(360, 0)
	var lv := UI.vbox(6)
	lp.add_child(lv)
	var ph := UI.hbox(12)
	ph.add_child(ChibiPortrait.make(ChibiPortrait.for_player(p, ChibiPortrait.club_kit(int(p["club"]))), 84.0, "bust"))
	var pv := UI.vbox(2)
	pv.add_child(UI.pos_tag(p["pos"]))
	pv.add_child(UI.label(p["name"], 22, UI.TXT, true))
	pv.add_child(UI.label("%d anos • GER %d • %s" % [p["age"], p["ovr"], p["nat"]], 14, UI.MUTED))
	ph.add_child(pv)
	lv.add_child(ph)
	lv.add_child(UI.section("CONDIÇÕES DO %s" % Game.club(int(p["club"]))["short"]))
	lv.add_child(UI.label("Taxa de empréstimo: %s" % Game.money(t["fee"]), 16, UI.TXT, true))
	lv.add_child(UI.label("Você paga no mínimo %d%% do salário (%s)" % [t["pct"], Money.wage(p["wage"])], 15, UI.TXT))
	lv.add_child(UI.label("Opção de compra (se incluir): %s" % Game.money(t["buy"]), 15, UI.MUTED))
	lv.add_child(UI.spacer())
	hb.add_child(lp)
	var rp := UI.panel(UI.PANEL, 18)
	UI.expand(rp)
	var rv := UI.vbox(12)
	rp.add_child(rv)
	rv.add_child(UI.section("SUA PROPOSTA"))
	var dur := UI.hbox(8)
	dur.add_child(UI.expand(UI.button("Meia temporada", "gold" if l_half else "dark", func():
		l_half = true
		m.refresh(), 15, 42)))
	dur.add_child(UI.expand(UI.button("Temporada inteira", "gold" if not l_half else "dark", func():
		l_half = false
		m.refresh(), 15, 42)))
	rv.add_child(UI.field("DURAÇÃO", dur))
	rv.add_child(UI.field("% DO SALÁRIO QUE VOCÊ PAGA", UI.stepper("%d%%" % l_pct, func():
		l_pct = clampi(l_pct - 10, 0, 100)
		m.refresh(), func():
		l_pct = clampi(l_pct + 10, 0, 100)
		m.refresh(), 140)))
	rv.add_child(UI.button("Com opção de compra: SIM" if l_buy else "Com opção de compra: NÃO", "gold" if l_buy else "dark", func():
		l_buy = not l_buy
		m.refresh(), 15, 42))
	rv.add_child(UI.label("Custo no salário: %s • seu caixa %s" % [Money.wage(float(p["wage"]) * l_pct / 100.0), Game.money(Game.S["money"])], 14, UI.MUTED))
	rv.add_child(UI.spacer())
	hb.add_child(rp)
	var bh := UI.hbox(12)
	bh.add_child(UI.fixed(UI.button("Voltar", "dark", func():
		l_pid = -1
		m.back()), 220))
	bh.add_child(UI.expand(UI.button("Enviar pedido de empréstimo", "gold", func():
		var res := Loans.loan_in(pid, l_half, l_pct, l_buy)
		if res == "":
			l_pid = -1
			m.back()
			m.toast("%s chega emprestado!" % p["name"])
		else:
			m.toast(res))))
	v.add_child(bh)
