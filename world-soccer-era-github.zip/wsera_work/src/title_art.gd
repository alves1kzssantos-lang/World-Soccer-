class_name TitleArt
extends Control
## Arte de capa do menu inicial, desenhada por código (vale para qualquer resolução,
## do celular ao monitor): gramado em perspectiva com faixas, grande área e gol ao fundo,
## holofote, bola em primeiro plano e brilho dourado. Paleta do jogo: verde profundo,
## oliva do gramado e dourado só nos destaques.

const DEEP := Color("07140f")
const GRASS_A := Color("0f2a1c")
const GRASS_B := Color("123222")
const LINE := Color(1, 1, 1, 0.16)
const GOLD := Color("e6c56a")

var t: float = 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	clip_contents = true


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


## Ponto do gramado (u: -1..1 na largura, v: 0 fundo .. 1 frente) para a tela, em perspectiva.
func _p(u: float, v: float) -> Vector2:
	var w := size.x
	var h := size.y
	var horizon := h * 0.30
	var y := lerpf(horizon, h * 1.05, v)
	var half := lerpf(w * 0.42, w * 1.35, v)
	return Vector2(w * 0.5 + u * half, y)


func _quad(u0: float, u1: float, v0: float, v1: float, col: Color) -> void:
	draw_colored_polygon(PackedVector2Array([_p(u0, v0), _p(u1, v0), _p(u1, v1), _p(u0, v1)]), col)


func _poly_line(pts: Array, col: Color, wdt: float) -> void:
	var arr := PackedVector2Array()
	for q in pts:
		arr.append(_p(q.x, q.y))
	draw_polyline(arr, col, wdt, true)


func _draw() -> void:
	var w := size.x
	var h := size.y
	if w < 10.0 or h < 10.0:
		return
	draw_rect(Rect2(Vector2.ZERO, size), DEEP)
	# holofote no alto, pulsando de leve
	var glow := 0.5 + 0.5 * sin(t * 0.8)
	for k in 14:
		draw_circle(Vector2(w * 0.5, h * 0.1), h * (0.06 + k * 0.035), Color(0.9, 0.85, 0.55, 0.012 + 0.004 * glow))
	# gramado com faixas cortadas
	var bands := 10
	for i in bands:
		var v0 := float(i) / bands
		var v1 := float(i + 1) / bands
		_quad(-1.0, 1.0, v0 * v0, v1 * v1, GRASS_A if i % 2 == 0 else GRASS_B)
	# linhas: fundo, grande área, pequena área, meia-lua e arco do meio-campo
	_poly_line([Vector2(-1, 0), Vector2(1, 0)], LINE, 2.0)
	_poly_line([Vector2(-0.22, 0), Vector2(-0.22, 0.2), Vector2(0.22, 0.2), Vector2(0.22, 0)], LINE, 2.0)
	_poly_line([Vector2(-0.1, 0), Vector2(-0.1, 0.07), Vector2(0.1, 0.07), Vector2(0.1, 0)], LINE, 2.0)
	var arc: Array = []
	for i in 13:
		var a := PI * float(i) / 12.0
		arc.append(Vector2(cos(a) * 0.08, 0.2 + sin(a) * 0.06))
	_poly_line(arc, LINE, 2.0)
	var mid: Array = []
	for i in 25:
		var a2 := PI + PI * float(i) / 24.0
		mid.append(Vector2(cos(a2) * 0.16, 0.98 + sin(a2) * 0.14))
	_poly_line(mid, LINE, 2.0)
	# gol ao fundo: traves, travessão e rede
	var gl := _p(-0.04, 0.0)
	var gr := _p(0.04, 0.0)
	var gh := (gr.x - gl.x) * 0.36
	draw_rect(Rect2(gl.x, gl.y - gh, gr.x - gl.x, gh), Color(1, 1, 1, 0.07))
	for i in 9:
		var x := lerpf(gl.x, gr.x, float(i) / 8.0)
		draw_line(Vector2(x, gl.y - gh), Vector2(x, gl.y), Color(1, 1, 1, 0.1), 1.0)
	draw_polyline(PackedVector2Array([gl, gl - Vector2(0, gh), gr - Vector2(0, gh), gr]), Color(1, 1, 1, 0.75), 3.0, true)
	# bola em primeiro plano, com sombra e leve balanço
	var r := minf(w, h) * 0.13
	var bc := Vector2(w * 0.76, h * 0.80 - absf(sin(t * 1.6)) * r * 0.08)
	draw_set_transform(Vector2(w * 0.76 + r * 0.25, h * 0.80 + r * 0.92), 0.0, Vector2(1.0, 0.28))
	draw_circle(Vector2.ZERO, r * 1.05, Color(0, 0, 0, 0.35))
	draw_set_transform(Vector2.ZERO)
	draw_circle(bc, r, Color("eef0f2"))
	_pent(bc, r * 0.36, t * 0.25, Color("1a1c1f"))
	for i in 5:
		var a3 := t * 0.25 + TAU * (i + 0.5) / 5.0
		_pent(bc + Vector2(cos(a3), sin(a3)) * r * 0.86, r * 0.24, a3, Color("1a1c1f"))
	draw_arc(bc, r, 0, TAU, 48, Color(0, 0, 0, 0.55), maxf(r * 0.05, 1.5), true)
	draw_arc(bc, r * 0.7, -2.5, -1.3, 16, Color(1, 1, 1, 0.6), r * 0.08, true)
	# brilho dourado passando pela faixa de baixo
	var sx := fmod(t * 120.0, w + 400.0) - 200.0
	draw_rect(Rect2(sx, h - 6.0, 200.0, 3.0), Color(GOLD, 0.55))
	draw_rect(Rect2(0, h - 6.0, w, 1.0), Color(GOLD, 0.25))
	# escurece à esquerda para o texto da capa ficar legível
	for k in 8:
		var a4 := 0.07 * (8 - k)
		draw_rect(Rect2(w * 0.07 * k, 0, w * 0.07, h), Color(DEEP, a4))


func _pent(c: Vector2, r: float, rot: float, col: Color) -> void:
	var pts := PackedVector2Array()
	for i in 5:
		var a := rot - PI / 2.0 + TAU * i / 5.0
		pts.append(c + Vector2(cos(a), sin(a)) * r)
	draw_colored_polygon(pts, col)
