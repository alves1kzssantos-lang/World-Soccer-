class_name PressRoom
extends Control
## Cena da coletiva desenhada por código: painel de patrocínio ao fundo, a pessoa entrevistada
## atrás da mesa, microfones das emissoras, repórter em primeiro plano com o microfone
## estendido e flashes de câmera.
## Desempenho: o fundo, a mesa e os microfones só são redesenhados quando o tamanho muda
## (camada estática); a cada quadro só a camada leve dos flashes e do microfone do repórter.

const OUTLETS := [["TV1", "c0392b"], ["RÁDIO", "2463b8"], ["PB", "e6c56a"], ["BN", "237a47"], ["ESP", "8e44ad"], ["AF", "d35400"]]

var club_short: String = "WSE"
var person: Control = null        ## avatar do técnico/jogador (fica atrás da mesa)
var plate: String = ""            ## nome na plaquinha da mesa
var person_zoom: float = 1.0      ## avatar de corpo inteiro (jogador) precisa de zoom para o rosto aparecer acima da mesa
var person_lift: float = 0.76     ## quanto do avatar fica acima da linha da mesa (0..1)
var t: float = 0.0
var _flashes: Array = []          ## [pos, idade]
var _next_flash: float = 0.6
var _static: Control
var _fx: Control


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	clip_contents = true
	_static = Control.new()
	_static.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_static)
	_static.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_static.draw.connect(_draw_back)
	if person != null:
		add_child(person)
	var desk := Control.new()
	desk.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(desk)
	desk.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	desk.draw.connect(_draw_desk.bind(desk))
	_fx = Control.new()
	_fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_fx)
	_fx.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fx.draw.connect(_draw_fx)
	resized.connect(_layout)
	_layout()


func _layout() -> void:
	if person != null:
		# avatar grande: a cabeça e o tronco aparecem acima da mesa
		var h: float = size.y * 0.88 * person_zoom
		person.size = Vector2(h * 0.84, h)
		person.position = Vector2(size.x * 0.5 - person.size.x * 0.5, size.y * 0.70 - h * person_lift)


func _process(delta: float) -> void:
	t += delta
	_next_flash -= delta
	if _next_flash <= 0.0:
		_next_flash = Media.R.randf_range(0.35, 1.4)
		_flashes.append([Vector2(Media.R.randf_range(0.08, 0.92) * size.x, Media.R.randf_range(0.15, 0.6) * size.y), 0.0])
	var i := _flashes.size() - 1
	while i >= 0:
		_flashes[i][1] += delta
		if _flashes[i][1] > 0.35:
			_flashes.remove_at(i)
		i -= 1
	_fx.queue_redraw()


func _draw_back() -> void:
	var w := size.x
	var h := size.y
	var c := _static
	UI.draw_brand_bg(c, size, false)
	# painel de patrocínio: grade de logotipos alternados
	var f := UI.bold()
	var tw := 150.0
	var th := 46.0
	var rows := int(ceil(h / th)) + 1
	var cols := int(ceil(w / tw)) + 1
	for r in rows:
		for k in cols:
			var x := k * tw + (tw * 0.5 if r % 2 == 1 else 0.0) - tw * 0.5
			var y := r * th
			var txt := "A NOVA ERA" if (r + k) % 2 == 0 else club_short
			var col := Color(UI.NEON, 0.10) if (r + k) % 2 == 0 else Color(1, 1, 1, 0.06)
			c.draw_string(f, Vector2(x, y + 28), txt, HORIZONTAL_ALIGNMENT_CENTER, tw, 13, col)
	# luz de estúdio de cima e vinheta nas bordas
	for k in 8:
		c.draw_circle(Vector2(w * 0.5, -h * 0.2), h * (0.4 + k * 0.12), Color(1, 1, 1, 0.014))
	c.draw_rect(Rect2(0, 0, w * 0.08, h), Color(0, 0, 0, 0.18))
	c.draw_rect(Rect2(w * 0.92, 0, w * 0.08, h), Color(0, 0, 0, 0.18))


func _draw_desk(c: Control) -> void:
	var w := size.x
	var h := size.y
	var top := h * 0.70
	# mesa
	c.draw_rect(Rect2(w * 0.12, top, w * 0.76, h - top), Color("1a1e1c"))
	c.draw_rect(Rect2(w * 0.12, top, w * 0.76, 4.0), UI.NEON)
	c.draw_rect(Rect2(w * 0.12, top + 4.0, w * 0.76, 10.0), Color(0, 0, 0, 0.25))
	# plaquinha com o nome
	if plate != "":
		var pw := minf(260.0, w * 0.3)
		var pr := Rect2(w * 0.5 - pw * 0.5, top + 14.0, pw, 28.0)
		c.draw_rect(pr, Color("f4f6fa"))
		c.draw_string(UI.bold(), Vector2(pr.position.x, pr.position.y + 20.0), plate, HORIZONTAL_ALIGNMENT_CENTER, pw, 15, UI.DARKTXT)
	# microfones das emissoras na mesa
	var n := OUTLETS.size()
	for i in n:
		var u := (float(i) + 0.5) / n
		# microfones em leque, abaixo do rosto (apontam para a boca, sem cobrir)
		var x := lerpf(w * 0.36, w * 0.64, u)
		var base := Vector2(x, top + 2.0)
		var head := Vector2(lerpf(x, w * 0.5, 0.45), top - h * 0.02 - (0.5 - absf(u - 0.5)) * h * 0.02)
		c.draw_line(base, head, Color("2b2f33"), 3.0, true)
		var fl: Rect2 = Rect2(head.x - 18.0, head.y + 8.0, 36.0, 18.0)
		c.draw_rect(fl, Color(OUTLETS[i][1]))
		c.draw_string(UI.bold(), Vector2(fl.position.x, fl.position.y + 14.0), OUTLETS[i][0], HORIZONTAL_ALIGNMENT_CENTER, 36.0, 10, Color.WHITE)
		c.draw_circle(head, 9.0, Color("1c1f22"))
		c.draw_circle(head + Vector2(-2.5, -2.5), 3.0, Color(1, 1, 1, 0.18))


func _draw_fx() -> void:
	var w := size.x
	var h := size.y
	for fl in _flashes:
		var a: float = 1.0 - float(fl[1]) / 0.35
		_fx.draw_circle(fl[0], 26.0 * (0.6 + fl[1] * 2.0), Color(1, 1, 1, 0.20 * a))
		_fx.draw_circle(fl[0], 7.0, Color(1, 1, 1, 0.85 * a))
	# repórter em primeiro plano (silhueta) com o microfone estendido
	var sway := sin(t * 1.3) * 3.0
	var sh := Vector2(w * 0.10, h * 1.02)
	var hc := sh + Vector2(0, -h * 0.34)
	_fx.draw_circle(hc, h * 0.12, Color("050d0a"))
	_fx.draw_arc(hc, h * 0.12, -2.6, -0.6, 16, Color(1, 0.95, 0.75, 0.22), 2.0, true)   # luz de recorte
	_fx.draw_rect(Rect2(sh.x - h * 0.22, sh.y - h * 0.24, h * 0.44, h * 0.30), Color("050d0a"))
	_fx.draw_arc(sh + Vector2(0, -h * 0.10), h * 0.22, -2.9, -1.9, 12, Color(1, 0.95, 0.75, 0.15), 2.0, true)
	var hand := Vector2(w * 0.10 + h * 0.36, h * 0.66 + sway)
	_fx.draw_line(sh + Vector2(h * 0.16, -h * 0.18), hand, Color("050d0a"), 15.0, true)
	var mic := hand + Vector2(20, -20)
	_fx.draw_line(hand, mic, Color("1c1f22"), 7.0, true)
	_fx.draw_circle(mic, 11.0, Color("2b2f33"))
	_fx.draw_rect(Rect2(hand.x - 4, hand.y - 8, 26, 16), Color("ad3450"))
	_fx.draw_string(UI.bold(), Vector2(hand.x - 4, hand.y + 4), "TV1", HORIZONTAL_ALIGNMENT_CENTER, 26, 9, Color.WHITE)
