class_name Finance
extends RefCounted
## Economia do clube (modo técnico).
##
## Unidades: caixa, receitas, taxas e prêmios em MILHÕES; salários em MIL por semana (como nos jogadores).
## Modelo:
##   - Folha "esperada" de um clube de força f: W(f) = a * (f - 50)^b  (mil/sem), medida nos elencos do jogo.
##   - Receita semanal ≈ receita_sobre_folha * W(f): TV (liga), patrocínio (reputação) e bilheteria (só em casa,
##     cresce com o humor da torcida e com a capacidade do estádio).
##   - Despesas: salários (Loans.wage_bill, já divide emprestados), comissão técnica (fração de W), juros da dívida.
##   - A diretoria define no começo de cada temporada o orçamento de contratações e o teto da folha.
##     Gastar além disso derruba a confiança da diretoria; dívida grande bloqueia contratações.
## Números em assets/data/economy.json.

const KINDS := ["tv", "patrocinio", "bilheteria", "premios", "vendas", "salarios", "staff", "compras", "juros", "rescisoes"]
const INCOME := ["tv", "patrocinio", "bilheteria", "premios", "vendas"]
const LABELS := {"tv": "Direitos de TV", "patrocinio": "Patrocínio", "bilheteria": "Bilheteria", "premios": "Premiações",
	"vendas": "Vendas de jogadores", "salarios": "Salários", "staff": "Comissão técnica",
	"compras": "Contratações", "juros": "Juros da dívida", "rescisoes": "Rescisões"}

static var _cfg: Dictionary = {}


static func cfg(key: String, fallback: float) -> float:
	if _cfg.is_empty():
		var path := "res://assets/data/economy.json"
		if FileAccess.file_exists(path):
			var d = JSON.parse_string(FileAccess.get_file_as_string(path))
			if typeof(d) == TYPE_DICTIONARY:
				_cfg = d
		if _cfg.is_empty():
			_cfg = {"_": 0}
	return float(_cfg.get(key, fallback))


# ------------------------------------------------------------ modelo
## Folha salarial esperada (mil por semana) para um clube de força f.
static func wexp_k(f: float) -> float:
	return cfg("folha_a", 0.113) * pow(maxf(f - 50.0, 4.0), cfg("folha_b", 2.65))


## Receita base por semana (milhões) do clube cid, antes da bilheteria variar com a torcida.
static func base_revenue(f: float) -> float:
	return wexp_k(f) / 1000.0 * cfg("receita_sobre_folha", 1.18)


static func league_tv_mult() -> float:
	var pr: float = float(Game.league().get("prize", 1.0))
	return clampf(0.88 + 0.08 * pr, 0.85, 1.12)


static func tv_week(f: float) -> float:
	return base_revenue(f) * cfg("parte_tv", 0.38) * league_tv_mult()


static func sponsor_week(f: float) -> float:
	# reputação: força do clube + títulos recentes
	var rep := 1.0 + 0.03 * mini(int(Game.my_club().get("titles", 0)), 5)
	return base_revenue(f) * cfg("parte_patrocinio", 0.30) * rep


static func capacity(f: float) -> int:
	return int(clampf(cfg("estadio_base", 12000.0) + (f - 55.0) * cfg("estadio_por_ponto", 1600.0), 8000.0, 82000.0))


## Ocupação do estádio (0..1): torcida feliz e boa fase enchem mais.
static func occupancy() -> float:
	var sup := float(Game.S.get("support", 60)) / 100.0
	return clampf(0.32 + 0.62 * sup, 0.2, 1.0)


## Bilheteria de UM jogo em casa (milhões).
static func ticket_game(f: float) -> float:
	var ref_occ := 0.32 + 0.62 * 0.6
	# metade das rodadas é em casa: um jogo em casa paga duas "semanas" de bilheteria
	return base_revenue(f) * cfg("parte_bilheteria", 0.32) * 2.0 * occupancy() / ref_occ


static func staff_week(f: float) -> float:
	return wexp_k(f) / 1000.0 * cfg("staff_sobre_folha", 0.10)


## Público do último jogo em casa (para mostrar).
static func attendance(f: float) -> int:
	return int(capacity(f) * occupancy())


# ------------------------------------------------------------ estado guardado
static func defaults() -> Dictionary:
	return {"ledger": [], "hist": [], "transfer_budget": 0.0, "transfer_spent": 0.0, "wage_budget": 0.0,
		"board_warn": 0, "last_gate": 0}


## Garante as chaves novas (saves antigos e carreira nova). Não muda nada se já existir.
static func ensure() -> Dictionary:
	if Game.S.is_empty():
		return {}
	if not Game.S.has("econ") or typeof(Game.S["econ"]) != TYPE_DICTIONARY:
		Game.S["econ"] = defaults()
	var e: Dictionary = Game.S["econ"]
	for k in defaults().keys():
		if not e.has(k):
			e[k] = defaults()[k]
	var fin: Dictionary = Game.S["fin"]
	for k in KINDS:
		if not fin.has(k):
			fin[k] = 0.0
	return e


## Movimento no caixa: atualiza o saldo, a linha do balanço e o extrato.
static func book(kind: String, label: String, amount: float) -> void:
	var e := ensure()
	Game.S["money"] = float(Game.S["money"]) + amount
	var fin: Dictionary = Game.S["fin"]
	fin[kind] = float(fin.get(kind, 0.0)) + absf(amount)
	if absf(amount) >= 0.005:
		var led: Array = e["ledger"]
		led.push_front({"d": int(Game.S["day"]), "k": kind, "t": label, "v": snappedf(amount, 0.001)})
		if led.size() > 40:
			led.resize(40)


## Orçamento da temporada definido pela diretoria.
static func set_season_budget() -> void:
	var e := ensure()
	var f := float(Game.my_club()["str"])
	var cash := float(Game.S["money"])
	var surplus := (base_revenue(f) - wexp_k(f) / 1000.0 - staff_week(f)) * 38.0
	e["transfer_budget"] = snappedf(maxf(0.0, cash * cfg("orcamento_do_caixa", 0.55) + maxf(surplus, 0.0) * 0.5), 0.1)
	e["transfer_spent"] = 0.0
	e["wage_budget"] = snappedf(maxf(Loans.wage_bill(Game.S["club"]) * 1.05, wexp_k(f) * cfg("teto_folha_sobre_esperada", 1.1)), 1.0)
	e["board_warn"] = 0


static func transfer_left() -> float:
	var e := ensure()
	return float(e["transfer_budget"]) - float(e["transfer_spent"])


## Receita anual estimada (para medir o tamanho da dívida).
static func annual_revenue() -> float:
	var f := float(Game.my_club()["str"])
	return (tv_week(f) + sponsor_week(f)) * 52.0 + ticket_game(f) * 19.0


static func debt_limit() -> float:
	return -annual_revenue() * cfg("divida_maxima_sobre_receita", 0.45)


## "" se a diretoria libera o gasto; senão o motivo.
static func can_spend(fee: float, weekly_wage_k: float = 0.0) -> String:
	if Pro.is_pro():
		return ""
	if float(Game.S["money"]) < debt_limit():
		return "A diretoria bloqueou contratações: o clube está endividado demais."
	if fee > 0.0 and fee > transfer_left() * 1.5 + 0.5 and fee > float(Game.S["money"]) * 0.8:
		return "A diretoria não libera: o valor passa muito do orçamento de contratações (%s)." % Money.fmt(maxf(transfer_left(), 0.0))
	return ""


## Contratação feita: conta no orçamento e cobra a diretoria se estourou.
static func on_purchase(fee: float, weekly_wage_k: float) -> void:
	var e := ensure()
	e["transfer_spent"] = float(e["transfer_spent"]) + fee
	if Pro.is_pro():
		return
	var over := -transfer_left()
	if over > 0.05:
		Media._add_meter("diretoria", -clampf(3.0 + over / maxf(float(e["transfer_budget"]), 1.0) * 10.0, 3.0, 14.0))
		Game.add_news("Diretoria preocupada", "A contratação estourou o orçamento em %s." % Money.fmt(over))
	if Loans.wage_bill(Game.S["club"]) > float(e["wage_budget"]) and weekly_wage_k > 0.0:
		Media._add_meter("diretoria", -3.0)
		Game.add_news("Folha acima do teto", "A folha (%s) passou do teto da diretoria (%s)." % [Money.wage(Loans.wage_bill(Game.S["club"])), Money.wage(float(e["wage_budget"]))])


## Venda: metade do valor volta para o orçamento de contratações.
static func on_sale(value: float) -> void:
	var e := ensure()
	e["transfer_spent"] = float(e["transfer_spent"]) - value * cfg("venda_para_orcamento", 0.5)


## Fluxo de caixa entre duas datas (gap dias). was_home = o último jogo foi em casa.
static func round_tick(gap: int, was_home: bool) -> void:
	var e := ensure()
	var f := float(Game.my_club()["str"])
	var wk := gap / 7.0
	book("tv", "Cota de TV", tv_week(f) * wk)
	book("patrocinio", "Patrocínio", sponsor_week(f) * wk)
	if was_home:
		book("bilheteria", "Bilheteria (%s pagantes)" % Money._num(attendance(f), 0), ticket_game(f))
		e["last_gate"] = attendance(f)
	book("salarios", "Folha salarial", -Loans.wage_bill(Game.S["club"]) / 1000.0 * wk)
	book("staff", "Comissão técnica e estrutura", -staff_week(f) * wk)
	if float(Game.S["money"]) < 0.0:
		book("juros", "Juros da dívida", float(Game.S["money"]) * cfg("juros_semana", 0.0035) * wk)
	# diretoria acompanha a saúde financeira
	if not Pro.is_pro():
		var m := float(Game.S["money"])
		if m < debt_limit():
			Media._add_meter("diretoria", -2.0)
			if int(e["board_warn"]) < 3:
				e["board_warn"] = int(e["board_warn"]) + 1
				Game.add_news("Diretoria em alerta", "A dívida (%s) passou do limite. Contratações bloqueadas até o caixa melhorar." % Money.fmt(m))
		elif m > 0.0 and Loans.wage_bill(Game.S["club"]) <= float(e["wage_budget"]):
			Media._add_meter("diretoria", 0.15)
	var hist: Array = e["hist"]
	hist.append([int(Game.S["day"]), snappedf(float(Game.S["money"]), 0.01)])
	if hist.size() > 80:
		hist.pop_front()
	_ai_tick(wk)


# ------------------------------------------------------------ clubes da máquina
## Caixa simplificado dos clubes da máquina: pequena sobra semanal, limitada; transferências mexem nele.
static func ai_cash_init(c: Dictionary) -> void:
	if not c.has("cash"):
		c["cash"] = snappedf(maxf(float(c["str"]) - 50.0, 4.0) * cfg("caixa_inicial_por_ponto", 1.2), 0.1)


static func _ai_tick(wk: float) -> void:
	for c in Game.S["clubs"]:
		if int(c["id"]) == int(Game.S["club"]):
			continue
		ai_cash_init(c)
		var f := float(c["str"])
		var annual := base_revenue(f) * 52.0
		var cash := float(c["cash"]) + (base_revenue(f) - wexp_k(f) / 1000.0 - staff_week(f)) * wk
		# quem sobra muito investe (estrutura); quem deve corta custos aos poucos
		if cash > annual * 0.6:
			cash -= (cash - annual * 0.6) * 0.2
		elif cash < -annual * 0.3:
			cash += (-annual * 0.3 - cash) * 0.2
		c["cash"] = snappedf(cash, 0.01)


static func ai_can_buy(buyer: int, fee: float) -> bool:
	var c: Dictionary = Game.S["clubs"][buyer]
	ai_cash_init(c)
	return float(c["cash"]) >= fee * 0.6


static func ai_transfer_cash(seller: int, buyer: int, fee: float) -> void:
	for cid in [seller, buyer]:
		if cid >= 0 and cid < Game.S["clubs"].size():
			ai_cash_init(Game.S["clubs"][cid])
	if seller >= 0 and seller < Game.S["clubs"].size() and seller != int(Game.S["club"]):
		Game.S["clubs"][seller]["cash"] = float(Game.S["clubs"][seller]["cash"]) + fee
	if buyer >= 0 and buyer < Game.S["clubs"].size() and buyer != int(Game.S["club"]):
		Game.S["clubs"][buyer]["cash"] = float(Game.S["clubs"][buyer]["cash"]) - fee


# ------------------------------------------------------------ resumo para a tela
## Linhas do balanço da temporada: [[chave, rótulo, valor (+ receita / − despesa)], ...]
static func breakdown() -> Array:
	ensure()
	var fin: Dictionary = Game.S["fin"]
	var out: Array = []
	for k in KINDS:
		var v := float(fin.get(k, 0.0))
		out.append([k, LABELS[k], v if k in INCOME else -v])
	return out


static func season_result() -> float:
	var t := 0.0
	for r in breakdown():
		t += float(r[2])
	return t
