extends Control
# Tela principal: cabeçalho + área onde cada tela é montada.
# Para trocar de tela use  go("nome", argumento)  e  back().

const ScreensStart := preload("res://src/screens_start.gd")
const ScreensHub := preload("res://src/screens_hub.gd")
const ScreensTeam := preload("res://src/screens_team.gd")
const ScreensPro := preload("res://src/screens_pro.gd")
const ScreensMedia := preload("res://src/screens_media.gd")
const MATCH_VIEW := "res://src/match_view.gd"   ## carregada só quando a primeira partida abre (abre o jogo mais rápido)

var body: MarginContainer
var overlay: Control
var title_l: Label
var sub_l: Label
var date_l: Label
var central_b: Button
var money_l: Label
var money_p: Control
var back_b: Button
var crest_box: Control
var mid_box: Control
var chrome_head: PanelContainer
var comp_logo_r: TextureRect
var shell_theme: Dictionary = {}    ## tema do campeonato aplicado ao cabeçalho e ao fundo
var _theme_id: String = ""
var _head_sb: StyleBoxFlat
var _deco: Control

var stack: Array = []
var cur: Array = ["title", null]
var hub_tab: int = 0
var screens: Dictionary = {}
var _modal: Control = null
var _keep: Array = []


const APP_TITLE := "WORLD SOCCER — A NOVA ERA"


func _ready() -> void:
	get_window().title = "World Soccer — A Nova Era"
	_build_chrome()
	var a = ScreensStart.new(self)
	var b = ScreensHub.new(self)
	var c = ScreensTeam.new(self)
	var d = ScreensPro.new(self)
	var e = CupScreens.new(self)
	var f = ScreensMedia.new(self)
	_keep = [a, b, c, d, e, f]
	if _under_test():
		call_deferred("_first_run_import")
	else:
		_boot_ls = LoadingScreen.open(overlay, "Preparando o jogo…", LoadingScreen.MIN_SHOW, true)
		call_deferred("_boot")
	screens = {
		"title": a.title_screen, "careers": a.careers, "coach": a.coach_screen, "clubs": a.clubs, "datapack": a.datapack, "dp_browse": a.dp_browse,
		"hub": b.hub, "table": b.table, "calendar": b.calendar, "results": b.results, "postmatch": b.postmatch,
		"finance": b.finance, "cup": e.cup, "cup_results": e.cup_results, "central": b.central, "transfers": b.transfers, "season_end": b.season_end,
		"lineup": c.lineup, "squad": c.squad, "player": c.player, "youth": c.youth,
		"market": c.market, "contract": c.contract, "offers": c.offers,
		"match": _match_screen,
		"pro_create": d.create, "pro_trial": d.trial, "pro_post": d.post, "pro_offers": d.offers, "pro_hub": d.hub,
		"pro_season": d.season, "pro_feed": d.feed,
		"interview": f.interview, "social": f.social,
	}
	_apply_safe_area()
	get_viewport().size_changed.connect(_apply_safe_area)
	_render()


## Celular com recorte (notch) ou barra de gestos: afasta a interface das bordas inseguras.
## No computador a área segura é a tela toda, então nada muda.
func _apply_safe_area() -> void:
	if _chrome_root == null or not OS.has_feature("mobile"):
		return
	var ws := Vector2(DisplayServer.window_get_size())
	var sa := DisplayServer.get_display_safe_area()
	if ws.x <= 0.0 or ws.y <= 0.0 or sa.size.x <= 0:
		return
	var k := get_viewport_rect().size / ws
	_chrome_root.offset_left = sa.position.x * k.x
	_chrome_root.offset_top = sa.position.y * k.y
	_chrome_root.offset_right = -maxf(ws.x - sa.end.x, 0.0) * k.x
	_chrome_root.offset_bottom = -maxf(ws.y - sa.end.y, 0.0) * k.y


var _chrome_root: Control = null


func _build_chrome() -> void:
	# fundo da marca (preto com grão, faixas e pinceladas verdes): desenhado só quando o tamanho muda
	var deco := Control.new()
	deco.mouse_filter = Control.MOUSE_FILTER_IGNORE
	deco.draw.connect(func(): _draw_deco(deco))
	_deco = deco
	add_child(deco)
	deco.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var root := UI.vbox(0)
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_chrome_root = root

	var head_p := PanelContainer.new()
	chrome_head = head_p
	var hs := UI.sbox(UI.HEADER2, 0, 0)
	hs.content_margin_left = 18
	hs.content_margin_right = 18
	hs.content_margin_top = 8
	hs.content_margin_bottom = 8
	hs.border_color = UI.NEON
	hs.border_width_bottom = 2   # fio verde neon embaixo do cabeçalho (na carreira: cor do campeonato)
	_head_sb = hs
	head_p.add_theme_stylebox_override("panel", hs)
	root.add_child(head_p)
	var hb := UI.hbox(14)
	head_p.add_child(hb)
	crest_box = Control.new()
	crest_box.custom_minimum_size = Vector2(52, 52)
	hb.add_child(crest_box)
	# logo do campeonato da carreira ao lado do escudo (tema da competição)
	comp_logo_r = TextureRect.new()
	comp_logo_r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	comp_logo_r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	comp_logo_r.custom_minimum_size = Vector2(36, 36)
	comp_logo_r.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	comp_logo_r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.add_child(comp_logo_r)
	var tv := UI.vbox(0)
	UI.expand(tv)
	title_l = UI.label("", 24, UI.TXT, true)
	sub_l = UI.label("", 14, UI.MUTED)
	sub_l.clip_text = true
	tv.add_child(title_l)
	tv.add_child(sub_l)
	hb.add_child(tv)
	var mv := UI.vbox(2)
	mid_box = mv
	date_l = UI.center(UI.label("", 17, UI.TXT, true))
	central_b = UI.button("Central", "dark", func(): go("central"), 15, 30)
	central_b.custom_minimum_size = Vector2(170, 30)
	mv.add_child(date_l)
	mv.add_child(central_b)
	hb.add_child(mv)
	hb.add_child(UI.expand(Control.new(), 0.6))
	money_p = UI.panel(UI.BG2, 8, 8)
	money_p.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	money_l = UI.center(UI.label("", 19, UI.TXT, true))
	money_l.custom_minimum_size = Vector2(150, 0)
	money_p.add_child(money_l)
	hb.add_child(money_p)
	back_b = UI.button("Voltar", "dark", back, 17, 44)
	back_b.custom_minimum_size = Vector2(110, 44)
	back_b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(back_b)

	body = MarginContainer.new()
	for k in ["margin_left", "margin_right"]:
		body.add_theme_constant_override(k, 22)
	body.add_theme_constant_override("margin_top", 14)
	body.add_theme_constant_override("margin_bottom", 14)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(body)

	overlay = Control.new()
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(overlay)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


## Rodando dentro de uma cena de teste (main.tscn instanciada por outro nó): sem telas de
## carregamento, para não mudar o tempo da navegação que os testes esperam.
func _under_test() -> bool:
	return not is_inside_tree() or get_tree().current_scene != self


## Abre a tela de carregamento animada (null nos testes).
func loading(text: String, min_time: float = 0.6) -> LoadingScreen:
	if _under_test() or overlay == null:
		return null
	return LoadingScreen.open(overlay, text, min_time)


## Abertura do jogo: depois do splash do Godot, a tela de carregamento cobre o aquecimento
## (datapack, elencos reais, scripts da partida e o banner) com progresso de verdade.
var _boot_ls: LoadingScreen = null


func _boot() -> void:
	var ls := _boot_ls if _boot_ls != null and is_instance_valid(_boot_ls) else LoadingScreen.open(overlay, "Preparando o jogo…", LoadingScreen.MIN_SHOW, true)
	await ls.frame()
	ls.step(0.15, "Carregando escudos e campeonatos…")
	await ls.frame()
	DataPack.loaded()
	ls.step(0.35, "Montando os elencos reais…")
	await ls.frame()
	Game.real_roster("Flamengo")
	ls.step(0.55, "Preparando o estádio…")
	await ls.frame()
	for path in [MATCH_VIEW, "res://src/lance_view.gd", "res://src/field_view.gd", "res://src/chibi_portrait.gd"]:
		if ResourceLoader.exists(path):
			load(path)
		await ls.frame()
	ls.step(0.8, "Aquecendo os jogadores…")
	for path in ["res://assets/brand/banner.webp", "res://assets/brand/banner_1280.webp"]:
		if ResourceLoader.exists(path):
			load(path)
	await ls.frame()
	await _first_run_import()
	ls.step(1.0, "Tudo pronto!")
	ls.close()


## Na primeira abertura, importa o datapack que vem dentro do jogo (res://datapack.zip).
## Depois disso fica salvo no aparelho e não precisa importar de novo.
func _first_run_import() -> void:
	if (DataPack.loaded() and not DataPack.outdated()) or not FileAccess.file_exists("res://datapack.zip"):
		return
	var cover := ColorRect.new()
	cover.color = Color(0.02, 0.06, 0.045, 0.97)
	cover.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay.add_child(cover)
	cover.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var v := UI.vbox(10)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	cover.add_child(v)
	v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	v.add_child(UI.center(UI.label("WORLD SOCCER — A NOVA ERA", 34, UI.NEON, true)))
	v.add_child(UI.center(UI.label("Preparando clubes, escudos e estádios…", 20, UI.TXT, true)))
	v.add_child(UI.center(UI.label("Isso só acontece na primeira vez e leva poucos segundos.", 15, UI.MUTED)))
	for i in 3:
		await get_tree().process_frame
	var res := DataPack.import_zip("res://datapack.zip")
	cover.queue_free()
	_render()
	if res != "":
		toast(res)


func _notification(what: int) -> void:
	# botão "voltar" do Android
	if what != NOTIFICATION_WM_GO_BACK_REQUEST:
		return
	if _modal != null and is_instance_valid(_modal):
		close_modal()          # janela aberta: fecha
	elif body.get_child_count() > 0 and body.get_child(0).has_method("_on_pause"):
		body.get_child(0).call("_on_pause")   # na partida: pausa
	elif back_b != null and back_b.visible:
		back()


# ------------------------------------------------------------ navegação
func go(screen: String, arg = null) -> void:
	stack.append(cur)
	cur = [screen, arg]
	_render()


func replace(screen: String, arg = null) -> void:
	cur = [screen, arg]
	_render()


func back() -> void:
	if stack.is_empty():
		return
	cur = stack.pop_back()
	_render()


func home() -> void:
	stack.clear()
	cur = ["hub", null]
	if Pro.is_pro():
		cur = [{"peneira": "pro_trial", "propostas": "pro_offers", "livre": "pro_offers"}.get(str(Pro.P()["stage"]), "pro_hub"), null]
	_render()


func reset(screen: String) -> void:
	stack.clear()
	cur = [screen, null]
	_render()


func refresh() -> void:
	_render()


var _shown: String = ""   ## tela desenhada por último (a transição só roda quando ela muda)


func _render() -> void:
	close_modal()
	var from := _shown
	_shown = str(cur[0])
	if from != "" and from != _shown:
		_transition(from == "title")
	UI.clear(body)
	if chrome_head != null:
		chrome_head.visible = cur[0] != "title"
	body.add_theme_constant_override("margin_top", 8 if cur[0] == "title" else 14)
	head(cur[0], "", true)
	var f: Callable = screens[cur[0]]
	f.call(body, cur[1])


## Transição entre telas: a nova aparece com um esmaecimento rápido. Saindo do menu de
## abertura, uma cortina verde com fio dourado atravessa a tela (abertura da carreira).
func _transition(from_title: bool) -> void:
	if not is_inside_tree():
		return
	body.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(body, "modulate:a", 1.0, 0.22 if not from_title else 0.35)
	if not from_title:
		return
	var curtain := ColorRect.new()
	curtain.color = Color("07140f")
	curtain.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(curtain)
	curtain.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var edge := ColorRect.new()
	edge.color = UI.GOLD
	edge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	curtain.add_child(edge)
	edge.anchor_left = 0.0
	edge.anchor_right = 0.0
	edge.anchor_bottom = 1.0
	edge.offset_right = 6.0
	var w: float = maxf(size.x, 1.0)
	var ct := create_tween()
	ct.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
	ct.tween_property(curtain, "position:x", w + 10.0, 0.5)
	ct.tween_callback(curtain.queue_free)


func _match_screen(root: Control, _arg) -> void:
	var ls := loading("Preparando o estádio…", 0.8)
	var mv = load(MATCH_VIEW).new()
	mv.m = self
	root.add_child(mv)
	if ls != null:
		ls.step(1.0, "Entrando em campo…")
		ls.close()


# Cabeçalho de cada tela
func head(title: String, sub: String = "", show_back: bool = true) -> void:
	title_l.text = title
	sub_l.text = sub
	sub_l.visible = sub != ""
	back_b.visible = show_back and not stack.is_empty()
	var in_career: bool = not Game.S.is_empty()
	UI.clear(crest_box)
	crest_box.visible = in_career
	mid_box.visible = in_career
	money_p.visible = in_career
	comp_logo_r.visible = in_career
	_apply_comp_theme(CompTheme.current() if in_career else CompTheme.by_id(""))
	if in_career:
		comp_logo_r.texture = DataPack.comp_logo_or_badge(DataPack.comp_id(int(Game.S.get("league", 0))))
		var cr := Crest.make(Game.S["club"], 52)
		crest_box.add_child(cr)
		date_l.text = "%s • Temporada %d" % [Game.month_year(Game.S["day"]), Game.S["season"]]
		central_b.text = "Central • %d" % Game.S["unread"]
		UI.style_button(central_b, "gold" if Game.S["unread"] > 0 else "dark")
		var cash: float = float(Pro.P()["money"]) if Pro.is_pro() else float(Game.S["money"])
		money_l.text = Game.money(cash)
		money_l.add_theme_color_override("font_color", UI.TXT if cash >= 0.0 else Color("ff8b8b"))


# ------------------------------------------------------------ tema do campeonato
## Cabeçalho e fundo seguem a liga da carreira (CompTheme). Só redesenha quando o tema muda.
func _apply_comp_theme(th: Dictionary) -> void:
	var id: String = str(th.get("id", "default"))
	if id == _theme_id:
		return
	_theme_id = id
	shell_theme = th
	if _head_sb != null:
		_head_sb.border_color = th["accent"]
		_head_sb.bg_color = Color(th["bar"]) if id != "default" else UI.HEADER2
	if _deco != null:
		_deco.queue_redraw()


func _draw_deco(deco: Control) -> void:
	var th: Dictionary = shell_theme
	if th.is_empty() or str(th.get("id", "default")) == "default":
		UI.draw_brand_bg(deco, deco.size)
		return
	# fundo da marca sem as pinceladas verdes, tingido com as cores do campeonato
	UI.draw_brand_bg(deco, deco.size, false)
	var sz := deco.size
	var c1: Color = th["bg1"]
	var c2: Color = th["bg2"]
	var n := 12
	for i in n:
		var k := float(i) / float(n - 1)
		deco.draw_rect(Rect2(0, sz.y * i / n, sz.x, sz.y / n + 1.0), Color(c1.lerp(c2, k), 0.55))
	CompTheme.draw_pattern(deco, Rect2(Vector2.ZERO, sz), th, 0.028)
	var acc: Color = th["accent"]
	var acc2: Color = th["accent2"]
	UI.draw_brush(deco, Vector2(-40, sz.y * 0.22), Vector2(sz.x * 0.16, -30), 56.0, Color(acc, 0.16), 3)
	UI.draw_brush(deco, Vector2(-30, sz.y * 0.32), Vector2(sz.x * 0.09, sz.y * 0.05), 14.0, Color(acc2, 0.3), 5)
	UI.draw_brush(deco, Vector2(sz.x * 0.84, sz.y + 30), Vector2(sz.x + 40, sz.y * 0.74), 60.0, Color(acc, 0.16), 7)
	UI.draw_brush(deco, Vector2(sz.x * 0.9, sz.y + 10), Vector2(sz.x + 20, sz.y * 0.86), 14.0, Color(acc2, 0.3), 9)


# ------------------------------------------------------------ avisos e janelas
func toast(text: String) -> void:
	var p := UI.panel(Color("f4f6fa"), 14, 12)
	var l := UI.label(text, 18, UI.DARKTXT, true)
	p.add_child(l)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(p)
	p.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	p.grow_horizontal = Control.GROW_DIRECTION_BOTH
	p.grow_vertical = Control.GROW_DIRECTION_BEGIN
	p.position.y -= 90
	var tw := create_tween()
	tw.tween_interval(2.4)
	tw.tween_property(p, "modulate:a", 0.0, 0.4)
	tw.tween_callback(p.queue_free)


func modal(content: Control) -> void:
	close_modal()
	_modal = ColorRect.new()
	_modal.color = Color(0.01, 0.05, 0.035, 0.82)
	_modal.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay.add_child(_modal)
	_modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var mc := MarginContainer.new()
	for k in ["margin_left", "margin_right"]:
		mc.add_theme_constant_override(k, 120)
	for k in ["margin_top", "margin_bottom"]:
		mc.add_theme_constant_override(k, 50)
	_modal.add_child(mc)
	mc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mc.add_child(content)


func close_modal() -> void:
	if _modal != null and is_instance_valid(_modal):
		_modal.queue_free()
	_modal = null
