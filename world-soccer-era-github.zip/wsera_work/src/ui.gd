class_name UI
# Atalhos para montar a interface por código (cores, botões, painéis).

# Paleta da marca "World Soccer — A Nova Era": preto/grafite com textura, verde neon
# como destaque (com brilho), branco forte para títulos. Dourado só para troféus.
const BG := Color("0b0d0c")
const BG2 := Color("151917")
const PANEL := Color("181c1a")
const PANEL2 := Color("252a27")
const HEADER := Color("39e33f")
const HEADER2 := Color("0e110f")
const NEON := Color("39e33f")          ## verde da marca (amostrado do banner)
const NEON_DARK := Color("1c8f22")
const GOLD := NEON                     ## nome antigo do destaque: agora é o verde da marca
const TROPHY := Color("f2c64a")        ## dourado de taça (títulos, campeão)
const BLUE := Color("2463b8")   # contraste 5,3:1 com texto branco
const TXT := Color("f4f7f5")
const MUTED := Color("a3ada7")
const RED := Color("c2324f")
const GREEN := Color("1e8a2e")  # fundo de botão (texto branco)
const GREEN_TXT := Color("6dff73")  ## verde para texto sobre fundo escuro
const RED_TXT := Color("ff8b8b")    ## vermelho para texto sobre fundo escuro
const DARKTXT := Color("07120a")
const LINE := Color(1, 1, 1, 0.07)       ## borda fina dos cartões
const SURFACE := Color("111412")         ## fundo de seções (entre BG e PANEL)

# Escala de tipografia (px no viewport de 1280x720) e espaçamentos.
const FS_DISPLAY := 34
const FS_H1 := 26
const FS_H2 := 21
const FS_BODY := 17
const FS_SMALL := 14
const FS_CAPTION := 12
const SP_XS := 4
const SP_S := 8
const SP_M := 12
const SP_L := 16
const SP_XL := 24
const TOUCH := 48                        ## alvo de toque mínimo (diretriz do Android: 48dp)

static var _bold: FontVariation
static var _display: FontVariation


static func bold() -> Font:
	if _bold == null:
		_bold = FontVariation.new()
		_bold.base_font = ThemeDB.fallback_font
		_bold.variation_embolden = 0.8
	return _bold


## Fonte de título da marca: bem pesada e inclinada (como o logo). Sem arquivo de fonte extra:
## a fonte do Godot engrossada e com cisalhamento.
static func display() -> Font:
	if _display == null:
		_display = FontVariation.new()
		_display.base_font = ThemeDB.fallback_font
		_display.variation_embolden = 1.25
		_display.variation_transform = Transform2D(Vector2(1, 0), Vector2(-0.2, 1), Vector2.ZERO)
		_display.spacing_glyph = 1
	return _display


static func sbox(color: Color, radius: int = 12, pad: int = 0, border: Color = Color(0, 0, 0, 0), bw: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(radius)
	s.corner_detail = 10   # cantos bem redondos
	s.anti_aliasing = true
	s.set_content_margin_all(pad)
	if bw > 0:
		s.border_color = border
		s.set_border_width_all(bw)
	return s


static func label(text: String, size: int = 18, color: Color = TXT, is_bold: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if is_bold:
		# títulos grandes ganham a fonte da marca (pesada e inclinada)
		l.add_theme_font_override("font", display() if size >= 22 else bold())
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


static func wrap(l: Label) -> Label:
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


static func center(l: Label) -> Label:
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


static func button(text: String, kind: String = "dark", cb: Callable = Callable(), size: int = 18, min_h: int = TOUCH) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, maxi(min_h, TOUCH))
	b.focus_mode = Control.FOCUS_NONE
	b.mouse_filter = Control.MOUSE_FILTER_PASS
	b.clip_text = true
	b.add_theme_font_size_override("font_size", size)
	b.add_theme_font_override("font", display() if kind == "gold" else bold())
	style_button(b, kind)
	if cb.is_valid():
		b.pressed.connect(cb)
	_press_feedback(b)
	return b


## Toque: o botão afunda um pouco e volta (pivô no centro, recalculado quando muda de tamanho).
static func _press_feedback(b: Button) -> void:
	b.resized.connect(func(): b.pivot_offset = b.size * 0.5)
	b.button_down.connect(func():
		if b.is_inside_tree():
			b.create_tween().tween_property(b, "scale", Vector2(0.965, 0.965), 0.07))
	b.button_up.connect(func():
		if b.is_inside_tree():
			b.create_tween().tween_property(b, "scale", Vector2.ONE, 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT))


## Estilo de botão com "profundidade": borda inferior mais escura que some ao apertar.
static func _btn_box(bg: Color, depth: int, pressed: bool = false) -> StyleBoxFlat:
	var sb := sbox(bg, 14, 10)
	sb.content_margin_left = 14
	sb.content_margin_right = 14
	if bg.a > 0.5:
		sb.border_color = bg.darkened(0.35)
		sb.border_width_bottom = 0 if pressed else depth
		sb.content_margin_top = 10 + (depth if pressed else 0)
	else:
		sb.border_color = LINE
		sb.set_border_width_all(1)
	return sb


static func style_button(b: Button, kind: String) -> void:
	var bg := PANEL2
	var fg := TXT
	match kind:
		"gold":
			bg = GOLD
			fg = DARKTXT
		"blue":
			bg = BLUE
		"red":
			bg = RED
		"green":
			bg = GREEN
		"flat":
			bg = Color(1, 1, 1, 0.04)
	var normal := _btn_box(bg, 3)
	if kind == "gold":
		normal.shadow_color = Color(NEON, 0.35)   # brilho neon do botão principal
		normal.shadow_size = 6
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", _btn_box(bg.lightened(0.07), 3))
	b.add_theme_stylebox_override("pressed", _btn_box(bg.darkened(0.12), 3, true))
	b.add_theme_stylebox_override("disabled", sbox(Color(bg, 0.35), 14, 10))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(k, fg)
	b.add_theme_color_override("font_disabled_color", Color(fg, 0.5))


static func panel(color: Color = PANEL, pad: int = 14, radius: int = 18) -> PanelContainer:
	var p := PanelContainer.new()
	# cartões opacos ganham uma borda fina clara (separa do fundo sem sombra, que pesa no celular)
	p.add_theme_stylebox_override("panel", sbox(color, radius, pad, LINE, 1 if color.a > 0.5 else 0))
	p.mouse_filter = Control.MOUSE_FILTER_PASS
	return p


static func hbox(sep: int = 8) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", sep)
	h.mouse_filter = Control.MOUSE_FILTER_PASS
	return h


static func vbox(sep: int = 8) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", sep)
	v.mouse_filter = Control.MOUSE_FILTER_PASS
	return v


static func grid(cols: int, sep: int = 8) -> GridContainer:
	var g := GridContainer.new()
	g.columns = cols
	g.add_theme_constant_override("h_separation", sep)
	g.add_theme_constant_override("v_separation", sep)
	g.mouse_filter = Control.MOUSE_FILTER_PASS
	return g


static func expand(c: Control, ratio: float = 1.0) -> Control:
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.size_flags_stretch_ratio = ratio
	return c


static func vexpand(c: Control) -> Control:
	c.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return c


static func spacer() -> Control:
	var c := Control.new()
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.size_flags_vertical = Control.SIZE_EXPAND_FILL
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


static func fixed(c: Control, w: float, h: float = 0.0) -> Control:
	c.custom_minimum_size = Vector2(w, h)
	return c


static func scroll() -> ScrollContainer:
	var s := ScrollContainer.new()
	s.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return s


static func pos_color(pos: String) -> Color:
	if pos == "GOL":
		return Color("e79a3c")
	if pos in ["ZAG", "LD", "LE"]:
		return Color("e0c25c")
	if pos in ["VOL", "MEI"]:
		return Color("6fca8a")
	return Color("7fb4ee")


static func pos_tag(pos: String, size: int = 14) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", sbox(pos_color(pos), 5, 3))
	p.custom_minimum_size = Vector2(size * 3.4, 0)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	p.add_child(center(label(pos, size, DARKTXT, true)))
	return p


static func col(text: String, w: float, size: int = 16, color: Color = TXT, is_bold: bool = false, align: int = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := label(text, size, color, is_bold)
	l.custom_minimum_size = Vector2(w, 0)
	l.horizontal_alignment = align as HorizontalAlignment
	l.clip_text = true
	return l


static func card_title(text: String) -> Label:
	return label(text, 14, MUTED, true)


static func clear(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()


static func _ignore(n: Node) -> void:
	if n is Control:
		n.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for c in n.get_children():
		_ignore(c)


# Botão que leva qualquer conteúdo dentro (linha de lista, cartão clicável)
static func row_button(content: Control, cb: Callable = Callable(), min_h: int = 50, kind: String = "flat", pad: int = 10) -> Button:
	var b := button("", kind, cb, 16, min_h)
	var mc := MarginContainer.new()
	mc.add_theme_constant_override("margin_left", pad)
	mc.add_theme_constant_override("margin_right", pad)
	mc.add_theme_constant_override("margin_top", 4)
	mc.add_theme_constant_override("margin_bottom", 4)
	b.add_child(mc)
	mc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mc.add_child(content)
	_ignore(mc)
	return b


static func stepper(text: String, minus: Callable, plus: Callable, w: float = 150.0) -> HBoxContainer:
	var h := hbox(6)
	h.add_child(fixed(button("−", "dark", minus, 22), 52))
	var l := center(label(text, 19, TXT, true))
	l.custom_minimum_size = Vector2(w, 0)
	h.add_child(l)
	h.add_child(fixed(button("+", "dark", plus, 22), 52))
	return h


static func field(title: String, c: Control) -> VBoxContainer:
	var v := vbox(4)
	v.add_child(label(title, 13, MUTED))
	v.add_child(c)
	return v


static func bar(frac: float, color: Color = GOLD, h: float = 6.0) -> ProgressBar:
	var pb := ProgressBar.new()
	pb.show_percentage = false
	pb.min_value = 0.0
	pb.max_value = 1.0
	pb.value = clampf(frac, 0.0, 1.0)
	pb.custom_minimum_size = Vector2(0, h)
	pb.add_theme_stylebox_override("background", sbox(Color(1, 1, 1, 0.1), 3))
	pb.add_theme_stylebox_override("fill", sbox(color, 3))
	pb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return pb


# ------------------------------------------------------------ peças novas
## Etiqueta arredondada (assunto do momento, tom de resposta, efeito).
static func chip(text: String, color: Color = PANEL2, fg: Color = TXT, size: int = FS_SMALL) -> PanelContainer:
	var p := PanelContainer.new()
	var sb := sbox(color, 20, 0)
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 5
	sb.content_margin_bottom = 5
	p.add_theme_stylebox_override("panel", sb)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	p.add_child(center(label(text, size, fg, true)))
	return p


## Medidor com nome, valor e barra colorida pela faixa (vermelho < 35 < dourado < 65 < verde).
static func meter(title: String, value: float, hint: String = "") -> VBoxContainer:
	var v := vbox(3)
	var h := hbox(6)
	h.add_child(expand(label(title, FS_SMALL, MUTED, true)))
	var col := GREEN_TXT if value >= 65.0 else (GOLD if value >= 35.0 else RED_TXT)
	h.add_child(label("%d" % int(round(value)), FS_SMALL, col, true))
	v.add_child(h)
	v.add_child(bar(value / 100.0, col, 8.0))
	if hint != "":
		v.add_child(label(hint, FS_CAPTION, MUTED))
	return v


## Entrada suave: o controle aparece subindo um pouco (atraso em segundos para entrar em sequência).
static func appear(c: Control, delay: float = 0.0) -> Control:
	c.modulate.a = 0.0
	c.ready.connect(func():
		var tw := c.create_tween()
		tw.tween_interval(delay)
		tw.tween_property(c, "modulate:a", 1.0, 0.22), CONNECT_ONE_SHOT)
	return c


## Título de seção com fio dourado à esquerda.
static func section(text: String) -> HBoxContainer:
	var h := hbox(8)
	var r := ColorRect.new()
	r.color = GOLD
	r.custom_minimum_size = Vector2(4, 18)
	r.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_child(r)
	h.add_child(label(text, FS_SMALL, MUTED, true))
	return h


# ------------------------------------------------------------ identidade visual
## Coroa da marca (títulos, troféus, destaques).
static func crown(px: float = 22.0, color: Color = NEON) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(px * 1.3, px)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	c.draw.connect(func(): draw_crown(c, Vector2(c.size.x * 0.5, c.size.y * 0.55), px, color))
	return c


static func draw_crown(ci: CanvasItem, ctr: Vector2, px: float, color: Color) -> void:
	var w := px * 1.2
	var h := px * 0.8
	var b := ctr + Vector2(-w * 0.5, h * 0.5)
	var pts := PackedVector2Array([b, b + Vector2(0, -h * 0.75), b + Vector2(w * 0.25, -h * 0.35), b + Vector2(w * 0.5, -h),
		b + Vector2(w * 0.75, -h * 0.35), b + Vector2(w, -h * 0.75), b + Vector2(w, 0)])
	ci.draw_colored_polygon(pts, color)
	for q in [b + Vector2(0, -h * 0.8), b + Vector2(w * 0.5, -h * 1.05), b + Vector2(w, -h * 0.8)]:
		ci.draw_circle(q, px * 0.09, color)
	ci.draw_rect(Rect2(b.x, b.y + px * 0.04, w, px * 0.12), color)


## Pincelada verde em diagonal (cantos das telas, como no banner). dir = 1 sobe para a direita.
static func draw_brush(ci: CanvasItem, from: Vector2, to: Vector2, thick: float, color: Color, seed_i: int = 1) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_i
	var d := (to - from)
	var n := d.orthogonal().normalized()
	var top := PackedVector2Array()
	var bot := PackedVector2Array()
	var steps := 18
	for i in steps + 1:
		var k := float(i) / steps
		var taper := sin(k * PI) * 0.85 + 0.15
		var p := from + d * k
		top.append(p + n * thick * 0.5 * taper * rng.randf_range(0.8, 1.1))
		bot.append(p - n * thick * 0.5 * taper * rng.randf_range(0.7, 1.05))
	bot.reverse()
	top.append_array(bot)
	ci.draw_colored_polygon(top, color)


## Fundo da marca: preto grafite, faixas diagonais bem sutis, textura de grão e pinceladas
## verdes nos cantos. Desenhar só quando o tamanho muda (é estático).
static func draw_brand_bg(ci: CanvasItem, sz: Vector2, strokes: bool = true) -> void:
	ci.draw_rect(Rect2(Vector2.ZERO, sz), BG)
	var band := 46.0
	var i := -int(sz.y / band) - 2
	while i * band < sz.x + sz.y:
		if i % 3 == 0:
			var x := i * band
			ci.draw_colored_polygon(PackedVector2Array([Vector2(x, sz.y), Vector2(x + band * 0.6, sz.y),
				Vector2(x + band * 0.6 + sz.y * 0.6, 0), Vector2(x + sz.y * 0.6, 0)]), Color(1, 1, 1, 0.012))
		i += 1
	# grão (posições fixas: sempre o mesmo desenho)
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	for k in int(sz.x * sz.y / 9000.0):
		var p := Vector2(rng.randf() * sz.x, rng.randf() * sz.y)
		ci.draw_rect(Rect2(p, Vector2(2, 2)), Color(1, 1, 1, rng.randf_range(0.015, 0.05)))
	if strokes:
		var g := Color(NEON, 0.16)
		draw_brush(ci, Vector2(-40, sz.y * 0.22), Vector2(sz.x * 0.16, -30), 56.0, g, 3)
		draw_brush(ci, Vector2(-30, sz.y * 0.32), Vector2(sz.x * 0.09, sz.y * 0.05), 14.0, Color(NEON, 0.3), 5)
		draw_brush(ci, Vector2(sz.x * 0.84, sz.y + 30), Vector2(sz.x + 40, sz.y * 0.74), 60.0, g, 7)
		draw_brush(ci, Vector2(sz.x * 0.9, sz.y + 10), Vector2(sz.x + 20, sz.y * 0.86), 14.0, Color(NEON, 0.3), 9)
