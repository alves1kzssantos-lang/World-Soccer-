class_name LanceView
extends Control
## Lance em campo, visto de cima, com o time atacante indo para CIMA (como no World Soccer Champs):
## o gol atacado fica no alto da tela, com a rede e as placas de publicidade atrás dele.
## Plano em metros: gol atacado em y = 0, meio-campo em y = 52.5; z = altura.
## Na tela, y do mundo cresce para baixo (y_sign = 1); o FieldView usa o contrário (y_sign = -1).
##
## Como o jogador controla (no ataque do time dele o jogo pausa e fica cinza):
##   toque num companheiro .................. passe RASTEIRO
##   segurar o dedo num companheiro ......... passe ALTO (cruzamento se ele estiver na área)
##   toque dentro do gol .................... chute colocado (toque no fundo da rede = chute alto)
##   deslizar o dedo para cima, até o gol ... chute: direção = mira, tamanho = força
##
## Máquina de estados (transições):
##   intro  -> run
##   run    -> decide | tackle_result (falta, desarme, vantagem)
##   decide -> pass | shot
##   pass   -> run (dominou) | decide (cabeceio na área) | end (corte, domínio ruim, impedimento)
##   shot   -> end (gol, defesa, trave, fora, travado)
##   setpiece (pênalti / falta direta) -> decide (só chute)
##   end    -> done (emite "finished")
## Números: assets/data/match_tuning.json. Regras do juiz: src/referee.gd.

signal finished(result: Dictionary)

const GOAL_HALF := BallPhysics.GOAL_HALF
const CAMERA_WIDTH_M := 30.0   ## quantos metros de largura a câmera do lance mostra (menor = mais perto; ~43 px/m em 1280)
const LIVE_CAM_M := 32.0       ## largura da câmera da partida ao vivo (~40 px/m em 1280); FieldView.FIELD_CAM_M usa este
const STRIPE_M := 9.0          ## largura das faixas cortadas do gramado
const AD_H := 1.25             ## altura das placas de publicidade (metros de tela)
const PITCH := Color("7f9a17")    ## gramado verde-oliva
const STRIDE := 2.7            ## radianos de passada por metro corrido
const LIFT := 0.85             ## pixels de altura por pixel de chão (altura da bola, traves e bonecos)
const BODY_H := 3.15           ## altura desenhada do jogador em metros (exagerada para ler no celular)
const SKINS := [Color("f3cfae"), Color("e4b48a"), Color("c98d5c"), Color("a8703f"), Color("85532f"), Color("5e3a22")]
const HAIRS := [Color("1b1b1f"), Color("2e2018"), Color("5a3a22"), Color("8a5a2b"), Color("c9a24a"), Color("6e6e72")]
const AD_GAP := 3.3            ## distância (m) entre a linha de fundo e as placas atrás do gol atacado
const HUD_TOP := 78.0          ## pixels do placar no topo (a câmera não sobe além das placas)
const INK := Color("17171b")
const NEAR_BLACK := Color("202228")
const OUTLINE := Color("15110e")        ## contorno grosso dos bonecos
const BOOT_ACCENTS := [Color("39e05a"), Color("ff7a1a"), Color("2fd2ff"), Color("ffd21f"), Color("ff3d6e"), Color("f4f4f4")]
const WHITE_TEETH := Color("fbfbfb")
const KEEPER_SHIRT := Color("e8c61c")
const KEEPER_TRIM := Color("2b2b2b")
const REF_SHORTS := Color("15161a")
const BALL_DARK := Color("1c1c1c")
const BALL_WHITE := Color("f1f1f1")
const BALL_RIM := Color("101010")
const HAIR_GREY := Color("8a7060")
const LINE_COL := Color(1, 1, 1, 0.9)
const NET_COL := Color(1, 1, 1, 0.32)
const SEP_STATES := ["run", "pass", "shot", "end"]
const ANIM_KEYS := ["trap", "jump", "fall", "slide", "tc"]
## Linhas do campo do lance (pares de pontos, em metros): laterais, fundo, meio, grande área e pequena área.
const LANCE_LINES := [
	Vector2(-34, 0), Vector2(34, 0), Vector2(-34, 0), Vector2(-34, 70), Vector2(34, 0), Vector2(34, 70),
	Vector2(-34, 52.5), Vector2(34, 52.5),
	Vector2(-20.16, 0), Vector2(-20.16, 16.5), Vector2(20.16, 0), Vector2(20.16, 16.5), Vector2(-20.16, 16.5), Vector2(20.16, 16.5),
	Vector2(-9.16, 0), Vector2(-9.16, 5.5), Vector2(9.16, 0), Vector2(9.16, 5.5), Vector2(-9.16, 5.5), Vector2(9.16, 5.5)]

var sim: MatchSim
var side: int = 0
var user_ctrl: bool = false
var script_kind: String = ""   ## só no ataque da máquina: goal/save/out/lost/offside/penalty
var lost_at: int = 1
var ref: Referee
var bp: BallPhysics

var att: Array = []
var dfn: Array = []
var gk: Dictionary = {}
var kits: Array = []
var carrier: int = 0
var last_passer: int = -1
var presser: int = -1
var state: String = "intro"
var t: float = 0.0
var run_time: float = 0.9
var moments: int = 0
var cam_y: float = 22.0
var pass_to: int = -1
var pass_end: Vector2 = Vector2.ZERO
var pass_lofted: bool = false
var pass_offside: bool = false
var shot_from: Vector2 = Vector2.ZERO
var shot_only: bool = false    ## pênalti, falta direta ou cabeceio: só pode chutar
var header: bool = false
var setpiece: String = ""      ## "", "penalti", "falta_direta"
var wall: Array = []           ## índices dos defensores na barreira
var gk_react: float = 0.2
var gk_speed: float = 4.3
var gk_dive_x: float = 0.0
var gk_checked: bool = false
var gk_tilt: float = 0.0       ## inclinação do goleiro no pulo
var line_y: float = 18.0       ## linha da zaga (também é a linha de impedimento)
var result: Dictionary = {}
var banner: String = ""
var banner_t: float = 0.0
var card_flash: String = ""    ## "amarelo" / "vermelho" desenhado na tela
var pressing: bool = false
var press: Vector2 = Vector2.ZERO
var press_ms: int = 0
var drag_now: Vector2 = Vector2.ZERO
var s: float = 16.8            ## pixels por metro
var referee: Dictionary = {}   ## boneco do árbitro
var me_pid: int = -1           ## modo carreira de jogador: você só joga quando a bola está com ele
var stage_label: String = ""   ## fase/rodada no canto do placar (ex.: "Final", "Rodada 5")
var ads: Array = []            ## placas de publicidade do datapack (texturas)
var ad_t: float = 0.0          ## rolagem das placas de LED
var cel_t: float = 0.0         ## comemoração de gol (segundos)
var cel_ent: Dictionary = {}
var cel_name: String = ""
const STEP := 1.0 / 60.0         ## passo fixo da física (a simulação não depende da taxa de quadros)
var _acc_t: float = 0.0         ## tempo acumulado ainda não simulado
var _bodies_cache: Array = []   ## todos os corpos que colidem (jogadores, goleiro, árbitro)
var _bodies_sig: int = -1
var _path := PackedVector2Array()   ## caminho previsto da bola no passe (a cada PATH_DT)
var _path_z := PackedFloat32Array()
var _path_t0: float = 0.0
var _path_dirty: bool = false
const PATH_DT := 0.05
var gk_catch: bool = false      ## goleiro encaixou a bola (fica com ela nas mãos)
# números do corpo (match_tuning.json, seção "corpo"/"conducao"/"disputa")
var _b_acc := 8.0
var _b_acc_vel := 0.03
var _b_dec := 12.0
var _b_turn0 := 12.6
var _b_turn1 := 4.2
var _b_look := 0.45
var _b_avoid := 3.2
var _b_rest := 0.15
var _b_iter := 4
var _b_h := 1.85
var _b_walk := 2.4
var _t_reach := 0.75
var _settle_reach := 0.9   ## bola a esta distância do pé = dominada (pode decidir)
var _ai_think := 0.2       ## quanto a máquina "pensa" com a bola no pé (o jogo segue rolando)
var _intro_s := 0.25       ## abertura parada do lance antes de a jogada começar a correr
var _run_onside_min := 0.3 ## atacante segura a corrida até esta folga atrás da linha (m; negativo = adiantado)
const POSE_CACHE_MAX := 72
## Poses guardadas valem para a partida inteira (todos os lances e o campo ao vivo), por
## jogador + uniforme; no máximo POSE_STORE_MAX jogadores (os mais antigos saem).
static var _pose_store: Dictionary = {}
static var _pose_order: PackedStringArray = PackedStringArray()
const POSE_STORE_MAX := 30


func _pcache_of(e: Dictionary, cols: Array, ref_kit: bool) -> Dictionary:
	var pc: Variant = e.get("_pcache", null)
	if pc != null:
		return pc
	var pid: int = int(e["p"]["id"]) if e.has("p") else -1
	var key := "%s%d|%s|%s|%s|%s" % ["r" if ref_kit else "", pid, (cols[0] as Color).to_html(), (cols[1] as Color).to_html(), (cols[2] as Color).to_html(), str(cols[6])]
	var d: Dictionary = _pose_store.get(key, {})
	if not _pose_store.has(key):
		_pose_store[key] = d
		_pose_order.append(key)
		if _pose_order.size() > POSE_STORE_MAX:
			_pose_store.erase(_pose_order[0])
			_pose_order.remove_at(0)
	e["_pcache"] = d
	return d


const REF_KIT: Array = []   ## "uniforme" do árbitro: o mesmo array sempre (o cache de cores compara por identidade)   ## poses guardadas por jogador (3 vistas × 2 lados × parado/passadas)
var _desat: float = 0.0    ## 0..1: cena em preto e branco enquanto você decide (anéis e números ficam coloridos)
var _t_ahead := 1.25
var _t_vmax := 9.5
var _ft_base := 0.15
var _ft_vel := 0.035
var _d_reach := 1.15
var _d_shield := 22.0
var _d_behind := 0.22
var _d_stun := 0.9
var _d_bounce := 0.35
var _d_jockey := 1.5
var body_scale: float = 1.0     ## tamanho dos bonecos na tela (a partida usa um pouco maior que o avatar)
var zoom: float = 1.0           ## aproximação da câmera (1 = visão normal; o pênalti aproxima)
var runup_done: bool = false    ## pênalti: a corrida do batedor já terminou (o chute guardado foi feito)
var _runup_shot: Array = []     ## pênalti: chute pedido [tx, h, p], feito quando o batedor chega na bola
var _pen_gk: float = 0.0        ## pênalti: canto que o goleiro escolheu antes da cobrança
var reacted: bool = false       ## reação de jogadores e torcida já disparada no fim do lance
var confetti: Array = []        ## papel picado da torcida: [pos, vel, cor, giro]
var net_shake: float = 0.0      ## rede balançando depois do gol (1 -> 0)
var net_x: float = 0.0
# Comemoração do gol (design/gdd/fisica-gameplay.md §4.1): o autor corre ao canto da tela e desliza de
# joelhos; companheiros fazem a roda em volta dele. Estados do autor em e["cs"] (tabela CEL_STEPS).
const CEL_STEPS := {"run": ["slide", "pose"], "slide": ["kneel"], "kneel": [], "pose": []}
var slide_chance: float = -1.0  ## chance da deslizada de joelhos (< 0: lê do ajuste)
var skipped: bool = false       ## lance pulado: comemoração curta, sem a corrida
var cel_spot: Vector2 = Vector2.ZERO   ## onde o autor do gol termina a corrida/deslizada
var cel_dir: Vector2 = Vector2(1, 0)   ## direção da corrida do autor
var skids: Array = []           ## marcas na grama: [pos, idade, perpendicular]
var spray: Array = []           ## grama levantada: [pos, vel, z, vz, idade, cor]
var _fx_rng := RandomNumberGenerator.new()   ## sorteios só visuais (não mexem no Game.rng)
var _c_run_v := 8.2
var _c_fric := 5.5
var _c_run_min := 6.0
var _c_run_max := 10.0
var _c_corner := Vector2(15.0, 3.5)
var _c_zoom := 1.22
var _c_wait := 0.45
var _c_end := 4.0
var _c_ring := 1.3
var _c_skid_life := 2.6
var _cam_vy: float = 0.0
var _cam_lead: float = 0.35     ## câmera olha à frente da bola (segundos de movimento)
var _cam_omega: float = 4.5    ## rigidez da mola da câmera
var cam_x: float = 0.0         ## x do mundo no meio da tela (a câmera acompanha a bola de lado)
var _cam_vx: float = 0.0
var _v_base: float = 3.8         ## velocidade: base + ponto de atributo (lidos do ajuste uma vez)
var _v_pt: float = 0.055
var flip: bool = false          ## lance contínuo do mandante: o gol atacado fica embaixo na tela (igual ao campo ao vivo)
var seamless: bool = false      ## lance que nasceu da partida ao vivo (sem faixa de abertura, mesmas posições)
var band_ref: float = -1.0      ## faixas do gramado no y do campo inteiro (>= 0: y_campo = band_ref - y_lance)
var _drag_pts := PackedVector2Array()   ## caminho do dedo no arrasto (curva do chute)
var y_sign: float = 1.0        ## 1 = y do mundo cresce para baixo na tela (lance); -1 = para cima (FieldView)
static var _boxes: Dictionary = {}        ## raio -> {cor -> StyleBoxFlat}
static var _hud: Dictionary = {}          ## estilos do HUD (ver _hsb)
static var _brush_poly := PackedVector2Array()
const HUD_GLASS := Color(0.043, 0.051, 0.047, 0.86)   ## vidro grafite dos painéis do HUD (tema padrão)
## Tema do HUD (CompTheme da competição da partida). Mudar o tema refaz o cache de estilos.
static var hud_theme: Dictionary = {}
static var hud_acc: Color = UI.NEON          ## destaque do tema (formas, contornos, brilho)
static var hud_txt: Color = UI.NEON          ## destaque como texto (contraste garantido)
static var hud_acc2: Color = Color.WHITE
static var hud_glass: Color = HUD_GLASS
static var hud_bar: Color = Color(0.035, 0.043, 0.039, 0.96)
static var hud_score_bg: Color = Color("050706")
static var hud_logo: Texture2D = null        ## logo da competição (chip do placar)
const MINIMAP_PITCH := Color("1d3318")
const MINIMAP_LINE := Color(1, 1, 1, 0.4)
const ATTR_KEYS := ["vel", "pas", "chu", "des"]
const ATTR_NAMES := ["VEL", "PAS", "CHU", "DES"]

# --- números do arquivo de ajuste usados a cada quadro (lidos uma vez no setup)
var _tz_depth: float = 10.0
var _tz_line_min: float = 6.0
var _tz_line_max: float = 30.0
var _tz_compact: float = 0.62
var _tz_shift: float = 0.35
var _tz_cover: float = 2.4
var _tz_cut_react: float = 0.18

# --- caches de desenho e de lógica (evitam alocar arrays a cada quadro)
var _sep_ents: Array = []                  ## todo mundo que não pode se atravessar
var _sep_pos := PackedVector2Array()
var _sep_sig: int = -1
var _ro_ents: Array = []                   ## ordem de desenho: entidades (null = bola)
var _ro_kind := PackedInt32Array()         ## 0 atacante, 1 defensor, 2 goleiro, 3 árbitro, 4 bola
var _ro_key := PackedFloat32Array()
var _ro_ord := PackedInt32Array()
var _ro_sig: int = -1
var _bp := PackedVector2Array()            ## lote de triângulos já na tela (uma draw call)
var _bc := PackedColorArray()
var _lp := PackedVector2Array()            ## triângulos da peça atual, em coordenadas locais
var _lk: float = 1.0                       ## pixels por unidade local (define quantos lados o círculo tem)
var _batch_open: bool = false
var _ci_override := RID()                  ## sprites: o lote vai para o canvas do assador (SpriteBank) em vez do próprio
var _bake_part: int = 0                    ## sprites: 0 desenho normal, 1 só o corpo, 2 só a cabeça (assando)
var _bake_force := Vector2i.ZERO           ## sprites: (andar, fase de 8) forçados ao assar
var _goal_far: Array = []                  ## gol desenhado em cache (ver _goal_build), relativo à trave esquerda
var _goal_near: Array = []
var _lines_buf := PackedVector2Array()
var _dash_buf := PackedVector2Array()
var _dash_w: float = -1.0
static var _tmpl: Dictionary = {}
static var _rr_cache: Dictionary = {}      ## retângulos arredondados prontos (tamanho, canto, lados)
static var _cfill: Dictionary = {}         ## listas de cor prontas (cor + tamanho -> PackedColorArray)          ## modelos de círculo/quartos/pentágono/sorriso (gerados uma vez)


## Monta o lance. side = time que ataca; user_ = é o time do jogador?
func setup(sim_: MatchSim, side_: int, user_: bool) -> void:
	sim = sim_
	side = side_
	user_ctrl = user_
	ref = Referee.new(Game.rng)
	bp = BallPhysics.new()
	if not user_ctrl:
		script_kind = sim.lance_script()
		lost_at = Game.rng.randi_range(1, 2)
	var ac: Dictionary = Game.club(sim.cid(side))
	var dc: Dictionary = Game.club(sim.cid(1 - side))
	var am := Color(str(ac["c1"]))
	var dm := Color(str(dc["c1"]))
	var dt := Color(str(dc["c2"]))
	if _close(am, dm):
		dm = Color(str(dc["c2"]))
		dt = Color(str(dc["c1"]))
		if _close(am, dm):
			dm = Color("f0a419")
	# 3º item = camisa listrada? (lista em world_data.gd, pelo nome original do clube)
	var a_str: bool = striped(ac)
	var d_str: bool = striped(dc) and dm == Color(str(dc["c1"]))
	kits = [[am, Color(str(ac["c2"])), a_str], [dm, dt, d_str]]
	banner = "ATAQUE DO %s" % str(ac["name"]).to_upper()

	# --- atacantes (quem foi expulso não entra)
	var aslots: Array = Game.FORMATIONS[ac["formation"]]
	var anum := _numbers(aslots)
	var mids: Array = []
	var fwd: Array = []
	for i in 11:
		if sim.is_out_of_play(ac["xi"][i]):
			continue
		var ps: String = aslots[i][0]
		if ps in ["MEI", "VOL"]:
			mids.append(i)
		elif ps in ["PD", "PE", "AC"]:
			fwd.append(i)
	if mids.is_empty() and fwd.is_empty():
		for i in 11:
			if not sim.is_out_of_play(ac["xi"][i]) and aslots[i][0] != "GOL":
				mids.append(i)
	var cs: int = mids[Game.rng.randi_range(0, mids.size() - 1)] if not mids.is_empty() else fwd[0]
	var my_i: int = ac["xi"].find(me_pid) if me_pid >= 0 else -1
	if my_i >= 0 and aslots[my_i][0] != "GOL" and not sim.is_out_of_play(me_pid):
		cs = my_i   # o lance começa com o seu jogador
		if not (my_i in mids) and not (my_i in fwd):
			mids.append(my_i)
	var order: Array = [cs]
	for i in fwd:
		if i != cs:
			order.append(i)
	for i in mids:
		if i != cs and order.size() < 6:
			order.append(i)
	for i in order:
		var sl: Array = aslots[i]
		var x: float = (float(sl[1]) - 0.5) * 40.0
		var pos := Vector2(x, 33.0 + Game.rng.randf_range(0.0, 4.0))
		if i == cs:
			pos = Vector2(x * 0.5, 41.0)
		elif sl[0] in ["PD", "PE", "AC"]:
			pos = Vector2(x, 19.0 + (0.9 - float(sl[2])) * 30.0 + Game.rng.randf_range(0.0, 3.0))
		var e := _ent(Game.player(ac["xi"][i]), pos, anum[i])
		e["fwd"] = sl[0] in ["PD", "PE", "AC"]
		att.append(e)
	carrier = 0

	# --- defensores: linha de 4 (ou 3/5), volantes protegendo, goleiro
	var dslots: Array = Game.FORMATIONS[dc["formation"]]
	var dnum := _numbers(dslots)
	for i in 11:
		var pid: int = dc["xi"][i]
		if sim.is_out_of_play(pid):
			continue
		var ps2: String = dslots[i][0]
		var x2: float = -(float(dslots[i][1]) - 0.5) * 50.0
		if ps2 == "GOL":
			gk = _ent(Game.player(pid), Vector2(0, 1.3), dnum[i])
		elif ps2 in ["ZAG", "LD", "LE"]:
			var d := _ent(Game.player(pid), Vector2(x2, 18.0), dnum[i])
			d["role"] = "line"
			dfn.append(d)
		elif ps2 == "VOL":
			var d2 := _ent(Game.player(pid), Vector2(x2, 28.0 + Game.rng.randf_range(0.0, 3.0)), dnum[i])
			d2["role"] = "mid"
			dfn.append(d2)
	if gk.is_empty():
		# goleiro expulso: um zagueiro vai para o gol
		gk = dfn.pop_front() if not dfn.is_empty() else _ent(Game.player(dc["xi"][0]), Vector2(0, 1.3), 1)
		gk["pos"] = Vector2(0, 1.3)
	# face: 1 = de frente para a câmera (para baixo na tela), -1 = de costas.
	# O gol atacado fica em cima: a zaga e o goleiro olham para baixo; o ataque, para cima.
	gk["face"] = 1.0
	for d in dfn:
		d["face"] = 1.0
		d["home"] = d["pos"]
	for e in att:
		e["face"] = -1.0
	_load_tuning()
	_load_body_tuning()
	body_scale = Tuning.f("corpo", "escala_desenho", 1.18)
	gk["keeper"] = true
	bp.place(att[0]["pos"] + Vector2(0, -0.6))
	referee = {"p": {"id": 3}, "pos": bp.pos + Vector2(9, 6), "num": 0, "ph": 0.0, "moving": false, "dir": Vector2(0, -1),
		"face": 1.0, "skin": SKINS[1], "hair": HAIRS[0], "is_ref": true, "vel": Vector2.ZERO}
	if script_kind == "penalty":
		_setup_penalty(att[0]["pos"])


## Efeito do chute pela curva do arraste: o dedo que faz uma barriga para um lado
## (antes de chegar ao ponto final) faz a bola sair para esse lado e voltar.
## Devolve a aceleração lateral (m/s²) ou NAN quando o arraste é reto.
static func swipe_curl(a: Vector2, b: Vector2, pts: PackedVector2Array) -> float:
	var chord := b - a
	var L := chord.length()
	if L < 40.0 or pts.size() < 3:
		return NAN
	var nrm := Vector2(-chord.y, chord.x) / L
	var dev := 0.0
	for q in pts:
		var d: float = (q - a).dot(nrm)
		if absf(d) > absf(dev):
			dev = d
	var bend: float = dev / L
	if absf(bend) < 0.06:
		return NAN
	# barriga para a direita da tela (x maior) = a bola sai para a direita e curva para a esquerda
	var side_x: float = signf(nrm.x * dev) if absf(nrm.x) > 0.01 else signf(dev)
	return -side_x * clampf(absf(bend) * 3.0, 0.0, 1.0) * Tuning.f("bola", "curva_arraste_max", 5.0)


## Lance contínuo: nasce no ponto exato da partida ao vivo (mesmas posições, bola,
## câmera e escala) e sem faixa de abertura. Nas contas do lance o gol atacado continua
## em y = 0; só o desenho muda (flip: o mandante ataca para baixo na tela, igual ao campo).
## fv é o FieldView da partida (só lido aqui).
func setup_from_field(sim_: MatchSim, side_: int, user_: bool, fv: Control) -> void:
	setup(sim_, side_, user_)
	seamless = true
	var fwd: float = fv.FWD[side_]
	var g: float = fv.OWN_GOAL[1 - side_]
	flip = fwd < 0.0
	y_sign = -1.0 if flip else 1.0
	band_ref = -1.0 if flip else float(fv.LENGTH)
	banner = ""
	banner_t = 0.0
	_intro_s = 0.0
	for e in att + dfn + [gk]:
		e["face"] = float(e["face"]) * y_sign
	# câmera e escala iguais às da partida ao vivo; depois aproxima devagar
	var fs: float = maxf(fv.size.x, 1.0) / float(fv.FIELD_CAM_M)
	zoom = CAMERA_WIDTH_M / float(fv.FIELD_CAM_M)
	s = fs
	cam_x = float(fv.cam_x)
	cam_y = float(fv.cam_y) if flip else float(fv.LENGTH) - (float(fv.cam_y) + maxf(fv.size.y, 1.0) / fs)
	if script_kind == "penalty":
		return   # pênalti: a cobrança arruma os jogadores (a câmera aproxima)
	var by_id := {}
	for t in fv.teams:
		for fe in t:
			by_id[int(fe["p"]["id"])] = fe
	var have := {}
	for e in att + dfn + [gk]:
		have[int(e["p"]["id"])] = true
	# quem não entrava no lance (laterais, zagueiros do ataque, meias da defesa) entra também:
	# ninguém some da tela na troca
	for fe in fv.teams[side_]:
		if not have.has(int(fe["p"]["id"])) and not fe.get("keeper", false):
			var na := _ent(fe["p"], Vector2.ZERO, int(fe["num"]))
			na["face"] = -y_sign
			att.append(na)
	for fe in fv.teams[1 - side_]:
		if not have.has(int(fe["p"]["id"])) and not fe.get("keeper", false):
			var nd := _ent(fe["p"], Vector2.ZERO, int(fe["num"]))
			nd["role"] = "mid"
			nd["face"] = y_sign
			dfn.append(nd)
	for e in att + dfn + [gk]:
		var fe2: Variant = by_id.get(int(e["p"]["id"]), null)
		if fe2 == null:
			continue
		var fp: Vector2 = fe2["pos"]
		e["pos"] = Vector2(fp.x, (g - fp.y) * fwd)
		var fvl: Vector2 = fe2.get("vel", Vector2.ZERO)
		e["vel"] = Vector2(fvl.x, -fvl.y * fwd)
		var fd: Vector2 = fe2.get("dir", Vector2(0, 1))
		e["dir"] = Vector2(fd.x, -fd.y * fwd).normalized() if fd.length() > 0.01 else Vector2(0, -1)
		e["ph"] = float(fe2.get("ph", 0.0))
		e["run"] = e["pos"]
		e["home"] = e["pos"]
		# faixa da formação (largura) de cada um: ninguém se amontoa na bola
		var sl: Array = fe2.get("slot", [])
		if not sl.is_empty():
			e["slot"] = sl
			var team_sd: int = side_ if att.has(e) else 1 - side_
			e["lane"] = clampf((float(sl[1]) - 0.5) * 58.0 * (1.0 if team_sd == 0 else -1.0), -30.0, 30.0)
			if dfn.has(e) and str(e["role"]) != "line" and str(sl[0]) != "VOL":
				e["role"] = "track"
				e["off"] = {"MEI": 11.0, "PD": 13.0, "PE": 13.0, "AC": 26.0}.get(str(sl[0]), 12.0)
	if not fv.referee.is_empty():
		var rp: Vector2 = fv.referee["pos"]
		referee["pos"] = Vector2(rp.x, (g - rp.y) * fwd)
	# quem estava com a bola na partida continua com ela
	if int(fv.owner_side) == side_ and int(fv.holder) >= 0 and int(fv.holder) < fv.teams[side_].size():
		var hid: int = int(fv.teams[side_][fv.holder]["p"]["id"])
		for i in att.size():
			if int(att[i]["p"]["id"]) == hid:
				carrier = i
				break
	var bfp: Vector2 = fv.bp.pos
	var bl := Vector2(bfp.x, (g - bfp.y) * fwd)
	if bl.distance_to(att[carrier]["pos"]) < 2.5:
		bp.place(bl)
	else:
		bp.place(att[carrier]["pos"] + Vector2(0, -0.6))


## Lance contínuo do jogador: a jogada entra em câmera lenta até a hora de decidir.
func _slowmo_k() -> float:
	if seamless and user_ctrl and moments == 0 and state in ["intro", "run"]:
		return Tuning.f("ritmo", "camera_lenta_entrada", 0.4)
	return 1.0


## Lê do arquivo de ajuste os números que a zaga usa a cada quadro.
func _load_body_tuning() -> void:
	_v_base = Tuning.f("corpo", "vel_base", 3.8)
	_v_pt = Tuning.f("corpo", "vel_por_ponto", 0.055)
	_b_acc = Tuning.f("corpo", "aceleracao", 8.0)
	_b_acc_vel = Tuning.f("corpo", "aceleracao_por_vel", 0.03)
	_b_dec = Tuning.f("corpo", "freada", 12.0)
	_b_turn0 = deg_to_rad(Tuning.f("corpo", "giro_parado_graus", 720.0))
	_b_turn1 = deg_to_rad(Tuning.f("corpo", "giro_correndo_graus", 240.0))
	_b_look = Tuning.f("corpo", "olhar_a_frente_s", 0.45)
	_b_avoid = Tuning.f("corpo", "forca_desvio", 3.2)
	_b_rest = Tuning.f("corpo", "restituicao", 0.15)
	_b_iter = int(Tuning.f("corpo", "iteracoes_colisao", 4))
	_b_h = Tuning.f("corpo", "altura", 1.85)
	_b_walk = Tuning.f("corpo", "velocidade_caminhada", 2.4)
	_t_reach = Tuning.f("conducao", "alcance_toque", 0.75)
	_settle_reach = Tuning.f("ritmo", "bola_dominada_m", 0.9)
	_ai_think = Tuning.f("ritmo", "maquina_pensa_s", 0.2)
	_intro_s = Tuning.f("ritmo", "abertura_parada_s", 0.25)
	_run_onside_min = Tuning.f("ritmo", "corrida_folga_linha_m", 0.3)
	_t_ahead = Tuning.f("conducao", "toque_a_frente", 1.25)
	_t_vmax = Tuning.f("conducao", "toque_max_vel", 9.5)
	_ft_base = Tuning.f("conducao", "erro_dominio_base", 0.15)
	_ft_vel = Tuning.f("conducao", "erro_dominio_por_vel", 0.035)
	_d_reach = Tuning.f("disputa", "alcance_bote", 1.15)
	_d_shield = Tuning.f("disputa", "bonus_protecao", 22.0)
	_d_behind = Tuning.f("disputa", "falta_extra_por_tras", 0.22)
	_d_stun = Tuning.f("disputa", "atordoado_bote_errado", 0.9)
	_d_bounce = Tuning.f("disputa", "ricochete_corpo", 0.35)
	_d_jockey = Tuning.f("disputa", "distancia_cerco", 1.5)


func _load_tuning() -> void:
	_tz_depth = Tuning.f("zaga", "profundidade_linha", 10.0)
	_tz_line_min = Tuning.f("zaga", "linha_minima", 6.0)
	_tz_line_max = Tuning.f("zaga", "linha_maxima", 30.0)
	_tz_compact = Tuning.f("zaga", "compactacao", 0.62)
	_tz_shift = Tuning.f("zaga", "deslocar_para_bola", 0.35)
	_tz_cover = Tuning.f("zaga", "distancia_cobertura", 2.4)
	_tz_cut_react = Tuning.f("passe", "reacao_corte", 0.18)
	if slide_chance < 0.0:
		slide_chance = Tuning.f("comemoracao", "chance_deslizada", 0.6)
	_c_run_v = Tuning.f("comemoracao", "velocidade_corrida", 8.2)
	_c_fric = Tuning.f("comemoracao", "atrito_grama_deslizada", 5.5)
	_c_run_min = Tuning.f("comemoracao", "corrida_min", 6.0)
	_c_run_max = Tuning.f("comemoracao", "corrida_max", 10.0)
	_c_corner = Vector2(Tuning.f("comemoracao", "canto_x", 15.0), Tuning.f("comemoracao", "canto_y", 3.5))
	_c_zoom = minf(Tuning.f("comemoracao", "zoom_camera", 1.22), 1.1)   # câmera já perto: aproxima pouco
	_c_wait = Tuning.f("comemoracao", "espera_tela_grande", 0.45)
	_c_end = Tuning.f("comemoracao", "duracao_fim_gol", 4.0)
	_c_ring = Tuning.f("comemoracao", "raio_roda_companheiros", 1.3)
	_c_skid_life = Tuning.f("comemoracao", "vida_marca_grama", 2.6)


## Caixa arredondada (estilo dos menus), com cache dos estilos (chave: raio -> cor, sem montar texto).
func _rbox(r: Rect2, col: Color, rad: int = 14) -> void:
	var by_col = _boxes.get(rad)
	if by_col == null:
		by_col = {}
		_boxes[rad] = by_col
	var sb: StyleBoxFlat = by_col.get(col)
	if sb == null:
		sb = StyleBoxFlat.new()
		sb.bg_color = col
		sb.set_corner_radius_all(rad)
		sb.corner_detail = 8
		sb.anti_aliasing = true
		by_col[col] = sb
	draw_style_box(sb, r)


# ------------------------------------------------------------ HUD da partida (identidade da marca)
## Aplica o tema da competição ao HUD das partidas (placar, cartão, posse, minimapa, faixas).
## Só refaz os estilos quando o tema muda.
static func set_hud_theme(th: Dictionary) -> void:
	if th.is_empty():
		th = CompTheme.by_id("")
	if not hud_theme.is_empty() and str(hud_theme.get("id", "")) == str(th.get("id", "")):
		return
	hud_theme = th
	hud_acc = th["accent"]
	hud_txt = th["text_acc"]
	hud_acc2 = th["accent2"]
	hud_glass = th["glass"]
	var bar: Color = th["bar"]
	hud_bar = Color(bar.r, bar.g, bar.b, 0.96)
	hud_score_bg = th["score"]
	_hud.clear()


## Estilos do HUD no tema atual: vidro, contorno e brilho no destaque do tema, chips. Montados uma vez por tema.
static func _hsb(key: StringName) -> StyleBoxFlat:
	var sb: StyleBoxFlat = _hud.get(key)
	if sb != null:
		return sb
	sb = StyleBoxFlat.new()
	sb.anti_aliasing = true
	sb.corner_detail = 8
	sb.bg_color = hud_glass
	match key:
		&"glass":        # painel de vidro escuro com fio claro
			sb.set_corner_radius_all(14)
			sb.border_color = Color(1, 1, 1, 0.09)
			sb.set_border_width_all(1)
		&"glass_neon":   # cartão do jogador: contorno verde com brilho
			sb.set_corner_radius_all(14)
			sb.border_color = Color(hud_acc, 0.85)
			sb.set_border_width_all(2)
			sb.shadow_color = Color(hud_acc, 0.22)
			sb.shadow_size = 8
		&"score":        # bloco do placar no estilo do tema: inclinado, bloco reto ou pílula
			sb.bg_color = hud_score_bg
			sb.border_color = hud_acc
			sb.set_border_width_all(2)
			sb.shadow_color = Color(hud_acc, 0.35)
			sb.shadow_size = 10
			match str(hud_theme.get("score_style", "inclinado")):
				"bloco":
					sb.set_corner_radius_all(2)
					sb.set_border_width_all(3)
				"pilula":
					sb.set_corner_radius_all(28)
				_:
					sb.set_corner_radius_all(6)
					sb.skew = Vector2(0.22, 0.0)
		&"chip":         # chip de atributo
			sb.bg_color = Color(1, 1, 1, 0.07)
			sb.set_corner_radius_all(6)
		&"chip_neon":    # chip do minuto / fase / botão Pular: grafite com fio verde
			sb.bg_color = Color(0.03, 0.04, 0.035, 0.92)
			sb.set_corner_radius_all(7)
			sb.border_color = Color(hud_acc, 0.7)
			sb.set_border_width_all(1)
			sb.skew = Vector2(0.22, 0.0)
		&"button":       # Pular / pausa: vidro com contorno neon e brilho
			sb.set_corner_radius_all(12)
			sb.border_color = hud_acc
			sb.set_border_width_all(2)
			sb.shadow_color = Color(hud_acc, 0.3)
			sb.shadow_size = 8
		&"track":        # trilho escuro das barras
			sb.bg_color = Color(0, 0, 0, 0.6)
			sb.set_corner_radius_all(4)
		&"hint":         # dica do lance (pílula escura)
			sb.bg_color = Color(0.03, 0.04, 0.035, 0.84)
			sb.set_corner_radius_all(22)
			sb.border_color = Color(hud_acc, 0.45)
			sb.set_border_width_all(1)
		&"banner":       # faixa do meio da tela (defesa, impedimento...)
			sb.bg_color = Color(0.03, 0.04, 0.035, 0.88)
			sb.set_corner_radius_all(8)
			sb.border_color = Color(1, 1, 1, 0.1)
			sb.set_border_width_all(1)
			sb.shadow_color = Color(0, 0, 0, 0.35)
			sb.shadow_size = 14
			sb.skew = Vector2(0.18, 0.0)
		&"banner_goal":  # faixa de gol: contorno e brilho neon
			sb.bg_color = Color(0.03, 0.04, 0.035, 0.92)
			sb.set_corner_radius_all(8)
			sb.border_color = hud_acc
			sb.set_border_width_all(3)
			sb.shadow_color = Color(hud_acc, 0.38)
			sb.shadow_size = 18
			sb.skew = Vector2(0.18, 0.0)
		&"card_y", &"card_r":   # cartão amarelo / vermelho
			sb.bg_color = Color("f2d21f") if key == &"card_y" else Color("d7263d")
			sb.set_corner_radius_all(6)
			sb.border_color = Color(0, 0, 0, 0.55)
			sb.set_border_width_all(2)
			sb.shadow_color = Color(0, 0, 0, 0.45)
			sb.shadow_size = 10
	_hud[key] = sb
	return sb


## Pincelada da marca em coordenadas unitárias (de (0, 0) a (1, 0), espessura 1), gerada uma vez.
static func _brush_unit() -> PackedVector2Array:
	if _brush_poly.is_empty():
		var rng := RandomNumberGenerator.new()
		rng.seed = 11
		var top := PackedVector2Array()
		var bot := PackedVector2Array()
		var steps := 18
		for i in steps + 1:
			var k := float(i) / steps
			var taper := sin(k * PI) * 0.8 + 0.2 + k * 0.15   # termina mais grossa, como pincel arrastado
			top.append(Vector2(k, -0.5 * taper * rng.randf_range(0.8, 1.1)))
			bot.append(Vector2(k + rng.randf_range(-0.004, 0.004), 0.5 * taper * rng.randf_range(0.7, 1.05)))
		bot.reverse()
		top.append_array(bot)
		_brush_poly = top
	return _brush_poly


## Pincelada verde (sem criar arrays: o mesmo polígono, só muda a transformação).
func _brush_at(from: Vector2, length: float, thick: float, ang: float, col: Color) -> void:
	draw_set_transform(from, ang, Vector2(length, thick))
	draw_colored_polygon(_brush_unit(), col)
	draw_set_transform(Vector2.ZERO)


## Retângulo inclinado como o logo (k = quanto o topo vai para a direita por pixel de altura).
func _slant_rect(r: Rect2, col: Color, k: float = 0.22) -> void:
	draw_set_transform_matrix(Transform2D(Vector2(1, 0), Vector2(-k, 1), Vector2(r.position.x + r.size.y * k * 0.5, r.position.y)))
	draw_rect(Rect2(Vector2.ZERO, r.size), col)
	draw_set_transform_matrix(Transform2D.IDENTITY)


## Título da marca: branco (ou col), contorno escuro e brilho verde em volta.
func _glow_text(fnt: Font, pos: Vector2, text: String, w: float, fs: int, col: Color, glow: float = 0.22) -> void:
	if glow > 0.0:
		draw_string_outline(fnt, pos, text, HORIZONTAL_ALIGNMENT_CENTER, w, fs, int(fs * 0.36), Color(hud_acc, glow))
	draw_string_outline(fnt, pos, text, HORIZONTAL_ALIGNMENT_CENTER, w, fs, maxi(int(fs * 0.16), 4), Color(0.01, 0.02, 0.015, 0.92))
	draw_string(fnt, pos, text, HORIZONTAL_ALIGNMENT_CENTER, w, fs, col)


## Faixa do meio da tela ("GOOOL!", "Defesa de..."): título inclinado branco sobre grafite e pincelada neon.
func _draw_banner(text: String, goal: bool, bw: float) -> void:
	var mid := size.x / 2.0
	var y0: float = size.y * 0.36
	var fs: int = 44 if goal else 32
	draw_style_box(_hsb(&"banner_goal" if goal else &"banner"), Rect2(mid - bw / 2.0, y0, bw, 84))
	var tst: String = str(hud_theme.get("title_style", "inclinado"))
	if tst == "caixa":
		# faixa reta na segunda cor do tema em cima do título
		draw_rect(Rect2(mid - bw / 2.0 + 18.0, y0 + 8.0, bw - 36.0, 4.0), Color(hud_acc2, 0.9))
	_brush_at(Vector2(mid - bw * 0.3, y0 + 66.0), bw * 0.6, 11.0 if goal else 7.0, -0.025, Color(hud_acc, 0.95 if goal else 0.85))
	if tst == "espacado":
		text = _spaced(text)
		fs = int(fs * 0.86)
	_glow_text(UI.display(), Vector2(mid - bw / 2.0, y0 + 52.0 + (4.0 if goal else 0.0)), text, bw, fs, Color.WHITE, 0.3 if goal else 0.14)


static var _sp_src: String = ""
static var _sp_out: String = ""

## Título com letras espaçadas (estilo "espacado" dos temas); guarda o último para não refazer a cada quadro.
static func _spaced(text: String) -> String:
	if text == _sp_src:
		return _sp_out
	_sp_src = text
	var parts := PackedStringArray()
	for ch in text:
		parts.append(ch)
	_sp_out = " ".join(parts)
	return _sp_out


## Cor de time legível sobre o trilho escuro (camisas pretas/azul-marinho clareiam um pouco).
static func _hud_team_col(c: Color) -> Color:
	return c.lightened(0.3) if c.get_luminance() < 0.22 else c


## Moldura do minimapa (vidro escuro), energia de quem está com a bola e o gramado escuro com as linhas.
func _minimap_frame(f: Font, m: Rect2, en: float) -> void:
	draw_style_box(_hsb(&"glass"), Rect2(m.position.x - 8, m.position.y - 30, m.size.x + 16, m.size.y + 38))
	draw_string(f, Vector2(m.position.x, m.position.y - 16), "ENERGIA", HORIZONTAL_ALIGNMENT_LEFT, 60, 10, UI.MUTED)
	draw_string(f, Vector2(m.position.x, m.position.y - 16), "%d" % int(round(en * 100.0)), HORIZONTAL_ALIGNMENT_RIGHT, m.size.x, 10, Color.WHITE)
	var eb := Rect2(m.position.x, m.position.y - 11, m.size.x, 5)
	draw_style_box(_hsb(&"track"), eb)
	if en > 0.02:
		_rbox(Rect2(eb.position, Vector2(eb.size.x * clampf(en, 0.0, 1.0), eb.size.y)), hud_acc if en >= 0.35 else UI.RED_TXT, 2)
	draw_rect(m, MINIMAP_PITCH)
	draw_line(Vector2(m.position.x, m.position.y + m.size.y / 2), Vector2(m.end.x, m.position.y + m.size.y / 2), MINIMAP_LINE, 1.0)
	draw_arc(m.position + m.size / 2, 7.0, 0, TAU, 20, MINIMAP_LINE, 1.0)


## Área que a câmera mostra no minimapa (verde translúcido com fio neon) e a borda do campo.
func _minimap_view(m: Rect2, vis: Rect2) -> void:
	draw_rect(vis, Color(hud_acc, 0.14))
	draw_rect(vis, Color(hud_acc, 0.7), false, 1.0)
	draw_rect(m, Color(1, 1, 1, 0.55), false, 1.5)


## Gramado com faixas largas (como na TV), em toda a área visível.
func _pitch_bands() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), _dc(PITCH))
	var ya: float = _s2w(Vector2(0, 0)).y
	var yb: float = _s2w(Vector2(0, size.y)).y
	if band_ref >= 0.0:
		# lance do visitante: as faixas seguem o campo inteiro (mesma fase da partida ao vivo)
		ya = band_ref - ya
		yb = band_ref - yb
	var lo := floori(minf(ya, yb) / STRIPE_M)
	var hi := ceili(maxf(ya, yb) / STRIPE_M)
	var dark := _dc(PITCH.darkened(0.085))
	for k in range(lo, hi + 1):
		if k % 2 == 0:
			continue
		var y0: float = k * STRIPE_M
		var y1: float = (k + 1) * STRIPE_M
		if band_ref >= 0.0:
			y0 = band_ref - y0
			y1 = band_ref - y1
		var a := _w2s(Vector2(0, y0))
		var b := _w2s(Vector2(0, y1))
		draw_rect(Rect2(0, minf(a.y, b.y), size.x, absf(b.y - a.y)), dark)


## Placas de publicidade do datapack atrás da linha de fundo (y do gol, dirv = para onde fica o campo,
## gap = metros entre a linha de fundo e as placas). As placas ficam em pé: sobem na tela a partir da base.
func _draw_adboards(goal_y: float, dirv: float, gap: float = 4.6) -> void:
	var base := _w2s(Vector2(-60.0, goal_y - dirv * gap))
	var hpx: float = AD_H * s
	var top_y: float = base.y - hpx
	draw_rect(Rect2(0, top_y - 4.0, size.x, hpx + 8.0), Color("1c2a5a"))
	if ads.is_empty():
		return
	var x: float = -fmod(ad_t * 18.0, 4000.0)
	var i := 0
	var guard := 0
	while x < size.x and guard < 80:
		guard += 1
		var tex: Texture2D = ads[i % ads.size()]
		var ts := tex.get_size()
		var w: float = hpx * ts.x / maxf(ts.y, 1.0)
		if x + w > 0.0:
			draw_texture_rect(tex, Rect2(x, top_y, w, hpx), false, Color(1, 1, 1).lerp(Color(0.62, 0.62, 0.62), _desat))
		x += w
		i += 1
		if x < 0.0 and i > ads.size() * 6:
			break
	draw_rect(Rect2(0, top_y + hpx, size.x, 3.0), Color(0, 0, 0, 0.35))


## Comemoração: o autor do gol grande na tela, "GOOOOOL!!" e o nome (como no WSC).
func _draw_celebration(_f: Font) -> void:
	if cel_t <= 0.0 or cel_ent.is_empty():
		return
	var k: float = clampf(cel_t / 0.25, 0.0, 1.0)
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.02, 0.05, 0.03, 0.42 * k))
	var mid := size.x / 2.0
	var e: Dictionary = cel_ent.duplicate()
	e["cheer"] = true
	e["cel"] = int(e.get("cel", int(e["p"]["id"]) % 4 if e.has("p") else 0))
	var hop_px: float = 0.0 if e["cel"] == 2 else absf(sin(cel_t * 7.0)) * 12.0   # de joelhos não pula
	e["screen"] = Vector2(mid, size.y * 0.5 - hop_px)
	e["moving"] = false
	e["spd"] = 0.0
	e["face"] = 1.0
	e["dir"] = Vector2(0, 1)
	var s0 := s
	s = s * 2.7 * (0.7 + 0.3 * k)
	_draw_player(e, cel_ent.get("kit", kits[0]), false)
	s = s0
	# "GOOOOOL!!" no estilo do logo: pincelada neon atrás, título pesado inclinado com contorno e brilho
	var y0: float = size.y * 0.5 + 66.0
	_brush_at(Vector2(mid - 250.0, y0 - 8.0), 500.0, 34.0 * k, -0.05, Color(hud_acc, 0.9))
	_brush_at(Vector2(mid - 170.0, y0 + 46.0), 340.0, 7.0 * k, -0.03, Color(hud_acc, 0.95))
	_glow_text(UI.display(), Vector2(0, y0), "GOOOOOL!!", size.x, 62, Color.WHITE, 0.3)
	_glow_text(UI.display(), Vector2(0, y0 + 38.0), "%s marca!" % cel_name, size.x, 26, Color.WHITE, 0.0)


func start_celebration(e: Dictionary, kit: Array, who: String) -> void:
	cel_ent = e.duplicate()
	cel_ent["kit"] = kit
	cel_name = who
	cel_t = 0.001


## Camisa listrada? (pelo nome original do clube na sua liga; convidados das copas também)
static func striped(c: Dictionary) -> bool:
	var ci: int = int(c.get("ci", c["id"]))
	if ci < 0:
		return false
	var lg: Array = World.LEAGUES[int(c.get("li", Game.S.get("league", 0)))]["clubs"]
	return ci < lg.size() and lg[ci][0] in World.STRIPED


func _close(a: Color, b: Color) -> bool:
	return Vector3(a.r - b.r, a.g - b.g, a.b - b.b).length() < 0.4


func _ent(p: Dictionary, pos: Vector2, num: int) -> Dictionary:
	var id: int = p["id"]
	return {"p": p, "pos": pos, "num": num, "a": Game.attrs(p), "ph": float(id % 7), "moving": false, "run": pos,
		"home": pos, "stun": 0.0, "dir": Vector2(0, -1), "face": 1.0, "role": "", "fwd": false,
		"vel": Vector2.ZERO, "acc": Vector2.ZERO,
		"skin": SKINS[int(p.get("look_skin", (id * 3) % SKINS.size()))], "hair": HAIRS[int(p.get("look_hcolor", (id * 5) % HAIRS.size()))]}


func _numbers(slots: Array) -> Array:
	var pool := {"GOL": [1], "LD": [2], "LE": [6], "ZAG": [3, 4, 13], "VOL": [5, 15], "MEI": [8, 10, 20], "PD": [7], "PE": [11], "AC": [9, 19]}
	var used := {}
	var out: Array = []
	for sl in slots:
		var k: int = int(used.get(sl[0], 0))
		var arr: Array = pool[sl[0]]
		out.append(arr[k] if k < arr.size() else 20 + out.size())
		used[sl[0]] = k + 1
	return out


func _spd(e: Dictionary) -> float:
	return (_v_base + float(e["a"]["vel"]) * _v_pt) * _stam(e)


## Cansaço do jogador (1,0 descansado .. ~0,84 esgotado), de Game.stamina_factor.
## Guardado na entidade e refeito só quando o minuto da partida muda (não a cada quadro);
## ao mudar, a aceleração do corpo acompanha.
func _stam(e: Dictionary) -> float:
	if e.get("is_ref", false) or not e.has("p"):
		return 1.0
	var mk: int = sim.minute if sim != null else 0
	if int(e.get("_stam_m", -1)) == mk:
		return float(e["_stam"])
	var f: float = clampf(Game.stamina_factor(int(e["p"]["id"])), 0.6, 1.0)
	e["_stam"] = f
	e["_stam_m"] = mk
	var b: Body = e.get("b", null)
	if b != null and e.has("a"):
		b.max_accel = (_b_acc + float(e["a"]["vel"]) * _b_acc_vel) * f
	return f


## Ordem de movimento: a entidade quer ir ao alvo com velocidade máxima speed.
## O movimento de verdade acontece no BodyWorld (aceleração, freada e giro limitados, desvio),
## e a passada da animação anda junto com o deslocamento real (o pé não escorrega).
## e["_press"] = true antes da chamada: ordem sem desvio (atacar a bola, receber o passe).
func _move(e: Dictionary, target: Vector2, speed: float, _delta: float = 0.0) -> void:
	_body(e).command(target, speed, bool(e.get("_press", false)))
	e["_press"] = false


## Teleporte de bola parada (cobrança, saída): posição nova e corpo parado.
func _place(e: Dictionary, p: Vector2) -> void:
	e["pos"] = p
	_body(e).place(p)
	e["vel"] = Vector2.ZERO
	e["spd"] = 0.0
	e["moving"] = false


## Corpo físico da entidade (criado na primeira vez, com raio, massa e limites pelo tipo).
func _body(e: Dictionary) -> Body:
	var b: Body = e.get("b", null)
	if b != null:
		return b
	b = Body.new()
	if e.get("is_ref", false):
		b.radius = Tuning.f("corpo", "raio_arbitro", 0.38)
		b.inv_mass = 1.0 / 70.0
		b.max_accel = _b_acc + 1.5
	else:
		var vel_a: float = float(e["a"]["vel"]) if e.has("a") else 60.0
		var des: float = float(e["a"]["des"]) if e.has("a") else 60.0
		b.max_accel = (_b_acc + vel_a * _b_acc_vel) * (_stam(e) if e.has("a") else 1.0)
		if e.get("keeper", false):
			b.radius = Tuning.f("corpo", "raio_goleiro", 0.5)
			b.inv_mass = 1.0 / 85.0
		else:
			b.radius = Tuning.f("corpo", "raio_jogador", 0.42)
			b.inv_mass = 1.0 / (Tuning.f("corpo", "massa_base", 72.0) + des * Tuning.f("corpo", "massa_por_forca", 0.25))
	b.max_decel = _b_dec
	b.turn_still = _b_turn0
	b.turn_run = _b_turn1
	b.place(e["pos"])
	b.facing = e.get("dir", Vector2(0, -1))
	e["b"] = b
	if not e.has("vel"):
		e["vel"] = Vector2.ZERO
	if not e.has("acc"):
		e["acc"] = Vector2.ZERO
	return b


var world: BodyWorld = null
var _world_src: Array = []
var _world_list: Array[Body] = []


## Um passo fixo dos corpos: entidade -> corpo (detecta teleporte e corpo cinemático),
## mundo integra e colide, corpo -> entidade (posição, velocidade, passada e direção).
func _step_bodies(ents: Array, dt: float) -> void:
	if world == null:
		world = BodyWorld.new()
	if not is_same(ents, _world_src) or ents.size() != _world_list.size():
		_world_src = ents
		_world_list.clear()
		for e in ents:
			_world_list.append(_body(e))
		world.set_bodies(_world_list)
	for e in ents:
		var b: Body = e["b"]
		var p: Vector2 = e["pos"]
		var kin: bool = bool(e.get("_kin", false))
		if p != b.synced:
			if kin:
				b.vel = (p - b.synced) / dt
			b.pos = p
		b.kinematic = kin
	world.step(dt)
	for e in ents:
		var b2: Body = e["b"]
		e["pos"] = b2.pos
		b2.synced = b2.pos
		e["vel"] = b2.vel
		e["acc"] = b2.acc
		if not b2.kinematic:
			e["ph"] = float(e["ph"]) + b2.step_dist * STRIDE
			e["spd"] = b2.step_dist / dt
			e["moving"] = e["spd"] > 0.15
			if e["moving"]:
				e["dir"] = b2.facing


## Bola × corpo: bola baixa (até a altura do corpo) que encosta num jogador bate e desvia.
## Não vale para quem controla a bola, quem acabou de chutar, o recebedor do passe e o goleiro
## (que tem a lógica de defesa). ignore = entidade extra a ignorar.
func _ball_vs_bodies(bodies: Array, owner: Variant, ignore: Variant) -> void:
	if bp.z > _b_h:
		return
	var br: float = bp.radius
	var bx: float = bp.pos.x
	var by: float = bp.pos.y
	for e in bodies:
		var ep: Vector2 = e["pos"]
		if absf(ep.x - bx) > 0.7 or absf(ep.y - by) > 0.7:
			continue   # longe da bola: descarta antes de qualquer outra conta
		if is_same(e, owner) or is_same(e, ignore) or e.get("keeper", false) or (e.get("is_ref", false) and bp.z > 1.6):
			continue
		if float(e.get("kick", 0.0)) > 0.12:
			continue
		var rs: float = _body(e).radius + br
		var rel: Vector2 = bp.pos - e["pos"]
		var d2 := rel.length_squared()
		if d2 >= rs * rs:
			continue
		var dist := sqrt(d2)
		var nrm := rel / dist if dist > 0.0001 else -bp.vel.normalized()
		var is_def := dfn.has(e)
		if state == "pass" and is_def and user_ctrl and bp.speed() < 4.0 and t > 0.25:
			# bola lenta no pé do defensor: ele domina
			e["kick"] = 0.2
			bp.vel = e["vel"]
			_finish("lost", "Bola roubada por %s!" % e["p"]["name"])
			return
		if state == "shot" and is_def and user_ctrl:
			# chute que bate no corpo do zagueiro é bola travada
			var vn2: float = (bp.vel - e["vel"]).dot(nrm)
			if vn2 < 0.0:
				bp.vel -= nrm * ((1.0 + _d_bounce) * vn2)
				bp.vel *= 0.6
				bp.curve = Vector2.ZERO
			bp.pos = e["pos"] + nrm * rs
			_finish("blocked", "Travado por %s!" % e["p"]["name"])
			return
		if state == "pass" and is_def and not e.get("tried", false):
			if user_ctrl:
				if _cut_roll(e, att[carrier]):
					return
			else:
				e["tried"] = true   # lance da máquina: o defensor não alcança (segue o roteiro)
		var vrel: Vector2 = bp.vel - e["vel"]
		var vn := vrel.dot(nrm)
		if vn < 0.0:
			if e.get("tried", false):
				# o defensor errou o corte: a bola passa raspando, contornando o corpo
				bp.vel -= nrm * vn
			else:
				bp.vel -= nrm * ((1.0 + _d_bounce) * vn)
				bp.vel *= 0.88
				bp.curve = Vector2.ZERO
				if bp.z > 0.3:
					bp.vz *= 0.6
			_path_dirty = true
		bp.pos = e["pos"] + nrm * rs


## Todos os corpos do lance (jogadores, goleiro e árbitro), num array reaproveitado.
func _bodies() -> Array:
	var sig: int = att.size() * 1000 + dfn.size() + (0 if referee.is_empty() else 500)
	if sig != _bodies_sig:
		_bodies_sig = sig
		_bodies_cache = att + dfn + [gk]
		if not referee.is_empty():
			_bodies_cache.append(referee)
	return _bodies_cache


func _defenders_y() -> Array:
	var ys: Array = [gk["pos"].y]
	for d in dfn:
		ys.append(d["pos"].y)
	return ys


func _say(text: String, dur: float = 1.1) -> void:
	banner = text
	banner_t = dur


# ------------------------------------------------------------ organização da zaga
## Compatibilidade: a separação agora é a colisão do BodyWorld (feita em _step_bodies).
func _separate(_ents: Array, _min_d: float = 0.9) -> void:
	pass


## Todos os jogadores em campo (atacantes, zaga e goleiro), num array reaproveitado.
func _everyone() -> Array:
	var sig: int = att.size() * 1000 + dfn.size()
	if sig != _sep_sig:
		_sep_sig = sig
		_sep_ents = att + dfn + [gk]
	return _sep_ents


## Atualiza a linha da zaga: acompanha a bola, sem passar dos limites do arquivo de ajuste.
func _update_line() -> void:
	var target := clampf(bp.pos.y - _tz_depth, _tz_line_min, _tz_line_max)
	line_y = lerpf(line_y, target, 0.08)


## Para onde cada defensor vai neste quadro.
func _defender_target(j: int) -> Vector2:
	var d: Dictionary = dfn[j]
	if str(d["role"]) == "track" and j != presser:
		# meia/atacante do time que defende: segura a zona na frente da linha, na sua faixa
		return Vector2(clampf(float(d["lane"]) * 0.8 + bp.pos.x * 0.2, -30.0, 30.0), maxf(line_y + float(d["off"]), 6.0))
	var compact := _tz_compact
	var shift := _tz_shift
	if j == presser:
		# o marcador ataca a bola pelo lado do gol (o condutor protege com o corpo)
		# marca de frente, do lado do gol, a distância de "cerco"; na hora do bote vai na bola
		if float(d.get("lunge", 0.0)) <= 0.0 and state == "run" and user_ctrl and moments > 0:
			return bp.pos
		var goal_side: Vector2 = (Vector2(0, 0) - bp.pos).normalized()
		return bp.pos + goal_side * _d_jockey
	if d["role"] == "line":
		var tx: float = d["home"].x * compact + bp.pos.x * shift
		var ty := line_y
		# cobertura: o vizinho do zagueiro que saiu no bote recua um pouco
		if presser >= 0 and dfn[presser]["role"] == "line" and absf(dfn[presser]["home"].x - d["home"].x) < 16.0:
			ty -= _tz_cover
			tx = lerpf(tx, dfn[presser]["home"].x * compact, 0.3)
		return Vector2(tx, ty)
	# volante: fica na linha de passe entre a bola e o atacante mais perigoso
	var danger := -1
	var dy := 1e9
	for i in att.size():
		if i != carrier and att[i]["pos"].y < dy:
			dy = att[i]["pos"].y
			danger = i
	if danger >= 0:
		var mid: Vector2 = bp.pos.lerp(att[danger]["pos"], 0.45)
		return Vector2(lerpf(mid.x, d["home"].x * compact, 0.3), maxf(mid.y, line_y + 4.0))
	return d["home"]


# ------------------------------------------------------------ fases
func _start_run(dur: float) -> void:
	run_time = dur
	state = "run"
	t = 0.0
	for i in att.size():
		var e: Dictionary = att[i]
		if e["fwd"]:
			# atacante tenta passar da linha da zaga (pode ficar impedido)
			# segura a corrida na linha (em condição) até o passe; quem recebe ataca o espaço depois
			e["run"] = Vector2(clampf(e["pos"].x * 0.85 + Game.rng.randf_range(-3.0, 3.0), -28.0, 28.0),
				maxf(line_y + Game.rng.randf_range(_run_onside_min, 3.0), 5.0))
		elif e.has("slot"):
			e["run"] = _support_run(e)
		else:
			e["run"] = Vector2(clampf(e["pos"].x * 0.85 + Game.rng.randf_range(-3.0, 3.0), -30.0, 30.0),
				maxf(e["pos"].y - Game.rng.randf_range(4.0, 8.0), line_y + 3.0))
	presser = -1
	for d0 in dfn:
		d0["tackled"] = false
		# tempo de cerco antes do bote: marcador bom dá o bote mais cedo
		d0["lunge"] = Game.rng.randf_range(0.2, 0.55) * (1.6 - float(d0["a"]["des"]) / 100.0)
	var bd := 1e9
	for j in dfn.size():
		if dfn[j]["stun"] > 0.0 or j in wall:
			continue
		var dist: float = dfn[j]["pos"].distance_to(att[carrier]["pos"])
		if dist < bd:
			bd = dist
			presser = j


## Corrida de apoio de quem não é atacante, pela posição da formação: zagueiro segura
## atrás, lateral passa por fora bem aberto, volante fica na entrada da área, meia aparece
## na sua faixa. Mantém largura e profundidade (ninguém corre todo mundo para a bola).
func _support_run(e: Dictionary) -> Vector2:
	var lane: float = float(e.get("lane", e["pos"].x))
	var pos: Vector2 = e["pos"]
	match str(e["slot"][0]):
		"ZAG":
			return Vector2(lerpf(pos.x, lane * 0.7, 0.5), maxf(pos.y - 3.0, 42.0))
		"LD", "LE":
			var sx: float = signf(lane) if absf(lane) > 1.0 else (1.0 if pos.x >= 0.0 else -1.0)
			return Vector2(sx * 26.0, maxf(pos.y - 9.0, line_y + 2.0))
		"VOL":
			return Vector2(lerpf(pos.x, lane * 0.5, 0.5), maxf(pos.y - 4.0, line_y + 12.0))
		_:
			return Vector2(clampf(lerpf(pos.x, lane, 0.5) + Game.rng.randf_range(-2.0, 2.0), -30.0, 30.0),
				maxf(pos.y - Game.rng.randf_range(4.0, 8.0), line_y + 4.0))


func _move_all(delta: float, chase_ball: bool = false) -> void:
	_update_line()
	for i in att.size():
		var e: Dictionary = att[i]
		if i == carrier and state != "pass":
			pass   # o condutor é guiado por _dribble / _settle
		elif state == "pass" and i == pass_to:
			# vai ao ponto do passe; quando a bola chega perto, ataca a bola
			var go: Vector2 = pass_end
			if not pass_lofted:
				var ip := _intercept_point(e)
				go = ip if ip.x < 1e8 else bp.pos
			if not bp.in_air() and (bp.pos.distance_to(e["pos"]) < 2.0 or bp.speed() < 2.0):
				go = bp.pos
			e["_press"] = true
			_move(e, go, _spd(e), delta)
		else:
			var go2: Vector2 = e["run"]
			var sp2: float = _spd(e) * 0.75
			if e["fwd"] and state in ["run", "settle", "decide"]:
				# acompanha a linha da zaga em tempo real: se ela sobe, ele recua para ficar em condição
				var onside_y: float = line_y + _run_onside_min
				if go2.y < onside_y:
					go2.y = onside_y
				if e["pos"].y < onside_y - 0.5:
					sp2 = _spd(e) * 0.95   # está adiantado: volta rápido
			_move(e, go2, sp2, delta)
	for j in dfn.size():
		var d: Dictionary = dfn[j]
		if j in wall:
			continue
		if d["stun"] > 0.0:
			d["stun"] -= delta
			d["moving"] = false
			continue
		if chase_ball and not pass_lofted and t > _tz_cut_react:
			# vai ao primeiro ponto do caminho da bola que consegue alcançar a tempo
			var ip := _intercept_point(d, 0.85)
			if ip.x < 1e8:
				d["_press"] = true
				_move(d, ip, _spd(d) * 0.85, delta)
				continue
		elif chase_ball and pass_lofted and d["pos"].distance_to(pass_end) < 7.0:
			_move(d, pass_end, _spd(d) * 0.95, delta)
			continue
		var sp := 0.9 if j == presser else 0.8
		if j == presser and state in ["run", "settle"]:
			d["_press"] = true   # o marcador vai na bola, sem desviar do condutor
		_move(d, _defender_target(j), _spd(d) * sp, delta)
	if state != "shot":
		_move(gk, Vector2(clampf(bp.pos.x * 0.14, -2.6, 2.6), 1.3), 3.0, delta)


# ------------------------------------------------------------ condução, bote e árbitro
## Condução com toques de verdade: o condutor corre rumo ao gol e, quando a bola está ao
## alcance do pé, dá um toque que a manda um pouco à frente (mais forte quanto mais rápido ele vai).
## Com marcador perto, o toque sai para o lado oposto ao dele (proteção de bola).
func _dribble(c: Dictionary) -> void:
	var goal_pt := Vector2(c["pos"].x * 0.75, maxf(c["pos"].y - 12.0, 7.0))
	var tgt := goal_pt
	if bp.pos.distance_to(c["pos"]) > 1.5:
		tgt = bp.pos   # a bola escapou: vai buscar
	_move(c, tgt, _spd(c) * 0.8)
	var threat := Vector2(1e9, 1e9)
	if presser >= 0 and presser < dfn.size():
		threat = dfn[presser]["pos"]
	_touch(c, goal_pt, threat)


## Toque de condução: se a bola está ao alcance do pé e não está correndo à frente, o condutor
## a toca rumo a toward, um pouco mais rápido que ele mesmo. Com um adversário (threat) a menos
## de 2,6 m, o toque sai para o lado oposto (proteção de bola).
func _touch(c: Dictionary, toward: Vector2, threat: Vector2 = Vector2(1e9, 1e9)) -> void:
	if bp.in_air() or float(c.get("tc", 0.0)) > 0.0:
		return
	var cdir: Vector2 = c["dir"]
	var foot: Vector2 = c["pos"] + cdir * 0.3
	if bp.pos.distance_to(foot) > _t_reach:
		return
	var cv: Vector2 = c["vel"]
	if (bp.vel - cv).dot(cdir) > 0.8:
		return   # a bola já está correndo à frente
	var dirv: Vector2 = (toward - bp.pos).normalized() if toward.distance_to(bp.pos) > 0.5 else cdir
	dirv = cdir.lerp(dirv, 0.5).normalized()
	var pr: Vector2 = threat - c["pos"]
	if pr.length() < 2.6:
		var away := -pr.normalized()
		dirv = dirv.lerp(away, 0.35 * (1.0 - pr.length() / 2.6)).normalized()
	var spd := minf(maxf(cv.length() * 1.18 + _t_ahead, 1.5), _t_vmax)
	bp.kick_ground(bp.pos + dirv, spd)
	c["kick"] = 0.12
	c["tc"] = 0.22


## Fim da corrida: o condutor alcança a bola e a prende sob a sola antes da decisão.
func _end_run() -> void:
	if presser >= 0 and presser < dfn.size() and setpiece == "":
		var d: Dictionary = dfn[presser]
		var c: Dictionary = att[carrier]
		if d["pos"].distance_to(c["pos"]) < 2.0 and d["stun"] <= 0.0:
			if user_ctrl and moments == 0:
				d["stun"] = 0.8   # no primeiro toque você sempre tem a chance de decidir
			elif not user_ctrl and script_kind == "lost" and moments >= lost_at:
				d["slide"] = 0.7
				_poke_ball(d)
				_finish("lost", "Desarme de %s!" % d["p"]["name"])
				return
	state = "settle"
	t = 0.0


## Antes da decisão o condutor não freia: segue conduzindo e, assim que a bola está no pé
## (ao alcance do próximo toque), o momento de decidir chega — no lance do jogador o tempo
## congela ali mesmo; no da máquina a jogada continua enquanto ela escolhe.
func _settle() -> void:
	var c: Dictionary = att[carrier]
	var cdir: Vector2 = c["dir"]
	var foot: Vector2 = c["pos"] + cdir * 0.34
	var goal_pt := Vector2(c["pos"].x * 0.75, maxf(c["pos"].y - 12.0, 7.0))
	var near: bool = not bp.in_air() and bp.pos.distance_to(foot) < _settle_reach
	if near:
		# bola dominada: acompanha o pé sem toque novo (o próximo toque já é a jogada)
		bp.vel = bp.vel.lerp(c["vel"], 0.35)
		_move(c, goal_pt, _spd(c) * 0.8)
	else:
		c["_press"] = true
		_move(c, bp.pos, _spd(c) * 0.85)   # a bola escapou um pouco: vai nela
	if near or t > 0.6:
		if not near:
			bp.place(foot)
		state = "decide"
		t = 0.0


## Bote: quando o marcador alcança a bola, tenta o desarme. A chance depende do desarme dele,
## da velocidade/passe do condutor, da proteção de corpo (marcador do outro lado da bola) e de
## vir por trás (mais falta). Errar deixa o marcador para trás por um instante.
func _try_tackle() -> void:
	if presser < 0 or presser >= dfn.size() or setpiece != "" or not user_ctrl or moments == 0:
		return
	var d: Dictionary = dfn[presser]
	if d["stun"] > 0.0 or d.get("tackled", false):
		return
	if d["pos"].distance_to(bp.pos) > _d_reach or bp.z > 0.8:
		return
	d["tackled"] = true
	var c: Dictionary = att[carrier]
	var to_ball: Vector2 = (bp.pos - c["pos"]).normalized()
	var to_def: Vector2 = (d["pos"] - c["pos"]).normalized()
	# craque: finta (puxa a bola de lado) e deixa o marcador no chão por um instante
	var craque: float = (float(c["a"]["vel"]) + float(c["a"]["pas"])) / 2.0
	if craque >= Tuning.f("disputa", "finta_min", 80.0) and Game.rng.randf() < (craque - 76.0) / Tuning.f("disputa", "finta_div", 60.0):
		var side_dir := Vector2(-to_def.y, to_def.x)
		if side_dir.dot(Vector2(-bp.pos.x, 0.0)) < 0.0:
			side_dir = -side_dir   # puxa para o lado do meio do campo
		bp.pos += side_dir * 0.9
		c["vel"] = c.get("vel", Vector2.ZERO) + side_dir * 3.0
		c["trap"] = 0.3
		d["stun"] = 1.0
		_say("Drible de %s!" % c["p"]["name"], 0.9)
		return
	var shield := clampf(-to_ball.dot(to_def), 0.0, 1.0)   # 1 = corpo do condutor entre o marcador e a bola
	var behind: bool = c["dir"].dot(to_def) < -0.3
	var att_skill: float = (float(c["a"]["vel"]) + float(c["a"]["pas"])) / 2.0 + shield * _d_shield
	var res: Dictionary = ref.judge_tackle(float(d["a"]["des"]), att_skill, _d_behind if behind else 0.0)
	d["slide"] = 0.7
	if res["tipo"] == "limpo":
		_poke_ball(d)
		_finish("lost", "Desarmado por %s!" % d["p"]["name"])
	elif res["tipo"] == "falta":
		_foul(d, c, res["cartao"], Game.rng.randf() < 0.5)
	else:
		d["stun"] = _d_stun   # errou o bote: passou do lance


## O desarme tira a bola: ela espirra para longe do condutor.
func _poke_ball(d: Dictionary) -> void:
	var away: Vector2 = (bp.pos - att[carrier]["pos"]).normalized().rotated(Game.rng.randf_range(-0.6, 0.6))
	if away.length() < 0.1:
		away = Vector2(0, 1)
	bp.kick_ground(bp.pos + away, Game.rng.randf_range(4.0, 7.0))
	d["kick"] = 0.2


## Primeiro ponto do caminho previsto da bola que o defensor alcança antes dela.
## Devolve Vector2(1e9, 1e9) se não alcança nenhum.
func _intercept_point(d: Dictionary, speed_k: float = 1.0) -> Vector2:
	var sp := _spd(d) * speed_k
	var now_k := int((t - _path_t0) / PATH_DT)
	for k in range(now_k, _path.size()):
		if _path_z[k] > 2.3:
			continue
		var tk := (k - now_k) * PATH_DT
		if _tz_cut_react + d["pos"].distance_to(_path[k]) / sp <= tk:
			if d["pos"].distance_to(_path[k]) < 9.0:
				return _path[k]
			return Vector2(1e9, 1e9)
	return Vector2(1e9, 1e9)


## Guarda o caminho da bola depois do chute/passe (mesma física, sem mexer na bola).
func _record_path() -> void:
	_path_t0 = t if state == "pass" else 0.0
	_path_dirty = false
	_path.clear()
	_path_z.clear()
	var sv := bp.vel
	var sp := bp.pos
	var sz := bp.z
	var svz := bp.vz
	var sc := bp.curve
	var ss := bp.spin
	var sub := int(round(PATH_DT / STEP))
	for k in 80:
		_path.append(bp.pos)
		_path_z.append(bp.z)
		for q in sub:
			bp.step(STEP)
		if not bp.in_air() and bp.speed() < 0.05:
			break
	bp.pos = sp
	bp.vel = sv
	bp.z = sz
	bp.vz = svz
	bp.curve = sc
	bp.spin = ss


## Domínio do passe: a bola não "gruda". Ela vem para a frente do recebedor com um amortecimento;
## o erro cresce com a velocidade da bola e cai com o passe do jogador.
func _first_touch(r: Dictionary, want_dir: Vector2 = Vector2.ZERO) -> void:
	var bsp: float = sqrt(bp.vel.length_squared() + bp.vz * bp.vz)
	var skill: float = float(r["a"]["pas"])
	var err: float = (_ft_base + _ft_vel * bsp) * clampf(1.35 - skill / 100.0, 0.2, 1.0)
	var want: Vector2 = want_dir
	if want == Vector2.ZERO:
		want = (Vector2(r["pos"].x * 0.7, maxf(r["pos"].y - 6.0, 5.0)) - r["pos"]).normalized()
	var v: Vector2 = want * (1.0 + bsp * 0.06) + Vector2(Game.rng.randfn(0.0, err), Game.rng.randfn(0.0, err)) * bsp * 0.35
	bp.pos = r["pos"] + r["dir"] * 0.3
	bp.z = 0.0
	bp.vz = 0.0
	bp.curve = Vector2.ZERO
	bp.vel = v.limit_length(6.0)
	r["trap"] = 0.3
	r["tc"] = 0.25


## No fim do lance todos desaceleram; quem comemora corre para o autor do gol.
func _move_all_end(_delta: float) -> void:
	for d in dfn:
		if float(d.get("slide", 0.0)) > 0.25:
			d["_press"] = true
			_move(d, bp.pos, 6.0)


## Falta do defensor d no atacante c. keeps = o atacante conseguiu seguir com a bola.
func _foul(d: Dictionary, c: Dictionary, card: String, keeps: bool) -> void:
	var dside := 1 - side
	sim.add_foul(dside)
	d["slide"] = 0.7
	if not keeps:
		c["fall"] = 1.3   # o atacante cai e levanta
	var where: Vector2 = c["pos"]
	var restart := ref.restart_for_foul(where, keeps)
	if card != "":
		var sent_off := sim.give_card(dside, d["p"]["id"], card)
		card_flash = "vermelho" if sent_off else card
		if sent_off:
			dfn.erase(d)
			presser = -1
	match restart:
		"penalti":
			_say("PÊNALTI!", 1.4)
			_setup_penalty(where)
		"falta_direta":
			_say("FALTA!", 1.2)
			_setup_free_kick(where)
		"vantagem":
			_say("VANTAGEM!", 1.0)
			d["stun"] = 1.5
			state = "decide"
			t = 0.0
		_:
			_say("FALTA!", 1.0)
			for o in dfn:
				o["stun"] = 0.8
			bp.place(c["pos"] + Vector2(0, -0.6))
			state = "decide"
			t = 0.0


## Cobrança de pênalti: bola na marca, só o batedor e o goleiro na área.
func _setup_penalty(_where: Vector2) -> void:
	setpiece = "penalti"
	shot_only = true
	header = false
	var c: Dictionary = att[carrier]
	# o batedor se afasta da bola para tomar distância (corrida em diagonal)
	_place(c, Vector2(-1.5 if Game.rng.randf() < 0.5 else 1.5, Referee.PEN_SPOT + 2.6))
	c["dir"] = Vector2(0, -1)
	bp.place(Vector2(0, Referee.PEN_SPOT))
	runup_done = false
	if banner_t <= 0.0:
		_say("PÊNALTI!", 1.3)   # sem isso a faixa da abertura ficava na tela durante a cobrança
	_pen_gk = [-2.8, 0.0, 2.8][Game.rng.randi_range(0, 2)]
	for i in att.size():
		if i != carrier:
			_place(att[i], Vector2(-16.0 + i * 6.0, Referee.BOX_DEPTH + 3.0))
	# Cena especial: três defensores ficam posicionados dentro da rede,
	# atrás do goleiro, como barreira visual de pressão no pênalti.
	# Os demais saem do enquadramento para não poluir a cobrança.
	for j in dfn.size():
		var defender: Dictionary = dfn[j]
		defender["moving"] = false
		defender["stun"] = 99.0
		if j < 3:
			_place(defender, Vector2([-4.8, 0.0, 4.8][j], -1.8))
			defender["face"] = 1.0
		else:
			_place(defender, Vector2(55.0 + j * 3.0, -20.0))
	_place(gk, Vector2(0, 0.4))
	presser = -1
	state = "decide"
	t = 0.0


## Falta direta: bola parada e barreira a 9,15 m entre a bola e o gol.
func _setup_free_kick(where: Vector2) -> void:
	setpiece = "falta_direta"
	shot_only = true
	header = false
	bp.place(where)
	_place(att[carrier], where + Vector2(0, 1.0))
	var to_goal := (Vector2(0, 0) - where).normalized()
	var spot := where + to_goal * 9.15
	var perp := Vector2(-to_goal.y, to_goal.x)
	wall.clear()
	var n := mini(4, dfn.size())
	for k in n:
		# ombro a ombro: a distância entre eles é a soma dos raios dos corpos
		_place(dfn[k], spot + perp * (float(k) - (n - 1) / 2.0) * 0.86)
		dfn[k]["moving"] = false
		wall.append(k)
	for j in range(n, dfn.size()):
		dfn[j]["stun"] = 99.0
	_place(gk, Vector2(clampf(where.x * 0.2, -1.5, 1.5), 0.6))
	presser = -1
	state = "decide"
	t = 0.0


# ------------------------------------------------------------ decisões da máquina
func _ai_decide() -> void:
	var c: Dictionary = att[carrier]
	if script_kind == "lost" and moments >= lost_at:
		var nm: String = dfn[presser]["p"]["name"] if presser >= 0 and presser < dfn.size() else "zaga"
		if presser >= 0 and presser < dfn.size():
			dfn[presser]["slide"] = 0.7
			_poke_ball(dfn[presser])
		_finish("lost", "Desarme de %s!" % nm)
		return
	# modo jogador: o companheiro costuma devolver para você
	if user_ctrl and me_pid >= 0 and not shot_only and moments < 4:
		for i in att.size():
			if i != carrier and int(att[i]["p"]["id"]) == me_pid and Game.rng.randf() < 0.6:
				_do_pass(i, absf(c["pos"].x) > 14.0 and Referee.in_box(att[i]["pos"]))
				return
	if not shot_only and c["pos"].y > 19.0 and moments < 3:
		var opts: Array = []
		for i in att.size():
			if i != carrier and att[i]["pos"].y < c["pos"].y - 3.0:
				opts.append(i)
		if not opts.is_empty():
			var to: int = opts[Game.rng.randi_range(0, opts.size() - 1)]
			var lofted: bool = absf(c["pos"].x) > 14.0 and Referee.in_box(att[to]["pos"])
			_do_pass(to, lofted)
			return
		if script_kind == "offside":
			_do_pass(0 if carrier != 0 else mini(1, att.size() - 1), false)
			return
	# roteiro de perda ou impedimento: a máquina não chuta (o resultado já foi sorteado)
	if not user_ctrl and script_kind == "lost":
		var nm2: String = dfn[presser]["p"]["name"] if presser >= 0 and presser < dfn.size() else "zaga"
		if presser >= 0 and presser < dfn.size():
			dfn[presser]["slide"] = 0.7
			_poke_ball(dfn[presser])
		_finish("lost", "Desarme de %s!" % nm2)
		return
	if not user_ctrl and script_kind == "offside" and att.size() > 1:
		var far := 0 if carrier != 0 else 1
		for i in att.size():
			if i != carrier and att[i]["pos"].y < att[far]["pos"].y:
				far = i
		_do_pass(far, false)
		return
	var sgn: float = -1.0 if gk["pos"].x > 0.0 else 1.0
	if Game.rng.randf() < 0.3:
		sgn = -sgn
	var tx: float = gk["pos"].x + Game.rng.randf_range(-0.6, 0.6)
	var h := 0.5
	var goal_kind: bool = script_kind == "goal" or (script_kind == "penalty" and sim.penalty_scored)
	if user_ctrl:
		# companheiro do modo jogador: mira num canto, a física decide
		tx = sgn * Game.rng.randf_range(1.2, 3.4)
		h = Game.rng.randf_range(0.3, 1.8)
	if goal_kind:
		tx = sgn * Game.rng.randf_range(2.2, 3.0)
	elif script_kind in ["out", "lost", "offside"]:
		tx = sgn * Game.rng.randf_range(4.4, 6.5)
		if Game.rng.randf() < 0.4:
			tx = sgn * Game.rng.randf_range(0.5, 2.5)
			h = 3.2   # por cima
	_do_shot(tx, h, 0.6)


# ------------------------------------------------------------ passe
## Passe para o atacante i. lofted = passe alto / cruzamento.
func _do_pass(i: int, lofted: bool) -> void:
	var c: Dictionary = att[carrier]
	var r: Dictionary = att[i]
	pass_to = i
	pass_lofted = lofted
	# impedimento é julgado no momento do passe
	pass_offside = Referee.is_offside(r["pos"], bp.pos, _defenders_y())
	if not user_ctrl:
		pass_offside = script_kind == "offside"
	var lead: Vector2 = (r["run"] - r["pos"]).limit_length(3.0 if lofted else 2.0)
	var aim: Vector2 = r["pos"] + lead
	var d: Vector2 = aim - bp.pos
	var dist := d.length()
	if user_ctrl:
		var deg := Tuning.f("passe", "erro_base_graus", 1.5) + (100.0 - float(c["a"]["pas"])) * Tuning.f("passe", "erro_por_ponto_faltando", 0.09)
		var near := 1e9
		for o in dfn:
			near = minf(near, o["pos"].distance_to(c["pos"]))
		var pd := Tuning.f("passe", "distancia_pressao", 3.0)
		if near < pd:
			deg += Tuning.f("passe", "erro_pressao_graus", 4.0) * (1.0 - near / pd)
		if lofted:
			deg *= 1.3
		deg /= _stam(c)   # cansado erra mais
		d = d.rotated(deg_to_rad(Game.rng.randfn(0.0, deg))) * Game.rng.randf_range(0.93, 1.07)
	pass_end = bp.pos + d
	if lofted:
		var apex := Tuning.f("passe", "altura_cruzamento", 3.4) if Referee.in_box(r["pos"]) else Tuning.f("passe", "altura_passe_alto", 4.2)
		bp.kick_lofted(pass_end, apex)
	else:
		# força para a bola chegar no alvo com a velocidade de chegada pedida (física do gramado)
		var spd := clampf(bp.ground_speed_for(d.length(), Tuning.f("passe", "velocidade_chegada", 7.0)),
			Tuning.f("passe", "velocidade_rasteiro_min", 13.0), Tuning.f("passe", "velocidade_rasteiro_max", 24.0))
		bp.kick_ground(pass_end, spd)
		_clear_lane(c)
	_record_path()
	presser = -1
	c["kick"] = 0.28
	for o in dfn:
		# quem está colado na bola no momento do passe já foi driblado pelo toque
		o["tried"] = o["pos"].distance_to(bp.pos) < 1.2
	state = "pass"
	t = 0.0


## Passe rasteiro com um marcador colado na frente: o passador abre o ângulo o mínimo
## necessário para a bola passar ao lado do corpo dele (em vez de atravessá-lo).
func _clear_lane(passer: Dictionary) -> void:
	var sp := bp.speed()
	if sp < 0.1:
		return
	var dirv := bp.vel / sp
	for d in _bodies():
		if is_same(d, passer) or (pass_to >= 0 and pass_to < att.size() and is_same(d, att[pass_to])):
			continue
		if user_ctrl and not d.get("tried", false):
			continue   # no ataque do jogador, só o marcador já driblado é contornado
		var rel: Vector2 = d["pos"] - bp.pos
		var ahead := rel.dot(dirv)
		if ahead <= 0.0 or ahead > 3.0:
			continue
		var side_d := rel.x * dirv.y - rel.y * dirv.x
		var clear: float = _body(d).radius + bp.radius + 0.06
		if absf(side_d) >= clear:
			continue
		var need := asin(clampf(clear / maxf(rel.length(), clear), 0.0, 1.0)) - asin(clampf(absf(side_d) / maxf(rel.length(), 0.01), 0.0, 1.0))
		if need > 0.45:
			continue   # marcador bem na frente: o passe bate nele (não dá para abrir tanto)
		dirv = dirv.rotated(need * (1.0 if side_d > 0.0 else -1.0))
	bp.vel = dirv * sp
	pass_end = bp.pos + dirv * bp.pos.distance_to(pass_end)
	passer["kick"] = 0.28


## Tentativa de corte do passe pelo defensor d (uma por defensor). Devolve true se cortou.
## Bola rápida e passe bom são mais difíceis de cortar.
func _cut_roll(d: Dictionary, passer: Dictionary) -> bool:
	d["tried"] = true
	var pc := Tuning.f("passe", "chance_corte_base", 0.4) + (float(d["a"]["des"]) - float(passer["a"]["pas"])) / 150.0 \
		- bp.speed() / 60.0
	if Game.rng.randf() < clampf(pc, 0.1, 0.7):
		d["kick"] = 0.2
		bp.vel *= 0.25
		_finish("lost", "Passe cortado por %s!" % d["p"]["name"])
		return true
	d["stun"] = maxf(float(d["stun"]), 0.5)   # errou o corte: fica para trás no lance
	return false


func _update_pass() -> void:
	var r: Dictionary = att[pass_to]
	# corte de defensor (só no ataque do jogador; o da máquina segue o roteiro)
	if user_ctrl and t > 0.12:
		var passer: Dictionary = att[carrier]
		for d in dfn:
			if d["stun"] > 0.0 or d.get("tried", false):
				continue
			var dist: float = d["pos"].distance_to(bp.pos)
			if bp.z <= Tuning.f("passe", "altura_max_corte_pe", 0.9) and dist < Tuning.f("passe", "alcance_corte_pe", 1.0):
				if _cut_roll(d, passer):
					return
			if bp.z <= Tuning.f("passe", "altura_max_corte_cabeca", 2.3) and bp.z > 1.2 and dist < Tuning.f("passe", "alcance_corte_cabeca", 1.25):
				if Game.rng.randf() < 0.5 + (float(d["a"]["des"]) - float(r["a"]["vel"])) / 200.0:
					_finish("lost", "%s ganha pelo alto!" % d["p"]["name"])
					return
	# chegou no recebedor? (o da máquina estica a perna um pouco mais: o passe já estava certo)
	if r["pos"].distance_to(bp.pos) < (1.3 if user_ctrl else 1.8) and bp.z < 2.1:
		if pass_offside:
			_finish("offside", "IMPEDIMENTO!")
			return
		last_passer = carrier
		carrier = pass_to
		moments += 1
		r["trap"] = 0.3   # domínio: o pé sobe para amortecer
		if bp.z > 0.5:
			# bola pelo alto: cabeceio dentro da área, senão precisa dominar
			if Referee.in_box(r["pos"]) and bp.z > 1.0:
				header = true
				shot_only = true
				state = "decide"
				t = 0.0
				return
			var ctrl := Tuning.f("passe", "chance_dominio_alto", 0.82) + (float(r["a"]["pas"]) - 75.0) / 200.0
			if user_ctrl and Game.rng.randf() > ctrl:
				_finish("lost", "%s dominou mal!" % r["p"]["name"])
				return
		_first_touch(r)
		_start_run(0.75)
		return
	# bola parou ou passou longe
	if not bp.in_air():
		var away: bool = (bp.pos - r["pos"]).dot(bp.vel) > 0.0 and bp.pos.distance_to(r["pos"]) > 4.0
		if bp.speed() < 0.6 or away:
			_finish("lost", "Passe errado!")
			return
	if t > 4.0:
		_finish("lost", "Passe errado!")


# ------------------------------------------------------------ chute
## Chute mirando x na linha do gol, altura h (metros) e força p (0..1).
func _do_shot(tx: float, h: float, p: float, curl_in: float = NAN) -> void:
	var c: Dictionary = att[carrier]
	if setpiece == "penalti" and not runup_done:
		# primeiro a corrida até a bola; o chute sai no contato do pé (_update_runup)
		_runup_shot = [tx, h, p]
		state = "runup"
		t = 0.0
		return
	shot_from = bp.pos
	var chu := float(c["a"]["chu"])
	var target := Vector2(clampf(tx, -9.0, 9.0), -0.3)
	var d: Vector2 = target - bp.pos
	var spd: float
	var deg: float
	if header:
		spd = Tuning.f("chute", "velocidade_cabeceio", 14.0) + chu * 0.03
		deg = Tuning.f("chute", "erro_cabeceio_graus", 5.0) + (100.0 - chu) * 0.05
		h = minf(h, 1.6)
	else:
		spd = lerpf(Tuning.f("chute", "velocidade_min", 16.0), Tuning.f("chute", "velocidade_max", 31.0), p) * ((Tuning.f("chute", "forca_base", 0.72) + chu * Tuning.f("chute", "forca_por_ponto", 0.0032)) if user_ctrl else (0.85 + chu / 650.0))
		deg = Tuning.f("chute", "erro_base_graus", 1.2) + (100.0 - chu) * Tuning.f("chute", "erro_por_ponto_faltando", 0.10) \
			+ Tuning.f("chute", "erro_por_forca_graus", 3.0) * p * p
	if setpiece == "penalti":
		deg *= 0.6
	if not user_ctrl:
		deg *= 0.25   # a máquina segue o resultado já sorteado
	deg /= _stam(c)   # cansado erra mais
	d = d.rotated(deg_to_rad(Game.rng.randfn(0.0, deg)))
	# onde a direção (já com o erro) cruza a linha do gol
	var tx_e: float = target.x
	if d.y < -0.01:
		tx_e = bp.pos.x + d.x * (bp.pos.y / -d.y)
	var start_z := 1.6 if header else 0.05
	# efeito: a bola faz curva para dentro (mais na falta, para contornar a barreira).
	# A mira resolve a trajetória com arrasto e curva: ela termina onde foi mirada.
	var curl := 0.0
	if not header:
		curl = Tuning.f("bola", "curva_falta", 4.0) if setpiece == "falta_direta" else Tuning.f("bola", "curva_chute", 1.6)
		if setpiece == "penalti":
			curl *= 0.5
		curl *= -signf(tx_e) if absf(tx_e) > 0.8 else (1.0 if Game.rng.randf() < 0.5 else -1.0)
		curl *= 0.6 + p * 0.6
		if not is_nan(curl_in):
			curl = curl_in   # efeito escolhido pelo dedo (curva do arraste)
	bp.aim_shot(tx_e, h, spd, curl, start_z)
	if user_ctrl and not header:
		# muita força faz a bola subir demais
		bp.vz += Game.rng.randfn(0.0, 0.3 + p * Tuning.f("chute", "subida_por_forca", 3.4) * (1.25 - chu / 100.0) * 0.5)
	c["kick"] = 0.32
	c["windup"] = 0.0
	if header:
		c["jump"] = 0.5
	# goleiro
	var gko: float = float(gk["p"]["ovr"])
	gk_react = Tuning.f("goleiro", "reacao_base", 0.12) + (99.0 - gko) * Tuning.f("goleiro", "reacao_por_ponto_faltando", 0.004)
	gk_speed = Tuning.f("goleiro", "velocidade_base", 2.6) + gko * Tuning.f("goleiro", "velocidade_por_ponto", 0.024)
	gk_dive_x = gk["pos"].x
	if setpiece == "penalti":
		# no pênalti o goleiro escolhe um canto antes do chute
		gk_dive_x = _pen_gk
		gk_react = 0.0
		gk_speed = 9.0
	var goal_kind: bool = script_kind == "goal" or (script_kind == "penalty" and sim.penalty_scored)
	if not user_ctrl:
		if goal_kind:
			gk_speed = 1.2
			gk_react = 0.35
			gk_dive_x = -signf(tx) * 2.5
		elif script_kind == "save" or script_kind == "penalty":
			gk_speed = 14.0
			gk_react = 0.04
			gk_dive_x = tx
	for k in wall:
		dfn[k]["stun"] = 0.0
	for o in dfn:
		o["tried"] = false
	gk_checked = false
	state = "shot"
	t = 0.0


## Pênalti: para onde o goleiro vai (o mesmo que _do_shot decide), para a antecipação.
func _pen_gk_target(tx: float) -> float:
	if not user_ctrl:
		if script_kind == "penalty" and sim.penalty_scored:
			return -signf(tx) * 2.5
		if script_kind == "penalty":
			return tx
	return _pen_gk


## Corrida do batedor até a bola. O goleiro se mexe na linha e se antecipa no fim;
## a perna arma para trás e o chute sai no contato do pé com a bola.
func _update_runup(delta: float) -> void:
	const RUNUP := 0.8
	var c: Dictionary = att[carrier]
	var from_side: float = signf(c["pos"].x) if absf(c["pos"].x) > 0.05 else 1.0
	var contact: Vector2 = bp.pos + Vector2(from_side * 0.35, 0.55)
	var left: float = maxf(RUNUP - t, 0.05)
	_move(c, contact, maxf(c["pos"].distance_to(contact) / left, 1.0), delta)
	c["windup"] = clampf((t - (RUNUP - 0.24)) / 0.24, 0.0, 1.0)
	# goleiro: passinhos na linha e, no fim, o corpo pende para o canto escolhido
	var lean: float = signf(_pen_gk_target(float(_runup_shot[0])))
	gk["pos"].x = sin(t * 9.0) * 0.18
	gk["ph"] += delta * 6.0
	gk["spd"] = 1.2
	gk_tilt = lean * 0.28 * clampf((t - 0.45) / 0.35, 0.0, 1.0)
	if t >= RUNUP:
		runup_done = true
		_do_shot(float(_runup_shot[0]), float(_runup_shot[1]), float(_runup_shot[2]))


func _update_shot(delta: float) -> void:
	var cross := bp.goal_line_crossing()
	# goleiro se joga para onde a bola vai cruzar a linha
	if t > gk_react:
		var target_x: float = gk_dive_x
		if setpiece != "penalti" and not cross.is_empty():
			target_x = cross["x"]
		var tx := clampf(target_x, -4.2, 4.2)
		var gap: float = tx - gk["pos"].x
		gk_tilt = lerpf(gk_tilt, clampf(gap / 1.2, -1.0, 1.0) * 1.15, clampf(delta * 14.0, 0.0, 1.0))
		gk["pos"].x = move_toward(gk["pos"].x, tx, gk_speed * delta)
		gk["ph"] += delta * 11.0
	# barreira e zagueiros podem travar o chute
	if bp.pos.distance_to(shot_from) > 1.5 and bp.pos.y > 2.5:
		for j in dfn.size():
			var d: Dictionary = dfn[j]
			var reach := 0.55 if j in wall else 0.65
			var top := 1.95 if j in wall else 1.7
			if d.get("tried", false):
				continue
			if d["pos"].distance_to(bp.pos) < reach and bp.z < top and (user_ctrl or script_kind == "lost"):
				d["tried"] = true
				if j not in wall and Game.rng.randf() > Tuning.f("chute", "chance_travar", 0.45):
					continue
				bp.vel = Vector2(Game.rng.randf_range(-5.0, 5.0), 6.0)
				bp.vz = 2.0
				_finish("blocked", "Travado por %s!" % d["p"]["name"])
				return
	# goleiro alcança?
	if not gk_checked and bp.pos.y <= gk["pos"].y + 0.25:
		gk_checked = true
		var lat := absf(bp.pos.x - gk["pos"].x)
		var reach_l := Tuning.f("goleiro", "alcance_lateral", 1.15)
		var reach_h := Tuning.f("goleiro", "alcance_alto", 2.55)
		var saved := lat <= reach_l and bp.z <= reach_h
		if saved and bp.z > 1.7 and lat > 0.6:
			saved = Game.rng.randf() < Tuning.f("goleiro", "chance_espalmar_canto_alto", 0.55)
		var goal_kind: bool = script_kind == "goal" or (script_kind == "penalty" and sim.penalty_scored)
		if not user_ctrl and goal_kind:
			saved = false
		if saved:
			# bola perto do corpo e não muito forte: encaixa; senão espalma para o lado
			var hard: bool = bp.speed() > 25.0
			gk_catch = lat < 0.65 and bp.z < 1.7 and not hard
			if gk_catch:
				bp.vel = Vector2.ZERO
				bp.vz = 0.0
			else:
				var side_s: float = signf(bp.pos.x - gk["pos"].x) if absf(bp.pos.x - gk["pos"].x) > 0.05 else 1.0
				bp.vel = Vector2(side_s * Game.rng.randf_range(4.0, 8.0), Game.rng.randf_range(5.0, 9.0))
				bp.vz = 2.5
				bp.curve = Vector2.ZERO
			_finish("save", "Defesa de %s!" % gk["p"]["name"])
			return
	if bp.pos.y <= 0.0:
		var kind := BallPhysics.classify_crossing(bp.pos.x, bp.z)
		match kind:
			"gol":
				_finish("goal", "GOOOL!" if setpiece != "penalti" else "GOOOL DE PÊNALTI!")
			"trave":
				bp.vel = Vector2(-bp.vel.x * 0.5, 7.0)
				_finish("out", "Na trave!")
			"travessao":
				bp.vel = Vector2(bp.vel.x * 0.3, 6.0)
				bp.vz = -2.0
				_finish("out", "No travessão!")
			"por_cima":
				_finish("out", "Por cima do gol!")
			_:
				_finish("out", "Pra fora!")
		return
	if t > 3.0:
		_finish("out", "Pra fora!")


func _finish(kind: String, text: String) -> void:
	var apid := 0
	if kind == "goal" and last_passer >= 0 and last_passer != carrier and setpiece == "":
		apid = att[last_passer]["p"]["id"]
	result = {"goal": kind == "goal", "kind": kind, "pid": att[carrier]["p"]["id"], "apid": apid, "pen": setpiece == "penalti"}
	banner = text
	banner_t = 99.0
	state = "end"
	t = 0.0


## Pula o lance da máquina e aplica o resultado já sorteado.
func skip() -> void:
	if user_ctrl or state == "done":
		return
	if state == "end":
		# já no fim (comemoração do gol): pular encerra o lance na hora
		if result.get("goal", false):
			state = "done"
			finished.emit(result)
		return
	skipped = true
	var best := 0
	for i in att.size():
		if att[i]["pos"].y < att[best]["pos"].y:
			best = i
	carrier = best
	var kind := script_kind
	if kind == "penalty":
		kind = "goal" if sim.penalty_scored else "save"
		setpiece = "penalti"
	var texts := {"goal": "GOOOL!", "save": "Defesa de %s!" % gk["p"]["name"], "out": "Pra fora!", "lost": "A zaga cortou!", "offside": "IMPEDIMENTO!"}
	_finish(kind, texts[kind])
	t = 0.9


## Quadro: a simulação anda em passos fixos de STEP (60 Hz); desenho e câmera seguem o quadro.
func _process(delta: float) -> void:
	delta = minf(delta, 0.1) * _slowmo_k()
	_acc_t += delta
	var n := 0
	while _acc_t >= STEP - 0.000001 and n < 6:
		_acc_t -= STEP
		_tick(STEP)
		n += 1
	if n >= 6:
		_acc_t = 0.0
	ad_t += delta
	_desat = move_toward(_desat, 1.0 if _user_turn() else 0.0, delta * 6.0)
	_update_camera(delta)
	queue_redraw()


## O jogador está escolhendo a jogada: o lance fica congelado (pausa de verdade — ninguém
## freia, a bola não anda; ao tocar, tudo continua exatamente de onde parou).
func _user_turn() -> bool:
	if state != "decide" or not user_ctrl:
		return false
	return not (me_pid >= 0 and int(att[carrier]["p"]["id"]) != me_pid)


## Um passo fixo da simulação do lance.
func _tick(delta: float) -> void:
	t += delta
	if _user_turn():
		if banner_t > 0.0:
			banner_t -= delta
			if banner_t <= 0.0:
				banner = ""
				card_flash = ""
		return
	if cel_t > 0.0:
		cel_t += delta
	if banner_t > 0.0 and state != "end":
		banner_t -= delta
		if banner_t <= 0.0:
			banner = ""
			card_flash = ""
	for e in att:
		if float(e.get("kick", 0.0)) > 0.0:
			e["kick"] = float(e["kick"]) - delta
	_tick_anims(delta)
	_net_step(delta)
	match state:
		"intro":
			# a faixa "ATAQUE DO..." fica na tela, mas a jogada já começa a correr por baixo dela
			if t > _intro_s:
				if banner_t <= 0.0:
					banner_t = 0.75
				_start_run(0.9 + (0.9 - _intro_s))
		"run":
			_move_all(delta)
			bp.step(delta)
			_dribble(att[carrier])
			_try_tackle()
			if state == "run" and t > run_time:
				_end_run()
		"settle":
			_move_all(delta)
			bp.step(delta)
			_settle()
		"decide":
			# máquina (ou companheiro no modo jogador): o jogo segue rolando enquanto ela decide
			if setpiece == "":
				_move_all(delta)
				bp.step(delta)
				_dribble(att[carrier])
			if t > (0.9 if setpiece != "" else _ai_think):
				_ai_decide()
		"pass":
			bp.step(delta)
			_move_all(delta, user_ctrl)
			_update_pass()
		"runup":
			_update_runup(delta)
		"shot":
			bp.step(delta)
			_move_all(delta)
			_update_shot(delta)
		"end":
			bp.step(delta)
			_move_all_end(delta)
			_end_reactions(delta)
			if gk_catch:
				# encaixou: a bola fica presa nas mãos do goleiro
				bp.place(gk["pos"] + Vector2(0, 0.25))
				bp.z = 1.05
			_net_ball(delta)   # a rede estufa e segura a bola (só visual: o resultado já saiu)
			if result.get("goal", false):
				bp.pos.y = maxf(bp.pos.y, -(NET_DEPTH + 0.8))
				bp.pos.x = clampf(bp.pos.x, -GOAL_HALF + 0.2, GOAL_HALF - 0.2)
				# depois de passar a linha a bola fica no gol: a rede devolve, mas não para fora
				if bp.pos.y < 0.0:
					_ball_netted = true
				if _ball_netted and bp.z < 0.06:
					bp.vel *= 0.86   # caída no pano da rede, a bola quase não rola
				if _ball_netted and bp.pos.y > -0.25:
					bp.pos.y = -0.25
					if bp.vel.y > 0.0:
						bp.vel.y = -bp.vel.y * 0.25
				if bp.pos.y <= -(NET_DEPTH + 0.8):
					bp.vel = Vector2.ZERO
			if result.get("goal", false):
				_tick_celebration(delta)
			# a comemoração grande vem depois da deslizada (lance pulado: logo depois da reação)
			if result.get("goal", false) and cel_t <= 0.0 and _cel_overlay_ready():
				start_celebration(att[carrier], kits[0], str(att[carrier]["p"]["name"]))
			if _end_done():
				state = "done"
				finished.emit(result)
	# árbitro acompanha a jogada de perto, sem atrapalhar
	var rt := Vector2(clampf(bp.pos.x + 9.0, -30.0, 30.0), clampf(bp.pos.y + 7.0, 3.0, 60.0))
	_move(referee, rt, 6.5, delta)
	gk["_kin"] = state == "shot" or state == "runup"
	var bodies := _bodies()
	_step_bodies(bodies, delta)
	if state in ["run", "settle", "end"] or (state in ["pass", "shot"] and user_ctrl):
		var owner: Variant = att[carrier] if state in ["run", "settle"] else null
		var ign: Variant = att[pass_to] if state == "pass" and pass_to >= 0 and pass_to < att.size() else null
		if not (state == "end" and (result.get("goal", false) or gk_catch)):
			_ball_vs_bodies(bodies, owner, ign)
	if _path_dirty and state == "pass":
		_record_path()


func _update_camera(delta: float) -> void:
	# câmera: cam_y = y do mundo no topo da tela. A bola fica a 62% da altura, então
	# há mais campo à frente dela (acima, rumo ao gol). No máximo, o topo mostra as placas.
	# pênalti: a câmera se aproxima da cobrança (gol em cima, batedor embaixo)
	var zt := 1.1 if setpiece == "penalti" and state != "intro" else 1.0   # a câmera já é perto: aproxima pouco
	var cel_cam := _cel_cam()
	if cel_cam:
		zt = _c_zoom
	if seamless and state in ["end", "done"] and t > _end_len() - 0.7:
		zt = CAMERA_WIDTH_M / LIVE_CAM_M   # fim do lance contínuo: volta à escala da partida ao vivo
	zoom = lerpf(zoom, zt, clampf(delta * (6.0 if seamless and state in ["end", "done"] else 2.2), 0.0, 1.0))
	if size.x > 0.0:
		s = size.x / CAMERA_WIDTH_M * zoom   # mesma escala do _draw (o limite da câmera depende dela)
	var vh: float = size.y / s
	var cam_min: float = _cam_min_y()
	var target: float = clampf(bp.pos.y - vh * 0.62, cam_min, maxf(66.0 - vh, cam_min))
	if setpiece == "penalti":
		target = clampf(-vh * 0.32, cam_min, maxf(66.0 - vh, cam_min))
	if cel_cam:
		target = clampf(float(att[carrier]["pos"].y) - vh * 0.55, cam_min, maxf(66.0 - vh, cam_min))
	# segue a bola um pouco à frente (para onde ela vai) com mola criticamente amortecida:
	# sem tranco quando a bola muda de direção e sem passar do ponto
	if setpiece != "penalti" and not cel_cam:
		target = clampf(target + clampf(bp.vel.y * _cam_lead, -6.0, 6.0), cam_min, maxf(66.0 - vh, cam_min))
	var sp: Vector2 = _spring(cam_y, _cam_vy, target, _cam_omega, delta)
	cam_y = sp.x
	_cam_vy = sp.y
	# de lado: segue a bola sem mostrar além das laterais (no pênalti fica no meio do gol)
	var vw: float = size.x / s
	var lim: float = maxf(37.0 - vw / 2.0, 0.0)
	var tx: float = 0.0 if setpiece == "penalti" else clampf(bp.pos.x * 0.85, -lim, lim)
	var sx: Vector2 = _spring(cam_x, _cam_vx, tx, _cam_omega * 0.8, delta)
	cam_x = sx.x
	_cam_vx = sx.y
	queue_redraw()


## Mola criticamente amortecida (sem oscilar): devolve [posição, velocidade] depois de dt.
static func _spring(x: float, v: float, target: float, omega: float, dt: float) -> Vector2:
	var ex := exp(-omega * dt)
	var d := x - target
	var tmp := (v + omega * d) * dt
	return Vector2(target + (d + tmp) * ex, (v - omega * tmp) * ex)


## Contagem regressiva das animações curtas (domínio, cabeceio, queda, carrinho) e dos efeitos.
func _tick_anims(delta: float) -> void:
	for e in att:
		_tick_ent(e, delta)
	for e in dfn:
		_tick_ent(e, delta)
	if not gk.is_empty():
		_tick_ent(gk, delta)
	net_shake = maxf(net_shake - delta * 0.9, 0.0)
	var k := confetti.size() - 1
	while k >= 0:
		var cf: Array = confetti[k]
		cf[1].y = minf(cf[1].y + 260.0 * delta, 170.0)   # papel cai devagar
		cf[1].x += sin(ad_t * 3.0 + k) * 30.0 * delta
		cf[0] += cf[1] * delta
		cf[3] += delta * 6.0
		if cf[0].y > size.y + 20.0:
			confetti.remove_at(k)
		k -= 1


func _tick_ent(e: Dictionary, delta: float) -> void:
	if float(e.get("lunge", 0.0)) > 0.0:
		e["lunge"] = float(e["lunge"]) - delta
	for key in ANIM_KEYS:
		if float(e.get(key, 0.0)) > 0.0:
			e[key] = maxf(float(e[key]) - delta, 0.0)


## Fim do lance: goleiro se recupera do mergulho, jogadores e torcida reagem.
func _end_reactions(delta: float) -> void:
	if t > 0.55:
		gk_tilt = lerpf(gk_tilt, 0.0, clampf(delta * 3.5, 0.0, 1.0))
	var kind: String = str(result.get("kind", ""))
	if kind == "goal" and net_shake <= 0.0 and not reacted and bp.pos.y <= 0.0:
		net_shake = 1.0
		net_x = bp.pos.x
	if reacted or t < 0.3:
		return
	reacted = true
	var goal := kind == "goal"
	if goal or kind == "save":
		var c: Dictionary = att[carrier]
		for i in att.size():
			var e: Dictionary = att[i]
			e["cheer"] = goal
			e["sad"] = not goal and i == carrier
			e["cel"] = int(e["p"]["id"]) % 4 if i == carrier else [0, 3][i % 2]
		if goal:
			_start_scorer(c)
		for d in dfn:
			d["cheer"] = not goal
			d["sad"] = goal
			d["cel"] = 0
		gk["cheer"] = not goal
		gk["sad"] = goal
		# torcida: papel picado nas cores de quem comemora
		var kit: Array = kits[0] if goal else kits[1]
		for i in (70 if goal else 40):
			var col: Color = [kit[0], kit[1], Color.WHITE][i % 3]
			confetti.append([Vector2(Game.rng.randf_range(0.0, size.x), Game.rng.randf_range(-size.y * 0.3, size.y * 0.45)),
				Vector2(Game.rng.randf_range(-40.0, 40.0), Game.rng.randf_range(40.0, 140.0)), col, Game.rng.randf_range(0.0, TAU)])


# ------------------------------------------------------------ comemoração do gol
## O autor do gol escolhe a comemoração (deslizada de joelhos ~60%, ou soco no ar, aviãozinho,
## apontar o céu) e o ponto do canto da tela para onde corre; cada companheiro ganha um lugar
## na roda em volta dele (atrás e dos lados, nunca no caminho da deslizada).
func _start_scorer(c: Dictionary) -> void:
	_fx_rng.seed = int(c["p"]["id"]) * 7919 + (sim.minute if sim != null else 0) * 131 + 17
	var slide: bool = not skipped and _fx_rng.randf() < slide_chance
	c["cel"] = 2 if slide else [0, 1, 3][_fx_rng.randi() % 3]
	c["cheer"] = not slide   # na deslizada, a pose de joelhos começa quando ele cai na grama
	var cp: Vector2 = c["pos"]
	var sx: float = signf(cp.x) if absf(cp.x) > 0.5 else (1.0 if _fx_rng.randf() < 0.5 else -1.0)
	# canto mais perto; se a zaga estiver no caminho da deslizada, vai para o outro lado
	var best := INF
	for side_x in [sx, -sx]:
		var d: Vector2 = Vector2(side_x * _c_corner.x, _c_corner.y) - cp
		var dir: Vector2 = d.normalized() if d.length() > 0.1 else Vector2(side_x, 0.0)
		var spot: Vector2 = cp + dir * clampf(d.length(), _c_run_min, _c_run_max)
		spot = Vector2(clampf(spot.x, -_c_corner.x - 3.0, _c_corner.x + 3.0), clampf(spot.y, 1.5, 40.0))
		var cost: float = 0.0 if side_x == sx else 1.5
		for o in dfn + [gk, referee]:
			if o.is_empty():
				continue
			var op: Vector2 = o["pos"]
			var seg: Vector2 = Geometry2D.get_closest_point_to_segment(op, spot - dir * 6.0, spot + dir * 1.0)
			if op.distance_to(seg) < 3.0:
				cost += 1.0
		if cost < best:
			best = cost
			cel_dir = dir
			cel_spot = spot
	if skipped:
		cel_spot = cp
	c["cs"] = "pose" if skipped else "run"
	c["cs_t"] = 0.0
	# lugares da roda: dos lados e atrás dele na tela (quem fica na frente esconderia a pose),
	# fora do cone à frente da deslizada
	var n: int = att.size() - 1
	var free: Array = []
	for j in 25:
		var ang: float = -PI - 0.35 + (PI + 0.7) * j / 24.0
		if absf(angle_difference(ang, cel_dir.angle())) > deg_to_rad(35.0) or skipped:
			free.append(ang)
	var k := 0
	for i in att.size():
		if i == carrier:
			continue
		var a2: float = free[int((k + 0.5) / maxf(n, 1.0) * free.size()) % free.size()]
		att[i]["ring"] = Vector2.from_angle(a2) * (_c_ring + 0.5 * (k % 2))
		k += 1


## Troca de estado do autor do gol, só pelas transições da tabela CEL_STEPS.
func _cel_go(c: Dictionary, nxt: String) -> void:
	var cur: String = str(c.get("cs", ""))
	assert(CEL_STEPS.has(cur) and nxt in CEL_STEPS[cur], "comemoração: %s -> %s" % [cur, nxt])
	c["cs"] = nxt
	c["cs_t"] = 0.0
	if nxt == "slide":
		c["cheer"] = true                 # cai de joelhos: pose da deslizada
		_body(c).max_decel = _c_fric      # sem ordem de movimento: só o atrito da grama freia o corpo
	elif nxt == "kneel":
		_body(c).max_decel = _b_dec
		_body(c).inv_mass = 1.0 / 300.0   # de joelhos e firme: quem chega para abraçar não o arrasta


## Um passo da comemoração: corrida (corpo físico em sprint), deslizada (freada pelo atrito da
## grama, sem teleporte), de joelhos; companheiros correm para a roda e pulam em volta dele.
func _tick_celebration(delta: float) -> void:
	_tick_fx(delta)
	if not reacted or att.is_empty():
		return
	var c: Dictionary = att[carrier]
	var b := _body(c)
	var cs: String = str(c.get("cs", ""))
	c["cs_t"] = float(c.get("cs_t", 0.0)) + delta
	match cs:
		"run":
			c["_press"] = true
			_move(c, cel_spot, _c_run_v)
			var rest: float = (c["pos"] as Vector2).distance_to(cel_spot)
			var v := b.speed()
			if int(c["cel"]) == 2:
				# cai na grama quando a freada pelo atrito termina no ponto escolhido
				if (v > 2.0 and rest <= v * v / (2.0 * _c_fric) + 0.1) or float(c["cs_t"]) > 2.4:
					_cel_go(c, "slide")
			elif rest < 0.35 or float(c["cs_t"]) > 2.6:
				_cel_go(c, "pose")
		"slide":
			banner = ""   # a faixa "GOOOL!" sai da frente: a deslizada aparece inteira
			_slide_fx(c, b)
			if b.speed() < 0.2:
				_cel_go(c, "kneel")
	cs = str(c.get("cs", ""))
	# enquanto ele corre e desliza, os companheiros vêm atrás (sem cortar a frente dele);
	# depois fecham a roda em volta dele
	var trailing: bool = cs == "run" or cs == "slide"
	var k := 0
	for i in att.size():
		if i == carrier:
			continue
		var m: Dictionary = att[i]
		var ring: Vector2 = m.get("ring", Vector2(0.0, 1.4))
		var tgt: Vector2 = c["pos"] + ring
		if trailing:
			tgt = c["pos"] - cel_dir * (2.6 + 0.6 * (k % 3)) + ring * 0.8
		_move(m, tgt, _spd(m))
		if (cs == "kneel" or cs == "pose") and (m["pos"] as Vector2).distance_to(tgt) < 0.7 \
				and float(m.get("jump", 0.0)) <= 0.0 and fmod(t + k * 0.37, 1.1) < delta * 1.01:
			m["jump"] = 0.5   # pula de alegria em volta do autor do gol
		k += 1


## Rastro da deslizada: marca dos joelhos na grama e grama/terra levantada.
func _slide_fx(c: Dictionary, b: Body) -> void:
	var sp := b.speed()
	if sp < 0.05:
		return
	var dir: Vector2 = b.vel / sp
	var perp := Vector2(-dir.y, dir.x)
	var knee: Vector2 = c["pos"] + dir * 0.12
	if skids.is_empty() or (skids[-1][0] as Vector2).distance_to(knee) > 0.1:
		skids.append([knee, 0.0, perp])
	if sp > 0.9:
		var cols := [PITCH.lightened(0.22), PITCH.darkened(0.3), Color("6b5232")]
		for j in 2:
			var sd: float = -1.0 if j == 0 else 1.0
			var pv: Vector2 = dir * sp * _fx_rng.randf_range(0.45, 0.95) + perp * sd * _fx_rng.randf_range(0.3, 1.8)
			spray.append([knee + dir * 0.25 + perp * sd * 0.18, pv, 0.05, _fx_rng.randf_range(1.4, 3.2) * minf(sp / 5.0, 1.0) + 0.6, 0.0,
				cols[_fx_rng.randi() % 3]])


func _tick_fx(delta: float) -> void:
	for sk in skids:
		sk[1] = float(sk[1]) + delta
	while not skids.is_empty() and float(skids[0][1]) > _c_skid_life:
		skids.pop_front()
	var k := spray.size() - 1
	while k >= 0:
		var q: Array = spray[k]
		q[4] = float(q[4]) + delta
		q[3] = float(q[3]) - 9.8 * delta
		q[2] = float(q[2]) + float(q[3]) * delta
		q[0] = (q[0] as Vector2) + (q[1] as Vector2) * delta
		q[1] = (q[1] as Vector2) * (1.0 - 1.5 * delta)
		if float(q[2]) <= 0.0 or float(q[4]) > 1.2:
			spray.remove_at(k)
		k -= 1


func _draw_skids() -> void:
	if skids.size() < 2:
		return
	var w: float = 0.2 * s
	for i in range(1, skids.size()):
		var a: Array = skids[i - 1]
		var b2: Array = skids[i]
		if (a[0] as Vector2).distance_to(b2[0]) > 0.6:
			continue
		var al: float = 0.5 * clampf(1.0 - float(b2[1]) / _c_skid_life, 0.0, 1.0)
		for sd in [-1.0, 1.0]:
			var o: Vector2 = (b2[2] as Vector2) * 0.17 * sd
			draw_line(_w2s(a[0] + o), _w2s(b2[0] + o), Color(0.27, 0.33, 0.05, al), w)
		draw_line(_w2s(a[0]), _w2s(b2[0]), Color(0.75, 0.82, 0.45, al * 0.35), w * 0.6)   # grama amassada


func _draw_spray() -> void:
	var px: float = maxf(s / 9.0, 2.0)
	for q in spray:
		var sp: Vector2 = _w2s(q[0]) + Vector2(0.0, -float(q[2]) * s * LIFT)
		var col: Color = q[5]
		col.a = clampf(1.0 - float(q[4]) / 1.2, 0.0, 1.0)
		draw_rect(Rect2(sp - Vector2(px, px) * 0.5, Vector2(px, px)), col)


## A tela grande ("GOOOOOL!!") entra depois da deslizada, com o autor já de joelhos.
func _cel_overlay_ready() -> bool:
	if skipped or att.is_empty():
		return t > (0.9 if setpiece == "penalti" else 0.45)
	if not reacted:
		return false
	var c: Dictionary = att[carrier]
	var cs: String = str(c.get("cs", ""))
	return ((cs == "kneel" or cs == "pose") and float(c.get("cs_t", 0.0)) > _c_wait) or t > _c_end - 0.7


## Duração prevista do fim do lance (para a câmera voltar à escala do campo antes da troca).
func _end_len() -> float:
	if not result.get("goal", false):
		return 1.5
	return 2.9 if skipped else _c_end


func _end_done() -> bool:
	if not result.get("goal", false):
		return t > 1.5
	if skipped:
		return t > 2.9
	return t > _c_end and (cel_t > 0.9 or t > _c_end + 1.0)


## Câmera da comemoração: segue o autor do gol, um pouco mais perto.
func _cel_cam() -> bool:
	return (state == "end" or state == "done") and result.get("goal", false) and not skipped and reacted and not att.is_empty()


func _draw_confetti() -> void:
	for cf in confetti:
		var w: float = 7.0 * absf(cos(cf[3]))
		draw_rect(Rect2(cf[0] - Vector2(w * 0.5, 2.5), Vector2(maxf(w, 1.5), 5.0)), cf[2])


## Menor cam_y do lance: o alto das placas atrás do gol encosta logo abaixo do placar.
func _cam_min_y() -> float:
	return -(AD_GAP + AD_H) - HUD_TOP / maxf(s, 1.0)


# ------------------------------------------------------------ toque
## Mundo -> tela. O gol atacado (y = 0) fica em cima; cam_y é o y do mundo no topo da tela.
func _w2s(w: Vector2) -> Vector2:
	if flip:
		return Vector2(size.x / 2.0 + (w.x - cam_x) * s, size.y - (w.y - cam_y) * s)
	return Vector2(size.x / 2.0 + (w.x - cam_x) * s, (w.y - cam_y) * s)


## Tela -> mundo (inverso de _w2s).
func _s2w(p: Vector2) -> Vector2:
	if flip:
		return Vector2((p.x - size.x / 2.0) / s + cam_x, cam_y + (size.y - p.y) / s)
	return Vector2((p.x - size.x / 2.0) / s + cam_x, cam_y + p.y / s)


## A mesma conversão de _w2s como Transform2D (para converter muitos pontos de uma vez).
func _w2s_xf() -> Transform2D:
	if flip:
		return Transform2D(Vector2(s, 0.0), Vector2(0.0, -s), Vector2(size.x / 2.0 - cam_x * s, size.y + cam_y * s))
	return Transform2D(Vector2(s, 0.0), Vector2(0.0, s), Vector2(size.x / 2.0 - cam_x * s, -cam_y * s))


func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseMotion and pressing:
		drag_now = e.position
		if _drag_pts.size() < 64:
			_drag_pts.append(e.position)
	if not (e is InputEventMouseButton) or e.button_index != MOUSE_BUTTON_LEFT:
		return
	accept_event()
	if e.pressed:
		if not user_ctrl and Rect2(size.x - 190, 80, 180, 56).has_point(e.position):
			skip()
			return
		pressing = true
		press = e.position
		press_ms = Time.get_ticks_msec()
		drag_now = e.position
		_drag_pts.clear()
		return
	if not pressing:
		return
	pressing = false
	if state != "decide" or not user_ctrl:
		return
	if me_pid >= 0 and int(att[carrier]["p"]["id"]) != me_pid:
		return   # a bola está com um companheiro
	var held: float = (Time.get_ticks_msec() - press_ms) / 1000.0
	var drag: Vector2 = e.position - press
	if drag.length() >= 40.0:
		# deslizar (para cima, rumo ao gol): direção = mira, comprimento = força
		var dir := Vector2(drag.x, drag.y * y_sign).normalized()
		if dir.y < -0.08:
			var p := clampf(drag.length() / Tuning.f("chute", "arraste_para_forca_maxima_px", 260.0), 0.2, 1.0)
			_do_shot(bp.pos.x + dir.x / -dir.y * bp.pos.y, 0.4 + p * 1.2, p, swipe_curl(press, e.position, _drag_pts))
		return
	if not shot_only:
		var best := -1
		var bd := 58.0
		for i in att.size():
			if i == carrier:
				continue
			var dd: float = (_w2s(att[i]["pos"]) - Vector2(0, 18)).distance_to(e.position)
			if dd < bd:
				bd = dd
				best = i
		if best >= 0:
			_do_pass(best, held >= Tuning.f("passe", "toque_longo_segundos", 0.35))
			return
	var w := _s2w(e.position)
	# o gol fica em pé sobre a linha (y = 0): subir na tela a partir da linha = mais alto no gol
	var up_m: float = -w.y * y_sign
	if absf(w.x) < 5.6 and up_m < BallPhysics.CROSSBAR * LIFT + 0.8 and up_m > -2.0:
		# toque perto do chão = chute rasteiro; perto do travessão = chute alto
		var h := clampf(up_m / LIFT, 0.1, 2.3)
		_do_shot(w.x, h, 0.55)


# ------------------------------------------------------------ desenho
func _ellipse(c: Vector2, rx: float, ry: float, col: Color) -> void:
	draw_set_transform(c, 0.0, Vector2(1.0, ry / rx))
	draw_circle(Vector2.ZERO, rx, col)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# ------------------------------------------------------------ desenho em lote
# Bonecos e bola não usam draw_circle/draw_rect soltos (cada círculo virava uma draw call
# com buffer próprio: ~70 por boneco). As formas viram triângulos num lote único e o lote
# vai para a tela numa chamada só (_flush). O formato de cada peça é o mesmo de antes.
#   _q_*        ..... acrescenta uma forma em _lp (coordenadas locais) e a cor em _bc
#   _commit(xf) ..... leva _lp para a tela com a transformação do boneco
#   _flush()    ..... desenha o lote acumulado

## Quantos lados o círculo precisa para parecer redondo com raio r_px na tela.
static func _circle_n(r_px: float) -> int:
	if r_px < 2.0:
		return 6
	if r_px < 3.0:
		return 8
	if r_px < 6.0:
		return 12
	if r_px < 10.0:
		return 18
	if r_px < 20.0:
		return 28
	if r_px < 40.0:
		return 48
	return 64


## Círculo unitário em triângulos (n lados), gerado uma vez.
static func _circle_tris(n: int) -> PackedVector2Array:
	var got: PackedVector2Array = _tmpl.get(n, PackedVector2Array())
	if not got.is_empty():
		return got
	var out := PackedVector2Array()
	for i in n:
		var a0 := TAU * i / n
		var a1 := TAU * (i + 1) / n
		out.append(Vector2.ZERO)
		out.append(Vector2(cos(a0), sin(a0)))
		out.append(Vector2(cos(a1), sin(a1)))
	_tmpl[n] = out
	return out


## Um quarto de círculo unitário (q: 0 sup. esq., 1 sup. dir., 2 inf. dir., 3 inf. esq.), n/4 lados.
static func _quarter_tris(n: int, q: int) -> PackedVector2Array:
	var key := 1000 + n * 4 + q
	var got: PackedVector2Array = _tmpl.get(key, PackedVector2Array())
	if not got.is_empty():
		return got
	var out := PackedVector2Array()
	var m := maxi(int(n / 4.0), 2)
	var start: float = [PI, PI * 1.5, 0.0, PI * 0.5][q]
	for i in m:
		var a0: float = start + PI * 0.5 * i / m
		var a1: float = start + PI * 0.5 * (i + 1) / m
		out.append(Vector2.ZERO)
		out.append(Vector2(cos(a0), sin(a0)))
		out.append(Vector2(cos(a1), sin(a1)))
	_tmpl[key] = out
	return out


## Polígono convexo (lista de pontos) em leque de triângulos, guardado com um nome.
static func _fan_tmpl(key: String, pts: PackedVector2Array) -> PackedVector2Array:
	var got: PackedVector2Array = _tmpl.get(key, PackedVector2Array())
	if not got.is_empty():
		return got
	var out := PackedVector2Array()
	for i in range(1, pts.size() - 1):
		out.append(pts[0])
		out.append(pts[i])
		out.append(pts[i + 1])
	_tmpl[key] = out
	return out


## Pentágono unitário da bola.
static func _pent_tris() -> PackedVector2Array:
	if _tmpl.has("pent"):
		return _tmpl["pent"]
	var pts := PackedVector2Array()
	for j in 5:
		pts.append(Vector2(cos(TAU * j / 5.0), sin(TAU * j / 5.0)))
	return _fan_tmpl("pent", pts)


## Sorriso de frente (meia elipse 8,5 x 4,6) e de lado (5 x 3,6), centrados na boca.
static func _smile_tris(side_view: bool) -> PackedVector2Array:
	var key := "smile_s" if side_view else "smile_f"
	if _tmpl.has(key):
		return _tmpl[key]
	var pts := PackedVector2Array()
	var n := 6 if side_view else 10
	for i in n + 1:
		var ang := PI * i / n
		pts.append(Vector2(cos(ang) * (5.0 if side_view else 8.5), sin(ang) * (3.6 if side_view else 4.6)))
	return _fan_tmpl(key, pts)


## Cor da cena com a dessaturação do momento de decidir (cinza pela luminância, um pouco mais escuro).
func _dc(c: Color) -> Color:
	if _desat <= 0.0:
		return c
	var g: float = c.get_luminance() * 0.86 + 0.04
	return Color(lerpf(c.r, g, _desat), lerpf(c.g, g, _desat), lerpf(c.b, g, _desat), c.a)


## Acrescenta n vezes a cor col no lote (listas prontas guardadas por cor e tamanho).
func _fill(col: Color, n: int) -> void:
	if _desat > 0.0:
		col = _dc(col)
	var key := Vector4(col.r, col.g, col.b, col.a * 1000.0 + n)
	var a: PackedColorArray = _cfill.get(key, PackedColorArray())
	if a.is_empty():
		if _cfill.size() > 2048:
			_cfill.clear()   # cores que variam a cada quadro (sombras) não acumulam
		a.resize(n)
		a.fill(col)
		_cfill[key] = a
	_bc.append_array(a)


func _q_tri(a: Vector2, b: Vector2, c: Vector2, col: Color) -> void:
	_lp.append(a)
	_lp.append(b)
	_lp.append(c)
	_fill(col, 3)


func _q_quad(a: Vector2, b: Vector2, c: Vector2, d: Vector2, col: Color) -> void:
	_lp.append(a)
	_lp.append(b)
	_lp.append(c)
	_lp.append(a)
	_lp.append(c)
	_lp.append(d)
	_fill(col, 6)


func _q_rect(r: Rect2, col: Color) -> void:
	_q_quad(r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y), col)


## Linha com largura w (o mesmo retângulo que draw_line monta).
func _q_line(a: Vector2, b: Vector2, col: Color, w: float) -> void:
	var tv := (b - a).orthogonal().normalized() * (w * 0.5)
	_q_quad(a - tv, a + tv, b + tv, b - tv, col)


## Segmento sem pontas redondas, um pouco esticado (preenchimento sobre um membro com contorno).
func _q_seg(a: Vector2, b: Vector2, w: float, col: Color) -> void:
	var d := b - a
	var l := d.length()
	if l < 0.001:
		return
	var u := d / l * (w * 0.35)
	_q_line(a - u, b + u, col, w)


func _q_circle(c: Vector2, r: float, col: Color) -> void:
	var tm := _circle_tris(_circle_n(r * _lk))
	_lp.append_array(Transform2D(0.0, Vector2(r, r), 0.0, c) * tm)
	_fill(col, tm.size())


func _q_ellipse(c: Vector2, rx: float, ry: float, col: Color) -> void:
	var tm := _circle_tris(_circle_n(maxf(rx, ry) * _lk))
	_lp.append_array(Transform2D(0.0, Vector2(rx, ry), 0.0, c) * tm)
	_fill(col, tm.size())


## Membro com pontas redondas (linha + dois círculos), como antes.
func _q_limb(a: Vector2, b: Vector2, w: float, col: Color) -> void:
	_q_line(a, b, col, w)
	_q_circle(a, w * 0.5, col)
	_q_circle(b, w * 0.5, col)


## Retângulo de cantos redondos (o canto nunca passa da metade do lado menor).
## A forma (tamanho + canto) é montada uma vez e reaproveitada, só deslocada.
func _q_rr(r: Rect2, rad: float, col: Color) -> void:
	rad = minf(rad, minf(r.size.x, r.size.y) * 0.5)
	var n := _circle_n(rad * _lk)
	var key := Vector4(r.size.x, r.size.y, rad, n)
	var tm: PackedVector2Array = _rr_cache.get(key, PackedVector2Array())
	if tm.is_empty():
		if _rr_cache.size() > 1024:
			_rr_cache.clear()
		tm = _rr_tris(r.size, rad, n)
		_rr_cache[key] = tm
	_lp.append_array(Transform2D(0.0, r.position) * tm)
	_fill(col, tm.size())


## Triângulos de um retângulo arredondado em (0, 0): duas faixas em cruz e quatro quartos de círculo.
static func _rr_tris(sz: Vector2, rad: float, n: int) -> PackedVector2Array:
	var out := PackedVector2Array()
	for rc in [Rect2(rad, 0.0, sz.x - rad * 2.0, sz.y), Rect2(0.0, rad, sz.x, sz.y - rad * 2.0)]:
		var q: Rect2 = rc
		out.append_array(PackedVector2Array([q.position, Vector2(q.end.x, q.position.y), q.end,
			q.position, q.end, Vector2(q.position.x, q.end.y)]))
	var sc := Vector2(rad, rad)
	out.append_array(Transform2D(0.0, sc, 0.0, Vector2(rad, rad)) * _quarter_tris(n, 0))
	out.append_array(Transform2D(0.0, sc, 0.0, Vector2(sz.x - rad, rad)) * _quarter_tris(n, 1))
	out.append_array(Transform2D(0.0, sc, 0.0, Vector2(sz.x - rad, sz.y - rad)) * _quarter_tris(n, 2))
	out.append_array(Transform2D(0.0, sc, 0.0, Vector2(rad, sz.y - rad)) * _quarter_tris(n, 3))
	return out


## Modelo pronto (triângulos) deslocado para o ponto o.
func _q_tmpl(tm: PackedVector2Array, o: Vector2, col: Color) -> void:
	_lp.append_array(Transform2D(0.0, o) * tm)
	_fill(col, tm.size())


func _commit(xf: Transform2D) -> void:
	_bp.append_array(xf * _lp)
	_lp.clear()


func _commit_screen() -> void:
	_bp.append_array(_lp)
	_lp.clear()


## Desenha o lote acumulado numa única chamada.
func _flush() -> void:
	if not _lp.is_empty():
		_commit_screen()
	if not _bp.is_empty():
		RenderingServer.canvas_item_add_triangle_array(_ci_override if _ci_override.is_valid() else get_canvas_item(), PackedInt32Array(), _bp, _bc)
	_bp.clear()
	_bc.clear()


## Visual guardado do jogador (montado uma vez):
## [estilo do cabelo, barba, cor da chuteira, número como texto, faixa na cabeça, munhequeira, celebração]
## Chaves do jogador (iguais nos menus e na partida) — quando faltam, saem do id:
##   look_hstyle  = id % 7      (0 curto espetado, 1 topete/moicano, 2 black power, 3 careca,
##                                4 raspado degradê, 5 franja, 6 cachos longos com faixa)
##   look_beard   = id % 4 == 1
##   look_skin    = (id * 3) % 6     look_hcolor = (id * 5) % 6
##   look_boots   = "17171b" (cor da chuteira; o detalhe colorido sai de BOOT_ACCENTS[id % 6])
##   look_headband = id % 9 == 4 (sempre no estilo 6)    look_wrist = id % 5 == 2
func _look(e: Dictionary) -> Array:
	var lk: Array = e.get("_look", [])
	if lk.is_empty():
		var p: Dictionary = e["p"]
		var id: int = int(p["id"])
		var style: int = int(p.get("look_hstyle", id % 7))
		lk = [style, bool(p.get("look_beard", id % 4 == 1)), Color(str(p.get("look_boots", "17171b"))), str(e["num"]),
			bool(p.get("look_headband", id % 9 == 4)) or style == 6, bool(p.get("look_wrist", id % 5 == 2)),
			BOOT_ACCENTS[id % BOOT_ACCENTS.size()]]
		e["_look"] = lk
	return lk


## Cores mais vivas para a camisa (saturação e brilho um pouco acima, como na arte do jogo).
static func vivid(c: Color) -> Color:
	return Color.from_hsv(c.h, minf(c.s * 1.18, 1.0), minf(c.v * 1.06 + 0.02, 1.0), c.a)


## Boneco da partida: figura pequena e bem proporcionada (~4 cabeças de altura), contorno
## escuro fino, sombra do sol na diagonal, camisa/calção/meião nas cores do time e número
## nas costas. Os retratos dos menus continuam no estilo chibi (src/chibi_portrait.gd).
## Unidades do corpo: 100 = altura toda (pés em 0, topo da cabeça em -100).
## A pose sai do estado físico: velocidade (parado/caminhada/corrida), aceleração (inclinação),
## chute/passe (perna), domínio, carrinho e queda (corpo deitado), goleiro (agachado, mergulho,
## encaixe) e comemoração (e["cel"]: 0 soco no ar, 1 aviãozinho, 2 de joelhos deslizando, 3 apontar o céu).
## Estilos de cabelo (look_hstyle): 0 curto espetado, 1 moicano, 2 black power, 3 careca,
## 4 raspado, 5 franja, 6 cachos longos com faixa.
func _draw_player(e: Dictionary, kit: Array, keeper: bool = false, ref_kit: bool = false) -> void:
	var p: Vector2 = e["screen"] if e.has("screen") else _w2s(e["pos"])
	var ku: float = BODY_H * LIFT * s / 100.0 * body_scale
	if _bake_part == 0 and SpriteBank.enabled() and not e.has("screen") and _sprite_fast(e, kit, keeper, ref_kit, p, ku):
		return
	var lk := _look(e)
	_lk = 1.0
	if _bake_part == 0 and me_pid >= 0 and not ref_kit and e.has("p") and int(e["p"]["id"]) == me_pid:
		var tip := p + Vector2(0, -110.0 * ku)
		_q_tri(tip + Vector2(0, 2) * ku, tip + Vector2(-9, -11) * ku, tip + Vector2(9, -11) * ku, OUTLINE)
		_q_tri(tip, tip + Vector2(-6.5, -9) * ku, tip + Vector2(6.5, -9) * ku, UI.GOLD)
		_q_ellipse(p, 15.0 * ku, 5.0 * ku, Color(UI.GOLD, 0.35))
	# cores do uniforme calculadas uma vez por jogador (mudam só se o uniforme mudar)
	var cols: Array = e.get("_cols", [])
	if cols.is_empty() or not is_same(cols[5], kit) or bool(cols[6]) != keeper:
		var shirt0 := NEAR_BLACK
		var trim0 := Color("f2f2f2")
		var striped0 := false
		if keeper:
			shirt0 = KEEPER_SHIRT
			trim0 = KEEPER_TRIM
		elif ref_kit:
			shirt0 = Color("1b1d22")
			trim0 = Color("e8e8e8")
		else:
			shirt0 = vivid(kit[0])
			trim0 = vivid(kit[1])
			striped0 = kit.size() > 2 and kit[2]
		var shorts0: Color = trim0 if not _close(trim0, shirt0) else shirt0.darkened(0.25)
		if ref_kit:
			shorts0 = REF_SHORTS
		var ink1 := Color("151515") if shirt0.get_luminance() > 0.55 else Color("f4f4f4")
		cols = [shirt0, trim0, shorts0, shirt0 if not striped0 else trim0, striped0, kit, keeper, ink1]
		e["_cols"] = cols
		e.erase("_pcache")
	var shirt: Color = cols[0]
	var trim: Color = cols[1]
	var shorts: Color = cols[2]
	var sock: Color = cols[3]
	var striped: bool = cols[4]
	var skin: Color = e["skin"]
	var hair: Color = e["hair"]
	var spd: float = float(e.get("spd", 0.0))
	var walk_k: float = clampf(spd / maxf(_b_walk, 0.1), 0.0, 1.0)          # 0 parado .. 1 caminhada
	var run_k: float = clampf((spd - _b_walk) / 4.0, 0.0, 1.0)               # 0 caminhada .. 1 corrida
	var amp: float = walk_k * (0.55 + 0.45 * run_k)
	var ph: float = e["ph"]
	var dir: Vector2 = e["dir"]
	var sd := Vector2(dir.x, dir.y * y_sign)
	var view := 1 if float(e["face"]) < 0.0 else 0      # 0 frente, 1 costas, 2 lado
	if e["moving"] or amp > 0.05:
		if absf(sd.x) > 0.7:
			view = 2
		else:
			view = 0 if sd.y > 0.0 else 1
	var flip := -1.0 if sd.x < 0.0 else 1.0
	var kick: float = clampf(float(e.get("kick", 0.0)) / 0.3, 0.0, 1.0)
	var windup: float = float(e.get("windup", 0.0))
	var trap: float = clampf(float(e.get("trap", 0.0)) / 0.3, 0.0, 1.0)
	var pid: int = int(e["p"]["id"]) if e.has("p") else 0
	var idv: float = float(pid % 13) * 0.7
	var idle: float = 1.0 - walk_k
	var dive: float = gk_tilt if keeper and _bake_part == 0 else 0.0
	var cheer: bool = e.get("cheer", false)
	var cel: int = int(e.get("cel", 0)) if cheer else -1
	var catch_pose: bool = _bake_part == 0 and keeper and gk_catch and state == "end" and is_same(e, gk)
	if cel == 2:
		amp = 0.0
		if not e["moving"]:
			view = 0
	var crouch: float = 1.0 if _bake_part == 0 and keeper and (state == "shot" or state == "runup") and absf(dive) < 0.35 else 0.0
	var fwd := Vector2(flip, 0.0) if view == 2 else Vector2(0.0, 1.0 if view == 0 else -1.0)

	# sombras: contato sob os pés e a sombra do sol esticada na diagonal (direita, para baixo)
	var lying: float = absf(dive) + float(e.get("fall", 0.0)) + float(e.get("slide", 0.0))
	if _bake_part == 0:
		_q_ellipse(p + Vector2(15.0 * ku, 4.0 * ku), (20.0 + lying * 10.0) * ku, 5.0 * ku, Color(0, 0, 0, 0.16))
		_q_ellipse(p + Vector2(1.0 * ku, 0.5 * ku), (11.0 + lying * 12.0) * ku, 3.6 * ku, Color(0, 0, 0, 0.30))
		_commit_screen()
	var bob: float = absf(sin(ph * 2.0)) * 2.6 * amp * (0.4 + 0.6 * run_k) + sin(ad_t * (1.7 + float(pid % 5) * 0.12) + idv) * 0.7 * idle
	bob -= crouch * 9.0
	var hop: float = 0.0
	var jmp: float = float(e.get("jump", 0.0))
	if jmp > 0.0:
		hop = sin((1.0 - jmp / 0.5) * PI) * 30.0
	elif cheer and not e.has("screen") and cel != 2:
		hop = absf(sin(ad_t * 8.0 + idv)) * (10.0 if cel == 0 else 5.0)
	if cel == 2:
		bob -= 22.0   # de joelhos
	var lay: float = 0.0
	var fl: float = float(e.get("fall", 0.0))
	if fl > 0.0:
		lay = 1.45 * minf(clampf((1.3 - fl) / 0.18, 0.0, 1.0), clampf(fl / 0.35, 0.0, 1.0)) * (-flip)
	var sl: float = float(e.get("slide", 0.0))
	var slide_k: float = 0.0
	if sl > 0.0:
		slide_k = minf(clampf((0.7 - sl) / 0.12, 0.0, 1.0), clampf(sl / 0.25, 0.0, 1.0))
		lay = 1.1 * slide_k * flip
	var acc: Vector2 = e.get("acc", Vector2.ZERO)
	var lean: float = clampf(acc.x * 0.01, -0.14, 0.14)
	if view == 2:
		lean += clampf(spd / 12.0, 0.0, 1.0) * 0.12 * flip   # corpo à frente na corrida de perfil
	if cel == 1:
		lean += sin(ad_t * 3.0 + idv) * 0.18
	elif cel == 2:
		lean += (-0.22 * flip) if view == 2 else 0.0
	# poses comuns (parado/caminhada/corrida) ficam em cache por jogador: a figura em
	# coordenadas do corpo é montada uma vez por pose quantizada e só transformada depois
	var cacheable: bool = not (kick > 0.0 or windup > 0.0 or trap > 0.0 or slide_k > 0.0 or fl > 0.0 or jmp > 0.0 \
		or cheer or e.get("sad", false) or crouch > 0.0 or catch_pose or absf(dive) > 0.01 or (e.has("screen") and _bake_part == 0) or cel >= 0)
	var ckey: int = -1
	var gait_s: int = 0
	var ph_raw: float = ph
	if cacheable:
		# andar: 0 parado, 1 caminhada, 2 trote, 3 corrida; 8 fases da passada; respiração em 3
		var gait: int = 0 if walk_k < 0.25 else (1 if run_k < 0.2 else (2 if run_k < 0.7 else 3))
		var pb: int = posmod(int(round(ph / TAU * 12.0)), 12) if gait > 0 else 0
		var ib: int = posmod(int(round((ad_t * (1.7 + float(pid % 5) * 0.12) + idv) / TAU * 6.0)), 6) if gait == 0 else 0
		if _bake_part > 0:
			gait = _bake_force.x
			pb = 0
			ib = 0
		gait_s = gait
		ph = TAU * pb / 12.0
		if _bake_part > 0:
			ph = TAU * float(_bake_force.y) / 8.0
		amp = [0.0, 0.55, 0.8, 1.0][gait]
		run_k = [0.0, 0.0, 0.5, 1.0][gait]
		idle = 1.0 if gait == 0 else 0.0
		bob = absf(sin(ph * 2.0)) * 2.6 * amp * (0.4 + 0.6 * run_k) + sin(TAU * ib / 6.0) * 0.7 * idle
		ckey = (((view * 2 + (1 if flip > 0.0 else 0)) * 12 + pb) * 4 + gait) * 6 + ib
	var xf := Transform2D(dive + lay + lean, Vector2(ku, ku), 0.0,
		p + Vector2(0, -absf(dive) * 26.0 * ku - (0.0 if ckey >= 0 else bob * 0.25 * ku) - hop * ku))
	var pcache: Dictionary = _pcache_of(e, cols, ref_kit)
	if ckey >= 0 and _desat > 0.0 and _desat < 0.999:
		ckey = -1   # no meio do esmaecimento a cor muda a cada quadro: monta sem cache
		xf = Transform2D(dive + lay + lean, Vector2(ku, ku), 0.0, p + Vector2(0, -bob * 0.25 * ku - hop * ku))
	if ckey >= 0 and _bake_part == 0 and _desat <= 0.0 and SpriteBank.enabled():
		if _draw_sprite(e, kit, keeper, ref_kit, view, flip, gait_s, ph_raw, acc, p, ku, cols, lk):
			return
	if ckey >= 0 and pcache.has(ckey):
		var hit: Array = pcache[ckey]
		_bp.append_array(xf * (hit[0] as PackedVector2Array))
		if _desat >= 0.999:
			if hit.size() < 4:
				var gc := PackedColorArray()
				gc.resize((hit[1] as PackedColorArray).size())
				for q in gc.size():
					gc[q] = _dc(hit[1][q])
				hit.append(gc)
			_bc.append_array(hit[3])
		else:
			_bc.append_array(hit[1])
		if view == 1:
			_num_q(xf * Vector2(0.0, -55.0 - float(hit[2])), lk[3], cols[7], ku)
		_lk = 1.0
		if not _batch_open:
			_flush()
			_flush_numbers()
		return
	var bc0: int = _bc.size()
	var head_lp: int = 0
	var head_bc: int = 0
	_lk = ku
	if ckey >= 0:
		xf = Transform2D(dive + lay + lean, Vector2(ku, ku), 0.0, p + Vector2(0, -hop * ku))
	var boots: Color = lk[2]
	var accent: Color = lk[6]
	var wid := 1.0 if view != 2 else 0.62

	# --- pernas: contorno, coxa (pele), meião e chuteira
	for li in 2:
		var leg: float = -1.0 if li == 0 else 1.0
		var phase := ph + (0.0 if leg > 0.0 else PI)
		var sw: float = sin(phase) * amp
		if leg > 0.0 and windup > 0.0:
			sw = -1.4 * windup
		elif kick > 0.0 and leg > 0.0:
			sw = 1.7 * pow(kick, 0.6)
		elif trap > 0.0 and leg < 0.0:
			sw = 0.9 * sin(trap * PI)
		if slide_k > 0.0:
			sw = (1.9 if leg > 0.0 else -0.5) * slide_k
		var hx2: float = leg * 5.2 * wid
		var hip := Vector2(hx2, -35.0 - bob)
		var foot := Vector2(hx2 + (leg * 1.5 if crouch > 0.0 else 0.0), -1.5) + fwd * sw * (15.0 if view == 2 else 4.0)
		foot.y -= maxf(0.0, -cos(phase)) * (7.0 * run_k + 2.5) * amp
		if trap > 0.0 and leg < 0.0:
			foot.y -= 6.0 * sin(trap * PI)
		var knee := hip.lerp(foot, 0.5) + fwd * (2.0 * amp if view == 2 else 0.0)
		if cel == 2:
			knee = Vector2(leg * 5.0 + (flip * 7.0 if view == 2 else 0.0), -4.0)
			foot = Vector2(leg * 5.0 - (flip * 9.0 if view == 2 else 0.0), -3.0)
		_q_line(hip, knee, OUTLINE, 10.0)
		_q_limb(knee, foot, 9.6, OUTLINE)
		_q_seg(hip, knee, 7.2, skin)
		_q_seg(knee.lerp(foot, 0.15), foot, 7.0, sock)
		var boot := foot + (fwd * 1.8 if view == 2 else Vector2(0, 0.4))
		_q_rr(Rect2(boot.x - 5.6, boot.y - 3.0, 11.2, 6.2), 2.8, OUTLINE)
		_q_rr(Rect2(boot.x - 4.4, boot.y - 1.9, 8.8, 4.2), 2.0, boots)
		_q_rect(Rect2(boot.x - 3.0, boot.y + 0.7, 6.0, 1.2), accent)

	# --- calção
	_q_rr(Rect2(-13.0 * wid - 1.4, -47.0 - bob - 1.4, 26.0 * wid + 2.8, 15.8), 4.0, OUTLINE)
	_q_rr(Rect2(-13.0 * wid, -47.0 - bob, 26.0 * wid, 13.0), 3.4, shorts)

	# --- braços: o de trás antes do tronco
	var shp_l := Vector2(-12.0 * wid, -66.0 - bob)
	var shp_r := Vector2(12.0 * wid, -66.0 - bob)
	var armk: float = amp * (0.55 + 0.45 * run_k)
	var swing := 12.0 if view == 2 else 4.0
	var hand_l := shp_l + Vector2(-2.5 * wid, 19.0) + fwd * (-sin(ph + PI) * armk) * swing
	var hand_r := shp_r + Vector2(2.5 * wid, 19.0) + fwd * (-sin(ph) * armk) * swing
	if view == 2 and armk > 0.1:
		hand_l.y -= absf(sin(ph + PI)) * 5.0 * armk   # cotovelo dobrado na corrida
		hand_r.y -= absf(sin(ph)) * 5.0 * armk
	hand_l.x += sin(ad_t * 1.7 + idv) * 0.8 * idle
	hand_r.x -= sin(ad_t * 1.7 + idv) * 0.8 * idle
	if keeper and absf(dive) > 0.35:
		hand_l = shp_l + Vector2(-3.0, -24.0)
		hand_r = shp_r + Vector2(3.0, -24.0)
	elif catch_pose:
		hand_l = Vector2(-4.0, -54.0 - bob)
		hand_r = Vector2(4.0, -54.0 - bob)
	elif crouch > 0.0:
		hand_l = shp_l + Vector2(-9.0, 14.0)
		hand_r = shp_r + Vector2(9.0, 14.0)
	elif cel == 0:
		hand_r = shp_r + Vector2(2.0, -24.0)
		hand_l = shp_l + Vector2(-5.0, 14.0)
	elif cel == 1:
		hand_l = shp_l + Vector2(-22.0, 1.0)
		hand_r = shp_r + Vector2(22.0, 1.0)
	elif cel == 2:
		hand_l = shp_l + Vector2(-19.0, -14.0)
		hand_r = shp_r + Vector2(19.0, -14.0)
	elif cel == 3:
		hand_r = shp_r + Vector2(1.0, -25.0)
		hand_l = shp_l + Vector2(-3.0, 18.0)
	elif cheer:
		hand_l = shp_l + Vector2(-3.0, -22.0)
		hand_r = shp_r + Vector2(3.0, -22.0)
	elif e.get("sad", false):
		hand_l = shp_l + Vector2(6.0, -16.0)
		hand_r = shp_r + Vector2(-6.0, -16.0)
	elif slide_k > 0.0:
		hand_l = shp_l + Vector2(-13.0, -4.0)
		hand_r = shp_r + Vector2(9.0, 10.0)
	var left_behind := view != 2 or flip > 0.0
	if left_behind:
		_arm3(shp_l, hand_l, shirt, skin, keeper)
	else:
		_arm3(shp_r, hand_r, shirt, skin, keeper)

	# --- tronco (camisa) com gola e listras
	var tw := 12.8 * wid
	var ttop := -69.0 - bob
	_q_rr(Rect2(-tw - 1.4, ttop - 1.4, tw * 2.0 + 2.8, 28.8), 6.0, OUTLINE)
	_q_rr(Rect2(-tw, ttop, tw * 2.0, 26.0), 5.0, shirt)
	if striped:
		for k2 in 3:
			var cx: float = -tw + tw * 2.0 * (k2 + 0.5) / 3.0
			_q_rect(Rect2(cx - tw * 0.16, ttop + 0.8, tw * 0.32, 24.4), trim)
	_q_rect(Rect2(-tw + 1.0, ttop + 20.0, tw * 2.0 - 2.0, 3.0), Color(0, 0, 0, 0.13))   # sombra na barra
	_q_rect(Rect2(-tw + 1.5, ttop + 1.0, tw * 0.6, 18.0), Color(1, 1, 1, 0.07))         # luz do sol
	if view == 0:
		_q_tri(Vector2(-4.0, ttop - 0.3), Vector2(4.0, ttop - 0.3), Vector2(0, ttop + 5.5), trim)
		_q_tri(Vector2(-2.2, ttop - 0.3), Vector2(2.2, ttop - 0.3), Vector2(0, ttop + 3.0), skin)
	elif view == 1:
		_q_rect(Rect2(-4.5, ttop - 0.3, 9.0, 2.0), trim)
		if _bake_part == 0:
			_num_q(xf * Vector2(0.0, ttop + 14.0), lk[3], cols[7], ku)
	if left_behind:
		_arm3(shp_r, hand_r, shirt, skin, keeper)
	else:
		_arm3(shp_l, hand_l, shirt, skin, keeper)
	if catch_pose:
		_q_circle(Vector2(0, -56.0 - bob), 6.4, OUTLINE)
		_q_circle(Vector2(0, -56.0 - bob), 5.0, BALL_WHITE)

	# --- pescoço e cabeça redonda
	var hx: float = (1.5 * flip) if view == 2 else 0.0
	var hc := Vector2(hx, -84.0 - bob)
	var hr := 14.5
	var style: int = lk[0]
	var beard: bool = lk[1]
	var band: bool = lk[4]
	_q_rect(Rect2(-3.2, -72.0 - bob, 6.4, 4.0), skin.darkened(0.12))
	head_lp = _lp.size()
	head_bc = _bc.size()
	_hair_back3(hc, hr, hair, style, view)
	_q_circle(hc, hr + 1.3, OUTLINE)
	_q_circle(hc, hr, skin)
	_q_circle(hc + Vector2(hr * 0.35, hr * 0.15), hr * 0.62, Color(0, 0, 0, 0.06))   # lado na sombra
	_hair_top3(hc, hr, hair, style, view, flip)
	if view == 0:
		_q_rr(Rect2(hc.x - 6.6, hc.y - 1.2, 3.0, 4.2), 1.4, INK)
		_q_rr(Rect2(hc.x + 3.6, hc.y - 1.2, 3.0, 4.2), 1.4, INK)
		_q_rr(Rect2(hc.x - 3.6, hc.y + 5.6, 7.2, 2.6), 1.2, WHITE_TEETH)    # sorriso
		if beard:
			_q_rr(Rect2(hc.x - 6.5, hc.y + 4.5, 13.0, 5.5), 2.8, hair.darkened(0.1))
	elif view == 2:
		_q_rr(Rect2(hc.x + 6.0 * flip - 1.5, hc.y - 1.2, 3.0, 4.2), 1.4, INK)
		_q_rr(Rect2(hc.x + (8.0 * flip) - 3.0, hc.y + 5.6, 5.0, 2.4), 1.1, WHITE_TEETH)
		_q_circle(hc + Vector2((hr - 0.2) * flip, 2.0), 1.6, skin.darkened(0.08))   # nariz
		if beard:
			_q_rr(Rect2(hc.x + (0.0 if flip > 0.0 else -9.0), hc.y + 4.0, 9.0, 5.5), 2.8, hair.darkened(0.1))
	if band and style != 3:
		_q_rect(Rect2(hc.x - hr - 0.5, hc.y - 6.0, hr * 2.0 + 1.0, 3.0), Color("1c1c20") if style == 6 else trim)
	if _bake_part == 1:
		_lp.resize(head_lp)
		_bc.resize(head_bc)
	elif _bake_part == 2:
		_lp = _lp.slice(head_lp)
		_bc = _bc.slice(0, bc0) + _bc.slice(head_bc)
		xf = Transform2D(0.0, Vector2(ku, ku), 0.0, p - hc * ku)
	# guarda só poses em cor (a cena cinza da decisão usa uma cópia feita a partir delas)
	if ckey >= 0 and _bake_part == 0 and _desat <= 0.0 and pcache.size() < POSE_CACHE_MAX:
		pcache[ckey] = [_lp.duplicate(), _bc.slice(bc0), bob]
		e["_pcache"] = pcache
	_commit(xf)
	_lk = 1.0
	if not _batch_open:
		_flush()
		_flush_numbers()


## Atalho do sprite: decide a pose só com o essencial (sem montar nada do boneco).
## Devolve false para poses especiais (chute, carrinho, queda, comemoração, goleiro em ação...)
## e para o 1º quadro de cada jogador; aí o caminho completo desenha.
func _sprite_fast(e: Dictionary, kit: Array, keeper: bool, ref_kit: bool, p: Vector2, ku: float) -> bool:
	var cols: Array = e.get("_cols", [])
	if cols.is_empty() or not is_same(cols[5], kit) or bool(cols[6]) != keeper or not e.has("_skey"):
		return false
	if float(e.get("kick", 0.0)) > 0.0 or float(e.get("windup", 0.0)) > 0.0 or float(e.get("trap", 0.0)) > 0.0 \
			or float(e.get("slide", 0.0)) > 0.0 or float(e.get("fall", 0.0)) > 0.0 or float(e.get("jump", 0.0)) > 0.0 \
			or e.get("cheer", false) or e.get("sad", false):
		return false
	if keeper and (absf(gk_tilt) > 0.01 or state == "shot" or state == "runup" or (gk_catch and state == "end")):
		return false
	if me_pid >= 0 and not ref_kit and e.has("p") and int(e["p"]["id"]) == me_pid:
		return false   # seta do seu jogador: caminho completo
	var bank := SpriteBank.inst()
	if bank == null:
		return false
	var spd: float = float(e.get("spd", 0.0))
	var walk_k: float = clampf(spd / maxf(_b_walk, 0.1), 0.0, 1.0)
	var run_k: float = clampf((spd - _b_walk) / 4.0, 0.0, 1.0)
	var gait: int = 0 if walk_k < 0.25 else (1 if run_k < 0.2 else (2 if run_k < 0.7 else 3))
	var dir: Vector2 = e["dir"]
	var sd := Vector2(dir.x, dir.y * y_sign)
	var view := 1 if float(e["face"]) < 0.0 else 0
	if e["moving"] or walk_k * (0.55 + 0.45 * run_k) > 0.05:
		if absf(sd.x) > 0.7:
			view = 2
		else:
			view = 0 if sd.y > 0.0 else 1
	var flip := -1.0 if sd.x < 0.0 else 1.0
	var ph: float = e["ph"]
	var pb8: int = posmod(int(round(ph / TAU * 8.0)), 8) if gait > 0 else 0
	var st: int = 0 if gait == 0 else 1 + (gait - 1) * 8 + pb8
	var bc: Array = bank.body_cell(e["_skey"], view, st)
	var hcell: Array = bank.head_cell(e["_hkey"], view)
	if bc.is_empty() or hcell.is_empty():
		return false
	if not _bp.is_empty() or not _lp.is_empty():
		_flush()
	if texture_filter != CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS:
		texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	var k: float = ku / SpriteBank.BAKE_KU
	draw_texture_rect(bank.shadow, Rect2(p + SpriteBank.SHADOW_OFF * ku, SpriteBank.SHADOW_SIZE * ku), false)
	var amp: float = [0.0, 0.55, 0.8, 1.0][gait]
	var rk: float = [0.0, 0.0, 0.5, 1.0][gait]
	var bob: float = absf(sin(TAU * pb8 / 8.0 * 2.0)) * 2.6 * amp * (0.4 + 0.6 * rk)
	var side_lean: float = (clampf(SpriteBank.gait_speed(gait, _b_walk) / 12.0, 0.0, 1.0) * 0.12) if view == 2 else 0.0
	var acc: Vector2 = e.get("acc", Vector2.ZERO)
	var mir: float = -1.0 if (view == 2 and flip < 0.0) else 1.0
	var bsrc: Rect2 = bc[1]
	var hsrc: Rect2 = hcell[1]
	draw_set_transform(p, clampf(acc.x * 0.01, -0.14, 0.14), Vector2(k * mir, k))
	draw_texture_rect_region(bc[0], Rect2(-SpriteBank.BODY_ANCHOR, bsrc.size), bsrc)
	var hc := Vector2(1.5 if view == 2 else 0.0, -84.0 - bob).rotated(side_lean) * SpriteBank.BAKE_KU
	draw_texture_rect_region(hcell[0], Rect2(hc - SpriteBank.HEAD_ANCHOR, hsrc.size), hsrc)
	draw_set_transform_matrix(Transform2D.IDENTITY)
	if view == 1:
		_num_q(p + Vector2(0.0, (-55.0 - bob) * ku), _look(e)[3], cols[7], ku)
	return true


## Sprites: poses comuns (parado/caminhada/trote/corrida) saem de imagens assadas uma vez
## (SpriteBank) em vez de ~900 triângulos por quadro. Corpo por (uniforme, pele) e cabeça
## por jogador. Devolve false enquanto a imagem não está pronta (desenha do jeito antigo).
func _draw_sprite(e: Dictionary, kit: Array, keeper: bool, ref_kit: bool, view: int, flip: float, gait: int,
		ph_raw: float, acc: Vector2, p: Vector2, ku: float, cols: Array, lk: Array) -> bool:
	var bank := SpriteBank.inst()
	if bank == null:
		return false
	if not is_same(e.get("_sk_cols", null), cols):
		e["_sk_cols"] = cols
		e["_skey"] = "%s|%s|%s|%s|%d|%d|%d|%s" % [cols[0].to_html(), cols[1].to_html(), cols[2].to_html(), cols[3].to_html(),
			int(cols[4]), int(keeper), int(ref_kit), (e["skin"] as Color).to_html()]
		var pid: int = int(e["p"]["id"]) if e.has("p") else -1
		e["_hkey"] = "%d|%s|%s|%s|%d|%d|%d" % [pid, (e["skin"] as Color).to_html(), (e["hair"] as Color).to_html(),
			cols[1].to_html(), int(lk[0]), int(lk[1]), int(lk[4])]
	var pb8: int = posmod(int(round(ph_raw / TAU * 8.0)), 8) if gait > 0 else 0
	var st: int = 0 if gait == 0 else 1 + (gait - 1) * 8 + pb8
	var bc: Array = bank.body_cell(e["_skey"], view, st)
	var hcell: Array = bank.head_cell(e["_hkey"], view)
	if bc.is_empty() or hcell.is_empty():
		bank.request(self, e, kit, keeper, ref_kit)
		return false
	if texture_filter != CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS:
		texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	# sombras (já no lote) saem antes do boneco
	_flush()
	var k: float = ku / SpriteBank.BAKE_KU
	var amp: float = [0.0, 0.55, 0.8, 1.0][gait]
	var run_k: float = [0.0, 0.0, 0.5, 1.0][gait]
	var ph: float = TAU * pb8 / 8.0
	var bob: float = absf(sin(ph * 2.0)) * 2.6 * amp * (0.4 + 0.6 * run_k)
	var side_lean: float = (clampf(SpriteBank.gait_speed(gait, _b_walk) / 12.0, 0.0, 1.0) * 0.12) if view == 2 else 0.0
	var rot: float = clampf(acc.x * 0.01, -0.14, 0.14)
	var mir: float = -1.0 if (view == 2 and flip < 0.0) else 1.0
	var bsrc: Rect2 = bc[1]
	var hsrc: Rect2 = hcell[1]
	draw_set_transform(p, rot, Vector2(k * mir, k))
	draw_texture_rect_region(bc[0], Rect2(-SpriteBank.BODY_ANCHOR, bsrc.size), bsrc)
	var hc := Vector2(1.5 if view == 2 else 0.0, -84.0 - bob).rotated(side_lean) * SpriteBank.BAKE_KU
	draw_texture_rect_region(hcell[0], Rect2(hc - SpriteBank.HEAD_ANCHOR, hsrc.size), hsrc)
	draw_set_transform_matrix(Transform2D.IDENTITY)
	if view == 1:
		_num_q(p + Vector2(0.0, (-55.0 - bob) * ku), lk[3], cols[7], ku)
	return true


## Assa as células pedidas pelo SpriteBank no canvas dele (chamado fora do _draw).
func bake_emit(rid: RID, cells: Array, bake_ku: float) -> void:
	var bp0 := _bp
	var bc0 := _bc
	var lp0 := _lp
	var s0 := s
	var bo := _batch_open
	_bp = PackedVector2Array()
	_bc = PackedColorArray()
	_lp = PackedVector2Array()
	_batch_open = true
	_ci_override = rid
	s = bake_ku * 100.0 / (BODY_H * LIFT * body_scale)
	for c in cells:
		_bake_part = int(c[0])
		_bake_force = Vector2i(int(c[1]), int(c[2]))
		_draw_player(c[3], c[4], bool(c[5]), bool(c[6]))
	_flush()
	_bake_part = 0
	_ci_override = RID()
	s = s0
	_batch_open = bo
	_bp = bp0
	_bc = bc0
	_lp = lp0
	_nq_pos.clear()
	_nq_txt.clear()
	_nq_col.clear()
	_nq_px.clear()


## Braço: contorno, pele e manga curta na cor da camisa; luva no goleiro.
func _arm3(shp: Vector2, hand: Vector2, shirt: Color, skin: Color, keeper: bool) -> void:
	var elbow := shp.lerp(hand, 0.5)
	_q_limb(shp, hand, 7.6, OUTLINE)
	_q_seg(shp, hand, 5.0, skin)
	_q_seg(shp, shp.lerp(elbow, 0.8), 6.6, shirt)
	if keeper:
		_q_circle(hand, 4.0, OUTLINE)
		_q_circle(hand, 3.0, Color("2b2b2b"))
	else:
		_q_circle(hand, 2.8, skin)


## Cabelo atrás da cabeça (volume do black power e dos cachos longos).
func _hair_back3(c: Vector2, r: float, hair: Color, style: int, view: int) -> void:
	if style == 2:
		_q_circle(c + Vector2(0, -2.0), r + 4.6, OUTLINE)
		_q_circle(c + Vector2(0, -2.0), r + 3.4, hair)
	elif style == 6:
		for k in 3:
			for sx in [-1.0, 1.0]:
				var q := c + Vector2(sx * (r - 0.5), -2.0 + k * 5.5 * (1.2 if view != 0 else 1.0))
				_q_circle(q, 4.4, OUTLINE)
				_q_circle(q, 3.4, hair)


## Cabelo por cima da cabeça, conforme o estilo e o lado que aparece.
func _hair_top3(c: Vector2, r: float, hair: Color, style: int, view: int, flip: float) -> void:
	if style == 3:
		_q_circle(c + Vector2(-r * 0.4, -r * 0.45), 2.0, Color(1, 1, 1, 0.3))   # brilho da careca
		return
	var col := hair if style != 4 else hair.lerp(HAIR_GREY, 0.35)
	if view == 1:
		# de costas o cabelo cobre quase toda a cabeça
		_q_rr(Rect2(c.x - r, c.y - r, r * 2.0, r * (1.45 if style != 4 else 1.0)), r * 0.8, col)
		return
	var cap_h := r * (0.75 if style != 4 else 0.45)
	_q_rr(Rect2(c.x - r - 0.4, c.y - r - 0.6, r * 2.0 + 0.8, cap_h + 0.6), r * 0.7, col)
	if view == 2:
		var bx: float = c.x - r if flip > 0.0 else c.x + r * 0.15
		_q_rr(Rect2(bx, c.y - r * 0.5, r * 0.85, r * 1.1), r * 0.4, col)   # nuca
	match style:
		0:
			for k in 3:
				var x := c.x - r * 0.6 + k * r * 0.6
				_q_tri(Vector2(x - 2.6, c.y - r + 1.5), Vector2(x + 2.6, c.y - r + 1.5), Vector2(x + 0.8 * (flip if view == 2 else 1.0), c.y - r - 3.0), col)
		1:
			_q_rr(Rect2(c.x - 2.2, c.y - r - 3.5, 4.4, r * 0.9), 2.0, col.darkened(0.15))
		5:
			_q_tri(Vector2(c.x - r * 0.8, c.y - r * 0.35), Vector2(c.x + r * 0.5, c.y - r * 0.35), Vector2(c.x - r * 0.35, c.y + 1.0), col)


## Números das costas: guardados durante o lote e escritos todos de uma vez depois dele
## (texto não entra no lote de triângulos; antes cada jogador de costas quebrava o lote).
var _nq_pos := PackedVector2Array()
var _nq_txt := PackedStringArray()
var _nq_col := PackedColorArray()
var _nq_px := PackedFloat32Array()


func _num_q(at: Vector2, txt: String, col: Color, ku: float) -> void:
	var px: float = 11.5 * ku
	if px < 6.0:
		return   # pequeno demais para ler
	_nq_pos.append(at)
	_nq_txt.append(txt)
	_nq_col.append(col)
	_nq_px.append(px)


func _flush_numbers() -> void:
	if _nq_pos.is_empty():
		return
	var f := UI.bold()
	for i in _nq_pos.size():
		var fs := int(_nq_px[i])
		draw_string(f, _nq_pos[i] + Vector2(-fs, fs * 0.36), _nq_txt[i], HORIZONTAL_ALIGNMENT_CENTER, fs * 2.0, fs, _nq_col[i])
	_nq_pos.clear()
	_nq_txt.clear()
	_nq_col.clear()
	_nq_px.clear()


# ------------------------------------------------------------ ordem de profundidade
func _ro_reset() -> void:
	_ro_ents.clear()
	_ro_kind.clear()


func _ro_add(e: Variant, kind: int) -> void:
	_ro_ents.append(e)
	_ro_kind.append(kind)


func _ro_done() -> void:
	var n := _ro_ents.size()
	_ro_key.resize(n)
	_ro_ord.resize(n)
	for i in n:
		_ro_ord[i] = i


## Quem entra no desenho do lance. Só é refeito quando o elenco muda (expulsão).
func _sync_roster() -> void:
	var sig: int = att.size() * 1000 + dfn.size() + (0 if referee.is_empty() else 500)
	if sig == _ro_sig:
		return
	_ro_sig = sig
	_ro_reset()
	for e in att:
		_ro_add(e, 0)
	for e in dfn:
		_ro_add(e, 1)
	_ro_add(gk, 2)
	if not referee.is_empty():
		_ro_add(referee, 3)
	_ro_add(null, 4)
	_ro_done()


## Desenha todo mundo e a bola em ordem de profundidade: quem está mais longe da câmera
## (mais em cima na tela) primeiro. A ordem do quadro anterior é reaproveitada e só
## ajustada (ordenação por inserção, sem criar arrays nem funções novas).
static var people_us: float = 0.0   ## medição: tempo acumulado em _draw_people (µs)
static var people_n: int = 0


func _draw_people(only_att: bool = false) -> void:
	var _t0 := Time.get_ticks_usec()
	_draw_people_impl(only_att)
	people_us += Time.get_ticks_usec() - _t0
	people_n += 1


func _draw_people_impl(only_att: bool = false) -> void:
	_sync_roster()
	var n := _ro_ents.size()
	for i in n:
		if _ro_kind[i] == 4:
			_ro_key[i] = bp.pos.y * y_sign + 0.05    # a bola fica na frente de quem está no mesmo ponto
		else:
			_ro_key[i] = _ro_ents[i]["pos"].y * y_sign
	for i in range(1, n):
		var v := _ro_ord[i]
		var kv := _ro_key[v]
		var j := i - 1
		while j >= 0 and _ro_key[_ro_ord[j]] > kv:
			_ro_ord[j + 1] = _ro_ord[j]
			j -= 1
		_ro_ord[j + 1] = v
	_batch_open = true
	for i in n:
		var k := _ro_ord[i]
		var kind := _ro_kind[k]
		if _far_front_pending and _ro_key[k] >= _far_line_key:
			_flush()
			_flush_numbers()
			_draw_far_front()   # quem está na frente da linha do gol passa por cima das traves
		if only_att and kind != 0 and kind != 4:
			continue
		match kind:
			4:
				_draw_ball()
			3:
				_draw_player(_ro_ents[k], REF_KIT, false, true)
			_:
				var e: Dictionary = _ro_ents[k]
				# fora da tela não desenha (os pés no chão, o corpo sobe ~1,2 altura)
				var sp: Vector2 = _w2s(e["pos"])
				if sp.x < -70.0 or sp.x > size.x + 70.0 or sp.y < -10.0 or sp.y > size.y + 170.0:
					continue
				_draw_player(e, kits[mini(kind, 1)], kind == 2 or e.get("keeper", false))
	_batch_open = false
	_flush()
	_flush_numbers()
	_draw_far_front()


func _line(a: Vector2, b: Vector2) -> void:
	draw_line(_w2s(a), _w2s(b), LINE_COL, maxf(0.12 * s, 2.0))


static var _lance_lines := PackedVector2Array(LANCE_LINES)


func _draw_field() -> void:
	_pitch_bands()
	_draw_adboards(0.0, 1.0, 4.6 if seamless else AD_GAP)
	# todas as linhas retas numa chamada só
	_lines_buf = _w2s_xf() * _lance_lines
	draw_multiline(_lines_buf, LINE_COL, maxf(0.12 * s, 2.0))
	draw_arc(_w2s(Vector2(0, 52.5)), 9.15 * s, 0, TAU, 64, Color(1, 1, 1, 0.92), 2.0)
	draw_circle(_w2s(Vector2(0, 52.5)), 4.0, Color(1, 1, 1, 0.85))
	draw_circle(_w2s(Vector2(0, 11)), 3.5, Color(1, 1, 1, 0.85))
	# meia-lua da grande área, do lado do campo (com o gol em cima, ela fica embaixo da área)
	if y_sign > 0.0:
		draw_arc(_w2s(Vector2(0, 11)), 9.15 * s, 0.645, PI - 0.645, 32, Color(1, 1, 1, 0.92), 2.0)
	else:
		draw_arc(_w2s(Vector2(0, 11)), 9.15 * s, -PI + 0.645, -0.645, 32, Color(1, 1, 1, 0.92), 2.0)


## ---------------------------------------------------------------- gol (traves e rede)
## Só desenho e a rede segurando a bola depois da linha: a física do gol
## (BallPhysics.GOAL_HALF / CROSSBAR, trave, travessão, gol ou não) não muda aqui.
## Pontos do gol em metros: x = lado (0 = meio do gol), d = fundo da rede atrás da linha,
## z = altura. _gp() leva para a tela relativo à base da trave esquerda; _g_ds diz para que
## lado da tela a rede vai (-1 = para cima, gol do fundo; 1 = para baixo, gol perto da câmera)
## e _g_pk dá uma perspectiva leve no fundo (encolhe longe da câmera, abre perto dela),
## para as redes laterais aparecerem.
## A rede é um pano de verdade (NetCloth: nós presos na armação, Verlet a 60 Hz, gravidade,
## amortecimento); ela só é simulada acordada (depois de um toque da bola) e dorme parada.
## O desenho fica em cache por escala: [chave, chão, panos, armação do fundo, traves,
## malha do fundo, das laterais, do teto]; a malha só é refeita enquanto a rede mexe.
const NET_DEPTH := 2.0          ## fundo da rede atrás da linha (m)
const NET_BACK_H := 0.8         ## altura do fundo da rede (fração do travessão)
const NET_PERSP := 0.06         ## quanto o fundo encolhe/abre por metro de fundo
const NET_MESH := 0.3           ## lado do losango da malha desenhada (m)
const POST_W := 0.26            ## espessura desenhada das traves (m; exagerada para ler no celular)
const POST_LIGHT := Color("ffffff")
const POST_BODY := Color("eef1f5")
const POST_MID := Color("cfd6df")
const POST_DARK := Color("9ea8b5")
const BAR_COL := Color("e3e7ec")
const BAR_DARK := Color("aab3bf")
const BAR_EDGE := Color("2a2c33")
const NET_BACK_COL := Color(0.86, 0.89, 0.93, 0.30)   ## fundo: mais escuro (mais longe)
const NET_SIDE_COL := Color(1, 1, 1, 0.36)
const NET_BALL_R := 0.11

var _g_ds: float = -1.0
var _g_pk: float = 0.0
var _gb_p := PackedVector2Array()   ## triângulos em montagem (cache do gol)
var _gb_c := PackedColorArray()
var _net_bufs: Array = [PackedVector2Array(), PackedVector2Array(), PackedVector2Array()]  ## fundo, laterais, teto
var _net_live: NetCloth = null      ## rede do gol atacado no lance (acorda quando a bola chega)
var _net_live_ver: int = -1
var _net_cur: NetCloth = null       ## pano usado por _net_w na montagem da malha
var _far_front_pending: bool = false   ## traves/teto do gol de cima ainda por desenhar (depois de quem está dentro do gol)
var _far_line_key: float = 0.0         ## chave de profundidade da linha do gol de cima (a mesma de _draw_people)
var _far_gl: Vector2 = Vector2.ZERO
var _far_live: bool = false
var _ball_netted: bool = false         ## a bola do gol já passou da linha (fica dentro, segura pela rede)
static var _net_rest: NetCloth = null
static var _no_idx := PackedInt32Array()


## Pano da rede: 4 painéis (0 fundo, 1 teto, 2 lateral esquerda, 3 lateral direita), cada um
## uma grade nu x nv de nós em metros (x, d, z). As bordas ficam presas na armação; os fios só
## resistem a esticar (rede de verdade não empurra quando folga), então ela cede com a gravidade.
class NetCloth:
	const DAMP := 0.986
	const ITERS := 5
	const SLACK := 1.05
	var nu := PackedInt32Array([13, 13, 5, 5])
	var nv := PackedInt32Array([7, 5, 7, 7])
	var base := PackedInt32Array()
	var p := PackedVector3Array()
	var q := PackedVector3Array()
	var free := PackedByteArray()
	var sa := PackedInt32Array()
	var sb := PackedInt32Array()
	var sl := PackedFloat32Array()
	var awake: bool = false
	var quiet: int = 0
	var ver: int = 0

	func _init() -> void:
		var H := BallPhysics.GOAL_HALF
		var D := 2.0
		var h := BallPhysics.CROSSBAR
		var hb := h * 0.8
		var corners := [
			[Vector3(-H, D, 0), Vector3(H, D, 0), Vector3(H, D, hb), Vector3(-H, D, hb)],
			[Vector3(-H, 0, h), Vector3(H, 0, h), Vector3(H, D, hb), Vector3(-H, D, hb)],
			[Vector3(-H, 0, 0), Vector3(-H, D, 0), Vector3(-H, D, hb), Vector3(-H, 0, h)],
			[Vector3(H, 0, 0), Vector3(H, D, 0), Vector3(H, D, hb), Vector3(H, 0, h)]]
		# barriga de descanso para fora (fundo para trás, laterais para os lados, teto para baixo)
		var bulge := [Vector3(0, 0.18, 0), Vector3(0, 0, -0.1), Vector3(-0.08, 0, 0), Vector3(0.08, 0, 0)]
		for k in 4:
			base.append(p.size())
			var c: Array = corners[k]
			for j in nv[k]:
				for i in nu[k]:
					var u := float(i) / (nu[k] - 1)
					var v := float(j) / (nv[k] - 1)
					var w: Vector3 = (c[0].lerp(c[1], u)).lerp(c[3].lerp(c[2], u), v)
					var edge: bool = i == 0 or j == 0 or i == nu[k] - 1 or j == nv[k] - 1
					if not edge:
						w += bulge[k] * sin(PI * u) * sin(PI * v)
					p.append(w)
					free.append(0 if edge else 1)
			for j in nv[k]:
				for i in nu[k]:
					var a: int = base[k] + j * nu[k] + i
					if i + 1 < nu[k]:
						_spring(a, a + 1)
					if j + 1 < nv[k]:
						_spring(a, a + nu[k])
		q = p.duplicate()
		awake = true
		for n in 90:
			step(1.0 / 60.0)
		awake = false

	func _spring(a: int, b: int) -> void:
		sa.append(a)
		sb.append(b)
		sl.append(p[a].distance_to(p[b]) * SLACK)

	func copy_from(o: NetCloth) -> void:
		p = o.p.duplicate()
		q = o.p.duplicate()
		awake = false

	## Um passo de 60 Hz (Verlet + fios que só esticam). Dorme quando tudo para.
	func step(dt: float) -> void:
		if not awake:
			return
		var g := Vector3(0, 0, -9.8 * dt * dt)
		var mv := 0.0
		for i in p.size():
			if free[i] == 0:
				continue
			var cur := p[i]
			var vel := (cur - q[i]) * DAMP
			q[i] = cur
			p[i] = cur + vel + g
			mv = maxf(mv, vel.length_squared())
		for it in ITERS:
			for k in sa.size():
				var a := sa[k]
				var b := sb[k]
				var dv := p[b] - p[a]
				var ln := dv.length()
				if ln <= sl[k] or ln < 0.000001:
					continue
				var corr := dv * ((ln - sl[k]) / ln)
				var fa := free[a]
				var fb := free[b]
				if fa == 1 and fb == 1:
					p[a] += corr * 0.5
					p[b] -= corr * 0.5
				elif fa == 1:
					p[a] += corr
				elif fb == 1:
					p[b] -= corr
		# a rede não entra no chão
		for i in p.size():
			if free[i] == 1 and p[i].z < 0.02:
				p[i] = Vector3(p[i].x, p[i].y, 0.02)
		ver += 1
		quiet = quiet + 1 if mv < 0.0000004 else 0
		if quiet > 25:
			awake = false

	## Ponto do painel k em (u, v) 0..1 (interpolado entre os nós).
	func at(k: int, u: float, v: float) -> Vector3:
		var fu := clampf(u, 0.0, 1.0) * (nu[k] - 1)
		var fv := clampf(v, 0.0, 1.0) * (nv[k] - 1)
		var i := mini(int(fu), nu[k] - 2)
		var j := mini(int(fv), nv[k] - 2)
		var tu := fu - i
		var tv := fv - j
		var a: int = base[k] + j * nu[k] + i
		return (p[a].lerp(p[a + 1], tu)).lerp(p[a + nu[k]].lerp(p[a + nu[k] + 1], tu), tv)

	## Bola (centro c, raio r, velocidade vel em metros x, d, z) contra os painéis.
	## Empurra os nós perto dela (a rede estufa) e devolve a velocidade da bola freada.
	## inside = a bola entrou no gol (bate por dentro); senão só as laterais, por fora.
	func push_ball(c: Vector3, r: float, vel: Vector3, inside: bool, dt: float) -> Vector3:
		var H := BallPhysics.GOAL_HALF
		var axis := [1, 2, 0, 0]
		var sgn := [1.0, 1.0, -1.0, 1.0]
		for k in 4:
			if not inside and k < 2:
				continue
			var u: float
			var v: float
			if k == 0:
				u = (c.x + H) / (2.0 * H)
				v = c.z / (BallPhysics.CROSSBAR * 0.8)
			elif k == 1:
				u = (c.x + H) / (2.0 * H)
				v = c.y / 2.0
			else:
				u = c.y / 2.0
				v = c.z / lerpf(BallPhysics.CROSSBAR, BallPhysics.CROSSBAR * 0.8, clampf(u, 0.0, 1.0))
			if u < 0.0 or u > 1.0 or v < 0.0 or v > 1.0:
				continue
			var ax: int = axis[k]
			var sg: float = sgn[k] if inside else -sgn[k]
			var surf: float = at(k, u, v)[ax] * sg
			var pen: float = (c[ax] * sg + r) - surf
			if pen <= 0.0 or pen > 1.5:
				continue
			# a rede leva o empurrão (os nós perto da bola vão junto com ela: a rede estufa);
			# os fios esticados devolvem: a bola freia e volta um pouco
			var fu := u * (nu[k] - 1)
			var fv := v * (nv[k] - 1)
			var ci := clampi(int(round(fu)), 1, nu[k] - 2)
			var cj := clampi(int(round(fv)), 1, nv[k] - 2)
			for dj in range(-2, 3):
				for di in range(-2, 3):
					var jj: int = cj + dj
					var ii: int = ci + di
					if jj < 1 or ii < 1 or jj > nv[k] - 2 or ii > nu[k] - 2:
						continue
					var a: int = base[k] + jj * nu[k] + ii
					var dd := Vector2(ii - fu, jj - fv).length_squared()
					var wgt := exp(-dd * 0.6)
					var t := p[a]
					t[ax] += sg * pen * wgt
					p[a] = t
			# a rede absorve: a bola perde quase toda a velocidade contra o pano e cai lá dentro
			var vn: float = vel[ax] * sg
			vel[ax] = sg * (vn * 0.35 if vn > 0.0 else vn) - sg * pen * 2.5
			vel *= 0.94
			awake = true
			quiet = 0
		return vel


func _gp(x: float, d: float, z: float) -> Vector2:
	return Vector2((GOAL_HALF + x * (1.0 + _g_pk * d)) * s, _g_ds * d * s - z * LIFT * s)


static func _net_rest_cloth() -> NetCloth:
	if _net_rest == null:
		_net_rest = NetCloth.new()
	return _net_rest


## Malha em losango dos quatro painéis (pares de pontos para draw_multiline) em _net_bufs,
## tirada do pano c: as diagonais passam entre os nós, mais finas que a grade da física.
func _net_mesh_build(c: NetCloth) -> void:
	for i in 3:
		_net_bufs[i] = PackedVector2Array()
	var h := BallPhysics.CROSSBAR
	var hb := h * NET_BACK_H
	var dims := [Vector2(GOAL_HALF * 2.0, hb), Vector2(GOAL_HALF * 2.0, NET_DEPTH),
		Vector2(NET_DEPTH, (h + hb) * 0.5), Vector2(NET_DEPTH, (h + hb) * 0.5)]
	var which := [0, 2, 1, 1]
	for p in 4:
		var A: float = dims[p].x
		var B: float = dims[p].y
		var buf: PackedVector2Array = _net_bufs[which[p]]
		for fam in 2:
			# fam 0: a + b = k ; fam 1: a - b = k (as duas diagonais do losango)
			var k: float = NET_MESH * 0.5 - (B if fam == 1 else 0.0)
			var k_end: float = A + (B if fam == 0 else 0.0)
			while k < k_end:
				var a0: float = maxf(0.0, k - B) if fam == 0 else maxf(0.0, k)
				var a1: float = minf(A, k) if fam == 0 else minf(A, k + B)
				var n := maxi(1, ceili((a1 - a0) * 1.42 / 0.6))
				var prev := Vector2.ZERO
				for i in n + 1:
					var a := lerpf(a0, a1, float(i) / n)
					var b: float = (k - a) if fam == 0 else (a - k)
					var w := c.at(p, a / A, clampf(b / B, 0.0, 1.0))
					var pt := _gp(w.x, w.y, w.z)
					if i > 0:
						buf.append(prev)
						buf.append(pt)
					prev = pt
				k += NET_MESH
		_net_bufs[which[p]] = buf


func _gb_take() -> Array:
	var out := [_gb_p.duplicate(), _gb_c.duplicate()]
	_gb_p.clear()
	_gb_c.clear()
	return out


func _gb_tris(pts: PackedVector2Array, col: Color) -> void:
	_gb_p.append_array(pts)
	for i in pts.size():
		_gb_c.append(col)


func _gb_quad(a: Vector2, b: Vector2, c: Vector2, d: Vector2, col: Color) -> void:
	_gb_tris(PackedVector2Array([a, b, c, a, c, d]), col)


func _gb_rect(r: Rect2, col: Color) -> void:
	_gb_quad(r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y), col)


func _gb_ellipse(c: Vector2, rx: float, ry: float, col: Color) -> void:
	var n := clampi(int(maxf(rx, ry) * 1.6), 10, 28)
	for i in n:
		var a0 := TAU * i / n
		var a1 := TAU * (i + 1) / n
		_gb_tris(PackedVector2Array([c, c + Vector2(cos(a0) * rx, sin(a0) * ry), c + Vector2(cos(a1) * rx, sin(a1) * ry)]), col)


func _gb_seg(a: Vector2, b: Vector2, w: float, col: Color) -> void:
	var n := (b - a).orthogonal().normalized() * (w * 0.5)
	_gb_quad(a + n, b + n, b - n, a - n, col)


## Faixa grossa ao longo de uma linha quebrada, num polígono só (sem sobreposição: serve
## para sombras translúcidas). Pontas e quinas arredondadas.
func _gb_band(line: PackedVector2Array, r: float, col: Color) -> void:
	for poly in Geometry2D.offset_polyline(line, r, Geometry2D.JOIN_ROUND, Geometry2D.END_ROUND):
		var idx := Geometry2D.triangulate_polygon(poly)
		for i in idx:
			_gb_p.append(poly[i])
			_gb_c.append(col)


## Tubo da armação do fundo: contorno escuro, corpo claro e o lado de baixo/direito na sombra.
func _gb_tube(a: Vector2, e: Vector2, w: float, edge: float) -> void:
	_gb_seg(a, e, w + edge * 2.0, BAR_EDGE)
	_gb_ellipse(a, w * 0.5 + edge, w * 0.5 + edge, BAR_EDGE)
	_gb_ellipse(e, w * 0.5 + edge, w * 0.5 + edge, BAR_EDGE)


func _gb_tube_fill(a: Vector2, e: Vector2, w: float) -> void:
	_gb_seg(a, e, w, BAR_COL)
	var n := (e - a).orthogonal().normalized()
	if n.y < 0.0 or (absf(n.y) < 0.01 and n.x < 0.0):
		n = -n   # sombra do lado de baixo / direito
	_gb_seg(a + n * w * 0.28, e + n * w * 0.28, w * 0.44, BAR_DARK)
	_gb_ellipse(a, w * 0.5, w * 0.5, BAR_COL)
	_gb_ellipse(e, w * 0.5, w * 0.5, BAR_COL)


## Monta o gol inteiro (relativo à base da trave esquerda) para a escala atual.
func _goal_build(ds: float) -> Array:
	_g_ds = ds
	_g_pk = NET_PERSP * ds
	var L := LIFT * s
	var h := BallPhysics.CROSSBAR
	var hb := h * NET_BACK_H
	var H := GOAL_HALF
	var D := NET_DEPTH
	var W := H * 2.0 * s
	var hp := h * L
	var pw := maxf(POST_W * s, 7.0)
	var r := pw * 0.5
	var ow := clampf(0.07 * s, 1.5, 3.0)
	var ro := r + ow
	_gb_p.clear()
	_gb_c.clear()
	# 0) chão: sombra do piso da rede e sombra macia das traves na grama (luz do alto à esquerda)
	_gb_quad(_gp(-H, 0, 0), _gp(H, 0, 0), _gp(H, D, 0), _gp(-H, D, 0), Color(0, 0, 0, 0.12))
	var sv := Vector2(0.4, 0.14) * h * s
	var frame := PackedVector2Array([Vector2.ZERO, sv, Vector2(W, 0) + sv, Vector2(W, 0)])
	_gb_band(frame, pw * 1.2, Color(0, 0, 0, 0.06))
	_gb_band(frame, pw * 0.75, Color(0, 0, 0, 0.07))
	_gb_band(frame, pw * 0.4, Color(0, 0, 0, 0.09))
	for bx in [0.0, W]:
		_gb_ellipse(Vector2(bx + r * 0.4, r * 0.25), ro * 1.35, ro * 0.6, Color(0, 0, 0, 0.25))
	var ground := _gb_take()
	# 1) panos da rede (translúcidos: quem está dentro do gol continua aparecendo); o fundo mais escuro
	_gb_quad(_gp(-H, D, 0), _gp(H, D, 0), _gp(H, D, hb), _gp(-H, D, hb), Color(0.05, 0.08, 0.1, 0.10))
	for sx in [-H, H]:
		_gb_quad(_gp(sx, 0, 0), _gp(sx, 0, h), _gp(sx, D, hb), _gp(sx, D, 0), Color(1, 1, 1, 0.07))
	_gb_quad(_gp(-H, 0, h), _gp(H, 0, h), _gp(H, D, hb), _gp(-H, D, hb), Color(1, 1, 1, 0.07))
	var fills := _gb_take()
	# 2) armação do fundo: suportes inclinados do travessão até o fundo, colunas e barras do chão
	var bw := maxf(0.11 * s, 3.0)
	var be := maxf(0.04 * s, 1.0)
	var bars := [
		[Vector3(-H, D, 0), Vector3(H, D, 0)], [Vector3(-H, 0, 0), Vector3(-H, D, 0)], [Vector3(H, 0, 0), Vector3(H, D, 0)],
		[Vector3(-H, D, 0), Vector3(-H, D, hb)], [Vector3(H, D, 0), Vector3(H, D, hb)],
		[Vector3(-H, D, hb), Vector3(H, D, hb)],
		[Vector3(-H, 0, h), Vector3(-H, D, hb)], [Vector3(H, 0, h), Vector3(H, D, hb)]]
	var segs: Array = []
	for b in bars:
		segs.append([_gp(b[0].x, b[0].y, b[0].z), _gp(b[1].x, b[1].y, b[1].z)])
	for sg in segs:
		_gb_tube(sg[0], sg[1], bw, be)
	for sg in segs:
		_gb_tube_fill(sg[0], sg[1], bw)
	var bars_t := _gb_take()
	# 3) traves e travessão: contorno escuro, tubo branco com sombreado cilíndrico, quinas redondas
	for ps in 2:
		var rr: float = ro if ps == 0 else r
		var cc: Color = OUTLINE if ps == 0 else POST_BODY
		_gb_rect(Rect2(-rr, -hp, rr * 2.0, hp), cc)
		_gb_rect(Rect2(W - rr, -hp, rr * 2.0, hp), cc)
		_gb_rect(Rect2(0, -hp - rr, W, rr * 2.0), cc)
		_gb_ellipse(Vector2(0, -hp), rr, rr, cc)
		_gb_ellipse(Vector2(W, -hp), rr, rr, cc)
		_gb_ellipse(Vector2(0, 0), rr, rr * 0.5, cc)   # pé da trave (círculo deitado)
		_gb_ellipse(Vector2(W, 0), rr, rr * 0.5, cc)
	# faixas do cilindro: brilho à esquerda/em cima, meio-tom e sombra à direita/embaixo
	for bx in [0.0, W]:
		_gb_rect(Rect2(bx - r * 0.55, -hp, r * 0.4, hp), POST_LIGHT)
		_gb_rect(Rect2(bx + r * 0.2, -hp, r * 0.42, hp), POST_MID)
		_gb_rect(Rect2(bx + r * 0.62, -hp, r * 0.38, hp), POST_DARK)
	_gb_rect(Rect2(r * 0.62, -hp - r * 0.55, W - r * 1.24, r * 0.4), POST_LIGHT)
	_gb_rect(Rect2(r * 0.62, -hp + r * 0.2, W - r * 1.24, r * 0.42), POST_MID)
	_gb_rect(Rect2(r * 0.62, -hp + r * 0.62, W - r * 1.24, r * 0.38), POST_DARK)
	var posts := _gb_take()
	_net_mesh_build(_net_rest_cloth())
	return [Vector2(s, ds), ground, fills, bars_t, posts,
		_net_bufs[0].duplicate(), _net_bufs[1].duplicate(), _net_bufs[2].duplicate()]


func _gb_draw(tris: Array) -> void:
	var p: PackedVector2Array = tris[0]
	if not p.is_empty():
		RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), _no_idx, p, tris[1])


## Malha da rede: a do cache (pano em repouso) ou, se este gol tem rede viva que mexeu,
## refeita dos nós simulados (só quando o pano andou).
func _draw_goal_mesh(geo: Array, live: bool, roof_a: float, part: int = 3) -> void:
	var m0: PackedVector2Array = geo[5]
	var m1: PackedVector2Array = geo[6]
	var m2: PackedVector2Array = geo[7]
	if live and _net_live != null:
		# a malha é refeita a 30 Hz enquanto a rede mexe (metade dos passos): o olho não percebe
		if (_net_live.ver - _net_live_ver >= 2 or (not _net_live.awake and _net_live.ver != _net_live_ver)) \
				or _net_bufs[0].is_empty():
			_g_ds = geo[0].y
			_g_pk = NET_PERSP * _g_ds
			_net_mesh_build(_net_live)
			_net_live_ver = _net_live.ver
		m0 = _net_bufs[0]
		m1 = _net_bufs[1]
		m2 = _net_bufs[2]
	if part & 1:
		draw_multiline(m0, NET_BACK_COL, 1.0, true)
		draw_multiline(m1, NET_SIDE_COL, 1.0, true)
	if part & 2:
		draw_multiline(m2, Color(1, 1, 1, roof_a), 1.0, true)


## Um passo da rede viva do gol atacado (chamado no passo fixo do lance). Só custa algo acordada.
func _net_step(delta: float) -> void:
	if _net_live != null:
		_net_live.step(delta)


## Bola atrás da linha (ou raspando a rede lateral por fora): a rede viva estufa e segura a bola,
## que perde velocidade e cai no chão dentro do gol. Não decide nada do lance.
func _net_ball(delta: float) -> void:
	if bp.pos.y > 0.3 or bp.pos.y < -(NET_DEPTH + 1.2) or absf(bp.pos.x) > GOAL_HALF + 0.6:
		return
	if bp.z > BallPhysics.CROSSBAR + 0.4:
		return
	var inside: bool = bp.pos.y < 0.0 and absf(bp.pos.x) < GOAL_HALF and result.get("goal", false)
	if not inside and (absf(bp.pos.x) < GOAL_HALF or bp.pos.y > 0.0):
		return
	if _net_live == null:
		_net_live = NetCloth.new()
		_net_live.copy_from(_net_rest_cloth())
	var c := Vector3(bp.pos.x, -bp.pos.y, bp.z + NET_BALL_R)
	var v := Vector3(bp.vel.x, -bp.vel.y, bp.vz)
	var v2 := _net_live.push_ball(c, NET_BALL_R, v, inside, delta)
	if v2 != v:
		bp.vel = Vector2(v2.x, -v2.y)
		bp.vz = v2.z
		bp.curve = Vector2.ZERO
	# a bola não atravessa a rede: fica dentro da caixa estufada
	var dmax: float = NET_DEPTH + 0.8
	if inside and -bp.pos.y > dmax:
		bp.pos.y = -dmax
		bp.vel.y = maxf(bp.vel.y, 0.0)


func _goal_geo_far() -> Array:
	if _goal_far.is_empty() or _goal_far[0] != Vector2(s, -1.0):
		_goal_far = _goal_build(-1.0)
		_net_live_ver = -1
	return _goal_far


## Gol do fundo da tela (mais longe da câmera), em pé sobre a linha (gy) com a rede atrás
## (back = para que lado do mundo fica a rede). Desenhado antes dos jogadores: quem está
## no campo sempre fica na frente dele. No lance é o gol atacado, no alto da tela.
func _draw_goal_far(gy: float, back: float) -> void:
	var gl := _w2s(Vector2(-GOAL_HALF, gy))
	if gl.y < -2.0 or gl.y - 4.0 * s > size.y:
		return   # fora da tela (a base das traves acima do topo, ou o gol todo abaixo)
	var geo := _goal_geo_far()
	_far_live = gy == 0.0 and back < 0.0
	draw_set_transform(gl)
	_gb_draw(geo[1])
	_gb_draw(geo[2])
	_gb_draw(geo[3])
	_draw_goal_mesh(geo, _far_live, 0.16, 1)
	draw_set_transform(Vector2.ZERO)
	# teto da rede, traves e travessão ficam para depois de quem está dentro do gol
	# (goleiro adiantado, jogadores e bola na rede): _draw_people chama _draw_far_front
	_far_gl = gl
	_far_line_key = gy * y_sign
	_far_front_pending = true


## Frente do gol de cima: teto da rede, traves e travessão (por cima de quem está dentro do gol).
func _draw_far_front() -> void:
	if not _far_front_pending:
		return
	_far_front_pending = false
	var geo := _goal_geo_far()
	draw_set_transform(_far_gl)
	_draw_goal_mesh(geo, _far_live, 0.16, 2)
	_gb_draw(geo[4])
	draw_set_transform(Vector2.ZERO)


func _goal_geo_near() -> Array:
	if _goal_near.is_empty() or _goal_near[0] != Vector2(s, 1.0):
		_goal_near = _goal_build(1.0)
	return _goal_near


## Gol perto da câmera (no FieldView, o de baixo): a rede vem para o lado da câmera.
## back = sombras no chão (antes dos jogadores); front = rede, armação e traves por cima
## dos jogadores (quem entra no gol fica atrás da rede translúcida).
func _draw_goal(front: bool) -> void:
	var gl := _w2s(Vector2(-GOAL_HALF, 0))
	if gl.y + 3.0 * s < 0.0 or gl.y - 3.0 * s > size.y:
		return   # fora da tela
	var geo := _goal_geo_near()
	draw_set_transform(gl)
	if not front:
		_gb_draw(geo[1])
	else:
		_gb_draw(geo[2])
		_draw_goal_mesh(geo, false, 0.3)
		_gb_draw(geo[3])
		_gb_draw(geo[4])
	draw_set_transform(Vector2.ZERO)


func _draw_ball() -> void:
	var g := _w2s(bp.pos)
	var r: float = maxf(0.19 * s, 4.0)     # bola um pouco maior que a real para enxergar
	var b := g - Vector2(0, r + bp.z * s * LIFT)
	var sh: float = clampf(1.0 - bp.z * 0.12, 0.4, 1.0)
	_lk = 1.0
	_q_ellipse(g + Vector2(r * 0.3, 0), r * 1.05 * sh, r * 0.42 * sh, Color(0, 0, 0, 0.3 * sh))
	_q_circle(b, r, BALL_WHITE)
	var rot: float = bp.spin
	var pent := _pent_tris()
	_lp.append_array(Transform2D(rot, Vector2(r * 0.36, r * 0.36), 0.0, b) * pent)
	_fill(BALL_DARK, pent.size())
	for i in 5:
		var a3 := rot + TAU * (i + 0.5) / 5.0
		var c := b + Vector2(cos(a3), sin(a3)) * r * 0.84
		_lp.append_array(Transform2D(a3, Vector2(r * 0.27, r * 0.27), 0.0, c) * pent)
		_fill(BALL_DARK, pent.size())
		var a5 := rot + TAU * i / 5.0
		var dv := Vector2(cos(a5), sin(a5))
		_q_line(b + dv * r * 0.36, b + dv * r * 0.9, Color(0, 0, 0, 0.35), 1.0)
	_flush()
	draw_arc(b, r * 1.04, 0, TAU, 32, BALL_RIM, r * 0.2, true)
	draw_arc(b, r * 0.62, -2.4, -1.2, 8, Color(1, 1, 1, 0.55), r * 0.14, true)


func _draw() -> void:
	if sim == null or att.is_empty():
		return
	s = size.x / CAMERA_WIDTH_M * zoom
	var f := UI.bold()
	var ph_px: float = BODY_H * LIFT * s       # altura do boneco na tela
	_draw_field()
	if flip:
		_draw_goal(false)       # gol atacado embaixo (perto da câmera), como no campo ao vivo
	else:
		_draw_goal_far(0.0, -1.0)   # gol atacado em cima (a rede estufa no gol); os jogadores ficam na frente dele
	_draw_skids()
	var deciding: bool = _user_turn()
	if deciding:
		# anéis no chão, embaixo dos bonecos, em cor (a cena em volta fica em preto e branco)
		var c: Dictionary = att[carrier]
		var danger := false
		for d in dfn:
			if d["pos"].distance_to(c["pos"]) < 3.2 and d["stun"] <= 0.0:
				danger = true
		for i in att.size():
			var p := _w2s(att[i]["pos"])
			if i == carrier:
				_ellipse(p, ph_px * 0.42, ph_px * 0.19, Color(0.95, 0.32, 0.25, 0.75) if danger else Color(1.0, 0.7, 0.25, 0.7))
			else:
				_ellipse(p, ph_px * 0.5, ph_px * 0.22, Color(hud_acc, 0.45 * _desat))
	_draw_people()
	if flip:
		_draw_goal(true)
	_draw_spray()
	_draw_confetti()
	if deciding:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.12 * _desat))
		for i in att.size():
			if i == carrier:
				continue
			var p2 := _w2s(att[i]["pos"])
			draw_string(f, Vector2(p2.x - 40, p2.y - ph_px - 12), _look(att[i])[3], HORIZONTAL_ALIGNMENT_CENTER, 80, 18, Color.WHITE)
			draw_rect(Rect2(p2.x - 10, p2.y - ph_px - 8, 20, 3), Color("3ddc6a"))
		# boca do gol destacada (onde tocar para chutar)
		var g1 := _w2s(Vector2(-GOAL_HALF, 0))
		var g2 := _w2s(Vector2(GOAL_HALF, 0)) + Vector2(0, -BallPhysics.CROSSBAR * LIFT * s)
		if g1.y > -40.0 and g1.y < size.y + 40.0:
			var gm := Rect2(Vector2(g1.x, g2.y), Vector2(g2.x - g1.x, g1.y - g2.y))
			draw_rect(gm.grow(3.0), Color(hud_acc, 0.25), false, 6.0)
			draw_rect(gm, hud_acc, false, 3.0)
		# linha de impedimento (tracejada)
		if not shot_only:
			var oy := Referee.offside_line(_defenders_y(), bp.pos.y)
			var la := _w2s(Vector2(-34, oy))
			draw_set_transform(Vector2(0.0, la.y))
			draw_multiline(_dashes(), Color(1, 1, 1, 0.55), 2.0)
			draw_set_transform(Vector2.ZERO)
		if pressing and (drag_now - press).length() > 20.0:
			var b := _w2s(bp.pos)
			var tip := b + (drag_now - press).normalized() * 260.0
			draw_line(b, tip, Color(hud_acc, 0.3), 11.0)
			draw_line(b, tip, hud_acc, 5.0)

	_draw_scoreboard(f)
	var mid := size.x / 2.0
	if not user_ctrl and state != "end":
		# área de toque continua Rect2(size.x - 190, 80, 180, 56); o botão desenhado fica dentro dela
		draw_style_box(_hsb(&"button"), Rect2(size.x - 182, 86, 164, 46))
		draw_string(UI.display(), Vector2(size.x - 182, 116), "Pular  ›", HORIZONTAL_ALIGNMENT_CENTER, 164, 19, Color.WHITE)
	_draw_card(f, att[carrier])
	_draw_minimap(f)
	_draw_possession(f, 380.0, size.x - 400.0)
	if deciding:
		# no pênalti o gol fica perto do topo: a dica desce para não cobrir o travessão
		var hy: float = size.y - 178.0 if setpiece == "penalti" and not flip else 86.0
		draw_style_box(_hsb(&"hint"), Rect2(mid - 410, hy, 820, 44))
		var hint := "Toque = passe rasteiro  •  Segure = passe alto  •  Toque no gol ou deslize para cima = CHUTE"
		if header:
			hint = "CABECEIO! Toque no gol para mirar"
		elif setpiece == "penalti":
			hint = "PÊNALTI: toque no canto do gol (fundo da rede = alto) ou deslize"
		elif setpiece == "falta_direta":
			hint = "FALTA: deslize com força para passar a barreira, ou toque no gol"
		draw_string(f, Vector2(mid - 410, hy + 28.0), hint, HORIZONTAL_ALIGNMENT_CENTER, 820, 16, Color.WHITE)
	if banner != "" and cel_t <= 0.0:
		_draw_banner(banner, result.get("goal", false), 620.0)
	if card_flash != "":
		# cartão levantado, um pouco inclinado, à direita da faixa
		draw_set_transform(Vector2(mid + 257, size.y * 0.36 + 18), 0.14)
		draw_style_box(_hsb(&"card_y" if card_flash == "amarelo" else &"card_r"), Rect2(-27, -38, 54, 76))
		draw_set_transform(Vector2.ZERO)
	_draw_celebration(f)


## Traços da linha de impedimento (14 px a cada 26 px, na altura 0), refeitos só se a largura mudar.
func _dashes() -> PackedVector2Array:
	if _dash_w != size.x:
		_dash_w = size.x
		_dash_buf = PackedVector2Array()
		var xx := 0.0
		while xx < size.x:
			_dash_buf.append(Vector2(xx, 0.0))
			_dash_buf.append(Vector2(xx + 14, 0.0))
			xx += 26.0
	return _dash_buf


## Cartão de quem está com a bola (canto de baixo): vidro escuro com contorno neon, número em
## etiqueta verde inclinada, estrelas verdes e chips dos atributos.
func _draw_card(f: Font, cc: Dictionary) -> void:
	var r := Rect2(20, size.y - 114, 330, 94)
	draw_style_box(_hsb(&"glass_neon"), r)
	_slant_rect(Rect2(r.position.x + 14, r.position.y + 11, 42, 26), hud_acc)
	draw_string(UI.display(), Vector2(r.position.x + 13, r.position.y + 31), str(cc["num"]), HORIZONTAL_ALIGNMENT_CENTER, 42, 19, UI.DARKTXT)
	draw_string(f, Vector2(r.position.x + 66, r.position.y + 31), str(cc["p"]["name"]), HORIZONTAL_ALIGNMENT_LEFT, r.size.x - 150, 19, Color.WHITE)
	var stars: int = clampi(int((float(cc["p"]["ovr"]) - 55.0) / 7.0), 1, 5)
	for i in 5:
		_star(Vector2(r.end.x - 80 + i * 15, r.position.y + 24), 6.5, hud_acc if i < stars else Color(1, 1, 1, 0.16))
	var a: Dictionary = cc["a"]
	for i in 4:
		var ch := Rect2(r.position.x + 14 + i * 76, r.position.y + 50, 70, 30)
		draw_style_box(_hsb(&"chip"), ch)
		draw_string(f, Vector2(ch.position.x + 8, ch.position.y + 20), ATTR_NAMES[i], HORIZONTAL_ALIGNMENT_LEFT, 34, 11, UI.MUTED)
		var v: int = int(a[ATTR_KEYS[i]])
		draw_string(f, Vector2(ch.position.x + 30, ch.position.y + 21), str(v), HORIZONTAL_ALIGNMENT_RIGHT, 32, 16, UI.GREEN_TXT if v >= 80 else Color.WHITE)


## Barra de posse de bola: trilho escuro com as cores dos times e o ponto de virada em neon.
func _draw_possession(f: Font, x: float, w: float) -> void:
	var hcol := Color(str(Game.club(sim.h)["c1"]))
	var acol := Color(str(Game.club(sim.a)["c1"]))
	if _close(hcol, acol):
		acol = Color(str(Game.club(sim.a)["c2"]))
	hcol = _hud_team_col(hcol)
	acol = _hud_team_col(acol)
	var ph0: int = sim.possession(0)
	var ph2: float = clampf(ph0 / 100.0, 0.0, 1.0)
	var r := Rect2(x, size.y - 62, w, 42)
	draw_style_box(_hsb(&"glass"), r)
	draw_string(f, Vector2(x, r.position.y + 15), "POSSE DE BOLA", HORIZONTAL_ALIGNMENT_CENTER, w, 10, UI.MUTED)
	var D := UI.display()
	draw_string(D, Vector2(x + 12, r.position.y + 34), "%d%%" % ph0, HORIZONTAL_ALIGNMENT_LEFT, 60, 17, Color.WHITE)
	draw_string(D, Vector2(x + w - 72, r.position.y + 34), "%d%%" % sim.possession(1), HORIZONTAL_ALIGNMENT_RIGHT, 60, 17, Color.WHITE)
	var bar := Rect2(x + 66, r.position.y + 22, w - 132, 9)
	draw_style_box(_hsb(&"track"), bar)
	var split: float = bar.position.x + bar.size.x * ph2
	if ph2 > 0.0:
		_rbox(Rect2(bar.position + Vector2(1, 1), Vector2(maxf(split - bar.position.x - 3.0, 4.0), bar.size.y - 2)), hcol, 3)
	if ph2 < 1.0:
		_rbox(Rect2(Vector2(split + 2.0, bar.position.y + 1), Vector2(maxf(bar.end.x - split - 3.0, 4.0), bar.size.y - 2)), acol, 3)
	_slant_rect(Rect2(split - 4.0, bar.position.y - 5, 8, bar.size.y + 10), Color(hud_acc, 0.25), 0.3)
	_slant_rect(Rect2(split - 1.5, bar.position.y - 4, 3, bar.size.y + 8), hud_acc, 0.3)


func _star(c: Vector2, r: float, col: Color) -> void:
	var pts := PackedVector2Array()
	for i in 10:
		var ang := -PI / 2.0 + PI * i / 5.0
		var rr := r if i % 2 == 0 else r * 0.45
		pts.append(c + Vector2(cos(ang), sin(ang)) * rr)
	draw_colored_polygon(pts, col)


## Minimapa no canto: campo inteiro, área que a câmera mostra, jogadores e bola.
## Em cima, a energia de quem está com a bola.
func _draw_minimap(f: Font) -> void:
	var m := Rect2(30, 108, 74, 112)
	var en: float = float(att[carrier]["p"].get("energy", 100.0)) / 100.0
	_minimap_frame(f, m, en)
	draw_rect(Rect2(m.position.x + m.size.x * 0.22, m.end.y - m.size.y * 0.16, m.size.x * 0.56, m.size.y * 0.16), MINIMAP_LINE, false, 1.0)
	draw_rect(Rect2(m.position.x + m.size.x * 0.22, m.position.y, m.size.x * 0.56, m.size.y * 0.16), MINIMAP_LINE, false, 1.0)
	# visível: os dois cantos da tela levados ao minimapa (vale para qualquer orientação)
	var va := _to_map(m, _s2w(Vector2.ZERO), 105.0)
	var vb := _to_map(m, _s2w(size), 105.0)
	var v0 := Vector2(clampf(minf(va.x, vb.x), m.position.x, m.end.x), clampf(minf(va.y, vb.y), m.position.y, m.end.y))
	var v1 := Vector2(clampf(maxf(va.x, vb.x), m.position.x, m.end.x), clampf(maxf(va.y, vb.y), m.position.y, m.end.y))
	_minimap_view(m, Rect2(v0, v1 - v0))
	_lk = 1.0
	for e in att:
		_q_circle(_to_map(m, e["pos"], 105.0), 2.2, kits[0][0])
	for e in dfn:
		_q_circle(_to_map(m, e["pos"], 105.0), 2.2, kits[1][0])
	_q_circle(_to_map(m, gk["pos"], 105.0), 2.2, KEEPER_SHIRT)
	_q_circle(_to_map(m, bp.pos, 105.0), 1.8, Color.WHITE)
	_flush()


## Ponto do campo (metros) no minimapa m, na mesma orientação da tela:
## no lance, o gol atacado (y = 0) fica em cima; no FieldView, embaixo.
func _to_map(m: Rect2, w: Vector2, length: float) -> Vector2:
	var fy: float = w.y / length
	if y_sign < 0.0:
		fy = 1.0 - fy
	return Vector2(m.position.x + (w.x + 34.0) / 68.0 * m.size.x, m.position.y + fy * m.size.y)


## Placar no topo: faixa grafite com fio neon e brilho embaixo, cunhas nas cores dos times com o
## escudo, bloco do placar inclinado com contorno neon e o chip do minuto pendurado embaixo.
func _draw_scoreboard(f: Font) -> void:
	var hc: Dictionary = Game.club(sim.h)
	var ac: Dictionary = Game.club(sim.a)
	var mid := size.x / 2.0
	var H := 50.0
	draw_rect(Rect2(0, 0, size.x, H), hud_bar)
	if not hud_theme.is_empty():
		CompTheme.draw_pattern(self, Rect2(0, 0, size.x, H), hud_theme, 0.07)
	draw_rect(Rect2(0, H, size.x, 2), hud_acc)
	draw_rect(Rect2(0, H + 2, size.x, 3), Color(hud_acc, 0.2))
	draw_rect(Rect2(0, H + 5, size.x, 4), Color(hud_acc, 0.07))
	# cunhas nas cores dos times atrás dos escudos
	for it in [[hc, -24.0], [ac, size.x - 92.0]]:
		var x0: float = it[1]
		_slant_rect(Rect2(x0, 0, 116, H), Color(str(it[0]["c1"])), 0.4)
		var x2: float = x0 + 120.0 if x0 < mid else x0 - 12.0
		_slant_rect(Rect2(x2, 0, 7, H), Color(str(it[0]["c2"])), 0.4)
	draw_string(f, Vector2(110, 33), str(hc["name"]), HORIZONTAL_ALIGNMENT_RIGHT, mid - 210, 22, Color.WHITE)
	draw_string(f, Vector2(mid + 100, 33), str(ac["name"]), HORIZONTAL_ALIGNMENT_LEFT, mid - 210, 22, Color.WHITE)
	for it in [[hc, 34.0], [ac, size.x - 34.0]]:
		var cx: float = it[1]
		draw_circle(Vector2(cx, H / 2.0), 21.0, Color(0, 0, 0, 0.55))
		draw_circle(Vector2(cx, H / 2.0), 19.0, Color.WHITE)
		var ltex: Texture2D = Game.club_logo(int(it[0]["id"]))
		if ltex != null:
			draw_texture_rect(ltex, Rect2(cx - 14, H / 2.0 - 14, 28, 28), false)
		else:
			draw_circle(Vector2(cx, H / 2.0), 14.0, Color(str(it[0]["c1"])))
			draw_rect(Rect2(cx - 13, H / 2.0 - 4, 26, 8), Color(str(it[0]["c2"])))
	# bloco do placar
	draw_style_box(_hsb(&"score"), Rect2(mid - 84, -6, 168, 62))
	var D := UI.display()
	draw_string(D, Vector2(mid - 80, 43), str(sim.score[0]), HORIZONTAL_ALIGNMENT_CENTER, 68, 36, Color.WHITE)
	draw_string(D, Vector2(mid + 12, 43), str(sim.score[1]), HORIZONTAL_ALIGNMENT_CENTER, 68, 36, Color.WHITE)
	_slant_rect(Rect2(mid - 8, 26, 16, 5), hud_acc, 0.3)
	# chip do minuto (com a logo da competição ao lado, quando houver)
	draw_style_box(_hsb(&"chip_neon"), Rect2(mid - 62, 58, 124, 21))
	if hud_logo != null:
		var lsz := hud_logo.get_size()
		var lk: float = 26.0 / maxf(lsz.x, lsz.y)
		draw_circle(Vector2(mid - 84, 68), 16.0, Color(hud_score_bg, 0.95))
		draw_arc(Vector2(mid - 84, 68), 16.0, 0.0, TAU, 32, hud_acc, 1.5, true)
		draw_texture_rect(hud_logo, Rect2(Vector2(mid - 84, 68) - lsz * lk * 0.5, lsz * lk), false)
	draw_string(f, Vector2(mid - 58, 73), "1º TEMPO" if sim.minute <= 45 else "2º TEMPO", HORIZONTAL_ALIGNMENT_RIGHT, 62, 11, UI.MUTED)
	draw_string(D, Vector2(mid + 10, 74), "%d'" % sim.minute, HORIZONTAL_ALIGNMENT_LEFT, 50, 15, hud_txt)
	if stage_label != "":
		var sw: float = f.get_string_size(stage_label, HORIZONTAL_ALIGNMENT_LEFT, -1, 12).x + 26.0
		draw_style_box(_hsb(&"chip_neon"), Rect2(size.x - 20 - sw, 58, sw, 21))
		draw_string(f, Vector2(size.x - 20 - sw, 73), stage_label, HORIZONTAL_ALIGNMENT_CENTER, sw, 12, Color.WHITE)
