class_name LoadingScreen
extends Control
## Tela de carregamento animada (marca "A Nova Era").
## Fundo quase preto com faixas diagonais, banner do jogo pulsando, bola quicando e girando,
## barra de progresso verde neon com brilho e dicas que se alternam.
##
## Uso:
##   var ls := LoadingScreen.open(parent, "Preparando o estádio…")
##   ls.step(0.5, "Montando os elencos…")
##   await ls.frame()               # deixa a animação rodar entre passos pesados
##   ls.close()                     # some com fade (respeita o tempo mínimo na tela)
## Chamar open() de novo com uma tela já aberta reaproveita a mesma.

const MIN_SHOW := 1.2       ## segundos mínimos na tela na abertura do jogo
const FADE := 0.28
const TIMEOUT := 25.0       ## nunca prende o toque para sempre
const BG := Color("0b0d0c")
const BAND := Color(1, 1, 1, 0.022)
const NEON := Color("39e33f")
const TXT := Color("f4f7f5")
const MUTED := Color("a3ada7")

const TIPS := [
	"Toque num companheiro para passe rasteiro; segure para passe alto.",
	"Deslize o dedo rumo ao gol para chutar: o tamanho do gesto é a força.",
	"Chute forte demais sobe a bola por cima do travessão.",
	"A linha tracejada é a do impedimento: passe para quem está atrás dela.",
	"Contratos vencendo aparecem em vermelho. Renove antes que saiam de graça.",
	"Empreste os garotos que não jogam: com minutos, eles evoluem mais rápido.",
	"Jogador cansado corre menos e erra mais. Revezar o elenco faz diferença.",
	"Na coletiva, o tom da resposta mexe com diretoria, torcida e elenco.",
	"Provocar o rival anima a torcida, mas a imprensa não esquece.",
	"No intervalo a substituição não gasta parada: aproveite para mexer no time.",
	"Goleiro adiantado? Um chute no canto alto costuma resolver.",
	"Cruzamento na área vira cabeceio: segure o dedo no atacante.",
]

static var _current: LoadingScreen = null

var msg: String = ""
var progress: float = 0.0       ## alvo do progresso (0..1)
var shown: float = 0.0          ## progresso desenhado (persegue o alvo suavemente)
var min_show: float = MIN_SHOW
var t: float = 0.0
var alpha: float = 0.0
var closing: bool = false
var tip_i: int = 0
var tip_t: float = 0.0
var _logo: Texture2D = null
var _bands := PackedVector2Array()
var _bands_size := Vector2.ZERO
var _band_cols := PackedColorArray()
var _steps: Array = []          ## [progresso, mensagem]: a mensagem acompanha a barra desenhada
var _pts := PackedVector2Array([Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO])


## Abre (ou reaproveita) a tela de carregamento por cima de parent.
static func open(parent: Node, text: String = "Carregando…", min_time: float = MIN_SHOW, instant: bool = false) -> LoadingScreen:
	if _current != null and is_instance_valid(_current) and not _current.closing:
		_current._steps.append([_current.progress, text])
		_current.min_show = maxf(_current.t + 0.2, min_time if _current.t < min_time else 0.0)
		return _current
	var ls := LoadingScreen.new()
	ls.msg = text
	ls._steps = [[0.0, text]]
	ls.min_show = min_time
	if instant:
		ls.alpha = 1.0   # abertura do jogo: entra já coberta (continua o splash do Godot)
	ls.mouse_filter = Control.MOUSE_FILTER_STOP
	parent.add_child(ls)
	ls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_current = ls
	return ls


static func is_open() -> bool:
	return _current != null and is_instance_valid(_current) and not _current.closing


func _ready() -> void:
	tip_i = randi() % TIPS.size()
	var path := "res://assets/brand/banner_1280.webp"
	if not ResourceLoader.exists(path):
		path = "res://assets/brand/icon_512.png"
	if ResourceLoader.exists(path):
		_logo = load(path) as Texture2D


## Avança o progresso (0..1) e troca a mensagem.
func step(p: float, text: String = "") -> void:
	progress = clampf(maxf(progress, p), 0.0, 1.0)
	if text != "":
		_steps.append([progress, text])


## Espera um quadro (a animação continua rodando entre os passos pesados).
func frame() -> void:
	if is_inside_tree():
		await get_tree().process_frame


## Fecha com fade depois do tempo mínimo na tela.
func close() -> void:
	progress = 1.0
	closing = true


func _process(delta: float) -> void:
	delta = minf(delta, 0.1)
	t += delta
	shown = move_toward(shown, progress, delta * 1.6)
	for st in _steps:
		if float(st[0]) <= shown + 0.001:
			msg = str(st[1])
	tip_t += delta
	if tip_t > 2.6:
		tip_t = 0.0
		tip_i = (tip_i + 1) % TIPS.size()
	if t > TIMEOUT:
		closing = true
	var leaving: bool = closing and t >= min_show and shown >= progress - 0.01
	if leaving:
		alpha = move_toward(alpha, 0.0, delta / FADE)
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		if alpha <= 0.0:
			if _current == self:
				_current = null
			queue_free()
			return
	else:
		alpha = move_toward(alpha, 1.0, delta / FADE)
	modulate.a = alpha
	queue_redraw()


func _band_geo() -> PackedVector2Array:
	if _bands_size == size:
		return _bands
	_bands_size = size
	_bands = PackedVector2Array()
	var w := size.x
	var h := size.y
	var bw := w / 10.0
	var i := 0
	var x := -h
	while x < w + h:
		if i % 2 == 0:
			_bands.append_array(PackedVector2Array([Vector2(x, h), Vector2(x + bw, h), Vector2(x + bw + h * 0.45, 0), Vector2(x + bw + h * 0.45, 0), Vector2(x + h * 0.45, 0), Vector2(x, h)]))
		x += bw
		i += 1
	_band_cols = PackedColorArray()
	_band_cols.resize(_bands.size())
	_band_cols.fill(BAND)
	return _bands


func _draw() -> void:
	var w := size.x
	var h := size.y
	if w < 10.0:
		return
	draw_rect(Rect2(Vector2.ZERO, size), BG)
	# faixas diagonais (geometria em cache, um único lote de triângulos)
	var geo := _band_geo()
	if not geo.is_empty():
		RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), PackedInt32Array(), geo, _band_cols)
	# pinceladas verdes nos cantos
	draw_colored_polygon(PackedVector2Array([Vector2(0, h * 0.78), Vector2(w * 0.22, h * 0.62), Vector2(w * 0.24, h * 0.66), Vector2(0, h * 0.86)]), Color(NEON, 0.16))
	draw_colored_polygon(PackedVector2Array([Vector2(w, h * 0.10), Vector2(w * 0.80, h * 0.24), Vector2(w * 0.78, h * 0.20), Vector2(w, h * 0.04)]), Color(NEON, 0.14))
	var cx := w * 0.5
	# banner pulsando com brilho
	var pulse := 0.5 + 0.5 * sin(t * 2.2)
	var top := h * 0.08
	var logo_h := h * 0.5
	if _logo != null:
		var ts := _logo.get_size()
		var lw := logo_h * ts.x / maxf(ts.y, 1.0)
		if lw > w * 0.86:
			lw = w * 0.86
			logo_h = lw * ts.y / maxf(ts.x, 1.0)
		var k := 1.0 + 0.018 * pulse
		var r := Rect2(Vector2(cx - lw * k * 0.5, top + logo_h * (1.0 - k) * 0.5), Vector2(lw, logo_h) * k)
		for g in 3:
			var gpad: float = (g + 1) * 6.0
			draw_rect(r.grow(gpad), Color(NEON, (0.05 - g * 0.012) * (0.6 + 0.4 * pulse)), false, 4.0)
		draw_texture_rect(_logo, r, false)
		draw_rect(r, Color(NEON, 0.55), false, 2.0)
	# bola quicando e girando, com sombra que encolhe no alto
	var by0 := top + logo_h + h * 0.13
	var br := clampf(h * 0.045, 14.0, 34.0)
	var bounce := absf(sin(t * 3.4))
	var by := by0 - bounce * h * 0.07
	var squash := 1.0 - (1.0 - bounce) * 0.18 if bounce < 0.15 else 1.0
	var sh := 1.0 - bounce * 0.55
	draw_set_transform(Vector2(cx, by0 + br), 0.0, Vector2(1.0, 0.3))
	draw_circle(Vector2.ZERO, br * 1.1 * sh, Color(0, 0, 0, 0.45 * sh))
	draw_set_transform(Vector2(cx, by), t * 4.0, Vector2(1.0 / squash, squash))
	draw_circle(Vector2.ZERO, br, Color("f1f3f2"))
	_pent(Vector2.ZERO, br * 0.36, 0.0, Color("15171a"))
	for i in 5:
		var a := TAU * (i + 0.5) / 5.0
		_pent(Vector2(cos(a), sin(a)) * br * 0.86, br * 0.25, a, Color("15171a"))
	draw_arc(Vector2.ZERO, br, 0, TAU, 28, Color(0, 0, 0, 0.6), maxf(br * 0.08, 1.5), true)
	draw_set_transform_matrix(Transform2D.IDENTITY)
	# barra de progresso com brilho correndo
	var bw := minf(w * 0.56, 640.0)
	var bh := clampf(h * 0.018, 8.0, 14.0)
	var bar := Rect2(cx - bw * 0.5, by0 + br + h * 0.07, bw, bh)
	draw_rect(bar.grow(3.0), Color(1, 1, 1, 0.06))
	draw_rect(bar, Color("1a1f1c"))
	var fill := Rect2(bar.position, Vector2(bw * shown, bh))
	if fill.size.x > 0.5:
		draw_rect(fill.grow(2.0), Color(NEON, 0.18))
		draw_rect(fill, NEON)
		var sx := fill.position.x + fmod(t * bw * 0.7, maxf(fill.size.x + 60.0, 1.0)) - 60.0
		var s0 := maxf(sx, fill.position.x)
		var s1 := minf(sx + 60.0, fill.end.x)
		if s1 > s0:
			draw_rect(Rect2(s0, bar.position.y, s1 - s0, bh), Color(1, 1, 1, 0.35))
	var f := UI.bold()
	var fs := int(clampf(h * 0.03, 14.0, 22.0))
	var dots := ".".repeat(int(t * 3.0) % 4)
	draw_string(f, Vector2(bar.position.x, bar.position.y - 10.0), msg.trim_suffix("…").trim_suffix("...") + dots, HORIZONTAL_ALIGNMENT_LEFT, bw * 0.8, fs, TXT)
	draw_string(f, Vector2(bar.position.x, bar.position.y - 10.0), "%d%%" % int(round(shown * 100.0)), HORIZONTAL_ALIGNMENT_RIGHT, bw, fs, NEON)
	# dica (some e aparece)
	var ta := clampf(minf(tip_t / 0.35, (2.6 - tip_t) / 0.35), 0.0, 1.0)
	var tfs := int(clampf(h * 0.024, 12.0, 18.0))
	draw_string(f, Vector2(cx - w * 0.42, bar.end.y + h * 0.075), "DICA", HORIZONTAL_ALIGNMENT_CENTER, w * 0.84, tfs - 2, Color(NEON, 0.9 * ta))
	draw_string(f, Vector2(cx - w * 0.42, bar.end.y + h * 0.075 + tfs + 8.0), TIPS[tip_i], HORIZONTAL_ALIGNMENT_CENTER, w * 0.84, tfs, Color(MUTED, ta))


func _pent(c: Vector2, r: float, rot: float, col: Color) -> void:
	for i in 5:
		var a := rot - PI / 2.0 + TAU * i / 5.0
		_pts[i] = c + Vector2(cos(a), sin(a)) * r
	draw_colored_polygon(_pts, col)
