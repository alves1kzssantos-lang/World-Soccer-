class_name CoachAvatar
extends Control
## Técnico no estilo da marca: usa o retrato compartilhado (src/chibi_portrait.gd) com o
## visual escolhido na criação (pele, cabelo, cor do cabelo, barba/bigode e roupa).

const SKINS := [Color("f6d3b3"), Color("e8b88f"), Color("c98f62"), Color("9a643f"), Color("6b3f26")]
const HAIR_COLORS := [Color("1a1a1e"), Color("5a3a22"), Color("d9b25f"), Color("a9adb5")]
const HAIR_NAMES := ["Curto", "Espetado", "Cacheado com faixa", "Careca"]
const HAIR_COLOR_NAMES := ["Preto", "Castanho", "Loiro", "Grisalho"]
const BEARD_NAMES := ["Sem barba", "Barba", "Bigode"]
const SUITS := [Color("2553a8"), Color("1d2333"), Color("2c7a4d")]
const SUIT_NAMES := ["Terno azul", "Terno escuro", "Agasalho verde"]

var coach: Dictionary = {}:
	set(v):
		coach = v
		_sync()
var expr: String = "smile"
var _p: ChibiPortrait = null


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_p = ChibiPortrait.make({}, 100.0, "bust")
	_p.custom_minimum_size = Vector2.ZERO
	add_child(_p)
	_p.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_sync()


func _sync() -> void:
	if _p == null or coach.is_empty():
		return
	var lk := ChibiPortrait.for_coach(coach)
	lk["expr"] = expr
	_p.look = lk
	_p.queue_redraw()
