class_name Body
extends RefCounted
## Corpo cinemático de um jogador, goleiro ou árbitro (plano do campo, metros).
## Guarda o estado físico (posição, velocidade, aceleração, direção) e os limites do corpo
## (aceleração, freada, giro). Quem decide para onde ir dá uma ordem com command();
## o BodyWorld integra o movimento e resolve as colisões num passo fixo.

var pos: Vector2 = Vector2.ZERO
var vel: Vector2 = Vector2.ZERO
var acc: Vector2 = Vector2.ZERO        ## aceleração suavizada (para a inclinação da animação)
var facing: Vector2 = Vector2(0, -1)
var radius: float = 0.42
var inv_mass: float = 1.0 / 80.0
var max_accel: float = 10.0
var max_decel: float = 12.0
var turn_still: float = 12.6          ## giro parado (rad/s)
var turn_run: float = 4.2             ## giro em velocidade máxima (rad/s)

var target: Vector2 = Vector2.ZERO
var vmax: float = 0.0
var commanded: bool = false
var press: bool = false               ## ordem sem desvio (marcar a bola, atacar a bola, receber)
var kinematic: bool = false           ## movido pela cena (goleiro no mergulho): não integra, não é empurrado
var step_dist: float = 0.0            ## distância andada no último passo (passada da animação)
var synced: Vector2 = Vector2.ZERO    ## última posição escrita na entidade (detecta teleporte)
var contact: bool = false             ## encostou em outro corpo no último passo (o impulso pode virar a direção)
var avoid: Vector2 = Vector2.ZERO     ## empurrão de desvio (recalculado a cada 2 passos)


## Ordem de movimento para este passo: ir a tgt com velocidade máxima speed.
func command(tgt: Vector2, speed: float, no_avoid: bool = false) -> void:
	target = tgt
	vmax = speed
	commanded = true
	press = no_avoid


## Teleporte (bola parada, saída de bola): corpo parado na posição nova.
func place(p: Vector2) -> void:
	pos = p
	vel = Vector2.ZERO
	acc = Vector2.ZERO
	synced = p


func speed() -> float:
	return vel.length()
