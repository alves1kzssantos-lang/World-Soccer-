class_name BodyWorld
extends RefCounted
## Mundo dos corpos: integra o movimento (steering com limites de aceleração, freada e giro,
## chegada suave e desvio de quem está à frente) e resolve colisões entre corpos
## (separação iterativa ponderada pela massa + impulso inelástico). Passo fixo, sem alocar
## memória por passo. Números em assets/data/match_tuning.json, seção "corpo".

var bodies: Array[Body] = []
var arrive_decel: float = 9.6
var look_ahead: float = 0.45
var avoid_force: float = 3.2
var restitution: float = 0.15
var iterations: int = 4
var lat_accel: float = 11.0          ## aceleração lateral máxima (m/s²): em velocidade, a curva é aberta
var overlaps_last: int = 0             ## pares que se encostaram no último passo (diagnóstico)
var _frame: int = 0

var _p := PackedVector2Array()
var _v := PackedVector2Array()
var _w := PackedFloat32Array()
var _r := PackedFloat32Array()
var _ord := PackedInt32Array()   ## índices ordenados por x (varredura: só testa vizinhos em x)
var _rmax: float = 0.5


func _init() -> void:
	arrive_decel = Tuning.f("corpo", "freada", 12.0) * 0.8
	look_ahead = Tuning.f("corpo", "olhar_a_frente_s", 0.45)
	avoid_force = Tuning.f("corpo", "forca_desvio", 3.2)
	restitution = Tuning.f("corpo", "restituicao", 0.15)
	iterations = int(Tuning.f("corpo", "iteracoes_colisao", 4))
	lat_accel = Tuning.f("corpo", "aceleracao_lateral", 11.0)


func set_bodies(list: Array[Body]) -> void:
	bodies = list
	var n := bodies.size()
	_p.resize(n)
	_v.resize(n)
	_w.resize(n)
	_r.resize(n)
	_ord.resize(n)
	_rmax = 0.0
	for i in n:
		_ord[i] = i
		_rmax = maxf(_rmax, bodies[i].radius)


## Um passo fixo: movimento de todos e depois colisões.
func step(dt: float) -> void:
	var n := bodies.size()
	if _p.size() != n:
		set_bodies(bodies)
	for i in n:
		_p[i] = bodies[i].pos
		_r[i] = bodies[i].radius
	_frame += 1
	for i in n:
		_integrate(bodies[i], i, dt)
	collide()


func _integrate(b: Body, idx: int, dt: float) -> void:
	if b.kinematic:
		b.commanded = false
		b.step_dist = 0.0
		return
	var v_old := b.vel
	var desired := Vector2.ZERO
	if b.commanded:
		var d := b.target - b.pos
		var dist := d.length()
		if dist > 0.06:
			var arrive := sqrt(2.0 * arrive_decel * maxf(dist - 0.04, 0.0))
			desired = d / dist * minf(b.vmax, arrive)
			if not b.press:
				# metade dos corpos recalcula o desvio em cada passo (a outra metade reaproveita)
				if (idx + _frame) % 2 == 0:
					b.avoid = _avoid(idx, desired, dist)
				desired += b.avoid.limit_length(desired.length() * 0.9)
			else:
				b.avoid = Vector2.ZERO
	b.commanded = false
	var cur := b.vel.length()
	var want := desired.length()
	if cur < 0.25:
		b.vel = b.vel.move_toward(desired, b.max_accel * dt)
	else:
		var cdir := b.vel / cur
		var ndir := cdir
		var mag_target := want
		if want > 0.05:
			var ang := cdir.angle_to(desired / want)
			# giro limitado pelo corpo e pela aceleração lateral (v²/r): correndo, a curva abre;
			# para virar fechado o jogador freia (mag_target abaixo), como na vida real
			var tr := minf(lerpf(b.turn_still, b.turn_run, clampf(cur / 7.0, 0.0, 1.0)), lat_accel / cur) * dt
			var turn := clampf(ang, -tr, tr)
			ndir = cdir.rotated(turn)
			# virada brusca: freia enquanto gira (ninguém dá meia-volta correndo)
			mag_target = want * clampf(cos(ang - turn), 0.15, 1.0)
		var rate := b.max_accel if mag_target > cur else b.max_decel
		b.vel = ndir * move_toward(cur, mag_target, rate * dt)
	var stepv := b.vel * dt
	b.pos += stepv
	b.step_dist = stepv.length()
	b.acc = b.acc.lerp((b.vel - v_old) / dt, 0.25)
	if b.step_dist > 0.15 * dt:
		b.facing = b.vel.normalized()


## Desvio: olha à frente e empurra para o lado de quem vai ser atropelado.
## Usa as posições do início do passo (_p), sem alocar e descartando cedo quem está longe.
func _avoid(idx: int, desired: Vector2, tgt_dist: float) -> Vector2:
	var sp := desired.length()
	if sp < 0.5:
		return Vector2.ZERO
	var fdir := desired / sp
	var look := minf(sp * look_ahead + 0.6, tgt_dist)
	var lim := look + 1.2
	var p := _p[idx]
	var rb := _r[idx]
	var out := Vector2.ZERO
	var n := _p.size()
	for j in n:
		if j == idx:
			continue
		var rel := _p[j] - p
		if rel.x > lim or rel.x < -lim or rel.y > lim or rel.y < -lim:
			continue
		var ahead := rel.x * fdir.x + rel.y * fdir.y
		if ahead <= 0.0 or ahead > look:
			continue
		var side_d := rel.x * fdir.y - rel.y * fdir.x
		var clear := _r[j] + rb + 0.25
		if side_d > clear or side_d < -clear:
			continue
		var push := (1.0 - ahead / look) * (clear - absf(side_d)) / clear
		if side_d < 0.0:
			out += Vector2(fdir.y, -fdir.x) * (push * avoid_force)
		else:
			out += Vector2(-fdir.y, fdir.x) * (push * avoid_force)
	return out.limit_length(sp * 0.9)


## Ninguém entra em ninguém: separação iterativa ponderada pela massa (corpo cinemático não
## é empurrado) e impulso inelástico tirando a velocidade de aproximação.
func collide() -> void:
	var n := bodies.size()
	if _p.size() != n:
		set_bodies(bodies)
	for i in n:
		var b := bodies[i]
		_p[i] = b.pos
		_v[i] = b.vel
		_r[i] = b.radius
		_w[i] = 0.0 if b.kinematic else b.inv_mass
		b.contact = false
	overlaps_last = 0
	# ordena por x (quase ordenado de um passo para o outro: inserção é barata)
	for a in range(1, n):
		var v := _ord[a]
		var xv := _p[v].x
		var b2 := a - 1
		while b2 >= 0 and _p[_ord[b2]].x > xv:
			_ord[b2 + 1] = _ord[b2]
			b2 -= 1
		_ord[b2 + 1] = v
	var reach := 2.0 * _rmax
	var touched := false
	for it in iterations:
		var any := false
		for a in n:
			var i := _ord[a]
			var pi := _p[i]
			var ri := _r[i]
			for c in range(a + 1, n):
				var j := _ord[c]
				var dx := _p[j].x - pi.x
				if dx > reach:
					break
				var rs := ri + _r[j]
				if dx > rs or dx < -rs:
					continue
				var dy := _p[j].y - pi.y
				if dy > rs or dy < -rs:
					continue
				var d2 := dx * dx + dy * dy
				if d2 >= rs * rs:
					continue
				var wi := _w[i]
				var wj := _w[j]
				var ws := wi + wj
				if ws <= 0.0:
					continue
				var dist := sqrt(d2)
				var nrm := Vector2(dx, dy) / dist if dist > 0.0001 else Vector2(1, 0).rotated(float(i * 7 + j))
				var pen := rs - dist
				pi -= nrm * (pen * wi / ws)
				_p[j] += nrm * (pen * wj / ws)
				if it == 0:
					overlaps_last += 1
					bodies[i].contact = true
					bodies[j].contact = true
					var vn := (_v[j] - _v[i]).dot(nrm)
					if vn < 0.0:
						var jimp := -(1.0 + restitution) * vn / ws
						_v[i] -= nrm * (jimp * wi)
						_v[j] += nrm * (jimp * wj)
				any = true
			_p[i] = pi
		if not any:
			break
		touched = true
	if touched:
		for i in n:
			bodies[i].pos = _p[i]
			bodies[i].vel = _v[i]


## Menor folga entre dois corpos (distância menos a soma dos raios). Negativo = sobreposição.
func min_gap() -> float:
	var best := 1e9
	var n := bodies.size()
	for i in n:
		for j in range(i + 1, n):
			var g := bodies[i].pos.distance_to(bodies[j].pos) - bodies[i].radius - bodies[j].radius
			best = minf(best, g)
	return best
