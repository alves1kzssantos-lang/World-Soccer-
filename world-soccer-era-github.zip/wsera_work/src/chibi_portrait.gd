class_name ChibiPortrait
extends Control
## Retrato procedural no estilo da marca (o mesmo do banner e dos bonecos da partida):
## cabeça grande e redonda, contorno escuro grosso, olhos em pílula pretos, sobrancelhas
## grossas, sorriso branco grande e cabelo expressivo. Um só desenho para TODO personagem:
## técnico, jogador criado, jogadores do elenco/mercado, fãs, cornetas, imprensa, troféu.
##
## Uso: ChibiPortrait.make(look, px, mode)  — look vem de for_player / for_coach / for_handle.
## Modos: "head" (só cabeça, avatares pequenos), "bust" (cabeça e ombros), "full" (corpo inteiro).
## Desempenho: desenho estático (só redesenha quando o tamanho muda); o Godot guarda os
## comandos de desenho, então listas longas não refazem nada a cada quadro.

const SKINS := [Color("f3cfae"), Color("e4b48a"), Color("c98d5c"), Color("a8703f"), Color("85532f"), Color("5e3a22")]  ## = LanceView.SKINS
const HAIRS := [Color("1b1b1f"), Color("2e2018"), Color("5a3a22"), Color("8a5a2b"), Color("c9a24a"), Color("6e6e72")]  ## = LanceView.HAIRS
const INK := Color("121214")
const TEETH := Color("fbfbfb")
## Estilos de cabelo: 0..5 iguais aos da partida (curto, topete, cheio, careca, raspado, franja);
## 6 espetado, 7 cacheado com faixa.
const STYLE_NAMES := ["Curto", "Topete", "Cheio", "Careca", "Raspado", "Franja", "Espetado", "Cacheado com faixa"]

var look: Dictionary = {}
var mode: String = "bust"
var o: float = 3.2          ## espessura do contorno em unidades (100 = largura do desenho)


static func make(lk: Dictionary, px: float = 48.0, mode_: String = "bust") -> ChibiPortrait:
	var c := ChibiPortrait.new()
	c.look = lk
	c.mode = mode_
	var hgt := px * (1.7 if mode_ == "full" else (1.1 if mode_ == "bust" else 1.0))
	c.custom_minimum_size = Vector2(px, hgt)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	return c


# ------------------------------------------------------------ visuais a partir dos dados
## Visual de um jogador do jogo: as MESMAS regras do LanceView (_ent / _look), então o
## jogador tem a mesma cara no menu e na partida.
static func for_player(p: Dictionary, kit: Array = []) -> Dictionary:
	var id: int = int(p.get("id", 0))
	var lk := {"skin": int(p.get("look_skin", (id * 3) % SKINS.size())), "hcolor": int(p.get("look_hcolor", (id * 5) % HAIRS.size())),
		"hstyle": int(p.get("look_hstyle", id % 6)), "beard": bool(p.get("look_beard", id % 4 == 1)),
		"boots": str(p.get("look_boots", "17171b")), "num": str(p.get("num", "")), "expr": "smile"}
	if not kit.is_empty():
		lk["c1"] = kit[0]
		lk["c2"] = kit[1]
		lk["striped"] = kit.size() > 2 and bool(kit[2])
	if str(p.get("pos", "")) == "GOL":
		lk["keeper"] = true
	return lk


## Camisa do clube (cores do Game) para usar no visual.
static func club_kit(cid: int) -> Array:
	if Game.S.is_empty() or cid < 0 or cid >= Game.S["clubs"].size():
		return [Color("2f6fd6"), Color("f2f2f2"), false]
	var c: Dictionary = Game.S["clubs"][cid]
	return [Color(str(c["c1"])), Color(str(c["c2"])), LanceView.striped(c)]


## Visual do técnico (dados da criação: skin 0..4, hair 0..3, haircolor 0..3, beard 0..2, suit 0..2).
static func for_coach(co: Dictionary) -> Dictionary:
	var skin_map := [0, 1, 2, 4, 5]
	var hair_map := [0, 6, 7, 3]          # Curto, Topete (espetado), Longo ondulado (cacheado com faixa), Careca
	var hc_map := [0, 2, 4, 5]            # preto, castanho, loiro, grisalho
	var suits := [Color("2553a8"), Color("1d2333"), Color("2c7a4d")]
	var b: int = int(co.get("beard", 0))
	return {"skin": skin_map[int(co.get("skin", 1)) % 5], "hstyle": hair_map[int(co.get("hair", 0)) % 4],
		"hcolor": hc_map[int(co.get("haircolor", 0)) % 4], "beard": b == 1, "mustache": b == 2,
		"suit": suits[int(co.get("suit", 0)) % 3], "tie": int(co.get("suit", 0)) != 2, "expr": "smile"}


## Visual sorteado de forma fixa por um texto (usuários da rede social, repórter).
static func for_handle(handle: String, expr: String = "smile", shirt: Color = Color("3a3f3c")) -> Dictionary:
	var h: int = absi(hash(handle))
	return {"skin": h % SKINS.size(), "hcolor": (h / 7) % HAIRS.size(), "hstyle": (h / 49) % 8, "beard": (h / 343) % 5 == 1,
		"expr": expr, "c1": shirt, "c2": shirt.lightened(0.3)}


# ------------------------------------------------------------ desenho
func _ready() -> void:
	resized.connect(queue_redraw)


func _draw() -> void:
	if look.is_empty() or size.x < 4.0:
		return
	var full := mode == "full"
	var bust := mode == "bust"
	var uh := 170.0 if full else (110.0 if bust else 100.0)
	var k: float = minf(size.x / 100.0, size.y / uh)
	draw_set_transform(Vector2((size.x - 100.0 * k) * 0.5, size.y - uh * k), 0.0, Vector2(k, k))
	o = clampf(3.2 / maxf(k, 0.3) * 0.9, 2.4, 6.0)
	var head_c := Vector2(50, 46 if not full else 40)
	var hr := 34.0 if mode == "head" else (31.0 if bust else 27.0)
	if full:
		_body_full(Vector2(50, 66))
	elif bust:
		_shoulders(Vector2(50, 84))
	_head(head_c, hr)
	draw_set_transform(Vector2.ZERO)


func _skin() -> Color:
	return SKINS[int(look.get("skin", 1)) % SKINS.size()]


func _hair() -> Color:
	return HAIRS[int(look.get("hcolor", 0)) % HAIRS.size()]


func _shirt() -> Color:
	if look.has("suit"):
		return look["suit"]
	if look.get("keeper", false):
		return Color("e8c61c")
	return look.get("c1", Color("2f6fd6"))


## Forma com contorno: o contorno é a mesma forma desenhada antes, mais grossa e escura.
func _ocircle(c: Vector2, r: float, col: Color) -> void:
	draw_circle(c, r + o, INK)
	draw_circle(c, r, col)


func _opoly(pts: PackedVector2Array, col: Color) -> void:
	var closed := pts.duplicate()
	closed.append(pts[0])
	draw_polyline(closed, INK, o * 2.0, true)
	draw_colored_polygon(pts, col)


static func _rrect_pts(r: Rect2, rad: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var cs := [Vector2(r.end.x - rad, r.position.y + rad), Vector2(r.end.x - rad, r.end.y - rad),
		Vector2(r.position.x + rad, r.end.y - rad), Vector2(r.position.x + rad, r.position.y + rad)]
	var a0 := [-PI / 2.0, 0.0, PI / 2.0, PI]
	for i in 4:
		for s in 5:
			var a: float = a0[i] + PI / 2.0 * s / 4.0
			pts.append(cs[i] + Vector2(cos(a), sin(a)) * rad)
	return pts


func _head(c: Vector2, r: float) -> void:
	var skin := _skin()
	var hair := _hair()
	var st: int = int(look.get("hstyle", 0)) % 8
	# cabelo de trás (cheio e cacheado aparecem em volta da cabeça)
	if st == 2:
		_ocircle(c + Vector2(0, -r * 0.18), r * 1.06, hair)
	elif st == 7:
		for i in 11:
			var a := PI + PI * i / 10.0 + 0.0
			_ocircle(c + Vector2(cos(a), sin(a) * 0.95) * r * 0.98 + Vector2(0, r * 0.05), r * 0.3, hair)
		for sd in [-1.0, 1.0]:
			_ocircle(c + Vector2(sd * r * 1.05, r * 0.45), r * 0.28, hair)
	# orelhas
	for sd in [-1.0, 1.0]:
		_ocircle(c + Vector2(sd * r * 0.98, r * 0.12), r * 0.2, skin)
		draw_circle(c + Vector2(sd * r * 0.98, r * 0.12), r * 0.09, skin.darkened(0.15))
	# cabeça: redonda, um pouco mais larga nas bochechas
	_opoly(_rrect_pts(Rect2(c.x - r, c.y - r * 1.02, r * 2.0, r * 2.05), r * 0.82), skin)
	draw_colored_polygon(_rrect_pts(Rect2(c.x + r * 0.35, c.y - r * 0.6, r * 0.5, r * 1.3), r * 0.24), Color(0, 0, 0, 0.05))
	_hair_front(c, r, st, hair)
	if look.get("beard", false):
		var bd := PackedVector2Array([c + Vector2(-r * 0.92, r * 0.25), c + Vector2(r * 0.92, r * 0.25), c + Vector2(r * 0.7, r * 0.82),
			c + Vector2(0, r * 1.06), c + Vector2(-r * 0.7, r * 0.82)])
		draw_colored_polygon(bd, skin.lerp(hair, 0.55))
	_face(c, r, hair)


func _hair_front(c: Vector2, r: float, st: int, hair: Color) -> void:
	var top := c.y - r * 1.02
	match st:
		0:   # curto
			_opoly(PackedVector2Array([c + Vector2(-r * 1.0, -r * 0.25), c + Vector2(-r * 0.95, -r * 0.75), c + Vector2(-r * 0.5, -r * 1.08),
				c + Vector2(r * 0.4, -r * 1.12), c + Vector2(r * 0.95, -r * 0.78), c + Vector2(r * 1.0, -r * 0.25), c + Vector2(r * 0.7, -r * 0.62),
				c + Vector2(-r * 0.6, -r * 0.6)]), hair)
		1:   # topete
			_opoly(PackedVector2Array([c + Vector2(-r * 1.0, -r * 0.3), c + Vector2(-r * 0.9, -r * 0.85), c + Vector2(-r * 0.2, -r * 1.12),
				c + Vector2(r * 0.25, -r * 1.42), c + Vector2(r * 0.85, -r * 1.2), c + Vector2(r * 1.02, -r * 0.35), c + Vector2(r * 0.6, -r * 0.7),
				c + Vector2(-r * 0.5, -r * 0.68)]), hair)
		2:   # cheio (a parte de trás já foi desenhada)
			_opoly(PackedVector2Array([c + Vector2(-r * 1.04, -r * 0.1), c + Vector2(-r * 0.9, -r * 0.9), c + Vector2(0, -r * 1.2),
				c + Vector2(r * 0.9, -r * 0.9), c + Vector2(r * 1.04, -r * 0.1), c + Vector2(r * 0.55, -r * 0.62), c + Vector2(-r * 0.2, -r * 0.5),
				c + Vector2(-r * 0.7, -r * 0.6)]), hair)
		3:   # careca: brilho
			draw_arc(c + Vector2(-r * 0.25, -r * 0.55), r * 0.25, PI * 1.1, PI * 1.7, 8, Color(1, 1, 1, 0.35), r * 0.08, true)
		4:   # raspado
			draw_colored_polygon(_rrect_pts(Rect2(c.x - r * 0.92, top + r * 0.05, r * 1.84, r * 0.7), r * 0.34), Color(hair, 0.55))
		5:   # franja
			_opoly(PackedVector2Array([c + Vector2(-r * 1.0, -r * 0.2), c + Vector2(-r * 0.92, -r * 0.88), c + Vector2(0, -r * 1.14),
				c + Vector2(r * 0.92, -r * 0.88), c + Vector2(r * 1.0, -r * 0.2), c + Vector2(r * 0.55, -r * 0.42), c + Vector2(-r * 0.05, -r * 0.34),
				c + Vector2(-r * 0.6, -r * 0.42)]), hair)
		6:   # espetado
			var pts := PackedVector2Array([c + Vector2(-r * 1.02, -r * 0.25)])
			for i in 7:
				var x := -r * 0.95 + r * 1.9 * i / 6.0
				pts.append(c + Vector2(x, -r * 0.92 - (r * 0.36 if i % 2 == 1 else r * 0.08)))
			pts.append(c + Vector2(r * 1.02, -r * 0.25))
			pts.append(c + Vector2(r * 0.55, -r * 0.62))
			pts.append(c + Vector2(-r * 0.55, -r * 0.62))
			_opoly(pts, hair)
		7:   # cacheado com faixa (os cachos ficam no alto da cabeça; a faixa passa na testa, acima das sobrancelhas)
			for i in 7:
				var a := PI * 1.18 + PI * 0.64 * i / 6.0
				_ocircle(c + Vector2(cos(a), sin(a)) * r * 0.92, r * 0.26, hair)
			var band := PackedVector2Array([c + Vector2(-r * 0.97, -r * 0.74), c + Vector2(r * 0.97, -r * 0.74),
				c + Vector2(r * 0.99, -r * 0.56), c + Vector2(-r * 0.99, -r * 0.56)])
			_opoly(band, look.get("band", INK.lightened(0.12)))


func _face(c: Vector2, r: float, hair: Color) -> void:
	var expr: String = str(look.get("expr", "smile"))
	var ey := c.y + r * 0.02
	var brow := hair.darkened(0.35) if int(look.get("hstyle", 0)) != 3 else _skin().darkened(0.45)
	var tilt := 0.0
	if expr == "angry" or expr == "shouting":
		tilt = r * 0.14
	elif expr == "crying":
		tilt = -r * 0.12
	# sobrancelhas grossas
	for sd in [-1.0, 1.0]:
		var a := Vector2(c.x + sd * r * 0.58, ey - r * 0.3 - (0.0 if expr != "crying" else -r * 0.02))
		var b := Vector2(c.x + sd * r * 0.18, ey - r * 0.3 + tilt)
		draw_line(a, b, brow, r * 0.13, true)
		draw_circle(a, r * 0.065, brow)
		draw_circle(b, r * 0.065, brow)
	# olhos em pílula
	for sd in [-1.0, 1.0]:
		var ec := Vector2(c.x + sd * r * 0.38, ey)
		draw_colored_polygon(_rrect_pts(Rect2(ec.x - r * 0.15, ec.y - r * 0.1, r * 0.3, r * 0.2), r * 0.09), INK)
	if expr == "crying":
		for sd in [-1.0, 1.0]:
			draw_circle(Vector2(c.x + sd * r * 0.4, ey + r * 0.3), r * 0.08, Color("6ec6ff"))
	# nariz
	draw_line(Vector2(c.x - r * 0.06, ey + r * 0.22), Vector2(c.x + r * 0.06, ey + r * 0.24), _skin().darkened(0.3), r * 0.06, true)
	if look.get("mustache", false):
		draw_line(Vector2(c.x - r * 0.32, ey + r * 0.36), Vector2(c.x + r * 0.32, ey + r * 0.36), hair, r * 0.12, true)
	# boca
	var my := ey + r * 0.48
	match expr:
		"serious":
			draw_line(Vector2(c.x - r * 0.25, my), Vector2(c.x + r * 0.25, my), INK, r * 0.07, true)
		"angry", "crying":
			draw_arc(Vector2(c.x, my + r * 0.2), r * 0.28, PI * 1.2, PI * 1.8, 10, INK, r * 0.07, true)
		"shouting":
			var mo := _rrect_pts(Rect2(c.x - r * 0.22, my - r * 0.12, r * 0.44, r * 0.4), r * 0.18)
			draw_colored_polygon(mo, Color("3a0d12"))
			draw_circle(Vector2(c.x, my + r * 0.18), r * 0.1, Color("e0646e"))
			draw_polyline(mo + PackedVector2Array([mo[0]]), INK, r * 0.05, true)
		_:   # sorriso branco grande
			var sm := PackedVector2Array()
			for i in 13:
				var a := PI * i / 12.0
				sm.append(Vector2(c.x + cos(a) * r * 0.42, my - r * 0.06 + sin(a) * r * 0.32))
			draw_colored_polygon(sm, TEETH)
			var ol := sm.duplicate()
			ol.append(sm[0])
			draw_polyline(ol, INK, r * 0.06, true)


## Ombros e camisa (gola V; terno com gravata para o técnico).
func _shoulders(c: Vector2) -> void:
	var shirt := _shirt()
	var pts := PackedVector2Array([Vector2(c.x - 44, 112), Vector2(c.x - 42, c.y + 2), Vector2(c.x - 30, c.y - 12), Vector2(c.x - 12, c.y - 16),
		Vector2(c.x + 12, c.y - 16), Vector2(c.x + 30, c.y - 12), Vector2(c.x + 42, c.y + 2), Vector2(c.x + 44, 112)])
	_opoly(pts, shirt)
	if look.get("striped", false) and not look.has("suit"):
		for sx in [-24.0, 0.0, 24.0]:
			draw_rect(Rect2(c.x + sx - 5, c.y - 12, 10, 40), look.get("c2", Color.WHITE))
	if look.has("suit"):
		draw_colored_polygon(PackedVector2Array([Vector2(c.x - 10, c.y - 15), Vector2(c.x + 10, c.y - 15), Vector2(c.x, c.y + 14)]), Color("f4f6fa"))
		if look.get("tie", true):
			draw_colored_polygon(PackedVector2Array([Vector2(c.x - 3, c.y - 12), Vector2(c.x + 3, c.y - 12), Vector2(c.x + 5, c.y + 12), Vector2(c.x, c.y + 18), Vector2(c.x - 5, c.y + 12)]), Color("b8262f"))
	else:
		draw_colored_polygon(PackedVector2Array([Vector2(c.x - 11, c.y - 15), Vector2(c.x + 11, c.y - 15), Vector2(c.x, c.y - 2)]), look.get("c2", Color.WHITE))
		draw_colored_polygon(PackedVector2Array([Vector2(c.x - 7, c.y - 15), Vector2(c.x + 7, c.y - 15), Vector2(c.x, c.y - 6)]), _skin())
		var num := str(look.get("num", ""))
		if num != "":
			var ink := Color("151515") if shirt.get_luminance() > 0.55 else Color("f4f4f4")
			draw_string(UI.display(), Vector2(c.x + 14, c.y + 16), num, HORIZONTAL_ALIGNMENT_CENTER, 22, 14, ink)


## Corpo inteiro (criação do jogador, troféu): camisa, calção, meião e chuteira.
func _body_full(c: Vector2) -> void:
	var shirt := _shirt()
	var shorts: Color = look.get("c2", Color.WHITE) if not look.has("suit") else Color("20242c")
	var boots := Color(str(look.get("boots", "17171b")))
	var skin := _skin()
	var cheer: bool = str(look.get("expr", "")) in ["shouting"] or look.get("arms_up", false)
	# pernas
	for sd in [-1.0, 1.0]:
		_opoly(_rrect_pts(Rect2(c.x + sd * 11 - 7, c.y + 52, 14, 30), 5), skin)
		_opoly(_rrect_pts(Rect2(c.x + sd * 11 - 8, c.y + 64, 16, 26), 4), shirt if not look.has("suit") else Color("20242c"))
		_opoly(_rrect_pts(Rect2(c.x + sd * 11 - 10, c.y + 88, 20, 10), 4), boots)
	# braços
	for sd in [-1.0, 1.0]:
		var sh := Vector2(c.x + sd * 22, c.y + 6)
		var hand := sh + (Vector2(sd * 10, -34) if cheer else Vector2(sd * 8, 30))
		draw_line(sh, hand, INK, 12 + o * 2.0, true)
		draw_line(sh, hand, skin, 12, true)
		_ocircle(hand, 6.5, skin)
		draw_line(sh, sh.lerp(hand, 0.4), INK, 15 + o * 2.0, true)
		draw_line(sh, sh.lerp(hand, 0.4), shirt, 15, true)
	# camisa e calção
	_opoly(_rrect_pts(Rect2(c.x - 24, c.y - 2, 48, 40), 10), shirt)
	if look.get("striped", false):
		for sx in [-12.0, 4.0]:
			draw_rect(Rect2(c.x + sx, c.y + 2, 8, 34), look.get("c2", Color.WHITE))
	_opoly(_rrect_pts(Rect2(c.x - 23, c.y + 36, 46, 20), 5), shorts)
	var num := str(look.get("num", ""))
	if num != "":
		var ink := Color("151515") if shirt.get_luminance() > 0.55 else Color("f4f4f4")
		draw_string(UI.display(), Vector2(c.x - 15, c.y + 28), num, HORIZONTAL_ALIGNMENT_CENTER, 30, 18, ink)
