# World Soccer: Era (base Craque Manager)

Projeto de gerenciamento de futebol feito em **Godot 4.5 / GDScript**, com partidas 2D em visão superior e foco em carreira. Esta versão mantém a base original e inicia uma etapa de evolução visual e de jogabilidade.

## Abrir o projeto

1. Instale Godot 4.5 (compatível com o projeto).
2. Abra o Godot Project Manager e importe esta pasta selecionando `project.godot`.
3. Execute `main.tscn`.

## Sistemas existentes na base

- Carreira de técnico e carreira de jogador.
- Clubes, ligas, elencos e datapack externo.
- Calendário, classificação, competições e copas.
- Mercado, contratos, finanças e evolução de jogadores.
- Simulação de partida e cenas de lances em 2D.
- Escudos de clubes e logos de competições carregados do datapack.

## Evolução aplicada nesta revisão

- Menu inicial de abertura com identidade `WORLD SOCCER: ERA`, preservando paleta verde-escura e dourada.
- Opção de continuar a carreira mais recente disponível.
- Cena de pênalti com três defensores posicionados dentro da rede, atrás do goleiro; demais defensores ficam fora do enquadramento para manter a cobrança limpa.
- Ajustes iniciais no ciclo procedural dos bonecos: passada mais legível, elevação corporal e balanço dos braços.
- Nome do aplicativo atualizado.

## Observações de validação

A revisão de código foi feita sobre a pasta enviada. Este ambiente não possui o executável do Godot, então a compilação, a execução de cenas e os testes visuais precisam ser confirmados no Godot Editor antes de considerar a atualização pronta para distribuição.

## Próximas etapas recomendadas

1. Rodar o projeto e corrigir qualquer erro de parser ou layout.
2. Criar cenas de animação específicas para chute, passe, desarme, queda, comemoração e defesas do goleiro.
3. Refinar a câmera e o enquadramento da cobrança de pênalti.
4. Auditar o mapeamento dos logos de competições e escudos do datapack.
5. Testar cada tela em 1280×720 e em proporções mobile.
