# World Soccer: Era (base Craque Manager)

Projeto de gerenciamento de futebol feito em **Godot 4.5 / GDScript**, com partidas 2D em visão superior e foco em carreira. Esta versão mantém a base original e inicia uma etapa de evolução visual e de jogabilidade.

## Abrir o projeto

1. Instale Godot 4.5 (compatível com o projeto).
2. Abra o Godot Project Manager e importe esta pasta selecionando `project.godot`.
3. Execute `main.tscn`.

## Sistemas existentes na base

- Carreira de técnico e carreira de jogador.
- Clubes, ligas, elencos e datapack externo.
- Calendário, classificação, competições e copas.
- Mercado, contratos, finanças e evolução de jogadores.
- Simulação de partida e cenas de lances em 2D.
- Escudos de clubes e logos de competições carregados do datapack.

## Evolução aplicada nesta revisão

- Menu inicial de abertura com identidade `WORLD SOCCER: ERA`, preservando paleta verde-escura e dourada.
- Opção de continuar a carreira mais recente disponível.
- Cena de pênalti com três defensores posicionados dentro da rede, atrás do goleiro; demais defensores ficam fora do enquadramento para manter a cobrança limpa.
- Ajustes iniciais no ciclo procedural dos bonecos: passada mais legível, elevação corporal e balanço dos braços.
- Nome do aplicativo atualizado.

## Revisão 2 (concluída)

- **Escudos e logos voltaram a aparecer**: o projeto não trazia o `datapack.zip`, então nenhum escudo ou logo era
  carregado. Agora o jogo usa direto as imagens que já vêm em `assets/datapack/` (991 de 1008 escudos, 45 de 58 ligas).
- **Emblema padrão** para toda liga/copa sem logo no pacote, igual em todas as telas.
- **Pênalti completo**: câmera se aproxima, cobrador corre até a bola, a perna arma e o chute sai no contato,
  goleiro dá passinhos, se antecipa, mergulha e se recupera; os três jogadores no gol e a torcida reagem.
- **Animações novas dos bonecos**: respiração parado, domínio de bola, cabeceio com pulo, carrinho, queda na falta,
  comemoração e mãos na cabeça.
- **Bola com efeito** (curva nos chutes, mais forte na falta) e rede balançando no gol; papel picado da torcida.
- **Menu**: arte de capa desenhada por código e transição animada para a carreira.
- **Correção de travamento**: o botão "voltar" do Android durante um lance (sem o campo ao vivo) fechava o jogo com erro.
- Avisos do GDScript zerados.

## Validação

Validado no Godot 4.5.1 (também pelo servidor godot-mcp):

- `godot --headless --path . res://tests/run_tests.tscn` → 149 verificações, 0 falhas.
- Partida completa (`tests/movie.tscn`) sem erros de script.
- Capturas de conferência: `tests/shots_tour.tscn` (menu, transição, seleção de clubes, pênalti passo a passo).
- Auditoria de escudos/logos: `godot --headless --path . -s tests/audit_logos.gd`.

## Próximas etapas recomendadas

1. Refinar quique e desaceleração da bola no chão.
2. Revisar colisões e a leitura visual de quem está com a posse.
3. Conseguir as imagens que faltam no pacote (lista em `design/roadmap-world-soccer-era.md`).
4. Testar num celular real (toque, desempenho e proporções).
