# Análise do datapack — World Soccer: Era

Gerado por `analise/analisar_datapack.gd` (rode de novo depois de mudar o pacote ou as ligas):
`godot --headless --path . -s analise/analisar_datapack.gd`. Dados brutos em `clubes.csv`, `ligas.csv` e `placas.csv`.

## O que o pacote tem

| Pasta | Arquivos | Conteúdo |
|---|---|---|
| `assets/datapack/logos/` | 4122 | escudos de clubes (`ID.webp`) |
| `assets/datapack/comps/` | 152 | logos de competições (`ID.webp`) |
| `assets/datapack/adboards/` | 924 imagens em 90 pastas | placas de publicidade por país, continente e competição |

## O que o pacote NÃO tem

- **Nenhum nome de jogador.** Não há `players.csv`, `elencos.csv`, `clubs.csv`, `competitions.csv` nem `stadiums.csv`:
  o projeto foi enviado sem o `datapack.zip` original. Só existem imagens.
- Por isso os elencos reais vêm de `assets/data/rosters_real.json` (ver `analise/elencos.md`); clubes sem elenco
  real têm jogadores gerados com nomes do país da liga.
- Nomes de clubes e estádios do pacote também não existem: os nomes vêm de `src/world_data.gd`.
- Se você tiver o `datapack.zip` original (com `elencos.csv`), coloque-o na raiz do projeto: o jogo importa e ele tem
  prioridade sobre o `rosters_real.json`.

## Ligação com as ligas do jogo

- Ligas: 58, com logo no pacote: 45.
- Clubes: 1008, com escudo: 991 (98.3%).
- Clubes com elenco real (rosters_real.json): 176.
- Escudos do pacote que nenhum clube do jogo usa: 3175 de 4122 (clubes de ligas que o jogo não tem).
- Logos de competição sem uso no jogo: 100 de 152.

| Liga | País | ID | Logo | Clubes | Com escudo | Elenco real | Placas do país |
|---|---|---|---|---|---|---|---|
| Brasileirão Série A | Brasil | 1410 | sim | 20 | 20 | 20 | 25 |
| Brasileirão Série B | Brasil | 1420 | sim | 20 | 20 | 4 | 25 |
| Liga Argentina | Argentina | 830 | **não** | 20 | 20 | 9 | 29 |
| Premier League | Inglaterra | 2270 | **não** | 20 | 20 | 20 | 13 |
| La Liga | Espanha | 6790 | sim | 20 | 20 | 20 | 16 |
| Serie A Itália | Itália | 3890 | sim | 20 | 20 | 20 | 24 |
| Bundesliga | Alemanha | 3150 | **não** | 18 | 18 | 18 | 19 |
| Ligue 1 | França | 2980 | sim | 18 | 18 | 18 | 15 |
| Liga Portugal | Portugal | 5610 | sim | 18 | 18 | 4 | 18 |
| Brasileirão Série C | Brasil | 1424 | sim | 20 | 20 | 0 | 25 |
| EFL Championship | Inglaterra | 2280 | **não** | 24 | 24 | 0 | 13 |
| LaLiga 2 | Espanha | 6800 | sim | 20 | 20 | 0 | 16 |
| Serie B | Itália | 3900 | sim | 20 | 20 | 0 | 24 |
| 2. Bundesliga | Alemanha | 3160 | **não** | 18 | 18 | 0 | 19 |
| Ligue 2 | França | 2990 | sim | 18 | 18 | 0 | 15 |
| Eredivisie | Holanda | 5030 | sim | 18 | 18 | 4 | 17 |
| Jupiler Pro League | Bélgica | 1190 | sim | 16 | 16 | 2 | 11 |
| Süper Lig | Turquia | 7270 | sim | 18 | 18 | 4 | 15 |
| Saudi Pro League | Arábia Saudita | 6120 | sim | 18 | 18 | 6 | 5 |
| Major League Soccer | Estados Unidos | 7500 | **não** | 28 | 28 | 3 | 21 |
| Liga MX Apertura | México | 10320 | sim | 16 | 16 | 6 | 22 |
| Chilean Primera División | Chile | 1670 | sim | 14 | 14 | 0 | 10 |
| Primera A | Colômbia | 1770 | sim | 18 | 17 | 0 | 25 |
| Super League Greece | Grécia | 3280 | sim | 14 | 14 | 0 | 18 |
| Liga Portugal 2 | Portugal | 5620 | sim | 18 | 18 | 0 | 18 |
| Superliga | Dinamarca | 2060 | sim | 12 | 12 | 0 | 10 |
| Allsvenskan | Suécia | 6970 | sim | 16 | 16 | 0 | 16 |
| K League 1 | Coreia do Sul | 4260 | sim | 12 | 12 | 0 | 11 |
| Chinese Super League | China | 1690 | sim | 16 | 16 | 0 | 18 |
| Division Profesional | Paraguai | 5410 | sim | 12 | 12 | 0 | 8 |
| Liga 1 | Peru | 5430 | sim | 18 | 18 | 0 | 12 |
| EFL League One | Inglaterra | 2290 | **não** | 24 | 24 | 0 | 13 |
| EFL League Two | Inglaterra | 2300 | **não** | 24 | 24 | 0 | 13 |
| National League | Inglaterra | 2310 | **não** | 24 | 24 | 0 | 13 |
| 3. Liga | Alemanha | 3170 | **não** | 20 | 20 | 0 | 19 |
| Eerste Divisie | Holanda | 5040 | sim | 20 | 20 | 0 | 17 |
| Challenger Pro League | Bélgica | 1200 | sim | 16 | 14 | 0 | 11 |
| TFF 1. Lig | Turquia | 7280 | sim | 20 | 19 | 0 | 15 |
| Liga Expansión MX | México | 10410 | sim | 16 | 16 | 0 | 22 |
| Campeonato Primera B | Chile | 1680 | sim | 16 | 16 | 0 | 10 |
| Primera B | Colômbia | 1775 | **não** | 16 | 16 | 0 | 25 |
| Serie A Equador | Equador | 2180 | sim | 16 | 16 | 0 | 13 |
| Primera Nacional | Argentina | 840 | **não** | 20 | 20 | 0 | 29 |
| China League One | China | 1700 | sim | 16 | 12 | 0 | 18 |
| K League 2 | Coreia do Sul | 4263 | sim | 14 | 14 | 0 | 11 |
| UAE Pro League | Emirados Árabes | 7480 | sim | 14 | 14 | 0 | 7 |
| Persian Gulf Pro League | Irã | 9200 | sim | 16 | 16 | 0 | 9 |
| Botola Pro | Marrocos | 4950 | sim | 16 | 16 | 0 | 8 |
| Girabola | Angola | 9300 | sim | 16 | 14 | 0 | 0 |
| BRI Super League | Indonésia | 9350 | sim | 18 | 17 | 0 | 5 |
| USL Championship | Estados Unidos | 7520 | **não** | 24 | 23 | 0 | 21 |
| Canadian Premier League | Canadá | 1610 | sim | 8 | 6 | 0 | 11 |
| Campeonato Paulista | Brasil | 10700 | sim | 16 | 16 | 6 | 25 |
| Campeonato Carioca | Brasil | 10800 | sim | 12 | 12 | 4 | 25 |
| Campeonato Mineiro | Brasil | 91420 | sim | 12 | 12 | 2 | 25 |
| Campeonato Gaúcho | Brasil | 91440 | sim | 12 | 12 | 3 | 25 |
| Campeonato Paranaense | Brasil | 91450 | sim | 12 | 11 | 2 | 25 |
| Campeonato Catarinense | Brasil | 91470 | sim | 12 | 10 | 1 | 25 |

## Copas

| Copa | ID | Logo no pacote |
|---|---|---|
| Copa do Brasil | 1440 | sim |
| Copa do Nordeste | 10600 | sim |
| Copa Verde | 91430 | sim |
| FA Cup | 2370 | não (emblema padrão) |
| Carabao Cup | 92570 | não (emblema padrão) |
| KNVB Cup | 5060 | sim |
| Copa MX | 10510 | sim |
| Copa Chile | 91480 | sim |
| Hazfi Cup | 91500 | não (emblema padrão) |
| Piala Indonesia | 92490 | sim |
| Canadian Championship | 92590 | não (emblema padrão) |
| Copa Libertadores | -1 | não (emblema padrão) |
| Champions League | -1 | não (emblema padrão) |

## Ligas sem logo no pacote (usam o emblema padrão)

- Liga Argentina (id 830)
- Premier League (id 2270)
- Bundesliga (id 3150)
- EFL Championship (id 2280)
- 2. Bundesliga (id 3160)
- Major League Soccer (id 7500)
- EFL League One (id 2290)
- EFL League Two (id 2300)
- National League (id 2310)
- 3. Liga (id 3170)
- Primera B (id 1775)
- Primera Nacional (id 840)
- USL Championship (id 7520)

## Clubes sem escudo no pacote (usam o escudo desenhado)

- Primera A — Llaneros
- Challenger Pro League — Beveren
- Challenger Pro League — Club NXT
- TFF 1. Lig — Çorum FK
- China League One — Guangzhou FC
- China League One — Shanghai Jiading
- China League One — Dalian Kuncheng
- China League One — Heilongjiang Ice City
- Girabola — 1º de Agosto
- Girabola — Kabuscorp do Palanca
- BRI Super League — Malut United
- USL Championship — North Carolina
- Canadian Premier League — York United
- Canadian Premier League — Valour FC
- Campeonato Paranaense — Rio Branco-PR
- Campeonato Catarinense — Hercílio Luz
- Campeonato Catarinense — Inter de Lages

## Placas de publicidade

Países das ligas do jogo sem pasta de placas (a partida usa as placas genéricas, 68 imagens): Angola.
A contagem por pasta está em `placas.csv`.
