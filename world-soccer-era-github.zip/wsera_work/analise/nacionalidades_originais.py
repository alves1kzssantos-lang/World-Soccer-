#!/usr/bin/env python3
"""Uma vez: converte os 37 elencos originais do rosters_real.json (sem país) em
analise/elencos_fonte/originais.txt, com a nacionalidade real de cada jogador."""
import json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BR_CLUBS = {"Flamengo","Palmeiras","Cruzeiro","Corinthians","Botafogo","Atlético-MG","São Paulo","Fluminense","Internacional",
 "Bahia","Grêmio","Santos","Vasco da Gama","RB Bragantino","Athletico-PR","Fortaleza","Mirassol","Vitória","Coritiba","Sport"}
NAT = {
 # estrangeiros nos clubes brasileiros
 "Agustín Rossi":"ARG","Guillermo Varela":"URU","Erick Pulgar":"CHI","Jorginho":"ITA","Saúl Ñíguez":"ESP","de Arrascaeta":"URU","Gonzalo Plata":"EQU",
 "Gustavo Gómez":"PAR","Joaquín Piquerez":"URU","Aníbal Moreno":"ARG","Emiliano Martínez|Palmeiras":"URU","Facundo Torres":"URU","Fer López":"ARG",
 "Lucas Romero":"ARG","Félix Torres":"EQU","José Martínez":"VEN","Rodrigo Garro":"ARG","Memphis Depay":"HOL","Ángel Romero":"PAR",
 "Alexander Barboza":"ARG","Bastos":"ANG","J. Savarino":"VEN","Júnior Alonso":"PAR","Fausto Vera":"ARG","Alexis Cuello":"ARG",
 "Robert Arboleda":"EQU","Alan Franco":"EQU","Enzo Díaz":"ARG","Jonathan Calleri":"ARG","Facundo Bernal":"URU","Lucas Acosta":"ARG",
 "Jhon Arias":"COL","Germán Cano":"ARG","Sergio Rochet":"URU","A. Bernabei":"ARG","Enner Valencia":"EQU","Rafael Borré":"COL",
 "Johan Carbonero":"COL","Luciano Rodríguez":"URU","Walter Kannemann":"ARG","M. Villasanti":"PAR","Franco Cristaldo":"ARG",
 "M. Braithwaite":"DIN","Francis Amuzu":"BEL","Gonzalo Escobar":"ARG","B. Rollheiser":"ARG","Álvaro Barreal":"ARG",
 "Pol Rodríguez":"URU","Mauricio Lemos":"URU","Nuno Moreira":"POR","Pablo Vegetti":"ARG","Andrés Gómez":"COL",
 "Avilés Hurtado":"COL","Isidro Pitta":"PAR","Gastón Benavídez":"ARG","Bruno Zapelli":"ARG","Gonzalo Mastriani":"URU",
 "Agustín Canobbio":"URU","Emanuel Brítez":"ARG","Benjamín Kuscevic":"CHI","Tomás Pochettino":"ARG","Mono Martínez":"ARG",
 "Lautaro Lucero":"ARG","Sebastián Gómez":"COL","F. Domínguez":"URU","Christian Rivera":"COL","A. Barletta":"ARG","Gonçalo Paciência":"POR",
 # River e Boca (argentinos, salvo os listados)
 "Paulo Díaz":"CHI","Kevin Castaño":"COL","Jay Quintero":"COL","Miguel Borja":"COL","Luis Advíncula":"PER","Miguel Merentiel":"URU",
 "Edinson Cavani":"URU","Ander Herrera":"ESP","Carlos Palacios":"CHI",
 # Real Madrid
 "Thibaut Courtois":"BEL","Dany Carvajal":"ESP","Alexander-Arnold":"ING","Éder Militão":"BRA","Antonio Rüdiger":"ALE","Dean Huijsen":"ESP",
 "Álvaro Carreras":"ESP","Ferland Mendy":"FRA","A. Tchouaméni":"FRA","Federico Valverde":"URU","Jude Bellingham":"ING",
 "Eduardo Camavinga":"FRA","Arda Güler":"TUR","Rodrygo":"BRA","Vinicius Junior":"BRA","Kylian Mbappé":"FRA","F. Mastantuono":"ARG",
 # Barcelona
 "Joan García":"ESP","Marc ter Stegen":"ALE","Jules Koundé":"FRA","Ronald Araújo":"URU","Pau Cubarsí":"ESP","Eric García":"ESP",
 "Alejandro Balde":"ESP","Frenkie de Jong":"HOL","Pedri":"ESP","Gavi":"ESP","Fermín López":"ESP","Dani Olmo":"ESP","Lamine Yamal":"ESP",
 "Raphinha":"BRA","R. Lewandowski":"POL","Ferran Torres":"ESP","Marcus Rashford":"ING",
 # Atlético de Madrid
 "Jan Oblak":"SVN","Marcos Llorente":"ESP","Juan Giménez":"URU","Robin Le Normand":"ESP","Clément Lenglet":"FRA","Dávid Hancko":"SVK",
 "Koke":"ESP","Pablo Barrios":"ESP","Conor Gallagher":"ING","Álex Baena":"ESP","Giuliano Simeone":"ARG","Nico González":"ARG",
 "Antoine Griezmann":"FRA","Julián Alvarez":"ARG","Alexander Sørloth":"NOR",
 # Manchester City
 "G. Donnarumma":"ITA","Rúben Dias":"POR","Josko Gvardiol":"CRO","John Stones":"ING","Rico Lewis":"ING","Nathan Aké":"HOL","Rodri":"ESP",
 "Bernardo Silva":"POR","Tijjani Reijnders":"HOL","Rayan Cherki":"FRA","Phil Foden":"ING","Jérémy Doku":"BEL","Omar Marmoush":"EGI",
 "Erling Haaland":"NOR","Savinho":"BRA",
 # Liverpool
 "Alisson":"BRA","Jeremie Frimpong":"HOL","Virgil van Dijk":"HOL","Ibrahima Konaté":"FRA","Milos Kerkez":"HUN","Andrew Robertson":"ESC",
 "Ryan Gravenberch":"HOL","Mac Allister":"ARG","D. Szoboszlai":"HUN","Florian Wirtz":"ALE","Curtis Jones":"ING","Mohamed Salah":"EGI",
 "Cody Gakpo":"HOL","Hugo Ekitiké":"FRA","Alexander Isak":"SUE","Federico Chiesa":"ITA",
 # Arsenal
 "David Raya":"ESP","Ben White":"ING","Jurriën Timber":"HOL","William Saliba":"FRA","Gabriel Magalhães":"BRA","R. Calafiori":"ITA",
 "Declan Rice":"ING","Martín Zubimendi":"ESP","Martin Ødegaard":"NOR","Eberechi Eze":"ING","Mikel Merino":"ESP","Bukayo Saka":"ING",
 "G. Martinelli":"BRA","Leandro Trossard":"BEL","Viktor Gyökeres":"SUE","Kai Havertz":"ALE","Noni Madueke":"ING",
 # Chelsea
 "Robert Sánchez":"ESP","Reece James":"ING","Malo Gusto":"FRA","Levi Colwill":"ING","Wesley Fofana":"FRA","Trevoh Chalobah":"ING",
 "Marc Cucurella":"ESP","Moisés Caicedo":"EQU","Enzo Fernández":"ARG","Cole Palmer":"ING","Pedro Neto":"POR","Jamie Gittens":"ING",
 "Estêvão":"BRA","João Pedro|Chelsea":"BRA","Liam Delap":"ING","A. Garnacho":"ARG",
 # Manchester United
 "Altay Bayındır":"TUR","Diogo Dalot":"POR","Matthijs de Ligt":"HOL","Harry Maguire":"ING","Lisandro Martínez":"ARG","Leny Yoro":"FRA",
 "Luke Shaw":"ING","Casemiro":"BRA","Manuel Ugarte":"URU","Bruno Fernandes":"POR","Kobbie Mainoo":"ING","Bryan Mbeumo":"CMR",
 "Matheus Cunha":"BRA","Amad Diallo":"CIV","Benjamin Šeško":"SVN",
 # Bayern
 "Manuel Neuer":"ALE","Josip Stanisic":"CRO","Dayot Upamecano":"FRA","Jonathan Tah":"ALE","Min-jae Kim":"COR","Alphonso Davies":"CAN",
 "Joshua Kimmich":"ALE","A. Pavlovic":"ALE","Leon Goretzka":"ALE","Jamal Musiala":"ALE","Michael Olise":"FRA","Luis Díaz":"COL",
 "Serge Gnabry":"ALE","Harry Kane":"ING","Nicolas Jackson":"SEN",
 # Dortmund
 "Gregor Kobel":"SUI","Julian Ryerson":"NOR","N. Schlotterbeck":"ALE","Waldemar Anton":"ALE","Ramy Bensebaini":"ALG","Emre Can":"ALE",
 "Felix Nmecha":"ALE","Marcel Sabitzer":"AUT","Jobe Bellingham":"ING","Julian Brandt":"ALE","Karim Adeyemi":"ALE","Maximilian Beier":"ALE",
 "Serhou Guirassy":"GUI",
 # PSG
 "Lucas Chevalier":"FRA","Achraf Hakimi":"MAR","Marquinhos|Paris Saint-Germain":"BRA","Willian Pacho":"EQU","Lucas Beraldo":"BRA",
 "Nuno Mendes":"POR","Vitinha|Paris Saint-Germain":"POR","João Neves":"POR","Fabián Ruiz":"ESP","W. Zaïre-Emery":"FRA","Désiré Doué":"FRA",
 "K. Kvaratskhelia":"GEO","Bradley Barcola":"FRA","Ousmane Dembélé":"FRA","Gonçalo Ramos":"POR",
 # Inter
 "Yann Sommer":"SUI","Denzel Dumfries":"HOL","A. Bastoni":"ITA","Francesco Acerbi":"ITA","Stefan de Vrij":"HOL","Yann Bisseck":"ALE",
 "Federico Dimarco":"ITA","Hakan Çalhanoğlu":"TUR","Nicolò Barella":"ITA","H. Mkhitaryan":"ARM","Davide Frattesi":"ITA","Petar Sučić":"CRO",
 "Lautaro Martínez":"ARG","Marcus Thuram":"FRA","Ange-Yoan Bonny":"FRA",
 # Milan
 "Mike Maignan":"FRA","Koni De Winter":"BEL","Fikayo Tomori":"ING","S. Pavlović":"SER","Pervis Estupiñán":"EQU","A. Saelemaekers":"BEL",
 "Youssouf Fofana":"FRA","Luka Modrić":"CRO","Adrien Rabiot":"FRA","R. Loftus-Cheek":"ING","Christian Pulisic":"USA","Rafael Leão":"POR",
 "Santiago Gimenez":"MEX",
 # Juventus
 "Di Gregorio":"ITA","Pierre Kalulu":"FRA","Bremer":"BRA","Federico Gatti":"ITA","Lloyd Kelly":"ING","Andrea Cambiaso":"ITA",
 "Manuel Locatelli":"ITA","Khéphren Thuram":"FRA","Weston McKennie":"USA","Teun Koopmeiners":"HOL","Kenan Yıldız":"TUR",
 "F. Conceição":"POR","Dušan Vlahović":"SER","Jonathan David":"CAN","Loïs Openda":"BEL",
 # Napoli
 "Alex Meret":"ITA","Vladimir Savic":"MNE","Di Lorenzo":"ITA","Amir Rrahmani":"KOS","A. Buongiorno":"ITA","Sam Beukema":"HOL",
 "Mathías Olivera":"URU","L. Spinazzola":"ITA","Stanislav Lobotka":"SVK","Kevin De Bruyne":"BEL","Scott McTominay":"ESC",
 "Frank Anguissa":"CMR","Matteo Politano":"ITA","David Neres":"BRA","Romelu Lukaku":"BEL","Rasmus Højlund":"DIN",
}
ARG_CLUBS = {"River Plate", "Boca Juniors"}


def main():
    d = json.load(open(os.path.join(ROOT, "assets/data/rosters_real.json"), encoding="utf-8"))
    out = ["# Os 37 elencos que já vinham no projeto, agora com a nacionalidade de cada jogador.",
           "# Formato: Nome, POS, idade, nota, país"]
    missing = []
    for club, plist in d.items():
        old = [p for p in plist if len(p) < 5]
        if not old:
            continue
        out.append("## " + club)
        for p in plist:
            nat = p[4] if len(p) > 4 else NAT.get(p[0] + "|" + club, NAT.get(p[0]))
            if nat is None:
                if club in BR_CLUBS:
                    nat = "BRA"
                elif club in ARG_CLUBS:
                    nat = "ARG"
                else:
                    missing.append(f"{club}: {p[0]}")
                    continue
            out.append(f"{p[0]}, {p[1]}, {p[2]}, {p[3]}, {nat}")
    if missing:
        print("SEM PAÍS:", "; ".join(missing))
        raise SystemExit(1)
    open(os.path.join(ROOT, "analise/elencos_fonte/originais.txt"), "w", encoding="utf-8").write("\n".join(out) + "\n")
    print("ok", sum(1 for l in out if not l.startswith("#")))


if __name__ == "__main__":
    main()
