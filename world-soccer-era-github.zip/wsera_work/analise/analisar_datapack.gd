extends SceneTree
## Inventário completo do datapack que vem no jogo (assets/datapack) e da ligação com as ligas
## e clubes de World.LEAGUES. Usa as mesmas funções do jogo (DataPack.pack_id, comp_id...).
##
## Rodar (na raiz do projeto):
##   godot --headless --path . -s analise/analisar_datapack.gd
## Gera: analise/datapack.md, analise/clubes.csv, analise/ligas.csv, analise/placas.csv

const BUNDLED := "res://assets/datapack/"
const OUT := "res://analise/"


func _files(dir_path: String) -> Array:
	var out: Array = []
	var d := DirAccess.open(dir_path)
	if d == null:
		return out
	for f in d.get_files():
		var fn: String = f.trim_suffix(".import").trim_suffix(".remap")
		if fn.ends_with(".webp") and not (fn in out):
			out.append(fn)
	out.sort()
	return out


func _dirs(dir_path: String) -> Array:
	var d := DirAccess.open(dir_path)
	if d == null:
		return []
	var a: Array = Array(d.get_directories())
	a.sort()
	return a


func _csv(v) -> String:
	var s := str(v)
	if s.contains(",") or s.contains("\"") or s.contains("\n"):
		return "\"" + s.replace("\"", "\"\"") + "\""
	return s


func _write(path: String, text: String) -> void:
	var f := FileAccess.open(ProjectSettings.globalize_path(path), FileAccess.WRITE)
	f.store_string(text)
	f.close()


func _init() -> void:
	var real: Dictionary = {}
	var rj = JSON.parse_string(FileAccess.get_file_as_string("res://assets/data/rosters_real.json"))
	if typeof(rj) == TYPE_DICTIONARY:
		real = rj
	var logos := _files(BUNDLED + "logos")
	var comps := _files(BUNDLED + "comps")
	var logo_set := {}
	for f in logos:
		logo_set[int(f.get_basename())] = true
	var comp_set := {}
	for f in comps:
		comp_set[int(f.get_basename())] = true
	var ad_dirs := _dirs(BUNDLED + "adboards")
	var ad_count := {}
	var ad_total := 0
	for k in ad_dirs:
		var n := _files(BUNDLED + "adboards/" + k).size()
		ad_count[k] = n
		ad_total += n

	# --- clubes
	var clubes := PackedStringArray(["liga,pais,clube,sigla,forca,id_escudo,tem_escudo,elenco_real"])
	var ligas := PackedStringArray(["liga,pais,id_competicao,tem_logo,clubes,clubes_com_escudo,clubes_com_elenco_real,placas_pais"])
	var used_logo := {}
	var miss_club: Array = []
	var miss_comp: Array = []
	var lg_rows: Array = []
	var tot_clubs := 0
	var tot_crest := 0
	var tot_real := 0
	for li in World.LEAGUES.size():
		var lg: Dictionary = World.LEAGUES[li]
		var cid := DataPack.comp_id(li)
		var has_comp: bool = comp_set.has(cid)
		if not has_comp:
			miss_comp.append("%s (id %d)" % [lg["name"], cid])
		var n_crest := 0
		var n_real := 0
		for ci in lg["clubs"].size():
			var info: Array = lg["clubs"][ci]
			var pid := DataPack.pack_id(li, ci)
			var has: bool = logo_set.has(pid)
			if has:
				n_crest += 1
				used_logo[pid] = true
			else:
				miss_club.append("%s — %s" % [lg["name"], info[0]])
			var nr: int = (real.get(lg["name"] + "|" + info[0], real.get(info[0], [])) as Array).size()
			if nr > 0:
				n_real += 1
			clubes.append(",".join([_csv(lg["name"]), _csv(lg["country"]), _csv(info[0]), _csv(info[1]), str(info[4]), str(pid), "sim" if has else "nao", str(nr)]))
		tot_clubs += lg["clubs"].size()
		tot_crest += n_crest
		tot_real += n_real
		var ad_key := "country-" + str(DataPack.AD_COUNTRY.get(lg["country"], "?"))
		var n_ads: int = int(ad_count.get(ad_key, 0))
		ligas.append(",".join([_csv(lg["name"]), _csv(lg["country"]), str(cid), "sim" if has_comp else "nao", str(lg["clubs"].size()), str(n_crest), str(n_real), str(n_ads)]))
		lg_rows.append([lg["name"], lg["country"], cid, has_comp, lg["clubs"].size(), n_crest, n_real, n_ads])
	_write(OUT + "clubes.csv", "\n".join(clubes) + "\n")
	_write(OUT + "ligas.csv", "\n".join(ligas) + "\n")
	var placas := PackedStringArray(["pasta,imagens"])
	for k in ad_dirs:
		placas.append("%s,%d" % [k, ad_count[k]])
	_write(OUT + "placas.csv", "\n".join(placas) + "\n")

	# --- copas
	var cup_lines: Array = []
	var used_comp := {}
	for li in World.LEAGUES.size():
		used_comp[DataPack.comp_id(li)] = true
	for d in World.CUPS.size():
		var cd: Dictionary = World.CUPS[d]
		var id := int(cd.get("comp", -1))
		used_comp[id] = true
		cup_lines.append("| %s | %d | %s |" % [cd["name"], id, "sim" if comp_set.has(id) else "não (emblema padrão)"])

	# --- imagens órfãs
	var orphan_logos := 0
	for id in logo_set.keys():
		if not used_logo.has(id):
			orphan_logos += 1
	var orphan_comps := 0
	for id in comp_set.keys():
		if not used_comp.has(id):
			orphan_comps += 1
	# placas de país das ligas do jogo
	var countries_without_ads: Array = []
	var seen_c := {}
	for lg in World.LEAGUES:
		var c: String = lg["country"]
		if seen_c.has(c):
			continue
		seen_c[c] = true
		var key := "country-" + str(DataPack.AD_COUNTRY.get(c, "?"))
		if int(ad_count.get(key, 0)) == 0:
			countries_without_ads.append(c)

	# --- relatório
	var md := PackedStringArray()
	md.append("# Análise do datapack — World Soccer: Era")
	md.append("")
	md.append("Gerado por `analise/analisar_datapack.gd` (rode de novo depois de mudar o pacote ou as ligas):")
	md.append("`godot --headless --path . -s analise/analisar_datapack.gd`. Dados brutos em `clubes.csv`, `ligas.csv` e `placas.csv`.")
	md.append("")
	md.append("## O que o pacote tem")
	md.append("")
	md.append("| Pasta | Arquivos | Conteúdo |")
	md.append("|---|---|---|")
	md.append("| `assets/datapack/logos/` | %d | escudos de clubes (`ID.webp`) |" % logos.size())
	md.append("| `assets/datapack/comps/` | %d | logos de competições (`ID.webp`) |" % comps.size())
	md.append("| `assets/datapack/adboards/` | %d imagens em %d pastas | placas de publicidade por país, continente e competição |" % [ad_total, ad_dirs.size()])
	md.append("")
	md.append("## O que o pacote NÃO tem")
	md.append("")
	md.append("- **Nenhum nome de jogador.** Não há `players.csv`, `elencos.csv`, `clubs.csv`, `competitions.csv` nem `stadiums.csv`:")
	md.append("  o projeto foi enviado sem o `datapack.zip` original. Só existem imagens.")
	md.append("- Por isso os elencos reais vêm de `assets/data/rosters_real.json` (ver `analise/elencos.md`); clubes sem elenco")
	md.append("  real têm jogadores gerados com nomes do país da liga.")
	md.append("- Nomes de clubes e estádios do pacote também não existem: os nomes vêm de `src/world_data.gd`.")
	md.append("- Se você tiver o `datapack.zip` original (com `elencos.csv`), coloque-o na raiz do projeto: o jogo importa e ele tem")
	md.append("  prioridade sobre o `rosters_real.json`.")
	md.append("")
	md.append("## Ligação com as ligas do jogo")
	md.append("")
	md.append("- Ligas: %d, com logo no pacote: %d." % [World.LEAGUES.size(), World.LEAGUES.size() - miss_comp.size()])
	md.append("- Clubes: %d, com escudo: %d (%.1f%%)." % [tot_clubs, tot_crest, 100.0 * tot_crest / maxf(tot_clubs, 1)])
	md.append("- Clubes com elenco real (rosters_real.json): %d." % tot_real)
	md.append("- Escudos do pacote que nenhum clube do jogo usa: %d de %d (clubes de ligas que o jogo não tem)." % [orphan_logos, logos.size()])
	md.append("- Logos de competição sem uso no jogo: %d de %d." % [orphan_comps, comps.size()])
	md.append("")
	md.append("| Liga | País | ID | Logo | Clubes | Com escudo | Elenco real | Placas do país |")
	md.append("|---|---|---|---|---|---|---|---|")
	for r in lg_rows:
		md.append("| %s | %s | %d | %s | %d | %d | %d | %d |" % [r[0], r[1], r[2], "sim" if r[3] else "**não**", r[4], r[5], r[6], r[7]])
	md.append("")
	md.append("## Copas")
	md.append("")
	md.append("| Copa | ID | Logo no pacote |")
	md.append("|---|---|---|")
	md.append_array(PackedStringArray(cup_lines))
	md.append("")
	md.append("## Ligas sem logo no pacote (usam o emblema padrão)")
	md.append("")
	for m in miss_comp:
		md.append("- " + m)
	md.append("")
	md.append("## Clubes sem escudo no pacote (usam o escudo desenhado)")
	md.append("")
	for m in miss_club:
		md.append("- " + m)
	md.append("")
	md.append("## Placas de publicidade")
	md.append("")
	md.append("Países das ligas do jogo sem pasta de placas (a partida usa as placas genéricas, %d imagens): %s." % [int(ad_count.get("generic", 0)), ", ".join(countries_without_ads) if not countries_without_ads.is_empty() else "nenhum"])
	md.append("A contagem por pasta está em `placas.csv`.")
	_write(OUT + "datapack.md", "\n".join(md) + "\n")
	print("ANALISE OK clubes=%d escudos=%d ligas_sem_logo=%d orfaos=%d" % [tot_clubs, tot_crest, miss_comp.size(), orphan_logos])
	quit()
