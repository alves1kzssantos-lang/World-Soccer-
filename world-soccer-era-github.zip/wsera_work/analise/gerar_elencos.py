#!/usr/bin/env python3
"""Monta assets/data/rosters_real.json a partir de analise/elencos_fonte/*.txt.

Formato das fontes:
    ## Nome do clube   (exatamente como em src/world_data.gd)
    ## Liga|Nome do clube   (obrigatório quando o nome existe em ligas de países diferentes)
    Nome do jogador, POS, idade, nota, PAÍS
Os clubes que já estavam no JSON e não aparecem nas fontes são mantidos.
Rodar na raiz do projeto:  python3 analise/gerar_elencos.py
"""
import json, os, re, sys, unicodedata, glob

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JSON_PATH = os.path.join(ROOT, "assets/data/rosters_real.json")
POS = {"GOL", "ZAG", "LD", "LE", "VOL", "MEI", "PD", "PE", "AC"}
# correções em elencos antigos do JSON (jogadores que trocaram de clube na janela de 2025)
REMOVE = {"Milan": ["Samuel Chukwueze"], "Botafogo": ["Igor Jesus"], "Manchester United": ["André Onana"]}
# Calibragem de notas (ver analise/elencos.md, "Calibragem"):
#   xi = média das 11 maiores notas reais do clube; alvo = força do clube em world_data.gd
#   se |xi - alvo| > TOLERANCIA, todas as notas do clube andam (alvo - xi) - sinal * TOLERANCIA
# Só vale para clubes com 11 ou mais jogadores reais.
TOLERANCIA = 3
RENAME = {"Sport Recife": "Sport"}


def norm(s):
    s = unicodedata.normalize("NFKD", s.lower())
    return re.sub(r"[^a-z0-9]", "", "".join(c for c in s if not unicodedata.combining(c)))


def world_clubs():
    src = open(os.path.join(ROOT, "src/world_data.gd"), encoding="utf-8").read()
    out = {}
    for block in re.split(r'\n\t\{"name": "', src)[1:]:
        league = block.split('"')[0]
        cm = re.search(r'"country": "([^"]+)"', block.split("\n")[0])
        if cm is None:
            continue   # copas e outras tabelas
        country = cm.group(1)
        body = block.split("]]")[0]
        for m in re.finditer(r'\["([^"]+)", "([^"]+)", "[^"]*", "[^"]*", (\d+)', body):
            out.setdefault(m.group(1), []).append((league, int(m.group(3)), country))
            out.setdefault(league + "|" + m.group(1), []).append((league, int(m.group(3)), country))
    return out


def ambiguous(world, club):
    """Nome usado por clubes de países diferentes (ex.: Independiente na Argentina e na Colômbia)."""
    return "|" not in club and len({c for _, _, c in world.get(club, [])}) > 1


def main():
    data = json.load(open(JSON_PATH, encoding="utf-8"))
    for old, new in RENAME.items():
        if old in data:
            data[new] = data.pop(old)
    for club, names in REMOVE.items():
        data[club] = [p for p in data.get(club, []) if p[0] not in names]
    errors = []
    world_pre = world_clubs()
    for club in [k for k in data if ambiguous(world_pre, k)]:
        del data[club]   # chave antiga sem liga; as fontes trazem "Liga|Clube"
    for path in sorted(glob.glob(os.path.join(ROOT, "analise/elencos_fonte/*.txt"))):
        club = None
        for n, line in enumerate(open(path, encoding="utf-8"), 1):
            line = line.strip()
            if not line or (line.startswith("#") and not line.startswith("##")):
                continue
            if line.startswith("##"):
                club = line[2:].strip()
                data[club] = []
                continue
            parts = [p.strip() for p in line.split(",")]
            if len(parts) != 5 or club is None:
                errors.append(f"{os.path.basename(path)}:{n}: linha inválida: {line}")
                continue
            name, pos, age, ovr, nat = parts
            if pos not in POS or not age.isdigit() or not ovr.isdigit():
                errors.append(f"{os.path.basename(path)}:{n}: campo inválido: {line}")
                continue
            data[club].append([name, pos, int(age), max(40, min(94, int(ovr))), nat])
    world = world_clubs()
    seen = {}
    shifted = []
    for club, plist in data.items():
        if club not in world:
            errors.append(f"clube fora de World.LEAGUES: {club}")
            continue
        if ambiguous(world, club):
            ligas = ", ".join(sorted({l for l, _, _ in world[club]}))
            errors.append(f"nome de clube ambíguo, use '## Liga|{club}' ({ligas})")
            continue
        # mesmo nome E mesma idade = a mesma pessoa (no Brasil há muitos "Gabriel", "Allan"...)
        for p in plist:
            if len(p) < 5 or not str(p[4]).strip():
                errors.append(f"jogador sem país: {p[0]} ({club})")
            k = norm(p[0]) + "|" + str(p[2])
            if k in seen and seen[k] != club:
                errors.append(f"jogador repetido: {p[0]} ({seen[k]} e {club})")
            seen[k] = club
        if len(plist) >= 11:
            target = max(st for _, st, _ in world[club])
            top = sorted((p[3] for p in plist), reverse=True)[:11]
            xi = sum(top) / 11.0
            diff = target - xi
            if abs(diff) > TOLERANCIA + 0.5:
                d = round(diff - (TOLERANCIA if diff > 0 else -TOLERANCIA))
                for p in plist:
                    p[3] = max(40, min(94, p[3] + d))
                shifted.append(f"{club}: média XI {xi:.1f}, força {target}, ajuste {d:+d}")
    if errors:
        print("\n".join(errors))
        sys.exit(1)
    data = {k: v for k, v in data.items() if v}
    with open(JSON_PATH, "w", encoding="utf-8") as f:
        f.write("{\n")
        items = list(data.items())
        for i, (club, plist) in enumerate(items):
            f.write(f" {json.dumps(club, ensure_ascii=False)}: [\n")
            f.write(",\n".join("  " + json.dumps(p, ensure_ascii=False) for p in plist))
            f.write("\n ]" + ("," if i < len(items) - 1 else "") + "\n")
        f.write("}\n")
    for line in shifted:
        print("calibragem:", line)
    print(f"OK: {len(data)} clubes, {sum(len(v) for v in data.values())} jogadores")


if __name__ == "__main__":
    main()
