# Elencos reais — World Soccer: Era

## De onde vêm os jogadores

O datapack que veio no projeto **não tem nenhum nome de jogador** (só escudos, logos e placas — ver `datapack.md`).
Os jogadores reais ficam em `assets/data/rosters_real.json`, montado a partir das fontes editáveis em
`analise/elencos_fonte/*.txt` pelo script `analise/gerar_elencos.py`.

- **158 clubes** com elenco real, **2165 jogadores**.
- Ordem de prioridade na carreira: `elencos.csv` de um `datapack.zip` importado (se existir) → `rosters_real.json` →
  jogadores gerados para completar as vagas do elenco.

## Data e fontes

- **Base: temporada 2025/26** (elencos depois da janela de transferências do meio de 2025). Argentina, Brasil,
  EUA e México: temporada 2025 (calendário anual).
- Fonte: conhecimento do assistente sobre os elencos dessa temporada, com revisão manual de transferências
  conhecidas (ex.: Mamardashvili → Liverpool, Greif → Lyon, Onana emprestado ao Trabzonspor, Chukwueze → Fulham,
  Igor Jesus → Nottingham Forest). Não houve consulta a uma base oficial.
- **Transferências depois dessa data não estão refletidas.** O jogo está em novembro de 2026: espere jogadores em
  clubes antigos, aposentados ou com idade/nota defasada. Corrija editando o `.txt` da liga e rodando o script.
- Regra seguida: **nenhum nome inventado.** Onde a confiança era menor (Série B, MLS, clubes menores da Argentina,
  Portugal, Holanda e Arábia), só entraram os jogadores conhecidos com segurança; o resto do elenco é gerado.

## Cobertura por liga (clubes com elenco real / total)

| Liga | Clubes |
|---|---|
| Brasileirão Série A | 20 / 20 |
| Brasileirão Série B | 4 / 20 |
| Liga Argentina | 9 / 20 |
| Premier League | 20 / 20 |
| La Liga | 20 / 20 |
| Serie A Itália | 20 / 20 |
| Bundesliga | 18 / 18 |
| Ligue 1 | 18 / 18 |
| Liga Portugal | 4 / 18 |
| Eredivisie | 4 / 18 |
| Jupiler Pro League | 2 / 16 |
| Süper Lig | 4 / 18 |
| Saudi Pro League | 6 / 18 |
| Major League Soccer | 3 / 28 |
| Liga MX Apertura | 6 / 16 |
| Campeonato Paulista | 6 / 16 |
| Campeonato Carioca | 4 / 12 |
| Campeonato Mineiro | 2 / 12 |
| Campeonato Gaúcho | 3 / 12 |
| Campeonato Paranaense | 2 / 12 |
| Campeonato Catarinense | 1 / 12 |

Total: 176 vagas de clube cobertas em 1008 (os estaduais
brasileiros reaproveitam os elencos dos clubes de Série A/B). Ligas sem nenhuma linha acima usam só jogadores gerados.

## Regras do jogo (src/game.gd)

- `_add_real_players`: entram primeiro, com posição, idade, nota e país do JSON. Elenco **parcial** (menos de 11)
  também é usado — antes era descartado.
- `_fill_squad`: completa o modelo do elenco (24 vagas) só nas posições que faltam. Com elenco real parcial, os
  gerados titulares ficam 2 pontos abaixo da força do clube; reservas, 5.
- **Ninguém em dois clubes:** a chave é *nome + idade de origem* (no Brasil há vários "Gabriel", "Allan",
  "Fernando" que são pessoas diferentes). Vale também para clubes convidados nas copas.
- **Nome repetido em países diferentes** (Independiente, Tigres, Everton) usa a chave `Liga|Clube` no JSON; o jogo
  procura primeiro com a liga, então o Independiente colombiano não recebe o elenco argentino.

## Calibragem das notas

Fórmula (em `gerar_elencos.py`, botão de ajuste `TOLERANCIA = 3`):

    xi    = média das 11 maiores notas reais do clube
    alvo  = força do clube em src/world_data.gd
    se |xi - alvo| > TOLERANCIA + 0.5:
        ajuste = arredonda((alvo - xi) - sinal(alvo - xi) * TOLERANCIA)
        nota de cada jogador do clube += ajuste   (limitada a 40..94)

Só vale para clubes com 11+ jogadores reais. Na última geração só o Bayer Leverkusen precisou de ajuste (+2).
Assim a força do time na simulação continua coerente com a tabela de forças, e jogadores gerados (força ± 3)
não ficam melhores que os titulares reais.

## Como atualizar

    # 1) edite analise/elencos_fonte/<liga>.txt  (## Clube  /  Nome, POS, idade, nota, PAÍS)
    python3 analise/gerar_elencos.py          # valida clubes, posições, duplicados e calibra
    godot --headless --path . res://tests/run_tests.tscn
    godot --headless --path . -s analise/analisar_datapack.gd   # atualiza datapack.md e os CSVs

Siglas de país seguem o padrão do jogo (BRA, ARG, ING, ALE, HOL, POR...); são só texto exibido. **Todo jogador real
tem país** (o gerador recusa linha sem país). Os 37 elencos que já vinham no projeto não tinham país: foram
convertidos uma vez por `analise/nacionalidades_originais.py` para `elencos_fonte/originais.txt`. Se mesmo assim
um jogador real chegar sem país (ex.: `elencos.csv` de um datapack), o jogo usa o país da liga do clube.

## Verificação

- `tests/unit/rosters/test_rosters_real.gd`: clubes existem em World.LEAGUES, posições/idades/notas válidas,
  ninguém em dois clubes, todo elenco completo tem goleiro, carreira nova em 8 ligas coloca os nomes reais no
  clube certo, elenco parcial entra, nomes iguais em países diferentes não se misturam.
- `tests/all_leagues.tscn`: uma temporada inteira em cada uma das 58 ligas, sem erro e com campeão em todas as copas.
