extends Node
## Capturas de Finanças, elenco com energia, escalação (treino) e perfil.
## Rodar com tela: godot --path . res://tests/shots_economia.tscn  (SHOTS_DIR = pasta das imagens)
var out := ""
var main


func wait(sec: float) -> void:
	await get_tree().create_timer(sec).timeout


func shot(name: String) -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	img.save_png(out + "%s_%dx%d.png" % [name, img.get_width(), img.get_height()])


func _ready() -> void:
	out = OS.get_environment("SHOTS_DIR")
	if out == "":
		out = ProjectSettings.globalize_path("res://production/qa/evidence/")
	DirAccess.make_dir_recursive_absolute(out)
	if not out.ends_with("/"):
		out += "/"
	Game.delete_save(4)
	Game.rng.seed = 41
	main = load("res://main.tscn").instantiate()
	add_child(main)
	await wait(1.0)
	var coach = {"name": "Alves", "age": 38, "nat": "Brasil", "skin": 2, "hair": 1, "haircolor": 0, "beard": 1, "suit": 0, "rep": 5.0}
	Game.new_career(4, coach, 0, 0)
	for i in 9:
		Game.play_next(null)
		while Media.has_interview():
			Media.answer("humilde")
	# um titular cansado e um lesionado para aparecer nas telas
	var sq: Array = Game.squad(Game.S["club"])
	var xi: Array = Game.my_club()["xi"]
	Game.player(xi[3])["energy"] = 48.0
	Game.player(xi[5])["energy"] = 61.0
	Game.player(xi[7])["energy"] = 52.0
	for sz in [Vector2i(1280, 720), Vector2i(1600, 720), Vector2i(1280, 960)]:
		get_window().size = sz
		await wait(0.4)
		main.reset("hub")
		main.go("finance")
		await wait(0.6)
		await shot("financas")
	get_window().size = Vector2i(1280, 720)
	await wait(0.4)
	main.reset("hub")
	main.go("squad")
	await wait(0.6)
	await shot("elenco_energia")
	main.go("lineup")
	await wait(0.6)
	await shot("escalacao_treino")
	main.go("player", xi[3])
	await wait(0.6)
	await shot("perfil_energia")
	Game.delete_save(4)
	get_tree().quit()
