extends Node
## Grava a partida contínua: a jogada do seu time chega perto do gol, desacelera, congela
## no mesmo campo para você decidir, e segue. Quadros em SHOTS_DIR (ou scratch/partida_frames).
## Rodar: godot --path . --fixed-fps 30 --resolution 1280x576 res://tests/shots_partida.tscn
var main
var out := ""
var n := 0
var rec := false


func _snap() -> void:
	await RenderingServer.frame_post_draw
	if rec and n < 420:
		get_viewport().get_texture().get_image().save_png(out + "f%04d.png" % n)
		n += 1


func _ready() -> void:
	out = OS.get_environment("SHOTS_DIR")
	DirAccess.make_dir_recursive_absolute(out)
	if not out.ends_with("/"):
		out += "/"
	Game.delete_save(0)
	Game.rng.seed = 4242
	var suite = load("res://tests/integration/match/test_match_balance.gd").new()
	main = load("res://main.tscn").instantiate()
	add_child(main)
	while not DataPack.loaded():
		await get_tree().process_frame
	var coach = {"name": "Alves", "age": 35, "nat": "Brasil", "skin": 2, "hair": 1, "haircolor": 0, "beard": 1, "suit": 0, "rep": 5.0}
	Game.new_career(0, coach, 3, 0)
	main.home()
	await get_tree().create_timer(0.5).timeout
	main.go("match")
	await get_tree().create_timer(1.0).timeout
	var mv = main.body.get_child(0)
	mv._start()
	mv.speed = 2   # acelera até a chance aparecer
	var guard := 0
	var done_after := -1
	while guard < 30 * 600:
		guard += 1
		# espera a chance do seu time: a gravação começa no começo da chegada ao gol
		if not rec and not mv._pend.is_empty() and int(mv._pend["side"]) == mv.my_side:
			rec = true
			mv.speed = 1
		var L = mv.lance
		if rec and L != null and is_instance_valid(L) and L.user_ctrl and L.state == "decide" and L.t > 1.0:
			suite._auto_play(L)   # depois de 1 s congelado, joga (passe ou chute)
		if rec and L == null and mv._pend.is_empty() and done_after < 0:
			done_after = n + 75   # 2,5 s da partida seguindo depois do lance
		if rec and (n >= 420 or (done_after >= 0 and n >= done_after)):
			break
		await _snap()
		if not rec:
			await get_tree().process_frame
	print("PARTIDA FRAMES ", n)
	Game.delete_save(0)
	get_tree().quit()
