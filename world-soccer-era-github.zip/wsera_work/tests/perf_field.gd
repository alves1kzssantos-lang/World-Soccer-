extends Node
## Medição: custo de cada parte do passo de física do campo ao vivo.
## Rodar: godot --headless --path . res://tests/perf_field.tscn
func _ready():
	Game.rng.seed = 321
	var coach = {"name": "T", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.new_career(8, coach, 2, 0)
	var sim := MatchSim.new(0, 1)
	var fv := FieldView.new()
	fv.size = Vector2(1280, 720)
	fv.setup_field(sim)
	for i in 120: fv._tick_field(1.0/60.0)
	var N := 1200
	var t0 := Time.get_ticks_usec()
	for i in N: fv._tick_field(1.0/60.0)
	var tick := (Time.get_ticks_usec() - t0) / float(N)
	t0 = Time.get_ticks_usec()
	for i in N: fv.world.step(1.0/60.0)
	var wstep := (Time.get_ticks_usec() - t0) / float(N)
	t0 = Time.get_ticks_usec()
	for i in N: fv.world.collide()
	var col := (Time.get_ticks_usec() - t0) / float(N)
	t0 = Time.get_ticks_usec()
	for i in N: fv._step_bodies(fv._field_bodies, 1.0/60.0)
	var sb := (Time.get_ticks_usec() - t0) / float(N)
	t0 = Time.get_ticks_usec()
	for i in N: fv._ball_vs_bodies(fv._field_bodies, null, null)
	var bvb := (Time.get_ticks_usec() - t0) / float(N)
	t0 = Time.get_ticks_usec()
	for i in N:
		for sd in 2:
			for e in fv.teams[sd]:
				fv._move(e, fv._home(sd, e, fv.bp.pos), 5.0)
	var hm := (Time.get_ticks_usec() - t0) / float(N)
	t0 = Time.get_ticks_usec()
	for i in N:
		for e in fv._teams_all:
			if float(e.get("kick", 0.0)) > 0.0:
				e["kick"] = float(e["kick"]) - 0.016
			fv._tick_ent(e, 1.0/60.0)
	var te := (Time.get_ticks_usec() - t0) / float(N)
	t0 = Time.get_ticks_usec()
	for i in N: fv._nearest(0, fv.bp.pos)
	var nr := (Time.get_ticks_usec() - t0) / float(N)
	t0 = Time.get_ticks_usec()
	for i in N: Tuning.f("passe", "velocidade_chegada", 7.0)
	var tf := (Time.get_ticks_usec() - t0) / float(N)
	t0 = Time.get_ticks_usec()
	var c: Dictionary = fv.teams[0][3]
	for i in N: fv._touch(c, Vector2(0, 30), Vector2(1e9,1e9))
	var tc := (Time.get_ticks_usec() - t0) / float(N)
	t0 = Time.get_ticks_usec()
	for i in N:
		for b in fv.world.bodies:
			b.command(b.pos + Vector2(5, 3), 6.0)
		fv.world.step(1.0/60.0)
	var wcmd := (Time.get_ticks_usec() - t0) / float(N)
	t0 = Time.get_ticks_usec()
	for i in N:
		for b in fv.world.bodies:
			b.command(b.pos + Vector2(5, 3), 6.0, true)
		fv.world.step(1.0/60.0)
	var wcmd2 := (Time.get_ticks_usec() - t0) / float(N)
	print("PERF3 world.step commanded %.0f | commanded no-avoid %.0f" % [wcmd, wcmd2])
	print("PERF2 tick_ent+kick x22 %.0f | nearest %.1f | Tuning.f %.2f | touch %.1f" % [te, nr, tf, tc])
	print("PERF tick %.0f us | world.step %.0f | collide %.0f | step_bodies(sync+world) %.0f | ball_vs_bodies %.0f | home+move x22 %.0f" % [tick, wstep, col, sb, bvb, hm])
	fv.free()
	Game.delete_save(8)
	get_tree().quit()
