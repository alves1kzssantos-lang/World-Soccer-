extends Node
## Gravação para comparar o visual da partida (campo ao vivo e lance).
## godot --path . --resolution 1280x576 --fixed-fps 30 --write-movie DIR/frame.png res://tests/shots_visual.tscn
var suite
var phase := 0
var t := 0.0
var fv: FieldView
var lv: LanceView
var sim: MatchSim
var lances := 0

func _ready() -> void:
	Game.rng.seed = 2024
	var coach = {"name": "T", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.new_career(3, coach, 3, 0)
	suite = load("res://tests/integration/match/test_match_balance.gd").new()
	sim = MatchSim.new(Game.S["club"], (Game.S["club"] + 5) % 20)
	fv = FieldView.new()
	add_child(fv)
	fv.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fv.setup_field(sim)

func _process(delta: float) -> void:
	t += delta
	if phase == 0:
		if int(t * 2.0) != int((t - delta) * 2.0):
			for e in sim.step():
				if e["type"] == "goal":
					fv.kickoff(1 - e["side"])
			fv.feed_minute(sim.last_side)
		if t > 9.0:
			fv.queue_free()
			phase = 1
			_new_lance(true)
	elif phase == 1:
		if lv.state == "decide" and lv.user_ctrl and lv.t > 0.6:
			suite._auto_play(lv)
		if lv.state == "done" or lv.t > 9.0:
			lv.queue_free()
			lances += 1
			if lances >= 3:
				get_tree().quit()
				return
			_new_lance(lances != 1)

func _new_lance(user: bool) -> void:
	sim.pending = {"side": 0, "pg": 0.3}
	lv = LanceView.new()
	add_child(lv)
	lv.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	lv.setup(sim, 0, user)
	if not user:
		lv.script_kind = "goal"
