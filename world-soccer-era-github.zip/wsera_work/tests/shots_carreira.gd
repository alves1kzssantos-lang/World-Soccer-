extends Node
## Capturas das telas de carreira novas: renovação, empréstimo, banco na escalação,
## banco no intervalo da partida, propostas/empréstimos e perfil.
## Rodar com tela: SHOTS_DIR=... godot --path . res://tests/shots_carreira.tscn
var n := 0
var out := ""
var main


func shot(name: String) -> void:
	await RenderingServer.frame_post_draw
	n += 1
	get_viewport().get_texture().get_image().save_png(out + "carreira_%02d_%s.png" % [n, name])


func wait(sec: float) -> void:
	await get_tree().create_timer(sec).timeout


func _ready() -> void:
	out = OS.get_environment("SHOTS_DIR")
	if out == "":
		out = ProjectSettings.globalize_path("res://production/qa/evidence/")
	DirAccess.make_dir_recursive_absolute(out)
	if not out.ends_with("/"):
		out += "/"
	Game.delete_save(6)
	Game.rng.seed = 31
	main = load("res://main.tscn").instantiate()
	add_child(main)
	await wait(0.8)
	var coach = {"name": "Alves", "age": 35, "nat": "Brasil", "skin": 2, "hair": 1, "haircolor": 0, "beard": 1, "suit": 0, "rep": 5.0}
	Game.new_career(6, coach, 0, 0)
	var me: int = Game.S["club"]
	var sq := Game.squad(me)
	for k in [2, 6, 12]:
		sq[k]["contract"] = 1
	# um empréstimo de cada lado e um pedido da máquina
	var xi: Array = Game.my_club()["xi"]
	var spare: Array = sq.filter(func(p): return not (p["id"] in xi))
	Loans._start(spare[0], 19, false, 70, 2.5, 0.0)
	var av := Loans.available_in()
	Game.S["money"] = 200.0
	Loans.loan_in(av[3]["id"], true, int(Loans.terms_in(av[3])["pct"]), true)
	Loans.offers().append({"pid": spare[2]["id"], "club": 17, "pct": 80, "half": false, "buy": 3.2})
	main.home()
	await wait(0.8)
	await shot("hub")
	main.go("lineup")
	await wait(0.8)
	await shot("escalacao_banco")
	main.go("contract", {"renew": sq[2]["id"]})
	await wait(0.8)
	await shot("renovacao")
	main.back()
	main.go("contract", {"loan": av[5]["id"]})
	await wait(0.8)
	await shot("pedir_emprestimo")
	main.back()
	main.go("offers")
	await wait(0.8)
	await shot("propostas_emprestimos")
	main.go("player", spare[0]["id"])
	await wait(0.8)
	await shot("perfil_emprestado")
	main.go("player", sq[2]["id"])
	await wait(0.8)
	await shot("perfil_contrato_vencendo")
	main.go("market")
	main._keep[2].mk_tab = 2
	main.refresh()
	await wait(0.8)
	await shot("mercado_emprestimos")
	main.go("match")
	await wait(1.0)
	var mv = main.body.get_child(0)
	mv._kickoff()
	await wait(1.0)
	mv.sim.minute = 45
	mv._halftime()
	await wait(0.8)
	await shot("intervalo_banco")
	var c: Dictionary = Game.club(mv.sim.cid(mv.my_side))
	mv.sub_out = 9
	mv._subs_modal(mv._subs_title)
	await wait(0.4)
	var bp: Array = Game.bench(mv.sim.cid(mv.my_side))
	mv._sub_in(bp[1]["id"])
	await wait(0.6)
	await shot("intervalo_depois_da_troca")
	print("CARREIRA SHOTS DONE subs=", mv.sim.subs[mv.my_side], " xi=", c["xi"].size())
	Game.delete_save(6)
	get_tree().quit()
