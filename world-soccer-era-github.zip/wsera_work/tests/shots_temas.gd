extends Node
## Capturas dos temas por competição: hub, classificação, HUD do lance e abertura.
## Rodar com tela: godot --path . res://tests/shots_temas.tscn  (SHOTS_DIR = pasta das imagens)
var out := ""
var main


func wait(sec: float) -> void:
	await get_tree().create_timer(sec).timeout


func shot(name: String) -> void:
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(out + name + ".png")


func _ready() -> void:
	out = OS.get_environment("SHOTS_DIR")
	if out == "":
		out = ProjectSettings.globalize_path("res://production/qa/evidence/")
	DirAccess.make_dir_recursive_absolute(out)
	if not out.ends_with("/"):
		out += "/"
	var coach = {"name": "Alves", "age": 38, "nat": "Brasil", "skin": 2, "hair": 1, "haircolor": 0, "beard": 1, "suit": 0, "rep": 5.0}
	# [nome do arquivo, liga da carreira, competição do HUD/abertura]
	var cases := [["brasileirao", 0, "Brasileirão Série A"], ["libertadores", 0, "Copa Libertadores"], ["copa_brasil", 0, "Copa do Brasil"],
		["premier", 3, "Premier League"], ["champions", 3, "Champions League"], ["laliga", 4, "La Liga"],
		["padrao", 26, "Allsvenskan"]]
	main = load("res://main.tscn").instantiate()
	add_child(main)
	await wait(0.8)
	for c in cases:
		Game.rng.seed = 5
		Game.new_career(3, coach, 0, int(c[1]))
		Game.play_next(null)
		main.home()
		await wait(0.6)
		await shot("tema_%s_hub" % c[0])
		if str(c[2]) == str(World.LEAGUES[int(c[1])]["name"]):
			main.go("table")
			await wait(0.4)
			await shot("tema_%s_tabela" % c[0])
		await _hud(str(c[0]), str(c[2]))
		await _intro(str(c[0]), str(c[2]))
	Game.delete_save(3)
	print("TEMAS DONE")
	get_tree().quit()


func _hud(file: String, comp: String) -> void:
	main.visible = false
	var th := CompTheme.for_comp(comp)
	LanceView.set_hud_theme(th)
	var cid := -1
	for d in World.CUPS.size():
		if World.CUPS[d]["name"] == comp:
			cid = int(World.CUPS[d]["comp"])
	if cid < 0:
		cid = DataPack.comp_id(World.LEAGUES.map(func(l): return l["name"]).find(comp))
	LanceView.hud_logo = DataPack.comp_logo_or_badge(cid)
	var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 2) % 8)
	sim.minute = 63
	sim.score = [2, 1]
	sim.pending = {"side": 0, "pg": 0.3}
	var lv := LanceView.new()
	lv.size = Vector2(1280, 720)
	lv.stage_label = "Final" if cid != DataPack.comp_id(int(Game.S["league"])) else "Rodada 12"
	add_child(lv)
	lv.setup(sim, 0, false)
	lv.set_process(false)
	for i in 50:
		lv._process(1.0 / 60.0)
	lv.banner = "GOOOL!"
	lv.result = {"goal": true}
	lv.banner_t = 9.0
	await get_tree().process_frame
	await shot("tema_%s_hud" % file)
	lv.queue_free()
	main.visible = true
	await get_tree().process_frame


func _intro(file: String, comp: String) -> void:
	var it := CompIntro.new()
	it.title = comp
	it.sub = "Final" if comp != Game.LEAGUE else "Rodada 12"
	it.comp_th = CompTheme.for_comp(comp)
	it.accent = it.comp_th["accent"]
	it.tex = LanceView.hud_logo
	it.h = Game.S["club"]
	it.a = (Game.S["club"] + 2) % 8
	add_child(it)
	it.size = Vector2(1280, 720)
	await wait(1.9)
	await shot("tema_%s_abertura" % file)
	it.queue_free()
	await get_tree().process_frame
