extends Node
## Capturas da interface (menu, hub, pós-jogo, coletiva, redes) em vários tamanhos de tela.
## Rodar com tela: godot --path . res://tests/shots_ui.tscn  (SHOTS_DIR = pasta das imagens;
## SHOTS_SIZE = "1280x720" para um tamanho só; SHOTS_PRO = 1 para a carreira de jogador)
var out := ""
var main


func wait(sec: float) -> void:
	await get_tree().create_timer(sec).timeout


func shot(name: String) -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	img.save_png(out + "%s_%dx%d.png" % [name, img.get_width(), img.get_height()])


func _ready() -> void:
	out = OS.get_environment("SHOTS_DIR")
	if out == "":
		out = ProjectSettings.globalize_path("res://production/qa/evidence/")
	DirAccess.make_dir_recursive_absolute(out)
	if not out.ends_with("/"):
		out += "/"
	var sizes := [Vector2i(1280, 720), Vector2i(1600, 720), Vector2i(1280, 960)]
	var only := OS.get_environment("SHOTS_SIZE")
	Game.delete_save(4)
	Game.rng.seed = 31
	Media.R.seed = 31
	main = load("res://main.tscn").instantiate()
	add_child(main)
	await wait(1.0)
	if OS.get_environment("SHOTS_PRO") == "1":
		await _pro()
		return
	var coach = {"name": "Alves", "age": 38, "nat": "Brasil", "skin": 2, "hair": 1, "haircolor": 0, "beard": 1, "suit": 0, "rep": 5.0}
	Game.new_career(4, coach, 0, 0)
	for i in 3:
		Game.play_next(null)
		while Media.has_interview():
			Media.answer(["provocar", "humilde", "confiante"][i])
	Game.play_next(null)
	for sz in sizes:
		if only != "" and only != "%dx%d" % [sz.x, sz.y]:
			continue
		get_window().size = sz
		await wait(0.4)
		main.reset("title")
		await wait(0.7)
		await shot("menu")
		main.home()
		main.hub_tab = 0
		main.refresh()
		await wait(0.6)
		await shot("hub_jogos")
		main.go("postmatch", Game.S["last_user"])
		await wait(0.6)
		await shot("posjogo")
		main.go("interview")
		await wait(0.9)
		await shot("coletiva")
		main.hub_tab = 4
		main.home()
		await wait(0.6)
		await shot("hub_midia")
		main.go("social")
		await wait(0.6)
		await shot("redes")
	if OS.get_environment("SHOTS_EXTRA") == "1":
		get_window().size = Vector2i(1280, 720)
		await wait(0.4)
		main.home()
		main.go("squad")
		await wait(0.6)
		await shot("elenco")
		var best: Array = Game.squad(Game.S["club"])
		best.sort_custom(func(a, b): return int(a["ovr"]) > int(b["ovr"]))
		main.go("player", best[0]["id"])
		await wait(0.6)
		await shot("jogador")
		main.go("lineup")
		await wait(0.6)
		await shot("escalacao")
		main.reset("careers")
		await wait(0.6)
		await shot("carreiras")
		main._keep[0]._new(3)
		main._keep[0].coach["hair"] = 2
		main._keep[0].coach["skin"] = 3
		main.refresh()
		await wait(0.6)
		await shot("criar_tecnico")
		main.go("pro_create", {"slot": 3})
		await wait(0.6)
		await shot("criar_jogador")
		main.home()
		await wait(0.3)
		CupScreens.celebrate(main.overlay, "Brasileirão Série A", Game.club_name(Game.S["club"]), null, "ouro")
		await wait(2.6)
		await shot("trofeu")
	Game.delete_save(4)
	get_tree().quit()


func _pro() -> void:
	var prof := Pro.new_profile()
	prof["name"] = "Rafa Lima"
	prof["pos"] = "AC"
	Pro.start(4, prof)
	Game.play_next(null)
	Pro.accept(0)
	var guard := 0
	while not Media.has_interview() and guard < 8:
		guard += 1
		Game.play_next(null)
	get_window().size = Vector2i(1280, 720)
	await wait(0.4)
	main.reset("pro_post")
	await wait(0.6)
	await shot("pro_posjogo")
	main.go("interview")
	await wait(0.9)
	await shot("pro_entrevista")
	Game.delete_save(4)
	get_tree().quit()
