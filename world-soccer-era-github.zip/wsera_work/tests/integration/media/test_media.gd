extends RefCounted
## Coletiva pós-jogo e redes sociais (src/media.gd): perguntas pelo contexto,
## consequências salvas, feed com torcida/cornetas/imprensa/rivais e modo jogador.


func _fake_result(gf: int, ga: int) -> void:
	var me: int = Game.S["club"]
	var opp: int = (me + 1) % Game.n_league()
	Game.S["last_user"] = {"kind": "league", "round": 3, "comp": Game.LEAGUE, "label": "Rodada 4", "day": Game.S["day"],
		"h": me, "a": opp, "hg": gf, "ag": ga, "sc": [], "st": [[5, 5], [3, 3], [50, 50], [2, 2], [1, 1], [0, 0], [0, 0]], "pens": []}


func _count(kind: String) -> int:
	var n := 0
	for p in Media.feed():
		if str(p["kind"]) == kind:
			n += 1
	return n


func run(t) -> void:
	var coach = {"name": "Teste Midia", "age": 40, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.rng.seed = 77
	Media.R.seed = 77
	Game.new_career(5, coach, 0, 0)
	Game.play_next(null)
	var p := Media.pending()
	t.check(Media.has_interview(), "depois do jogo há coletiva pendente")
	t.check(p["qs"].size() >= 1 and p["qs"].size() <= 3, "1 a 3 perguntas", "%d" % p["qs"].size())
	var q0: Dictionary = p["qs"][0]
	t.check(q0["a"].size() == 4 and not ("{" in str(q0["q"])), "pergunta preenchida com 4 tons", str(q0["q"]))
	t.check(Media.feed().size() >= 3, "a rede comenta o jogo", "%d posts" % Media.feed().size())
	t.check(_count("jornalista") >= 1, "imprensa publica manchete")

	# provocar: imprensa cai, seguidores sobem, a fala repercute
	var press0 := Media.meter("imprensa")
	var fol0 := Media.followers()
	var feed0 := Media.feed().size()
	var r := Media.answer("provocar")
	t.check(Media.meter("imprensa") < press0, "provocar piora a relação com a imprensa", "%.0f -> %.0f" % [press0, Media.meter("imprensa")])
	t.check(Media.followers() > fol0, "provocar dá seguidores", "+%d" % (Media.followers() - fol0))
	t.check(Media.feed().size() > feed0, "a resposta repercute nas redes")
	t.check(str(r.get("texto", "")) != "", "resumo dos efeitos", str(r.get("texto", "")))
	t.check(not Media.st()["trending"].is_empty(), "coletiva polêmica entra nos assuntos do momento")

	# humilde melhora imprensa; o estado fica no save
	if Media.has_interview():
		var pr1 := Media.meter("imprensa")
		Media.answer("humilde")
		t.check(Media.meter("imprensa") > pr1, "humilde melhora a imprensa")
	while Media.has_interview():
		Media.answer("desviar")
	t.check(not Media.has_interview() and int(Media.st()["interviews"]) == 1, "coletiva termina e é contada")
	Game.save()
	var press_saved := Media.meter("imprensa")
	Game.load_career(5)
	t.check(absf(Media.meter("imprensa") - press_saved) < 0.01, "medidores ficam salvos na carreira")

	# moral mexe na energia do elenco (que entra na força do time)
	var e0 := float(Game.energy_avg(Game.S["club"]))
	for p2 in Game.squad(Game.S["club"]):
		p2["energy"] = 70.0
	e0 = float(Game.energy_avg(Game.S["club"]))
	Media._add_meter("moral", 10.0)
	t.check(float(Game.energy_avg(Game.S["club"])) > e0, "moral alta deixa o elenco mais disposto")

	# torcida do técnico = apoio que mexe na bilheteria
	var sup0: int = int(Game.S["support"])
	Media._add_meter("torcida", -5.0)
	t.check(int(Game.S["support"]) == maxi(sup0 - 5, 0), "humor da torcida é o apoio do clube")

	# sequência ruim: cornetas mais barulhentas
	Media.st()["feed"].clear()
	Media.st()["streak"] = 0
	for i in 6:
		_fake_result(2, 0)
		Media.after_match()
	var haters_good := _count("hater")
	var posts_good := Media.feed().size()
	Media.st()["feed"].clear()
	for i in 6:
		_fake_result(0, 2)
		Media.after_match()
	var haters_bad := _count("hater")
	t.check(haters_bad > haters_good * 2, "derrotas em sequência soltam as cornetas", "%d x %d" % [haters_bad, haters_good])
	t.check(int(Media.st()["streak"]) == -6, "sequência sem vencer contada")
	t.check(Media.feed().size() >= posts_good, "mais barulho na crise")
	t.check(_count("rival") >= 3, "rivais zoam depois das derrotas")
	var bad_tag := false
	for tg in Media.st()["trending"]:
		if "Fora" in str(tg) or "Crise" in str(tg) or "SemRumo" in str(tg) or "Acorda" in str(tg) or "PlanoB" in str(tg):
			bad_tag = true
	t.check(bad_tag, "crise vira assunto do momento", ", ".join(Media.st()["trending"]))
	_fake_result(0, 4)
	Media.after_match()
	var cats: Array = []
	for q in Media.pending()["qs"]:
		cats.append(q["cat"])
	t.check("derrota_pesada" in cats, "goleada sofrida gera pergunta de derrota pesada", ", ".join(cats))
	var board0 := Media.meter("diretoria")
	Media.skip_interview()
	t.check(not Media.has_interview(), "dá para pular a coletiva")
	t.check(Media.meter("diretoria") == board0, "pular não mexe na diretoria")
	Game.delete_save(5)

	# modo jogador: perguntas sobre a sua atuação, efeitos na confiança do técnico e na torcida
	Game.rng.seed = 2027
	var prof := Pro.new_profile()
	prof["name"] = "Midia Craque"
	prof["pos"] = "AC"
	Pro.start(5, prof)
	Game.play_next(null)   # peneira
	Pro.accept(0)
	var guard := 0
	while not Media.has_interview() and guard < 10:
		guard += 1
		Game.play_next(null)
	t.check(Media.has_interview() and Media.is_pro(), "modo jogador também tem entrevista")
	var pcats: Array = []
	for q in Media.pending()["qs"]:
		pcats.append(q["cat"])
	var has_pro := false
	for c in pcats:
		if str(c).begins_with("pro_"):
			has_pro = true
	t.check(has_pro, "pergunta sobre a sua atuação", ", ".join(pcats))
	var fans0 := float(Pro.P()["fans"])
	var fol1 := int(Pro.P()["followers"])
	Media.answer("confiante")
	t.check(float(Pro.P()["fans"]) != fans0 or int(Pro.P()["followers"]) > fol1, "resposta mexe na torcida/seguidores do jogador")
	Game.delete_save(5)
