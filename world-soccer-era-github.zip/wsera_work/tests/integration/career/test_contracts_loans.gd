extends RefCounted
## Carreira de técnico: renovação de contratos, Bosman, empréstimos, banco de reservas,
## substituições (limites e máquina) e save/load dos dados novos.

const SLOT := 4


func _coach() -> Dictionary:
	return {"name": "Teste", "age": 40, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}


func _play_season() -> void:
	var guard := 0
	while not Game.S["season_over"] and guard < 80:
		guard += 1
		Game.play_round(null)


func _squads_ok() -> bool:
	for cid in Game.n_league():
		var n := Game.squad(cid).size()
		if n < (16 if cid == Game.S["club"] else 18):
			return false
		var xi: Array = Game.S["clubs"][cid]["xi"]
		if xi.size() != 11:
			return false
		for pid in xi:
			if not Game.S["players"].has(pid) or int(Game.player(pid)["club"]) != cid:
				return false
	return true


func run(t) -> void:
	Game.rng.seed = 777
	Game.new_career(SLOT, _coach(), 2, 0)
	var me: int = Game.S["club"]

	# ---------------- contratos no início
	var short := 0
	for p in Game.S["players"].values():
		if int(p["club"]) >= 0 and int(p["contract"]) < 2:
			short += 1
	t.check(short == 0, "ninguém começa com contrato acabando")

	# ---------------- renovação: aceita, contraproposta, recusa
	var sq := Game.squad(me)
	var a: Dictionary = sq[3]
	var b: Dictionary = sq[5]
	var c: Dictionary = sq[7]
	for p in [a, b, c]:
		p["contract"] = 1
	t.check(Contracts.expiring_list(me).size() >= 3, "contratos a vencer aparecem", "%d" % Contracts.expiring_list(me).size())
	var da := Contracts.demand(a)
	var ra := Contracts.propose(a["id"], float(da["wage"]), int(da["years"]), str(da["role"]))
	t.check(ra["result"] == "aceita" and int(a["contract"]) == int(da["years"]) + 1, "renovação aceita no pedido", "%s, contrato %d" % [ra["result"], a["contract"]])
	t.check(not Contracts.expiring(a), "renovado sai da lista de vencimentos")
	var db := Contracts.demand(b)
	var rb := Contracts.propose(b["id"], float(db["wage"]) * 0.9, int(db["years"]), str(db["role"]))
	t.check(rb["result"] == "contraproposta", "proposta um pouco abaixo vira contraproposta", rb["result"])
	var dc := Contracts.demand(c)
	var rc := Contracts.propose(c["id"], float(dc["wage"]) * 0.5, int(dc["years"]), str(dc["role"]))
	t.check(rc["result"] == "recusa" and c.get("renew", {}).get("refused", false), "proposta muito baixa é recusada", rc["result"])
	var rc2 := Contracts.propose(c["id"], float(dc["wage"]) * 2.0, int(dc["years"]), str(dc["role"]))
	t.check(rc2["result"] == "recusa", "quem recusou não volta atrás")
	var res_cost := Contracts.release_cost(sq[9])
	t.check(res_cost > 0.0, "rescisão tem multa", Game.money(res_cost))

	# ---------------- banco de reservas
	var bench := Game.bench(me)
	var has_gk := false
	for p in bench:
		if p["pos"] == "GOL":
			has_gk = true
	t.check(bench.size() <= Game.bench_max() and bench.size() >= 7, "banco com até %d reservas" % Game.bench_max(), "%d" % bench.size())
	t.check(has_gk, "banco automático leva um goleiro")
	var out_pid: int = Game.not_listed(me)[0]["id"] if not Game.not_listed(me).is_empty() else -1
	if out_pid >= 0:
		t.check(Game.bench_toggle(out_pid) != "", "banco cheio não aceita mais um")
		Game.bench_toggle(bench[0]["id"])
		t.check(Game.bench_toggle(out_pid) == "" and out_pid in Game.bench(me).map(func(p): return p["id"]), "troca de quem é relacionado")
	var sim := MatchSim.new(me, (me + 1) % Game.n_league())
	var side := 0
	if out_pid >= 0 and Game.not_listed(me).size() > 0:
		var nl: int = Game.not_listed(me)[0]["id"]
		t.check(sim.substitute(side, 3, nl) != "", "não relacionado não entra")
	var bpids: Array = Game.bench(me).map(func(p): return p["id"])
	sim.minute = 50
	var ok1 := sim.substitute(side, 9, bpids[1]) == ""
	var ok2 := sim.substitute(side, 10, bpids[2]) == ""   # mesmo minuto: mesma parada
	sim.minute = 60
	var ok3 := sim.substitute(side, 8, bpids[3]) == ""
	sim.minute = 70
	var ok4 := sim.substitute(side, 7, bpids[4]) == ""
	sim.minute = 80
	var r5 := sim.substitute(side, 6, bpids[5])
	t.check(ok1 and ok2 and ok3 and ok4 and sim.sub_windows[side] == 3, "3 paradas, duas trocas na mesma parada", "paradas %d" % sim.sub_windows[side])
	t.check(r5 != "", "quarta parada é recusada", r5)
	sim.minute = 45
	var r6 := sim.substitute(side, 6, bpids[5])
	t.check(r6 == "" and sim.subs[side] == 5, "no intervalo a troca não gasta parada", "trocas %d" % sim.subs[side])
	t.check(sim.substitute(side, 5, bpids[6]) != "", "no máximo %d trocas" % sim.max_subs())
	# devolve a escalação original
	Game.S["clubs"][me]["xi"] = sim.orig_xi[0]
	Game.S["clubs"][sim.a]["xi"] = sim.orig_xi[1]

	# máquina substitui; o seu lado só quando liberado
	var ai_total := 0
	var mine_total := 0
	for k in 6:
		var s2 := MatchSim.new(me, (me + 2 + k) % Game.n_league())
		s2.ai_sides[0] = false
		while not s2.finished:
			s2.step()
		ai_total += s2.subs[1]
		mine_total += s2.subs[0]
		Game.S["clubs"][s2.h]["xi"] = s2.orig_xi[0]
		Game.S["clubs"][s2.a]["xi"] = s2.orig_xi[1]
	t.check(ai_total >= 6, "a máquina faz substituições", "%d em 6 jogos" % ai_total)
	t.check(mine_total == 0, "a máquina não mexe no seu time sem permissão")

	# ---------------- empréstimos
	var bill0 := Loans.wage_bill(me)
	var xi: Array = Game.my_club()["xi"]
	var cand: Array = Game.squad(me).filter(func(p): return not (p["id"] in xi) and not p.has("loan"))
	cand.sort_custom(func(x, y): return x["ovr"] > y["ovr"])
	var lo: Dictionary = cand[0]
	var weakest := 0
	for cid in Game.n_league():
		if cid != me and float(Game.S["clubs"][cid]["str"]) < float(Game.S["clubs"][weakest]["str"]):
			weakest = cid
	Loans._start(lo, weakest, false, 60, 0.0, 0.0)
	t.check(int(lo["club"]) == weakest and lo.has("loan"), "emprestado vai para o outro clube")
	var bill1 := Loans.wage_bill(me)
	t.check(absf((bill0 - bill1) - float(lo["wage"]) * 0.6) < 0.05, "salário dividido no empréstimo", "%.2f -> %.2f" % [bill0, bill1])
	t.check(not (lo["id"] in Game.squad(me).map(func(p): return p["id"])), "emprestado sai do seu elenco")
	# pedir emprestado com opção de compra
	var avail := Loans.available_in()
	t.check(not avail.is_empty(), "há jogadores disponíveis para empréstimo", "%d" % avail.size())
	var li_p: Dictionary = avail[avail.size() - 1]
	var terms := Loans.terms_in(li_p)
	Game.S["money"] = 500.0
	t.check(Loans.loan_in(li_p["id"], false, int(terms["pct"]) - 10, true) != "", "pagando pouco do salário o clube recusa")
	var m0: float = Game.S["money"]
	var rli := Loans.loan_in(li_p["id"], false, int(terms["pct"]), true)
	t.check(rli == "" and int(li_p["club"]) == me, "empréstimo recebido", rli)
	t.check(absf((m0 - float(Game.S["money"])) - float(terms["fee"])) < 0.01, "taxa de empréstimo paga")
	t.check(Game.sign_player(li_p["id"], 0.0, 99.0, 3) != "", "emprestado ao seu clube não pode ser contratado de novo")
	# meia temporada: outro jogador volta na metade
	var cand2: Array = Game.squad(me).filter(func(p): return not (p["id"] in Game.my_club()["xi"]) and not p.has("loan"))
	var half_p: Dictionary = cand2[0]
	Loans._start(half_p, (weakest + 1) % Game.n_league() if (weakest + 1) % Game.n_league() != me else (weakest + 2) % Game.n_league(), true, 100, 0.0, 0.0)
	t.check(int(half_p["loan"]["end_round"]) == int(Game.S["fixtures"].size() / 2.0), "empréstimo de meia temporada")
	var mid := int(Game.S["fixtures"].size() / 2.0)
	while int(Game.S["round"]) < mid + 1 and not Game.S["season_over"]:
		Game.play_round(null)
	t.check(int(half_p["club"]) == me and not half_p.has("loan"), "volta na metade da temporada")
	t.check(Loans.can_recall(lo), "dá para chamar de volta depois da metade")
	_play_season()
	t.check(int(lo["g"]) > 0, "emprestado joga pelo outro clube", "%d jogos pelo %s" % [lo["g"], Game.club_name(weakest)])
	var buy_txt := Loans.buy_option(li_p["id"])
	t.check(buy_txt == "" and not li_p.has("loan") and int(li_p["club"]) == me, "opção de compra exercida", buy_txt)

	# ---------------- fim de temporada: Bosman, volta dos emprestados, renovações da máquina
	var c_id: int = c["id"]
	Game.new_season()
	t.check(int(Game.player(c_id)["club"]) == Game.FREE, "quem recusou sai de graça (Bosman)")
	t.check(int(lo["club"]) == me and not lo.has("loan"), "emprestado volta no fim da temporada")
	t.check(not lo.get("loan_hist", []).is_empty() and int(lo["loan_hist"][0]["club"]) == weakest, "histórico do empréstimo guardado")
	t.check(_squads_ok(), "elencos válidos depois das renovações")
	var exp_ai := 0
	for p in Game.S["players"].values():
		if int(p["club"]) >= 0 and int(p["contract"]) < 1:
			exp_ai += 1
	t.check(exp_ai == 0, "nenhum contrato abaixo de 1")

	# ---------------- save / load
	Game.bench_toggle(Game.bench(me)[0]["id"])
	var lo2: Dictionary = Game.squad(me).filter(func(p): return not (p["id"] in Game.my_club()["xi"]))[0]
	Loans._start(lo2, weakest, false, 70, 1.5, 0.0)
	Game.S["loan_offers"].append({"pid": Game.squad(me)[0]["id"], "club": weakest, "pct": 80, "half": false, "buy": 0.0})
	var bench_before: Array = Game.my_club()["bench"].duplicate()
	Game.save()
	Game.load_career(SLOT)
	var lo2b: Dictionary = Game.player(lo2["id"])
	t.check(lo2b.has("loan") and float(lo2b["loan"]["buy"]) == 1.5 and int(lo2b["loan"]["pct"]) == 70, "empréstimo salvo e carregado")
	t.check(Game.my_club()["bench"] == bench_before and Game.my_club().get("bench_manual", false), "banco escolhido salvo")
	t.check(Loans.offers().size() == 1, "pedidos de empréstimo salvos")
	# save antigo sem os campos novos
	Game.S.erase("loan_offers")
	Game.save()
	Game.load_career(SLOT)
	t.check(Game.S.has("loan_offers"), "save antigo ganha os campos novos")

	# ---------------- três temporadas seguidas com tudo acontecendo
	var bad := false
	for season in 3:
		var guard := 0
		while not Game.S["season_over"] and guard < 80:
			guard += 1
			Game.play_round(null)
			if guard % 7 == 0:
				var exp := Contracts.expiring_list(me)
				if not exp.is_empty():
					var d := Contracts.demand(exp[0])
					Contracts.propose(exp[0]["id"], float(d["wage"]), int(d["years"]), str(d["role"]))
				if not Loans.offers().is_empty():
					Loans.accept_request(0)
		if not _squads_ok() or is_nan(float(Game.S["money"])):
			bad = true
		Game.new_season()
	t.check(not bad and _squads_ok(), "3 temporadas com renovações e empréstimos sem quebrar")
	var ai_loans := 0
	for p in Game.S["transfers"]:
		if p.get("loan", false) and int(p["from"]) != me and int(p["to"]) != me:
			ai_loans += 1
	t.check(ai_loans > 0, "clubes da máquina também emprestam", "%d" % ai_loans)
	Game.delete_save(SLOT)
