extends RefCounted
## Física dos corpos e da bola em uso real: lances do jogador, lances roteirizados da máquina,
## campo ao vivo e independência da taxa de quadros.

const SKIN := 0.02   ## sobreposição tolerada entre dois corpos (m) depois da colisão


func run(t) -> void:
	var coach = {"name": "T", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.rng.seed = 2024
	Game.new_career(8, coach, 3, 0)
	var suite = load("res://tests/integration/match/test_match_balance.gd").new()
	_user_lances(t, suite)
	_scripted(t)
	_field(t)
	_fps(t, suite)
	_celebration(t)
	Game.delete_save(8)


## Mede, num quadro, a pior sobreposição, NaN, velocidade e bola dentro de corpo.
func _frame_checks(lv: LanceView, acc: Dictionary) -> void:
	var w: BodyWorld = lv.world
	if w == null:
		return
	var g := w.min_gap()
	acc["worst"] = minf(float(acc["worst"]), g)
	if g < -SKIN:
		acc["overlap_frames"] = int(acc["overlap_frames"]) + 1
	acc["frames"] = int(acc["frames"]) + 1
	for b in w.bodies:
		if is_nan(b.pos.x) or is_nan(b.pos.y) or is_nan(b.vel.x) or is_nan(b.vel.y):
			acc["nan"] = int(acc["nan"]) + 1
		if not b.kinematic:
			acc["vmax"] = maxf(float(acc["vmax"]), b.vel.length())
	if is_nan(lv.bp.pos.x) or is_nan(lv.bp.pos.y) or is_nan(lv.bp.z):
		acc["nan"] = int(acc["nan"]) + 1


func _new_acc() -> Dictionary:
	return {"worst": 99.0, "overlap_frames": 0, "frames": 0, "nan": 0, "vmax": 0.0, "turn_bad": 0, "turn_n": 0, "ball_in": 0}


## Bola baixa dentro de um corpo que não é quem a controla, o goleiro ou quem acabou de tocar nela.
func _ball_inside(lv: LanceView) -> bool:
	if lv.bp.z > 1.6 or lv.state in ["intro", "decide", "settle", "end", "done", "runup"]:
		return false
	for e in lv._bodies():
		if e.get("keeper", false) or float(e.get("kick", 0.0)) > 0.0 or float(e.get("trap", 0.0)) > 0.0:
			continue
		if lv.state == "run" and is_same(e, lv.att[lv.carrier]):
			continue
		if lv.state == "pass" and lv.pass_to >= 0 and is_same(e, lv.att[lv.pass_to]):
			continue
		var r: float = lv._body(e).radius
		if e["pos"].distance_to(lv.bp.pos) < r * 0.8:
			return true
	return false


func _user_lances(t, suite) -> void:
	var acc := _new_acc()
	var prev_dir := {}
	var turn_limit: float = deg_to_rad(Tuning.f("corpo", "giro_parado_graus", 720.0)) / 60.0
	for k in 150:
		var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 1 + k % 19) % 20)
		sim.minute = 30
		sim.pending = {"side": 0, "pg": 0.3}
		var lv := LanceView.new()
		lv.size = Vector2(1280, 720)
		lv.setup(sim, 0, true)
		prev_dir.clear()
		var guard := 0
		while lv.state != "done" and guard < 2000:
			guard += 1
			if lv.state == "decide":
				suite._auto_play(lv)
			lv._process(1.0 / 60.0)
			_frame_checks(lv, acc)
			if _ball_inside(lv):
				acc["ball_in"] = int(acc["ball_in"]) + 1
			# giro: quem corre (> 3 m/s) não muda de direção mais que o limite (+ empurrão de colisão)
			for b in lv.world.bodies:
				if b.kinematic or b.vel.length() < 3.0 or b.contact:
					prev_dir.erase(b.get_instance_id())
					continue
				var key := b.get_instance_id()
				if prev_dir.has(key):
					acc["turn_n"] = int(acc["turn_n"]) + 1
					if absf((prev_dir[key] as Vector2).angle_to(b.vel)) > turn_limit * 1.5:
						acc["turn_bad"] = int(acc["turn_bad"]) + 1
				prev_dir[key] = b.vel
		lv.free()
	var frames: int = acc["frames"]
	t.check(frames > 20000, "lances simulados quadro a quadro", "%d quadros em 150 lances" % frames)
	t.check(int(acc["overlap_frames"]) == 0, "lances: nenhum corpo entra em outro", "pior folga %.3f m" % acc["worst"])
	t.check(int(acc["nan"]) == 0, "lances: sem NaN na física", str(acc["nan"]))
	t.check(float(acc["vmax"]) < 10.5, "lances: velocidade dentro do limite do corpo", "%.1f m/s" % acc["vmax"])
	var bad_pct := 100.0 * int(acc["turn_bad"]) / maxf(float(acc["turn_n"]), 1.0)
	t.check(bad_pct < 0.5, "lances: ninguém vira de direção instantaneamente", "%.2f%% de %d passos acima do giro máximo" % [bad_pct, acc["turn_n"]])
	t.check(int(acc["ball_in"]) == 0, "lances: bola nunca atravessa um corpo", "%d quadros" % acc["ball_in"])


## A máquina continua cumprindo o resultado sorteado pela simulação, com a física nova.
func _scripted(t) -> void:
	var want := {"goal": ["goal"], "save": ["save"], "out": ["out"], "lost": ["lost"], "offside": ["offside"]}
	var ok := 0
	var total := 0
	var acc := _new_acc()
	var miss := {}
	for kind in want.keys():
		for k in 30:
			var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 1 + k % 19) % 20)
			sim.minute = 50
			sim.pending = {"side": 0, "pg": 0.3}
			var lv := LanceView.new()
			lv.size = Vector2(1280, 720)
			lv.setup(sim, 0, false)
			lv.script_kind = kind
			var guard := 0
			while lv.state != "done" and guard < 2000:
				guard += 1
				lv._process(1.0 / 60.0)
				_frame_checks(lv, acc)
			total += 1
			if str(lv.result.get("kind", "")) in want[kind]:
				ok += 1
			else:
				miss[kind + ">" + str(lv.result.get("kind", "")) + ":" + lv.banner] = int(miss.get(kind + ">" + str(lv.result.get("kind", "")) + ":" + lv.banner, 0)) + 1
			lv.free()
	t.check(ok >= int(total * 0.95), "lances da máquina seguem o roteiro", "%d de %d %s" % [ok, total, miss])
	t.check(int(acc["overlap_frames"]) == 0, "lances da máquina: nenhum corpo entra em outro", "pior folga %.3f m" % acc["worst"])


## Campo ao vivo: 4 minutos de jogo a 60 Hz com 22 jogadores e árbitro.
func _field(t) -> void:
	var sim := MatchSim.new(0, 1)
	var fv := FieldView.new()
	fv.size = Vector2(1280, 720)
	fv.setup_field(sim)
	var acc := _new_acc()
	var ball_in := 0
	var t0 := Time.get_ticks_usec()
	for i in 60 * 240:
		if i % 120 == 0:
			for e in sim.step():
				if e["type"] == "chance":
					fv.show_chance(e["side"])
				elif e["type"] == "goal":
					fv.kickoff(1 - e["side"])
			fv.feed_minute(sim.last_side)
		fv._tick_field(1.0 / 60.0)
		_frame_checks(fv, acc)
		if fv.ball_state == "pass" or fv.ball_state == "loose":
			for e in fv._field_bodies:
				if e.get("keeper", false) or float(e.get("kick", 0.0)) > 0.0 or float(e.get("trap", 0.0)) > 0.0:
					continue
				if fv.ball_state == "pass" and fv.pass_target >= 0 and is_same(e, fv.teams[fv.owner_side][fv.pass_target]):
					continue
				if fv.bp.z < 1.6 and e["pos"].distance_to(fv.bp.pos) < fv._body(e).radius * 0.8:
					ball_in += 1
	var us := (Time.get_ticks_usec() - t0) / float(60 * 240)
	t.check(int(acc["overlap_frames"]) == 0, "campo ao vivo: nenhum corpo entra em outro", "pior folga %.3f m em %d passos" % [acc["worst"], acc["frames"]])
	t.check(int(acc["nan"]) == 0, "campo ao vivo: sem NaN", str(acc["nan"]))
	t.check(ball_in == 0, "campo ao vivo: bola não atravessa corpos", str(ball_in))
	t.check(us < 1500.0, "campo ao vivo: passo de física leve", "%.0f µs por passo de 1/60 s" % us)
	fv.free()


## Mesmo lance (mesma semente) a 30, 60 e 120 quadros por segundo: mesmo resultado.
func _fps(t, suite) -> void:
	var res: Array = []
	for fps in [30.0, 60.0, 120.0]:
		Game.rng.seed = 777
		var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 4) % 20)
		sim.minute = 20
		sim.pending = {"side": 0, "pg": 0.3}
		var lv := LanceView.new()
		lv.size = Vector2(1280, 720)
		lv.setup(sim, 0, false)
		lv.script_kind = "goal"
		var guard := 0
		while lv.state != "done" and guard < 6000:
			guard += 1
			lv._process(1.0 / fps)
		res.append([str(lv.result.get("kind", "")), lv.bp.pos, lv.att[lv.carrier]["pos"]])
		lv.free()
	var same_kind: bool = res[0][0] == res[1][0] and res[1][0] == res[2][0]
	var dball: float = maxf((res[0][1] as Vector2).distance_to(res[1][1]), (res[2][1] as Vector2).distance_to(res[1][1]))
	var dplayer: float = maxf((res[0][2] as Vector2).distance_to(res[1][2]), (res[2][2] as Vector2).distance_to(res[1][2]))
	t.check(same_kind and dball < 0.05 and dplayer < 0.05, "física igual a 30, 60 e 120 fps",
		"%s / %s / %s, bola difere %.3f m, autor %.3f m" % [res[0][0], res[1][0], res[2][0], dball, dplayer])


## Comemoração do gol: o autor corre, desliza de joelhos (freia pelo atrito, sem teleporte) e termina
## de joelhos; companheiros fazem a roda em volta dele, sem ninguém entrar em ninguém.
func _celebration(t) -> void:
	var tried := 0
	var good := 0
	var info := ""
	var acc := _new_acc()
	for k in 6:
		var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 2 + k) % 20)
		sim.minute = 60
		sim.pending = {"side": 0, "pg": 0.3}
		var lv := LanceView.new()
		lv.size = Vector2(1280, 720)
		lv.setup(sim, 0, false)
		lv.script_kind = "goal"
		lv.slide_chance = 1.0
		var guard := 0
		var vmax := 0.0
		var v_prev := -1.0
		var accel_in_slide := 0
		var jumps := 0
		var tele := 0
		var prev := Vector2.INF
		var slid := false
		var t_end := 0.0
		while lv.state != "done" and guard < 2000:
			guard += 1
			lv._process(1.0 / 60.0)
			if lv.state != "end" and lv.state != "done":
				continue
			_frame_checks(lv, acc)
			if lv.att.is_empty() or not lv.result.get("goal", false):
				break
			var c: Dictionary = lv.att[lv.carrier]
			var p: Vector2 = c["pos"]
			if prev != Vector2.INF and p.distance_to(prev) > 0.25:
				tele += 1
			prev = p
			t_end = lv.t
			if str(c.get("cs", "")) == "slide":
				slid = true
				var v: float = (c["vel"] as Vector2).length()
				vmax = maxf(vmax, v)
				if v_prev >= 0.0 and v > v_prev + 0.3:   # tranco de colisão pequeno é tolerado
					accel_in_slide += 1
				v_prev = v
			for i in lv.att.size():
				if i != lv.carrier and float(lv.att[i].get("jump", 0.0)) > 0.45:
					jumps += 1
		if not lv.result.get("goal", false):
			lv.free()
			continue
		tried += 1
		var c2: Dictionary = lv.att[lv.carrier]
		var near := 0
		for i in lv.att.size():
			if i != lv.carrier and (lv.att[i]["pos"] as Vector2).distance_to(c2["pos"]) < 3.5:
				near += 1
		var need: int = mini(2, lv.att.size() - 1)
		var ok: bool = slid and vmax > 4.0 and accel_in_slide <= 2 and tele == 0 and str(c2.get("cs", "")) == "kneel" \
			and (c2["vel"] as Vector2).length() < 0.3 and int(c2.get("cel", -1)) == 2 and near >= need and lv.skids.size() > 5
		if ok:
			good += 1
		info += "[v%.1f n%d/%d j%d t%.1f %s a%d tp%d sk%d e%.2f c%d] " % [vmax, near, lv.att.size() - 1, jumps, t_end, c2.get("cs", ""), accel_in_slide, tele, lv.skids.size(), (c2["vel"] as Vector2).length(), int(c2.get("cel", -1))]
		lv.free()
	t.check(tried >= 3 and good == tried, "gol: autor desliza de joelhos, para e recebe a roda dos companheiros", info)
	t.check(int(acc["overlap_frames"]) == 0, "comemoração: nenhum corpo entra em outro", "pior folga %.3f m" % acc["worst"])
