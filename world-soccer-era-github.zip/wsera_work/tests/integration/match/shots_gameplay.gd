extends Node
## Capturas de conferência da física e dos bonecos: disputa, bote, passe + domínio, chute com
## curva, defesa, área cheia, comemorações e o campo ao vivo com 22 jogadores.
## Rodar com tela: godot --path . res://tests/shots_gameplay.tscn
## Saída: SHOTS_DIR (ou res://production/qa/evidence/).
var out := ""
var got := {}


func shot(name: String) -> void:
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(out + "gp_%s.png" % name)
	got[name] = true


func _ready() -> void:
	out = OS.get_environment("SHOTS_DIR")
	if out == "":
		out = ProjectSettings.globalize_path("res://production/qa/evidence/")
	DirAccess.make_dir_recursive_absolute(out)
	if not out.ends_with("/"):
		out += "/"
	var coach = {"name": "T", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.new_career(5, coach, 0, 0)
	var suite = load("res://tests/integration/match/test_match_balance.gd").new()
	var want := ["disputa", "bote", "passe", "dominio", "chute_curva", "defesa", "gol", "comemoracao", "area_cheia", "deslizada_corrida", "deslizada", "deslizada_fim", "de_joelhos_roda"]
	for k in 160:
		if _all(want):
			break
		Game.rng.seed = 900 + k
		var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 1 + k % 19) % 20)
		sim.minute = 40
		sim.pending = {"side": 0, "pg": 0.3}
		var lv := LanceView.new()
		lv.size = Vector2(1280, 720)
		add_child(lv)
		lv.setup(sim, 0, true)
		lv.slide_chance = 1.0   # capturas da deslizada de joelhos
		lv.set_process(false)
		var guard := 0
		var pass_t := -1.0
		while lv.state != "done" and guard < 900:
			guard += 1
			if lv.state == "decide":
				suite._auto_play(lv)
			lv._process(1.0 / 60.0)
			var c: Dictionary = lv.att[lv.carrier]
			if lv.state == "run" and lv.presser >= 0 and lv.presser < lv.dfn.size() and not got.has("disputa"):
				if lv.dfn[lv.presser]["pos"].distance_to(c["pos"]) < 1.6:
					await shot("disputa")
			if float(lv.dfn[lv.presser].get("slide", 0.0) if lv.presser >= 0 and lv.presser < lv.dfn.size() else 0.0) > 0.4 and not got.has("bote"):
				await shot("bote")
			if lv.state == "pass" and not got.has("passe") and lv.t > 0.2:
				await shot("passe")
			if lv.state == "run" and float(c.get("trap", 0.0)) > 0.15 and not got.has("dominio"):
				await shot("dominio")
			if lv.state == "shot" and absf(lv.bp.curve.x) > 0.5 and lv.t > 0.25 and not got.has("chute_curva"):
				await shot("chute_curva")
			if lv.state == "shot" or lv.state == "settle" or lv.state == "run":
				var n_box := 0
				for e in lv.att + lv.dfn:
					if Referee.in_box(e["pos"]):
						n_box += 1
				if n_box >= 7 and not got.has("area_cheia"):
					await shot("area_cheia")
			if lv.state == "end" and lv.result.get("kind", "") == "save" and lv.t > 0.25 and not got.has("defesa"):
				await shot("defesa")
			if lv.state == "end" and lv.result.get("goal", false):
				if lv.t > 0.4 and lv.cel_t <= 0.0 and not got.has("gol"):
					await shot("gol")
				var sc: Dictionary = lv.att[lv.carrier]
				var cs: String = str(sc.get("cs", ""))
				if cs == "run" and float(sc.get("cs_t", 0.0)) > 0.45 and not got.has("deslizada_corrida"):
					await shot("deslizada_corrida")
				if cs == "slide" and float(sc.get("cs_t", 0.0)) > 0.3 and not got.has("deslizada"):
					await shot("deslizada")
				if cs == "slide" and float(sc.get("cs_t", 0.0)) > 0.9 and not got.has("deslizada_fim"):
					await shot("deslizada_fim")
				if cs == "kneel" and float(sc.get("cs_t", 0.0)) > 0.3 and lv.cel_t <= 0.0 and not got.has("de_joelhos_roda"):
					await shot("de_joelhos_roda")
				if lv.cel_t > 0.6 and not got.has("comemoracao"):
					await shot("comemoracao")
		lv.queue_free()
		await get_tree().process_frame
	await _field()
	print("GAMEPLAY SHOTS: ", got.keys())
	Game.delete_save(5)
	get_tree().quit()


func _all(keys: Array) -> bool:
	for k in keys:
		if not got.has(k):
			return false
	return true


func _field() -> void:
	var sim := MatchSim.new(0, 1)
	var fv := FieldView.new()
	fv.size = Vector2(1280, 720)
	add_child(fv)
	fv.setup_field(sim)
	fv.set_process(false)
	for i in 420:
		fv._process(1.0 / 60.0)
	await get_tree().process_frame
	await shot("campo_ao_vivo")
