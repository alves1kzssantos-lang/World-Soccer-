extends RefCounted
## Cena do pênalti: câmera se aproxima, batedor corre até a bola, o chute sai no contato,
## o goleiro mergulha e se recupera, e jogadores reagem no fim.


func run(t) -> void:
	var coach = {"name": "T", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.rng.seed = 11
	Game.new_career(6, coach, 0, 0)
	var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 1) % 20)
	sim.pending = {"side": 0, "pg": 0.3}
	var lv := LanceView.new()
	lv.size = Vector2(1280, 720)
	lv.setup(sim, 0, true)
	lv._setup_penalty(lv.att[0]["pos"])
	t.check(lv.banner == "PÊNALTI!", "faixa de pênalti substitui a da abertura")
	var in_net := 0
	for j in mini(3, lv.dfn.size()):
		if lv.dfn[j]["pos"].y < 0.0:
			in_net += 1
	t.check(in_net == mini(3, lv.dfn.size()), "três defensores dentro do gol")
	for i in 60:
		lv._process(1.0 / 60.0)
	t.check(lv.zoom > 1.2, "câmera aproxima no pênalti", "zoom %.2f" % lv.zoom)
	var kicker: Dictionary = lv.att[lv.carrier]
	var start_d: float = kicker["pos"].distance_to(lv.bp.pos)
	lv._do_shot(2.7, 0.8, 0.6)
	t.check(lv.state == "runup", "o chute começa pela corrida")
	t.check(lv.bp.speed() == 0.0, "bola parada durante a corrida")
	var max_wind := 0.0
	var guard := 0
	while lv.state == "runup" and guard < 200:
		guard += 1
		lv._process(1.0 / 60.0)
		max_wind = maxf(max_wind, float(kicker.get("windup", 0.0)))
	t.check(lv.state == "shot", "chute sai no fim da corrida")
	t.check(kicker["pos"].distance_to(lv.bp.pos) < start_d * 0.5 + 0.6, "batedor chegou na bola")
	t.check(max_wind > 0.8, "perna armada antes do contato")
	t.check(float(kicker.get("kick", 0.0)) > 0.25, "pé à frente no contato")
	var max_tilt := 0.0
	guard = 0
	while lv.state != "done" and guard < 600:
		guard += 1
		lv._process(1.0 / 60.0)
		max_tilt = maxf(max_tilt, absf(lv.gk_tilt))
	t.check(max_tilt > 0.5 or absf(lv._pen_gk) < 0.1, "goleiro mergulha", "inclinação %.2f" % max_tilt)
	t.check(absf(lv.gk_tilt) < max_tilt * 0.6 or max_tilt < 0.1, "goleiro se recupera depois do lance")
	t.check(lv.reacted, "jogadores e torcida reagem")
	var k: String = str(lv.result.get("kind", ""))
	if k == "goal":
		t.check(lv.dfn[0].get("sad", false) and lv.att[lv.carrier].get("cheer", false), "gol: defensores lamentam, batedor comemora")
	elif k == "save":
		t.check(lv.gk.get("cheer", false), "defesa: goleiro comemora")
	lv.free()
	Game.delete_save(6)
