extends RefCounted
## Partida contínua: o lance nasce do campo ao vivo sem corte. No instante da troca cada
## jogador e a bola ficam no mesmo pixel da tela (para os dois lados do campo), e na volta
## o campo recebe as posições de onde o lance terminou.


func run(t) -> void:
	var coach = {"name": "T", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.rng.seed = 31
	Game.new_career(6, coach, 0, 0)
	for sd in 2:
		var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 2) % 20)
		var fv := FieldView.new()
		fv.size = Vector2(1280, 720)
		fv.setup_field(sim)
		fv.s = fv.size.x / FieldView.FIELD_CAM_M   # no jogo o _draw do campo acerta a escala a cada quadro
		fv.want_side = sd
		fv.recent = [sd, sd]
		for i in 60 * 6:
			fv._tick_field(1.0 / 60.0)
		fv._process(0.016)
		var lv := LanceView.new()
		lv.size = fv.size
		lv.setup_from_field(sim, sd, false, fv)
		t.check(lv.flip == (sd == 0), "lado %d: mandante ataca para baixo na tela (flip)" % sd)
		t.check(lv.banner == "", "lado %d: sem faixa de abertura" % sd)
		if lv.script_kind != "penalty":
			var worst := 0.0
			var n := 0
			for fe in fv.teams[0] + fv.teams[1]:
				for le in lv.att + lv.dfn + [lv.gk]:
					if int(le["p"]["id"]) == int(fe["p"]["id"]):
						worst = maxf(worst, fv._w2s(fe["pos"]).distance_to(lv._w2s(le["pos"])))
						n += 1
			t.check(n >= 20 and worst < 1.0, "lado %d: troca sem pulo na tela" % sd, "%d jogadores, pior %.2f px" % [n, worst])
		# joga o lance da máquina até o fim e devolve ao campo
		var guard := 0
		while lv.state != "done" and guard < 2400:
			guard += 1
			lv._process(1.0 / 60.0)
		t.check(lv.state == "done", "lado %d: lance contínuo termina" % sd, str(lv.result.get("kind", "")))
		fv.absorb_lance(lv)
		# volta: cada jogador no campo exatamente onde terminou o lance (em metros)
		var g: float = FieldView.OWN_GOAL[1 - sd]
		var fw: float = FieldView.FWD[sd]
		var worst2 := 0.0
		for fe in fv.teams[0] + fv.teams[1]:
			for le in lv.att + lv.dfn:
				if int(le["p"]["id"]) == int(fe["p"]["id"]):
					var lp: Vector2 = le["pos"]
					var want := Vector2(clampf(lp.x, -36.0, 36.0), clampf(g - lp.y * fw, -2.0, 107.0))
					worst2 = maxf(worst2, fe["pos"].distance_to(want))
		t.check(worst2 < 0.01, "lado %d: volta ao campo sem pulo" % sd, "pior %.3f m" % worst2)
		t.check(absf(lv.zoom - LanceView.CAMERA_WIDTH_M / FieldView.FIELD_CAM_M) < 0.05, "lado %d: câmera do lance volta à escala do campo" % sd, "zoom %.2f" % lv.zoom)
		lv.free()
		fv.free()
	# arraste com barriga para a direita: a bola sai para a direita e curva para a esquerda
	var a := Vector2(640, 600)
	var b := Vector2(640, 300)
	var pts := PackedVector2Array([Vector2(660, 520), Vector2(700, 450), Vector2(690, 380), Vector2(650, 320)])
	var c1: float = LanceView.swipe_curl(a, b, pts)
	var c2: float = LanceView.swipe_curl(a, b, PackedVector2Array([Vector2(640, 500), Vector2(641, 400), Vector2(640, 320)]))
	t.check(not is_nan(c1) and c1 < 0.0, "arraste curvo dá efeito no sentido certo", "%.2f" % c1)
	t.check(is_nan(c2), "arraste reto não dá efeito extra")
	Game.delete_save(6)
