extends RefCounted
## Rede do gol (NetCloth): a bola entra, a rede estufa e segura a bola dentro do gol,
## balança e volta ao repouso; nada vira NaN.


func run(t) -> void:
	var coach = {"name": "T", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.rng.seed = 21
	Game.new_career(6, coach, 0, 0)
	var rest := LanceView._net_rest_cloth()
	var back_rest := 0.0
	for i in rest.p.size():
		back_rest = maxf(back_rest, rest.p[i].y)
	t.check(back_rest > 1.9 and back_rest < 2.6, "rede em repouso tem fundo e barriga", "%.2f m" % back_rest)
	var goals := 0
	var max_bulge := 0.0
	var inside_ok := 0
	var settled := 0
	var nan := false
	for k in 6:
		var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 1 + k) % 20)
		sim.minute = 30
		sim.pending = {"side": 0, "pg": 0.3}
		var lv := LanceView.new()
		lv.size = Vector2(1280, 720)
		lv.setup(sim, 0, false)
		lv.script_kind = "goal"
		var guard := 0
		while lv.state != "done" and guard < 1500:
			guard += 1
			lv._process(1.0 / 60.0)
			if lv._net_live != null:
				for i in lv._net_live.p.size():
					var q: Vector3 = lv._net_live.p[i]
					if is_nan(q.x) or is_nan(q.y) or is_nan(q.z):
						nan = true
					max_bulge = maxf(max_bulge, q.y - back_rest)
		if not lv.result.get("goal", false):
			lv.free()
			continue
		goals += 1
		var bpos: Vector2 = lv.bp.pos
		if bpos.y < 0.0 and bpos.y > -(LanceView.NET_DEPTH + 0.85) and absf(bpos.x) < BallPhysics.GOAL_HALF:
			inside_ok += 1
		# a rede volta a dormir sozinha (no máximo ~6 s depois do lance)
		var n := 0
		while lv._net_live != null and lv._net_live.awake and n < 360:
			lv._net_live.step(1.0 / 60.0)
			n += 1
		if lv._net_live == null or not lv._net_live.awake:
			settled += 1
		lv.free()
	t.check(goals >= 4, "lances com roteiro de gol viram gol", "%d de 6" % goals)
	t.check(max_bulge > 0.15, "a rede estufa quando a bola entra", "%.2f m além do repouso" % max_bulge)
	t.check(inside_ok == goals, "a bola fica dentro do gol, segura pela rede", "%d de %d" % [inside_ok, goals])
	t.check(settled == goals, "a rede para de balançar e dorme", "%d de %d" % [settled, goals])
	t.check(not nan, "rede sem NaN")
	Game.delete_save(6)
