extends RefCounted
## Regressão do passe de QA (production/qa/qa-report.md).
## Story type: Integration | Saída: tests/integration/qa/ | Gate: BLOCKING (roda em tests/run_tests.gd)
## Save/load idêntico depois de uma temporada inteira e da virada de temporada, save corrompido usa o
## backup, coletiva com os quatro tons mantém os medidores em 0..100.

const SLOT := 2


func run(t) -> void:
	var coach = {"name": "QA Reg", "age": 40, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.rng.seed = 818
	Media.R.seed = 818
	Game.new_career(SLOT, coach, 2, 51)   # liga de 8 clubes: temporada curta
	var tones := ["humilde", "confiante", "provocar", "desviar"]
	var n := 0
	var meters_ok := true
	var guard := 0
	while not Game.S["season_over"] and guard < 100:
		guard += 1
		Game.play_next(null)
		while Media.has_interview():
			Media.answer(tones[n % 4])
			n += 1
		for k in ["diretoria", "moral", "imprensa", "torcida"]:
			var v := Media.meter(k)
			if is_nan(v) or v < 0.0 or v > 100.0:
				meters_ok = false
	t.check(Game.S["season_over"] and guard < 100, "temporada termina", "%d jogos" % guard)
	t.check(n >= 8 and meters_ok, "coletivas com os 4 tons mantêm medidores em 0..100", "%d respostas" % n)
	t.check(Media.answer("tom_que_nao_existe").is_empty(), "tom inválido é ignorado")
	t.check(not is_nan(float(Game.S["money"])) and not is_inf(float(Game.S["money"])), "dinheiro finito")
	for c in Game.S["cups"]:
		t.check(int(c["champion"]) >= 0, "copa com campeão no fim da temporada", str(c["name"]))

	# round-trip: fim de temporada e depois da virada
	for stage in ["fim da temporada", "nova temporada"]:
		if stage == "nova temporada":
			Game.new_season()
		Game.save()
		var before := var_to_bytes(Game.S)
		var ok := Game.load_career(SLOT)
		t.check(ok and var_to_bytes(Game.S) == before, "save/load idêntico (%s)" % stage)
	t.check(not Game.S["season_over"] and int(Game.S["round"]) == 0 and int(Game.S["season"]) == 2, "virada reinicia o calendário")

	# save principal truncado: carrega o backup
	Game.S["money"] = 1.0
	Game.save()
	Game.S["money"] = 777.0
	Game.save()   # o de money=1 vira .bak
	var path: String = Game.SAVE_PATH % SLOT
	var bytes := FileAccess.get_file_as_bytes(path)
	var f := FileAccess.open(path, FileAccess.WRITE)
	f.store_buffer(bytes.slice(0, bytes.size() / 3))
	f.close()
	var ok2 := Game.load_career(SLOT)
	t.check(ok2 and absf(float(Game.S["money"]) - 1.0) < 0.001, "save truncado: carrega o backup")
	for p in [path, path + ".bak"]:
		var f2 := FileAccess.open(p, FileAccess.WRITE)
		f2.store_buffer(PackedByteArray([9, 9, 9, 9]))
		f2.close()
	t.check(not Game.load_career(SLOT) and Game.peek_save(SLOT).is_empty(), "save e backup corrompidos: não carrega e não quebra")
	Game.delete_save(SLOT)
	Game.S = {}
