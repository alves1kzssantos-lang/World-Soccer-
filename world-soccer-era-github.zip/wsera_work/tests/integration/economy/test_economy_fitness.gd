extends RefCounted
## Economia (src/finance.gd, src/money.gd) e energia (src/fitness.gd).

const SLOT := 5
const COACH := {"name": "T", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}


func run(t) -> void:
	_formatter(t)
	_energy_curves(t)
	_tired_plays_worse(t)
	_injury_risk(t)
	_economy_soak(t)
	_save_roundtrip(t)
	Game.delete_save(SLOT)


func _formatter(t) -> void:
	t.check(Money.fmt(12.44) == "$ 12,4 mi", "dinheiro: milhões com vírgula", Money.fmt(12.44))
	t.check(Money.fmt(0.85) == "$ 850 mil", "dinheiro: abaixo de 1 mi em mil", Money.fmt(0.85))
	t.check(Money.fmt(-3.25).begins_with("−$ 3,") , "dinheiro: negativo com sinal", Money.fmt(-3.25))
	t.check(Money.fmt(1250.0) == "$ 1.250 mi", "dinheiro: milhar com ponto", Money.fmt(1250.0))
	t.check(Money.fmt(0.0) == "$ 0", "dinheiro: zero", Money.fmt(0.0))
	t.check(Money.wage(43.8) == "$ 43,8 mil/sem", "salário semanal", Money.wage(43.8))
	t.check(Money.wage(1500.0) == "$ 1,50 mi/sem", "folha em milhões por semana", Money.wage(1500.0))
	t.check(Money.signed(1.5) == "+ $ 1,5 mi" and Money.signed(-0.2).begins_with("−"), "valor com sinal", Money.signed(1.5))
	t.check(Game.money(2.0) == Money.fmt(2.0), "Game.money usa o formatador único")


func _energy_curves(t) -> void:
	var mid := {"energy": 100.0, "pos": "MEI", "age": 26}
	var old := {"energy": 100.0, "pos": "MEI", "age": 34}
	var gk := {"energy": 100.0, "pos": "GOL", "age": 26}
	var e90 := Fitness.live(mid, 90)
	t.check(e90 > 60.0 and e90 < 80.0, "meia perde energia em 90 minutos", "%.1f" % e90)
	t.check(Fitness.live(old, 90) < e90, "veterano cansa mais", "%.1f" % Fitness.live(old, 90))
	t.check(Fitness.live(gk, 90) > 85.0, "goleiro quase não cansa", "%.1f" % Fitness.live(gk, 90))
	t.check(Fitness.factor(100.0) == 1.0 and Fitness.factor(40.0) < 0.95 and Fitness.factor(0.0) >= 0.8, "rendimento cai com a energia",
		"%.3f / %.3f" % [Fitness.factor(40.0), Fitness.factor(0.0)])
	var after := Fitness.after_match(mid, 90)
	t.check(after < 90.0 and after > 60.0, "depois do jogo sobra desgaste", "%.1f" % after)
	Game.new_career(SLOT, COACH.duplicate(true), 0, 0)
	var p: Dictionary = Game.squad(Game.S["club"])[3]
	p["energy"] = 70.0
	p["age"] = 26   # a regra é para um jogador no auge (veteranos recuperam mais devagar de propósito)
	var r7 := Fitness.recover(p, 7, true)
	var r3 := Fitness.recover(p, 3, true)
	t.check(r7 > r3 and r7 >= 95.0, "uma semana de descanso recupera; três dias não", "%.1f / %.1f" % [r3, r7])
	Game.S["training"] = "leve"
	var rl := Fitness.recover(p, 3, true)
	Game.S["training"] = "forte"
	var rf := Fitness.recover(p, 3, true)
	Game.S["training"] = "normal"
	t.check(rl > r3 and rf < r3, "treino leve recupera mais, forte menos", "%.1f / %.1f / %.1f" % [rl, r3, rf])


func _tired_plays_worse(t) -> void:
	Game.new_career(SLOT, COACH.duplicate(true), 0, 0)
	var me: int = Game.S["club"]
	var opp: int = (me + 1) % Game.n_league()
	var fresh := 0
	var tired := 0
	for k in 2:
		var win := 0
		for i in 80:
			for p in Game.squad(me):
				p["energy"] = 100.0 if k == 0 else 45.0
			for p in Game.squad(opp):
				p["energy"] = 100.0
			Game.rng.seed = 1000 + i
			var sim := MatchSim.new(me, opp)
			while not sim.finished:
				sim.step()
			Game.cur_sim = null
			win += sim.score[0] - sim.score[1]
		if k == 0:
			fresh = win
		else:
			tired = win
	t.check(tired < fresh, "time cansado rende menos na partida", "saldo descansado %d, cansado %d" % [fresh, tired])
	for p in Game.squad(me):
		p["energy"] = 100.0
	var r_fresh: int = Game.ratings(me)["ger"]
	for p in Game.squad(me):
		p["energy"] = 40.0
	t.check(Game.ratings(me)["ger"] < r_fresh, "energia baixa derruba a força do time")
	t.check(Game.stamina_factor(Game.squad(me)[0]["id"]) < 1.0, "fator de energia para as telas de partida")


func _injury_risk(t) -> void:
	var p := {"energy": 100.0, "pos": "MEI", "age": 26, "club": -99}
	var fresh := Fitness.injury_chance(p, 90, 85.0)
	var tired := Fitness.injury_chance(p, 90, 30.0)
	t.check(tired > fresh * 3.0, "cansado demais: risco de lesão bem maior", "%.4f -> %.4f" % [fresh, tired])
	t.check(fresh < 0.01, "descansado: lesão é rara", "%.4f" % fresh)


func _economy_soak(t) -> void:
	for li in [0, 3, 52]:
		Game.rng.seed = 77 + li
		Game.new_career(SLOT, COACH.duplicate(true), 4, li)
		var lname: String = Game.LEAGUE
		var start := float(Game.S["money"])
		var lo := start
		var nan_or_inf := false
		for season in 3:
			var guard := 0
			while not Game.S["season_over"] and guard < 140:
				guard += 1
				Game.play_next(null)
				while Media.has_interview():
					Media.answer("humilde")
				var mny := float(Game.S["money"])
				if is_nan(mny) or is_inf(mny):
					nan_or_inf = true
				lo = minf(lo, mny)
			if season < 2:
				Game.new_season()
		var mny2 := float(Game.S["money"])
		var annual := Finance.annual_revenue()
		t.check(not nan_or_inf, "%s: caixa sempre finito" % lname)
		t.check(mny2 > -annual * 0.5 and mny2 < annual * 4.0, "%s: caixa do clube num intervalo sensato em 3 temporadas" % lname,
			"início %s, fim %s, receita/ano %s" % [Money.fmt(start), Money.fmt(mny2), Money.fmt(annual)])
		t.check(lo > Finance.debt_limit() * 1.2, "%s: sem decisões ruins o clube não afunda em dívida" % lname, "mínimo %s" % Money.fmt(lo))
		var bad := 0
		var bad_names: Array = []
		for c in Game.S["clubs"]:
			if int(c["id"]) == int(Game.S["club"]):
				continue
			var an := Finance.base_revenue(float(c["str"])) * 52.0
			if float(c.get("cash", 0.0)) > an * 1.5 or float(c.get("cash", 0.0)) < -an * 0.45:
				bad += 1
				bad_names.append("%s %s (receita/ano %s)" % [c["name"], Money.fmt(float(c.get("cash", 0.0))), Money.fmt(an)])
			var ratio := Finance.wexp_k(float(c["str"])) / 1000.0 / Finance.base_revenue(float(c["str"]))
			if ratio < 0.6 or ratio > 0.95:
				bad += 1
		t.check(bad == 0, "%s: caixa e folha/receita dos clubes da máquina sensatos" % lname, "%d fora %s" % [bad, bad_names])
		var fin: Dictionary = Game.S["fin"]
		t.check(float(fin.get("tv", 0.0)) > 0.0 and float(fin.get("patrocinio", 0.0)) > 0.0 and float(fin.get("bilheteria", 0.0)) > 0.0,
			"%s: TV, patrocínio e bilheteria entram no balanço" % lname)
		t.check(not Finance.ensure()["ledger"].is_empty() and Finance.ensure()["hist"].size() > 5, "%s: extrato e histórico do caixa" % lname)
	# diretoria: contratação acima do orçamento derruba a confiança
	Game.new_career(SLOT, COACH.duplicate(true), 0, 0)
	var before := Media.meter("diretoria")
	Finance.ensure()["transfer_budget"] = 1.0
	Finance.on_purchase(6.0, 50.0)
	t.check(Media.meter("diretoria") < before, "estourar o orçamento irrita a diretoria", "%.0f -> %.0f" % [before, Media.meter("diretoria")])
	Game.S["money"] = Finance.debt_limit() - 5.0
	t.check(Finance.can_spend(1.0) != "", "dívida acima do limite bloqueia contratações")


func _save_roundtrip(t) -> void:
	Game.new_career(SLOT, COACH.duplicate(true), 0, 0)
	Game.save()
	var before := var_to_bytes(Game.S)
	var ok := Game.load_career(SLOT)
	t.check(ok and var_to_bytes(Game.S) == before, "save/load idêntico com economia e energia (carreira nova)")
	# save antigo sem os campos novos ganha valores padrão
	Game.S.erase("econ")
	Game.S.erase("training")
	Game.save()
	Game.load_career(SLOT)
	t.check(Game.S.has("econ") and str(Game.S.get("training", "")) == "normal" and Game.S["econ"].has("transfer_budget"),
		"save antigo ganha economia e treino padrão")
