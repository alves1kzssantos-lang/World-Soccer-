extends Node
## Capturas das telas e do pênalti para conferência visual.
## Rodar com tela: xvfb-run godot --path . res://tests/shots_tour.tscn
## As imagens vão para a pasta da variável SHOTS_DIR (ou res://production/qa/evidence/).
var n := 0
var out := ""
var main


func shot(name: String) -> void:
	await RenderingServer.frame_post_draw
	n += 1
	get_viewport().get_texture().get_image().save_png(out + "tour_%02d_%s.png" % [n, name])


func wait(sec: float) -> void:
	await get_tree().create_timer(sec).timeout


func _ready() -> void:
	out = OS.get_environment("SHOTS_DIR")
	if out == "":
		out = ProjectSettings.globalize_path("res://production/qa/evidence/")
	DirAccess.make_dir_recursive_absolute(out)
	if not out.ends_with("/"):
		out += "/"
	Game.delete_save(7)
	Game.rng.seed = 99
	main = load("res://main.tscn").instantiate()
	add_child(main)
	await wait(1.6)
	await shot("menu")
	main.go("careers")
	await wait(0.22)
	await shot("transicao")
	await wait(0.7)
	await shot("carreiras")
	var st = main._keep[0]
	for li in [0, 3, 2]:   # Brasileirão (com logo), Premier League e Liga Argentina (sem logo no pacote: emblema)
		st.sel_league = li
		main.replace("clubs")
		await wait(0.6)
		await shot("clubes_liga%d" % li)
	var coach = {"name": "Alves", "age": 35, "nat": "Brasil", "skin": 2, "hair": 1, "haircolor": 0, "beard": 1, "suit": 0, "rep": 5.0}
	Game.new_career(7, coach, 3, 0)
	main.home()
	await wait(0.8)
	await shot("hub")
	await _penalty()
	Game.delete_save(7)
	get_tree().quit()


## Pênalti a favor (lance do jogador): decisão, corrida, chute com o goleiro no mergulho e reação.
func _penalty() -> void:
	main.queue_free()
	await get_tree().process_frame
	var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 3) % 20)
	sim.minute = 70
	sim.pending = {"side": 0, "pg": 0.3}
	var lv := LanceView.new()
	lv.size = Vector2(1280, 720)
	add_child(lv)
	lv.setup(sim, 0, true)
	lv.set_process(false)
	lv._setup_penalty(lv.att[0]["pos"])
	for i in 80:
		lv._process(1.0 / 60.0)
		await get_tree().process_frame
	await shot("penalti_decisao")
	var corner := 2.7 if lv.gk_dive_x <= 0.0 else -2.7
	lv._do_shot(corner, 0.9, 0.65)
	var got := {}
	var guard := 0
	while lv.state != "done" and guard < 600:
		guard += 1
		lv._process(1.0 / 60.0)
		await get_tree().process_frame
		if lv.state == "runup" and lv.t > 0.3 and not got.has("runup"):
			got["runup"] = true
			await shot("penalti_corrida")
		if lv.state == "shot" and absf(lv.gk_tilt) > 0.7 and not got.has("dive"):
			got["dive"] = true
			await shot("penalti_mergulho")
		if lv.state == "end" and lv.t > 0.7 and not got.has("end"):
			got["end"] = true
			lv.cel_t = 0.0
			await shot("penalti_reacao_" + str(lv.result.get("kind", "")))
	print("PENALTI: ", lv.result, " ", got.keys())
	lv.queue_free()
