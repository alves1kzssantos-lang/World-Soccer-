extends SceneTree
func _init():
	if not DataPack.loaded() and FileAccess.file_exists("res://datapack.zip"): DataPack.import_zip("res://datapack.zip")
	print("loaded ", DataPack.loaded())
	var miss_comp := []
	var miss_club := 0
	var total := 0
	for li in World.LEAGUES.size():
		var lg = World.LEAGUES[li]
		var cid := DataPack.comp_id(li)
		if cid < 0 or DataPack.comp_logo_by_id(cid) == null: miss_comp.append("%s (id %d)" % [lg["name"], cid])
		var m := []
		for ci in lg["clubs"].size():
			total += 1
			if DataPack.logo(li, ci) == null:
				miss_club += 1; m.append(lg["clubs"][ci][0])
		if not m.is_empty(): print("  ", lg["name"], " sem escudo: ", ", ".join(m))
	print("ligas sem logo: ", miss_comp)
	print("clubes sem escudo: %d de %d" % [miss_club, total])
	for d in World.CUPS.size():
		var cd = World.CUPS[d]
		var id = int(cd.get("comp", -1))
		print("copa ", cd["name"], " id ", id, " logo ", DataPack.comp_logo_by_id(id) != null)
	quit()
