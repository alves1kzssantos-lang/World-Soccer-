extends RefCounted
## Escudos e logos do pacote que já vem no APK (sem precisar importar datapack.zip)
## e o emblema padrão quando a competição não tem logo.


func run(t) -> void:
	t.check(DataPack.has_bundled(), "o projeto traz as imagens do pacote em assets/datapack")
	t.check(DataPack.loaded(), "datapack disponível mesmo sem importar o zip")
	var ok := 0
	var total := 0
	for li in World.LEAGUES.size():
		for ci in World.LEAGUES[li]["clubs"].size():
			total += 1
			if DataPack.logo(li, ci) != null:
				ok += 1
	t.check(ok >= int(total * 0.95), "quase todos os clubes têm escudo", "%d de %d" % [ok, total])
	t.check(DataPack.comp_logo_by_id(DataPack.comp_id(0)) != null, "Brasileirão tem logo")
	var badge := DataPack.comp_badge()
	t.check(badge != null and badge.get_width() == 128, "emblema padrão gerado")
	t.check(DataPack.comp_logo_or_badge(-1) == badge, "competição sem logo usa o emblema")
	var missing := 0
	for li in World.LEAGUES.size():
		if DataPack.comp_logo_or_badge(DataPack.comp_id(li)) == null:
			missing += 1
	for d in World.CUPS.size():
		if DataPack.comp_logo_or_badge(int(World.CUPS[d].get("comp", -1))) == null:
			missing += 1
	t.check(missing == 0, "toda liga e copa mostra logo ou emblema")
