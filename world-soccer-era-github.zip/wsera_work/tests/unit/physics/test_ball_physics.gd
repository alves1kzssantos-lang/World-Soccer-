extends RefCounted
## Testes da física da bola (src/ball_physics.gd).


func run(t) -> void:
	# passe rasteiro para e não anda para trás
	var b := BallPhysics.new()
	b.place(Vector2(0, 40))
	b.kick_ground(Vector2(0, 20), 18.0)
	var last_y := 40.0
	var back := false
	for i in 600:
		b.step(1.0 / 60.0)
		if b.pos.y > last_y + 0.0001:
			back = true
		last_y = b.pos.y
	t.check(not back, "rasteiro anda só para frente")
	t.check(b.speed() < 0.01, "rasteiro para sozinho", "vel %.3f" % b.speed())
	t.check(not b.in_air(), "rasteiro fica no chão")

	# passe alto cai perto do alvo
	for target in [Vector2(10, 25), Vector2(-18, 12), Vector2(0, 5)]:
		b.place(Vector2(0, 40))
		var tt := b.kick_lofted(target, 4.0)
		var landed := Vector2.ZERO
		var top := 0.0
		for i in 600:
			b.step(1.0 / 240.0)
			top = maxf(top, b.z)
			if b.z <= 0.0 and i > 5:
				landed = b.pos
				break
		var err := landed.distance_to(target)
		t.check(err < 1.6, "passe alto cai perto de %s" % target, "erro %.2f m, voo %.2f s" % [err, tt])
		t.check(absf(top - 4.0) < 0.5, "passe alto chega na altura pedida", "%.2f m" % top)

	# leitura da linha do gol
	t.check(BallPhysics.classify_crossing(0.0, 1.0) == "gol", "meio do gol = gol")
	t.check(BallPhysics.classify_crossing(2.0, 3.5) == "por_cima", "acima do travessão = por cima")
	t.check(BallPhysics.classify_crossing(6.0, 0.5) == "fora", "longe do poste = fora")
	t.check(BallPhysics.classify_crossing(3.66, 1.0) == "trave", "na linha do poste = trave")
	t.check(BallPhysics.classify_crossing(1.0, 2.44) == "travessao", "na altura do travessão = travessão")

	# previsão de cruzamento da linha bate com a simulação
	b.place(Vector2(2, 16))
	b.kick_shot(Vector2(0.5, 0) - Vector2(2, 16), 25.0, 2.0)
	var pred := b.goal_line_crossing()
	var real := {}
	for i in 600:
		var prev := b.pos
		var ph := b.z
		b.step(1.0 / 120.0)
		if b.pos.y <= 0.0:
			real = {"x": b.pos.x, "z": ph}
			break
	t.check(not pred.is_empty() and absf(pred["x"] - real["x"]) < 0.15 and absf(pred["z"] - real["z"]) < 0.25,
		"previsão do chute na linha do gol", "prev %s real %s" % [pred, real])

	# mira com arrasto e curva: a bola cruza a linha onde foi mirada
	for c in [[Vector2(5, 18), 2.7, 0.6, 25.0, 1.6], [Vector2(-8, 25), -2.7, 1.8, 30.0, -2.0], [Vector2(0, 11), 2.8, 0.8, 22.0, 0.8]]:
		b.place(c[0])
		b.aim_shot(c[1], c[2], c[3], c[4])
		var cr := b.goal_line_crossing()
		t.check(not cr.is_empty() and absf(float(cr["x"]) - float(c[1])) < 0.05 and absf(float(cr["z"]) - float(c[2])) < 0.05,
			"chute mirado chega no ponto (curva %.1f)" % c[4], str(cr))
	# curva: a bola sai para um lado e volta (trajetória não é reta)
	b.place(Vector2(5, 20))
	b.aim_shot(2.0, 0.8, 24.0, 3.0)
	var max_dev := 0.0
	var p0 := b.pos
	for i in 120:
		b.step(1.0 / 60.0)
		if b.pos.y <= 0.0:
			break
		var line_x: float = lerpf(p0.x, 2.0, (p0.y - b.pos.y) / p0.y)
		max_dev = maxf(max_dev, absf(b.pos.x - line_x))
	t.check(max_dev > 0.3, "chute com efeito faz curva", "desvio máximo %.2f m" % max_dev)
	# passe: força calculada para chegar com a velocidade pedida
	b.place(Vector2(0, 40))
	var v0 := b.ground_speed_for(20.0, 7.0)
	b.kick_ground(Vector2(0, 20), v0)
	var steps := 0
	while b.pos.y > 20.0 and steps < 600:
		b.step(1.0 / 60.0)
		steps += 1
	t.check(absf(b.speed() - 7.0) < 0.3, "passe chega com a velocidade pedida", "saiu a %.1f, chegou a %.2f m/s" % [v0, b.speed()])
	t.check(absf(b.ground_reach(v0) - 20.0) > 1.0, "bola segue rolando depois do alvo", "alcance %.1f m" % b.ground_reach(v0))
	# quique: perde altura e velocidade
	b.place(Vector2(0, 30))
	b.kick_lofted(Vector2(0, 10), 5.0)
	var v_before := 0.0
	var v_after := 0.0
	var bounced := false
	var last_vz := b.vz
	for i in 600:
		var hv := b.vel.length()
		b.step(1.0 / 120.0)
		if not bounced and last_vz < 0.0 and b.vz > 0.0:
			bounced = true
			v_before = hv
			v_after = b.vel.length()
		last_vz = b.vz
	t.check(bounced and v_after < v_before * 0.9, "quique tira velocidade", "%.1f -> %.1f m/s" % [v_before, v_after])
