extends RefCounted
## Elencos reais (assets/data/rosters_real.json): nomes de clubes batem com World.LEAGUES,
## ninguém em dois clubes, todo elenco completo tem goleiro, e a carreira usa os nomes reais.

const POS := ["GOL", "ZAG", "LD", "LE", "VOL", "MEI", "PD", "PE", "AC"]


func run(t) -> void:
	var d = JSON.parse_string(FileAccess.get_file_as_string("res://assets/data/rosters_real.json"))
	t.check(typeof(d) == TYPE_DICTIONARY and d.size() >= 100, "rosters_real.json carrega", "%d clubes" % (d.size() if typeof(d) == TYPE_DICTIONARY else 0))
	if typeof(d) != TYPE_DICTIONARY:
		return
	var world := {}
	for lg in World.LEAGUES:
		for c in lg["clubs"]:
			world[c[0]] = true
			world[lg["name"] + "|" + c[0]] = true
	var bad_club: Array = []
	var bad_row: Array = []
	var no_gk: Array = []
	var seen := {}
	var dup: Array = []
	var no_nat: Array = []
	var total := 0
	for club in d.keys():
		if not world.has(club):
			bad_club.append(club)
		var gk := 0
		for r in d[club]:
			total += 1
			if r.size() < 4 or not (str(r[1]) in POS) or int(r[3]) < 40 or int(r[3]) > 94 or int(r[2]) < 15 or int(r[2]) > 45:
				bad_row.append("%s/%s" % [club, str(r[0])])
			if str(r[1]) == "GOL":
				gk += 1
			if r.size() < 5 or str(r[4]).strip_edges() == "":
				no_nat.append("%s/%s" % [club, str(r[0])])
			var key := "%s|%d" % [DataPack.norm(str(r[0])), int(r[2])]
			if seen.has(key) and seen[key] != club:
				dup.append("%s (%s, %s)" % [r[0], seen[key], club])
			seen[key] = club
		if d[club].size() >= 11 and gk == 0:
			no_gk.append(club)
	t.check(bad_club.is_empty(), "todo clube do JSON existe em World.LEAGUES", ", ".join(bad_club))
	t.check(bad_row.is_empty(), "posição, idade e nota válidas", "%d jogadores; %s" % [total, ", ".join(bad_row.slice(0, 5))])
	t.check(dup.is_empty(), "nenhum jogador em dois clubes", ", ".join(dup.slice(0, 5)))
	t.check(no_nat.is_empty(), "todo jogador real tem país", "%d sem país: %s" % [no_nat.size(), ", ".join(no_nat.slice(0, 5))])
	t.check(no_gk.is_empty(), "todo elenco completo tem goleiro", ", ".join(no_gk))

	# carreira nova em várias ligas: os nomes reais estão nos clubes certos, sem repetição
	var coach = {"name": "T", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	var checks := [["Premier League", "Tottenham", "Cristian Romero"], ["La Liga", "Villarreal", "Dani Parejo"],
		["Serie A Itália", "Atalanta", "Éderson"], ["Bundesliga", "Bayer Leverkusen", "Patrik Schick"],
		["Ligue 1", "Olympique de Marseille", "Mason Greenwood"], ["Liga Portugal", "Sporting", "Morten Hjulmand"],
		["Brasileirão Série A", "Flamengo", "Pedro"], ["Major League Soccer", "Inter Miami", "Lionel Messi"]]
	for ck in checks:
		var li := -1
		for i in World.LEAGUES.size():
			if World.LEAGUES[i]["name"] == ck[0]:
				li = i
		if li < 0:
			t.check(false, "liga %s existe" % ck[0])
			continue
		Game.new_career(5, coach, 0, li)
		var club_id := -1
		for c in Game.S["clubs"]:
			if not c["guest"] and World.LEAGUES[li]["clubs"][int(c["ci"])][0] == ck[1]:
				club_id = int(c["id"])
		var found := false
		var n_real := 0
		var sq: Array = Game.squad(club_id)
		for p in sq:
			if p["name"] == ck[2]:
				found = true
			if p.get("real", false):
				n_real += 1
		var names := {}
		var repeated := 0
		for pid in Game.S["players"]:
			var p: Dictionary = Game.S["players"][pid]
			if p.get("real", false):
				var k := "%s|%d" % [p["name"], int(p.get("real_age", p["age"]))]
				if names.has(k):
					repeated += 1
				names[k] = true
		# a carreira começa com algumas transferências da máquina: quem foi vendido aparece na lista
		var moved := false
		for tr in Game.S["transfers"]:
			if tr["name"] == ck[2]:
				moved = true
		t.check((found or moved) and sq.size() >= 22 and n_real >= 11, "%s: %s está no %s" % [ck[0], ck[2], ck[1]],
			"%d reais em %d%s" % [n_real, sq.size(), " (transferido)" if moved and not found else ""])
		t.check(repeated == 0, "%s: nenhum jogador real duplicado" % ck[0])
	# clube com elenco real parcial (menos de 11) também usa os nomes reais
	var bli := 0
	Game.new_career(5, coach, 0, bli)
	var remo := -1
	for c in Game.S["clubs"]:
		if not c["guest"] and World.LEAGUES[bli]["clubs"][int(c["ci"])][0] == "Remo":
			remo = int(c["id"])
	var has_rangel := false
	for p in Game.S["players"].values():
		# no clube, ou emprestado por ele (a máquina empresta jogadores entre clubes)
		if p["name"] == "Marcelo Rangel" and (int(p["club"]) == remo or (p.has("loan") and int(p["loan"]["from"]) == remo)):
			has_rangel = true
	t.check(remo < 0 or has_rangel, "elenco parcial entra (Remo: Marcelo Rangel)")
	# nome igual em países diferentes: o Independiente da Colômbia não recebe o elenco argentino
	t.check(Game.real_roster("Independiente", "Primera A").is_empty(), "Independiente (Colômbia) sem elenco argentino")
	t.check(Game.real_roster("Independiente", "Liga Argentina").size() >= 5, "Independiente (Argentina) com elenco real")
	t.check(Game.real_roster("Everton", "Chilean Primera División").is_empty(), "Everton (Chile) sem elenco inglês")
	t.check(Game.real_roster("Everton", "Premier League").size() >= 11, "Everton (Inglaterra) com elenco real")
	# nacionalidade que aparece na carreira: a do elenco real; sem ela, a do país da liga
	Game.new_career(5, coach, 0, 0)
	var nat_of := {}
	for pid in Game.S["players"]:
		var pl: Dictionary = Game.S["players"][pid]
		if pl.get("real", false):
			nat_of[pl["name"]] = pl["nat"]
	t.check(nat_of.get("Guillermo Varela", "") == "URU" and nat_of.get("Alex Sandro", "") == "BRA" \
		and nat_of.get("Jorginho", "") == "ITA" and nat_of.get("Léo Pereira", "") == "BRA",
		"países reais na carreira (Flamengo)", "Varela %s, Alex Sandro %s, Jorginho %s, Léo Pereira %s" % [nat_of.get("Guillermo Varela", "?"),
		nat_of.get("Alex Sandro", "?"), nat_of.get("Jorginho", "?"), nat_of.get("Léo Pereira", "?")])
	var flamengo := -1
	for c in Game.S["clubs"]:
		if not c["guest"] and World.LEAGUES[0]["clubs"][int(c["ci"])][0] == "Flamengo":
			flamengo = int(c["id"])
	Game._add_real_players([["Jogador Sem País Teste", "MEI", 25, 70]], flamengo, {}, false)
	var fallback := ""
	for pl in Game.squad(flamengo):
		if pl["name"] == "Jogador Sem País Teste":
			fallback = pl["nat"]
	t.check(fallback == World.LEAGUES[0]["nat"], "sem país no elenco: usa o país da liga", fallback)
	Game.delete_save(5)
