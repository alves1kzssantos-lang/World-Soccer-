extends RefCounted
## Temas por competição (src/comp_theme.gd, assets/data/temas.json): toda liga e copa tem tema
## válido, os temas próprios existem para as principais e o texto tem contraste suficiente.

const KEYS := ["accent", "accent2", "bg1", "bg2", "bar", "score", "text_acc", "on_accent", "glass"]


func _valid(th: Dictionary) -> bool:
	for k in KEYS:
		if not th.has(k) or typeof(th[k]) != TYPE_COLOR:
			return false
	return str(th.get("pattern", "")) in CompTheme.PATTERNS and str(th.get("score_style", "")) in CompTheme.SCORE_STYLES \
		and str(th.get("title_style", "")) in CompTheme.TITLE_STYLES and str(th.get("trophy", "")) in ["ouro", "prata"]


func run(t) -> void:
	var bad: Array = []
	for li in World.LEAGUES.size():
		if not _valid(CompTheme.for_league(li)):
			bad.append(World.LEAGUES[li]["name"])
	for d in World.CUPS.size():
		if not _valid(CompTheme.for_cup_def(d)):
			bad.append(World.CUPS[d]["name"])
	t.check(bad.is_empty(), "toda liga e copa tem tema válido", str(bad))
	var json_ids := CompTheme.ids()
	var missing: Array = []
	for id in json_ids:
		if str(CompTheme.by_id(id)["id"]) != str(id):
			missing.append(id)
	t.check(missing.is_empty() and json_ids.size() >= 20, "temas do arquivo montam", "%d temas %s" % [json_ids.size(), missing])
	# principais competições com tema próprio (não o padrão)
	var main := ["Brasileirão Série A", "Brasileirão Série B", "Brasileirão Série C", "Copa do Brasil", "Copa Libertadores",
		"Premier League", "FA Cup", "Carabao Cup", "La Liga", "Serie A Itália", "Bundesliga", "Ligue 1", "Liga Portugal",
		"Champions League", "Liga Argentina", "Major League Soccer", "Saudi Pro League", "Liga MX Apertura",
		"Campeonato Paulista", "Campeonato Carioca", "Campeonato Mineiro", "Campeonato Gaúcho"]
	var plain: Array = []
	for n in main:
		if str(CompTheme.for_comp(n)["id"]) == "default":
			plain.append(n)
	t.check(plain.is_empty(), "principais competições têm identidade própria", str(plain))
	var ids_seen := {}
	for n in main:
		ids_seen[str(CompTheme.for_comp(n)["id"])] = true
	t.check(ids_seen.size() >= 18, "identidades distintas", "%d" % ids_seen.size())
	t.check(str(CompTheme.for_comp("Liga que não existe")["id"]) == "default", "competição sem tema usa a marca")
	t.check(CompTheme.for_comp("Copa Libertadores")["trophy"] == "prata" and CupScreens.trophy_style("Champions League") == "prata", "taça de prata nas continentais")
	# contraste: texto branco sobre faixa/fundo e destaque como texto sobre a faixa >= 4.5
	var low: Array = []
	var all_ids: Array = json_ids.duplicate()
	all_ids.append("")
	for id in all_ids:
		var th := CompTheme.by_id(str(id))
		var pairs := [[Color.WHITE, th["bar"]], [Color.WHITE, th["bg1"]], [Color.WHITE, th["score"]], [th["text_acc"], th["bar"]],
			[th["on_accent"], th["accent"]]]
		for p in pairs:
			var r := CompTheme.contrast(p[0], p[1])
			if r < CompTheme.MIN_CONTRAST:
				low.append("%s %.2f" % [th["id"], r])
	t.check(low.is_empty(), "contraste do texto nos temas >= 4.5:1", str(low))
	t.check(absf(CompTheme.contrast(Color.WHITE, Color.BLACK) - 21.0) < 0.01, "cálculo de contraste (branco/preto = 21)")
	# cup_dict mantém as chaves das telas de copa
	var cd := CupScreens.theme_for("Copa do Brasil")
	var ok := true
	for k in ["bg", "bg1", "bg2", "head", "head2", "title", "sub", "btn", "btn2", "btn_txt", "tab", "tab_txt", "accent", "icon"]:
		ok = ok and cd.has(k)
	t.check(ok, "tema das telas de copa tem todas as chaves")
	# geometria dos fundos em cache (sem refazer a cada quadro)
	for pat in CompTheme.PATTERNS:
		var g1: Array = CompTheme.pattern_geo(pat, Vector2(1280, 50))
		var g2: Array = CompTheme.pattern_geo(pat, Vector2(1280, 50))
		if not is_same(g1, g2) or PackedVector2Array(g1[0]).size() < 2 or PackedVector2Array(g1[0]).size() % 2 != 0:
			ok = false
	t.check(ok, "fundos temáticos: geometria válida e em cache")
	# HUD: aplicar o tema troca o destaque e refaz os estilos
	LanceView.set_hud_theme(CompTheme.for_comp("Champions League"))
	var champ_acc := LanceView.hud_acc
	LanceView.set_hud_theme(CompTheme.by_id(""))
	t.check(champ_acc == Color(CompTheme.for_comp("Champions League")["accent"]) and LanceView.hud_acc == UI.NEON, "HUD segue o tema da partida")
