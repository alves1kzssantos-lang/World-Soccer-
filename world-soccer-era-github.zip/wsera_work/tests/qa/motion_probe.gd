extends Node
## Sonda de movimento: mede o "ritmo" da partida quadro a quadro (passo fixo de 60 Hz).
## godot --headless --path . res://tests/qa/motion_probe.tscn
## Campo ao vivo: % parado, trancos (aceleração acima do limite do corpo), teleportes,
## condutor parado (>1 s), passes por minuto, velocidade da bola no passe, tremida da câmera.
## Lances: duração, tempo em "decide", pausas por lance, % parado dos atacantes.
const DT := 1.0 / 60.0
var out := {}


func _ready() -> void:
	var coach = {"name": "T", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.rng.seed = 4242
	Game.new_career(2, coach, 3, 0)
	_field()
	_lances(false)
	_lances(true)
	print("MOTION ", JSON.stringify(out))
	Game.delete_save(2)
	get_tree().quit()


func _ent_stats(ents: Array, prev: Dictionary, acc: Dictionary) -> void:
	for e in ents:
		if e.get("is_ref", false):
			continue
		var id: int = int(e["p"]["id"])
		var v: Vector2 = e.get("vel", Vector2.ZERO)
		var p: Vector2 = e["pos"]
		acc["n"] += 1
		if v.length() < 0.3:
			acc["idle"] += 1
		if prev.has(id):
			var pv: Array = prev[id]
			var a: float = (v - pv[1]).length() / DT
			if a > 25.0:
				acc["jerk"] += 1
			if p.distance_to(pv[0]) > 0.5:
				acc["tele"] += 1
			# arranca-para: velocidade cai abaixo de 0,5 e volta acima de 2 em menos de 1 s
		prev[id] = [p, v]


func _field() -> void:
	var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 5) % 20)
	var fv := FieldView.new()
	fv.size = Vector2(1280, 576)
	add_child(fv)
	fv.setup_field(sim)
	fv.s = fv.size.x / FieldView.FIELD_CAM_M
	var acc := {"n": 0, "idle": 0, "jerk": 0, "tele": 0}
	var prev := {}
	var steps := 60 * 120
	var passes := 0
	var pass_spd := 0.0
	var last_state: String = fv.ball_state
	var stall_t := 0.0
	var stalls := 0
	var carrier_idle := 0
	var carrier_n := 0
	var cam_flip := 0
	var last_cvy := 0.0
	var fv_speed_sum := 0.0
	var sync_sum := 0.0
	var sync_n := 0
	var spd_var_sum := 0.0
	for i in steps:
		if i % 120 == 0:
			for e in sim.step():
				if e["type"] == "chance":
					fv.show_chance(e["side"])
				elif e["type"] == "goal":
					fv.kickoff(1 - e["side"])
			fv.feed_minute(sim.last_side)
		fv._process(DT)
		_ent_stats(fv._teams_all, prev, acc)
		for e in fv._teams_all:
			fv_speed_sum += float(e.get("vel", Vector2.ZERO).length())
		# sincronia: quanto os companheiros andam igual (1 = bloco robótico)
		for sd in 2:
			var vs: Array = []
			for e in fv.teams[sd]:
				var v: Vector2 = e.get("vel", Vector2.ZERO)
				if v.length() > 1.0 and not e.get("keeper", false):
					vs.append(v)
			if vs.size() >= 4:
				var m := Vector2.ZERO
				var ms := 0.0
				for v in vs:
					m += v.normalized()
					ms += v.length()
				sync_sum += m.length() / vs.size()
				ms /= vs.size()
				var var_s := 0.0
				for v in vs:
					var_s += absf(v.length() - ms)
				spd_var_sum += var_s / vs.size() / maxf(ms, 0.1)
				sync_n += 1
		if fv.ball_state == "pass" and last_state != "pass":
			passes += 1
			pass_spd += fv.bp.speed()
		last_state = fv.ball_state
		if fv.ball_state == "dribble" and fv.holder >= 0 and fv.holder < fv.teams[fv.owner_side].size():
			var c: Dictionary = fv.teams[fv.owner_side][fv.holder]
			carrier_n += 1
			if float(c.get("vel", Vector2.ZERO).length()) < 0.6:
				carrier_idle += 1
				stall_t += DT
			else:
				if stall_t > 1.0:
					stalls += 1
				stall_t = 0.0
		if signf(fv._cam_vy) != signf(last_cvy) and absf(fv._cam_vy) > 0.3:
			cam_flip += 1
		last_cvy = fv._cam_vy
	var mins := steps * DT / 60.0
	out["campo"] = {
		"parado_pct": snappedf(100.0 * acc["idle"] / acc["n"], 0.1),
		"trancos_pct": snappedf(100.0 * acc["jerk"] / acc["n"], 0.01),
		"teleportes": acc["tele"],
		"vel_media": snappedf(fv_speed_sum / acc["n"], 0.01),
		"condutor_parado_pct": snappedf(100.0 * carrier_idle / maxf(carrier_n, 1), 0.1),
		"condutor_paradas_1s_por_min": snappedf(stalls / mins, 0.01),
		"passes_por_min": snappedf(passes / mins, 0.1),
		"vel_passe": snappedf(pass_spd / maxf(passes, 1), 0.1),
		"camera_tremidas_por_min": snappedf(cam_flip / mins, 0.1),
		"sincronia_time": snappedf(sync_sum / maxf(sync_n, 1), 0.01),
		"variacao_velocidade": snappedf(spd_var_sum / maxf(sync_n, 1), 0.01),
	}
	fv.free()


func _lances(user: bool) -> void:
	var suite = load("res://tests/integration/match/test_match_balance.gd").new()
	var kinds := ["goal", "save", "out", "lost", "offside"]
	var n := 30
	var dur := 0.0
	var dec := 0.0
	var pauses := 0
	var acc := {"n": 0, "idle": 0, "jerk": 0, "tele": 0}
	var halt := 0
	var halt_n := 0
	for k in n:
		var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 3 + k % 7) % 20)
		sim.minute = 30
		sim.pending = {"side": 0, "pg": 0.3}
		var lv := LanceView.new()
		lv.size = Vector2(1280, 576)
		lv.setup(sim, 0, user)
		if not user:
			lv.script_kind = kinds[k % kinds.size()]
		var prev := {}
		var last := ""
		var guard := 0
		while lv.state != "done" and lv.state != "end" and guard < 60 * 20:
			guard += 1
			if user and lv.state == "decide":
				suite._auto_play(lv)   # o jogador decide na hora (sem contar o tempo de pensar)
			lv._process(DT)
			dur += DT
			if lv.state == "decide":
				dec += DT
			if lv.state == "decide" and last != "decide":
				pauses += 1
			last = lv.state
			_ent_stats(lv.att + lv.dfn, prev, acc)
			# todos quase parados ao mesmo tempo = "congelou"
			var still := 0
			for e in lv.att + lv.dfn:
				if float(e.get("vel", Vector2.ZERO).length()) < 0.5:
					still += 1
			halt_n += 1
			if still >= int((lv.att.size() + lv.dfn.size()) * 0.7):
				halt += 1
		lv.free()
	out["lances_jogador" if user else "lances_maquina"] = {
		"duracao_media_s": snappedf(dur / n, 0.01),
		"decide_s_por_lance": snappedf(dec / n, 0.01),
		"pausas_por_lance": snappedf(float(pauses) / n, 0.01),
		"parado_pct": snappedf(100.0 * acc["idle"] / maxf(acc["n"], 1), 0.1),
		"congelado_pct": snappedf(100.0 * halt / maxf(halt_n, 1), 0.1),
		"trancos_pct": snappedf(100.0 * acc["jerk"] / maxf(acc["n"], 1), 0.01),
		"teleportes": acc["tele"],
	}
