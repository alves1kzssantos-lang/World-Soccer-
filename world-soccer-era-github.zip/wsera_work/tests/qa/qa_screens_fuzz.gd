extends Node
## QA: abre todas as telas em vários estados da carreira e testa saves antigos/corrompidos.
## Story type: Integration | Saída: stdout; erros de script aparecem como "SCRIPT ERROR" no log | Gate: ADVISORY
## Rodar: XDG_DATA_HOME=... godot --headless --path . res://tests/qa/qa_screens_fuzz.tscn 2>&1 | grep -B2 -A6 "SCRIPT ERROR\|MARCA"
## Cada etapa imprime "MARCA <etapa>" antes de rodar, para localizar o erro no log.

const SLOT := 3
var main
var problems: Array = []


func bad(msg: String) -> void:
	problems.append(msg)
	print("  PROBLEMA: ", msg)


func frames(n: int) -> void:
	for i in n:
		await get_tree().process_frame


func show(name: String, arg = null) -> void:
	print("MARCA tela ", name, " ", str(arg).left(60))
	main.go(name, arg)
	await frames(2)


func coach_screens(tag: String) -> void:
	print("MARCA estado ", tag)
	var me: int = Game.S["club"]
	var sq := Game.squad(me)
	var other := Game.squad((me + 1) % Game.n_league())
	for s in ["hub", "table", "calendar", "results", "finance", "central", "transfers", "lineup", "squad", "youth", "market",
			"offers", "social", "interview"]:
		await show(s)
	if not sq.is_empty():
		await show("player", sq[0]["id"])
		await show("contract", sq[0]["id"])
	if not other.is_empty():
		await show("player", other[0]["id"])
		await show("contract", other[0]["id"])
	var free := Game.squad(Game.FREE)
	if not free.is_empty():
		await show("contract", free[0]["id"])
	if not Game.S.get("last_user", {}).is_empty():
		await show("postmatch", Game.S["last_user"])
	for ci in Game.S.get("cups", []).size():
		await show("cup", {"cup": ci, "next": false})
		await show("cup_results", {"cup": ci, "stage": -1, "next": false})
	if Game.S["season_over"]:
		await show("season_end")
	main.home()
	await frames(2)


func pro_screens(tag: String) -> void:
	print("MARCA estado pro ", tag)
	for s in ["pro_hub", "pro_season", "pro_feed", "social", "interview", "table", "calendar", "results"]:
		await show(s)
	for t in 5:
		main.screens.get("pro_hub")
		var sp = main._keep[3]
		sp.tab = t
		main.replace("pro_hub")
		await frames(2)
	main.home()
	await frames(2)


func _ready() -> void:
	Game.delete_save(SLOT)
	Game.rng.seed = 404
	Media.R.seed = 404
	main = load("res://main.tscn").instantiate()
	add_child(main)
	while not DataPack.loaded():
		await get_tree().process_frame
	for s in ["title", "careers", "coach", "clubs", "datapack", "dp_browse"]:
		await show(s)
	var coach = {"name": "QA Telas", "age": 44, "nat": "Portugal", "skin": 3, "hair": 2, "haircolor": 1, "beard": 0, "suit": 1, "rep": 5.0}
	Game.new_career(SLOT, coach, 5, 3)
	await coach_screens("início")
	for k in 12:
		Game.play_next(null)
		if k == 3:
			await show("interview")
	await coach_screens("meio (coletiva pendente)")
	while Media.has_interview():
		Media.answer("confiante")
	var guard := 0
	while not Game.S["season_over"] and guard < 200:
		guard += 1
		Game.play_next(null)
		Media.skip_interview()
	await coach_screens("fim de temporada")
	Game.new_season()
	await coach_screens("temporada 2")

	# ----- saves antigos: sem chaves opcionais (versões anteriores)
	Game.play_next(null)
	Game.save()
	var base: Dictionary = Game.S.duplicate(true)
	for k in ["media", "guests", "n_league", "last_user", "cups", "transfers", "offers", "history", "trophies", "fin", "unread", "mode", "ver", "league"]:
		print("MARCA save sem chave ", k)
		var d := base.duplicate(true)
		if not d.has(k):
			continue
		d.erase(k)
		var f := FileAccess.open(Game.SAVE_PATH % SLOT, FileAccess.WRITE)
		f.store_var(d)
		f.close()
		var pk := Game.peek_save(SLOT)
		if not Game.load_career(SLOT):
			bad("save sem '%s' não carrega" % k)
			continue
		main.home()
		await frames(2)
		Game.play_next(null)
		while Media.has_interview():
			Media.answer("humilde")
		main.home()
		await frames(2)
		await show("social")
		await show("finance")
		await show("transfers")
		if pk.is_empty():
			bad("peek_save vazio sem '%s'" % k)
		await show("careers")

	# ----- save corrompido: principal truncado -> usa o .bak
	print("MARCA save corrompido")
	Game.S = base.duplicate(true)
	Game.slot = SLOT
	Game.save()
	Game.S["money"] = 12345.0
	Game.save()   # o anterior vira .bak
	var bytes := FileAccess.get_file_as_bytes(Game.SAVE_PATH % SLOT)
	var f2 := FileAccess.open(Game.SAVE_PATH % SLOT, FileAccess.WRITE)
	f2.store_buffer(bytes.slice(0, bytes.size() / 2))
	f2.close()
	var ok := Game.load_career(SLOT)
	if not ok:
		bad("save truncado: nem o backup carrega")
	elif float(Game.S["money"]) == 12345.0:
		bad("save truncado carregou dados do arquivo quebrado")
	print("  truncado -> load ", ok, " dinheiro ", Game.S.get("money"))
	# lixo puro
	var f3 := FileAccess.open(Game.SAVE_PATH % SLOT, FileAccess.WRITE)
	f3.store_string("isto não é um save")
	f3.close()
	print("  lixo -> load ", Game.load_career(SLOT))
	await show("careers")
	# os dois corrompidos
	for p in [Game.SAVE_PATH % SLOT, (Game.SAVE_PATH % SLOT) + ".bak"]:
		var f4 := FileAccess.open(p, FileAccess.WRITE)
		f4.store_buffer(PackedByteArray([1, 2, 3, 4, 5, 6, 7, 8]))
		f4.close()
	print("  dois corrompidos -> load ", Game.load_career(SLOT), " peek ", Game.peek_save(SLOT))
	await show("careers")

	# ----- carreira de jogador
	Game.delete_save(SLOT)
	var prof := Pro.new_profile()
	prof["name"] = "QA Pro"
	prof["pos"] = "MEI"
	Pro.start(SLOT, prof)
	main.home()
	await frames(2)
	await show("pro_trial")
	Game.play_next(null)
	main.home()
	await frames(2)
	await show("pro_offers")
	Pro.accept(0)
	await pro_screens("início")
	for k in 8:
		Game.play_next(null)
	await pro_screens("meio")
	guard = 0
	while not Game.S["season_over"] and guard < 200:
		guard += 1
		Game.play_next(null)
	Pro.close_season()
	await pro_screens("fim")
	await show("careers")
	Game.delete_save(SLOT)
	print("QA SCREENS problemas: ", problems.size())
	for p in problems:
		print("   - ", p)
	get_tree().quit()
