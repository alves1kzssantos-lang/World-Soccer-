extends Node
## QA soak (headless): carreiras de técnico com várias temporadas em várias ligas + carreira de jogador.
## Story type: Integration | Saída: stdout (resumo em production/qa/qa-report.md) | Gate: ADVISORY (soak)
## Rodar: XDG_DATA_HOME=... godot --headless --path . res://tests/qa/qa_career_soak.tscn
##   argumentos opcionais depois de "--": leagues=0,3,51,19 seasons=3 pro_seasons=2
## Checa: NaN/inf em dinheiro e energia, escalações válidas, copas com campeão, round-trip de save/load
## (bytes idênticos), crescimento de memória/objetos por temporada, laços que não terminam.

const SLOT := 7
const PRO_SLOT := 6
const TONES := ["humilde", "confiante", "provocar", "desviar"]

var problems: Array = []
var leagues: Array = [0, 3, 51, 19]
var seasons := 3
var pro_seasons := 2
var tone_count := {}


func _args() -> void:
	for a in OS.get_cmdline_user_args():
		var kv := a.split("=")
		if kv.size() != 2:
			continue
		match kv[0]:
			"leagues":
				leagues = []
				for x in kv[1].split(","):
					leagues.append(int(x))
			"seasons":
				seasons = int(kv[1])
			"pro_seasons":
				pro_seasons = int(kv[1])


func bad(msg: String) -> void:
	if problems.size() < 200:
		problems.append(msg)
	print("  PROBLEMA: ", msg)


func mem() -> Dictionary:
	return {"obj": int(Performance.get_monitor(Performance.OBJECT_COUNT)),
		"mem_mb": Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0,
		"res": int(Performance.get_monitor(Performance.OBJECT_RESOURCE_COUNT)),
		"nodes": int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))}


func save_size(slot: int) -> int:
	var f := FileAccess.open(Game.SAVE_PATH % slot, FileAccess.READ)
	if f == null:
		return -1
	var n := f.get_length()
	f.close()
	return n


## Primeiro caminho onde a e b diferem (para o round-trip do save).
func diff_path(a, b, path: String = "S") -> String:
	if typeof(a) != typeof(b):
		return "%s: tipo %d != %d" % [path, typeof(a), typeof(b)]
	if typeof(a) == TYPE_DICTIONARY:
		if a.size() != b.size():
			return "%s: %d chaves != %d" % [path, a.size(), b.size()]
		for k in a:
			if not b.has(k):
				return "%s: falta chave %s" % [path, str(k)]
			var d := diff_path(a[k], b[k], "%s[%s]" % [path, str(k)])
			if d != "":
				return d
		return ""
	if typeof(a) == TYPE_ARRAY:
		if a.size() != b.size():
			return "%s: %d itens != %d" % [path, a.size(), b.size()]
		for i in a.size():
			var d := diff_path(a[i], b[i], "%s[%d]" % [path, i])
			if d != "":
				return d
		return ""
	if typeof(a) == TYPE_FLOAT:
		if a != b and not (is_nan(a) and is_nan(b)):
			return "%s: %s != %s" % [path, str(a), str(b)]
		return ""
	if a != b:
		return "%s: %s != %s" % [path, str(a), str(b)]
	return ""


func roundtrip(slot: int, tag: String) -> bool:
	Game.save()
	var before: Dictionary = Game.S.duplicate(true)
	var bb := var_to_bytes(Game.S)
	var ok := Game.load_career(slot)
	if not ok:
		bad("%s: load_career falhou" % tag)
		return false
	var d := diff_path(before, Game.S)
	if d != "":
		bad("%s: save/load diferente: %s" % [tag, d])
		return false
	if var_to_bytes(Game.S) != bb:
		bad("%s: save/load bytes diferentes" % tag)
		return false
	# peek_save precisa funcionar em qualquer save
	var pk := Game.peek_save(slot)
	if pk.is_empty():
		bad("%s: peek_save vazio" % tag)
	return true


func finite(x) -> bool:
	return not (is_nan(float(x)) or is_inf(float(x)))


## Invariantes depois de cada jogo.
func check_state(tag: String) -> void:
	var S: Dictionary = Game.S
	if not finite(S["money"]):
		bad("%s: dinheiro não finito %s" % [tag, str(S["money"])])
	if absf(float(S["money"])) > 1e6:
		bad("%s: dinheiro absurdo %s" % [tag, str(S["money"])])
	for k in S["fin"]:
		if not finite(S["fin"][k]):
			bad("%s: fin[%s] não finito" % [tag, k])
	var nan_p := 0
	for p in S["players"].values():
		if not finite(p["energy"]) or float(p["energy"]) < 0.0 or float(p["energy"]) > 100.0:
			nan_p += 1
		if not finite(p["value"]) or not finite(p["wage"]) or float(p["value"]) < 0.0:
			nan_p += 1
		if int(p["ovr"]) < 1 or int(p["ovr"]) > 99:
			nan_p += 1
	if nan_p > 0:
		bad("%s: %d jogadores com energia/valor/ovr inválidos" % [tag, nan_p])
	if int(S["support"]) < 0 or int(S["support"]) > 100:
		bad("%s: support fora de 0..100: %d" % [tag, S["support"]])
	# escalações: 11, sem repetidos, jogadores do clube
	for cid in S["clubs"].size():
		var xi: Array = S["clubs"][cid]["xi"]
		var seen := {}
		for pid in xi:
			if not S["players"].has(pid):
				bad("%s: clube %d escalado com jogador inexistente %d" % [tag, cid, pid])
				continue
			if int(S["players"][pid]["club"]) != cid:
				bad("%s: clube %d escala jogador de outro clube (%d está no %d)" % [tag, cid, pid, S["players"][pid]["club"]])
			if seen.has(pid):
				bad("%s: clube %d escala %d duas vezes" % [tag, cid, pid])
			seen[pid] = true
		if xi.size() != 11 and cid < Game.n_league():
			bad("%s: clube %d com %d titulares" % [tag, cid, xi.size()])
	var media: Dictionary = S.get("media", {})
	for k in ["diretoria", "moral", "imprensa", "aprovacao"]:
		if media.has(k) and (not finite(media[k]) or float(media[k]) < 0.0 or float(media[k]) > 100.0):
			bad("%s: media[%s] inválido %s" % [tag, k, str(media[k])])
	if media.has("feed") and media["feed"].size() > Media.FEED_MAX:
		bad("%s: feed passou do limite" % tag)


## Ações de mercado do usuário (técnico): contrata livre, aceita/recusa propostas, lista, promove base.
func market_actions(stats: Dictionary) -> void:
	var me: int = Game.S["club"]
	var r := Game.rng
	# aceitar ou recusar proposta
	if not Game.S["offers"].is_empty():
		if r.randf() < 0.5:
			var res := Game.accept_offer(0)
			if res == "":
				stats["sold"] += 1
		else:
			Game.reject_offer(0)
	# contratar um livre barato
	if r.randf() < 0.25 and Game.squad(me).size() < 28:
		var free: Array = Game.squad(Game.FREE)
		if not free.is_empty():
			var p: Dictionary = free[r.randi_range(0, free.size() - 1)]
			var res := Game.sign_player(int(p["id"]), 0.0, Game.ask_wage(p), 2)
			if res == "":
				stats["signed"] += 1
	# contratar de outro clube se tiver caixa
	if r.randf() < 0.1:
		var other := r.randi_range(0, Game.n_league() - 1)
		if other != me:
			var sq := Game.squad(other)
			if not sq.is_empty():
				var p: Dictionary = sq[r.randi_range(0, sq.size() - 1)]
				var fee := Game.ask_fee(p)
				var res := Game.sign_player(int(p["id"]), fee, Game.ask_wage(p), 3)
				if res == "":
					stats["bought"] += 1
					if Game.squad(other).size() < 11:
						bad("clube %d ficou com %d jogadores após venda ao usuário" % [other, Game.squad(other).size()])
	# listar jogador
	if r.randf() < 0.1:
		var sq := Game.squad(me)
		if sq.size() > 18:
			sq[r.randi_range(0, sq.size() - 1)]["listed"] = true
	# promover base
	if r.randf() < 0.05:
		var y := Game.squad(Game.YOUTH)
		if not y.is_empty():
			if Game.promote_youth(int(y[0]["id"])) == "":
				stats["promoted"] += 1


func press(stats: Dictionary) -> void:
	var guard := 0
	if Media.has_interview() and Game.rng.randf() < 0.08:
		Media.skip_interview()
		stats["skipped"] += 1
		return
	while Media.has_interview() and guard < 10:
		guard += 1
		var tone: String = TONES[int(stats["answers"]) % 4]
		var res := Media.answer(tone)
		if res.is_empty():
			bad("Media.answer(%s) devolveu vazio com coletiva pendente" % tone)
			break
		tone_count[tone] = int(tone_count.get(tone, 0)) + 1
		stats["answers"] += 1
	if guard >= 10:
		bad("coletiva não termina")


func coach_career(li: int) -> Dictionary:
	var coach = {"name": "QA Soak", "age": 40, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	var n_cl: int = World.LEAGUES[li]["clubs"].size()
	var club_id := (li * 7 + 3) % n_cl
	Game.new_career(SLOT, coach, club_id, li)
	var out := {"league": Game.LEAGUE, "li": li, "club": Game.my_club()["name"], "seasons": []}
	for s in seasons:
		var t0 := Time.get_ticks_msec()
		var stats := {"matches": 0, "cup_matches": 0, "sold": 0, "signed": 0, "bought": 0, "promoted": 0, "answers": 0, "skipped": 0}
		var guard := 0
		var cup_days := 0
		while not Game.S["season_over"] and guard < 200:
			guard += 1
			market_actions(stats)
			var mt := Game.next_user_match()
			if mt.is_empty():
				bad("%s T%d: next_user_match vazio antes do fim da temporada" % [Game.LEAGUE, s + 1])
				break
			if mt["kind"] == "cup":
				stats["cup_matches"] += 1
			var day0: int = int(Game.S["day"])
			Game.play_next(null)
			stats["matches"] += 1
			if int(Game.S["day"]) < day0:
				bad("%s: data voltou no tempo %d -> %d" % [Game.LEAGUE, day0, Game.S["day"]])
			press(stats)
			check_state("%s T%d J%d" % [Game.LEAGUE, s + 1, stats["matches"]])
		if guard >= 200:
			bad("%s T%d: temporada não terminou em 200 jogos (laço?)" % [Game.LEAGUE, s + 1])
		# copas: todas com campeão no fim da temporada
		var cups_info: Array = []
		for c in Game.S["cups"]:
			cups_info.append("%s:%s" % [c["name"], Game.club_name(int(c["champion"])) if int(c["champion"]) >= 0 else "SEM CAMPEÃO"])
			if int(c["champion"]) < 0:
				bad("%s T%d: copa %s sem campeão no fim da temporada" % [Game.LEAGUE, s + 1, c["name"]])
		var sm := Game.season_summary()
		var info := {"season": s + 1, "pos": sm["pos"], "money": snappedf(float(Game.S["money"]), 0.01), "matches": stats["matches"],
			"cup_matches": stats["cup_matches"], "stats": stats, "cups": cups_info, "players": Game.S["players"].size(),
			"clubs": Game.S["clubs"].size(), "save_kb": save_size(SLOT) / 1024.0, "ms": Time.get_ticks_msec() - t0}
		roundtrip(SLOT, "%s fim T%d" % [Game.LEAGUE, s + 1])
		Game.new_season()
		check_state("%s início T%d" % [Game.LEAGUE, s + 2])
		roundtrip(SLOT, "%s início T%d" % [Game.LEAGUE, s + 2])
		if Game.S["season_over"] or int(Game.S["round"]) != 0:
			bad("%s: nova temporada não reiniciou o calendário" % Game.LEAGUE)
		info.merge(mem())
		out["seasons"].append(info)
		print("  ", Game.LEAGUE, " T", s + 1, " ", info)
	return out


func pro_career() -> Dictionary:
	Game.rng.seed = 99
	var prof := Pro.new_profile()
	prof["name"] = "QA Craque"
	prof["pos"] = "PD"
	Pro.start(PRO_SLOT, prof)
	var out := {"seasons": []}
	if Game.next_user_match().get("kind", "") != "trial":
		bad("pro: primeira partida não é a peneira")
	Game.play_next(null)
	if Pro.P()["stage"] != "propostas" or Pro.P()["offers"].is_empty():
		bad("pro: sem propostas depois da peneira")
		return out
	Pro.accept(0)
	roundtrip(PRO_SLOT, "pro pós-assinatura")
	for s in pro_seasons:
		var t0 := Time.get_ticks_msec()
		var guard := 0
		var games := 0
		var replies := 0
		while not Game.S["season_over"] and guard < 200:
			guard += 1
			if Game.next_user_match().is_empty():
				bad("pro T%d: next_user_match vazio" % (s + 1))
				break
			Game.play_next(null)
			games += 1
			var gp := 0
			while Media.has_interview() and gp < 10:
				gp += 1
				Media.answer(TONES[(games + gp) % 4])
			for post_d in Pro.P()["feed"]:
				if Pro.can_reply(post_d) and replies < 30:
					Pro.reply(int(post_d["id"]), ["humilde", "provocar", "xingar"][replies % 3])
					replies += 1
					break
			if Pro.me().is_empty():
				bad("pro: jogador sumiu do save")
				break
			check_state("pro T%d J%d" % [s + 1, games])
			if not finite(Pro.P()["money"]):
				bad("pro: dinheiro do jogador não finito")
		if guard >= 200:
			bad("pro T%d: temporada não termina" % (s + 1))
		var rep := Pro.close_season()
		var info := {"season": s + 1, "games": games, "avg": snappedf(Pro.avg_rating(), 0.01), "money": snappedf(float(Pro.P()["money"]), 0.01),
			"stage": Pro.P()["stage"], "club": Game.my_club()["name"], "fame": snappedf(float(Pro.P()["fame"]), 0.1), "ms": Time.get_ticks_msec() - t0,
			"report_keys": rep.size(), "save_kb": save_size(PRO_SLOT) / 1024.0}
		roundtrip(PRO_SLOT, "pro fim T%d" % (s + 1))
		if Pro.P()["stage"] == "livre":
			Pro.accept(0)
		else:
			Pro.next_season()
		roundtrip(PRO_SLOT, "pro início T%d" % (s + 2))
		if Game.S["season_over"]:
			bad("pro: nova temporada continua encerrada")
		info.merge(mem())
		out["seasons"].append(info)
		print("  PRO T", s + 1, " ", info)
	return out


func _ready() -> void:
	_args()
	if not DataPack.loaded():
		DataPack.import_zip("res://datapack.zip")
	Game.rng.seed = 2026
	Media.R.seed = 2026
	var t0 := Time.get_ticks_msec()
	print("QA SOAK início ", mem())
	var res: Array = []
	for li in leagues:
		res.append(coach_career(li))
		Game.delete_save(SLOT)
	print("QA SOAK pro")
	var pr := pro_career()
	Game.delete_save(PRO_SLOT)
	Game.S = {}
	print("QA SOAK tons respondidos ", tone_count)
	print("QA SOAK fim ", mem(), " tempo total ", Time.get_ticks_msec() - t0, " ms")
	print("QA SOAK problemas: ", problems.size())
	for p in problems:
		print("   - ", p)
	get_tree().quit(1 if not problems.is_empty() else 0)
