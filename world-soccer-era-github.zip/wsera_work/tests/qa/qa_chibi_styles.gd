extends Node
func _ready():
	var n := 0
	for st in 8:
		for px in [24.0, 30.0, 38.0, 48.0, 56.0, 96.0, 100.0]:
			for mode in ["head", "bust", "full"]:
				var lk := {"hstyle": st, "skin": 1, "hair": 0}
				var c = ChibiPortrait.make(lk, px, mode)
				add_child(c)
				n += 1
	for i in 3: await get_tree().process_frame
	print("CHIBI drawn ", n)
	get_tree().quit()
