extends Node
## QA de desempenho: custo por quadro de _process e _draw (GDScript) e quadro total, por tela.
## Story type: Integration (perf) | Saída: stdout (tabela em production/qa/qa-report.md) | Gate: ADVISORY
## Rodar (sem limite de fps, delta fixo de 1/60 s):
##   headless:  godot --headless --fixed-fps 60 --path . res://tests/qa/qa_perf.tscn
##   janela:    DISPLAY=:99 godot --fixed-fps 60 --path . res://tests/qa/qa_perf.tscn   (inclui renderização por software)
## Medição só por sondas neste script (nada é instrumentado no código do jogo):
##   - sonda "início" (process_priority mínimo) e "fim" (máximo): tempo de _process de todos os nós;
##   - call_deferred da sonda "fim" roda depois das chamadas de _draw enfileiradas pelo queue_redraw do quadro;
##   - intervalo entre dois "início" = quadro inteiro (com renderização quando há janela).

var main
var rows: Array = []
var cur: Dictionary = {}
var _t_start := 0
var _t_proc := 0
var _prev_start := 0
var _obj0 := 0


class Probe extends Node:
	var cb: Callable
	func _process(_d: float) -> void:
		cb.call()


func _on_start() -> void:
	var now := Time.get_ticks_usec()
	if _prev_start > 0 and not cur.is_empty():
		cur["frame"].append(now - _prev_start)
		var o := int(Performance.get_monitor(Performance.OBJECT_COUNT))
		cur["obj"].append(o - _obj0)
	_prev_start = now
	_t_start = now
	_obj0 = int(Performance.get_monitor(Performance.OBJECT_COUNT))


func _on_end() -> void:
	_t_proc = Time.get_ticks_usec()
	if not cur.is_empty():
		cur["proc"].append(_t_proc - _t_start)
	call_deferred("_after_draw")


func _after_draw() -> void:
	if not cur.is_empty():
		cur["draw"].append(Time.get_ticks_usec() - _t_proc)


func begin(name: String) -> void:
	cur = {"name": name, "proc": [], "draw": [], "frame": [], "obj": []}


func finish(extra: String = "") -> void:
	var r := cur
	cur = {}
	r["extra"] = extra
	rows.append(r)


func stat(a: Array) -> Array:
	if a.is_empty():
		return [0.0, 0.0, 0.0]
	var s := a.duplicate()
	s.sort()
	var sum := 0.0
	for x in s:
		sum += x
	return [sum / s.size() / 1000.0, s[int(s.size() * 0.95)] / 1000.0, s[-1] / 1000.0]


func frames(n: int) -> void:
	for i in n:
		await get_tree().process_frame


func screen(name: String, arg = null, n := 60, scroll := false) -> void:
	var t0 := Time.get_ticks_usec()
	main.go(name, arg)
	var build := (Time.get_ticks_usec() - t0) / 1000.0
	await frames(3)
	begin(name + (" (rolando)" if scroll else ""))
	var sc: ScrollContainer = _find_scroll(main.body)
	for i in n:
		if scroll and sc != null:
			sc.scroll_vertical = (i * 23) % maxi(int(sc.get_v_scroll_bar().max_value), 1)
		await get_tree().process_frame
	finish("montagem %.1f ms, nós %d" % [build, Performance.get_monitor(Performance.OBJECT_NODE_COUNT)])


func _find_scroll(n: Node) -> ScrollContainer:
	if n is ScrollContainer:
		return n
	for c in n.get_children():
		var r := _find_scroll(c)
		if r != null:
			return r
	return null


func _ready() -> void:
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	Engine.max_fps = 0
	var a := Probe.new()
	a.process_priority = -1000000
	a.cb = _on_start
	add_child(a)
	var b := Probe.new()
	b.process_priority = 1000000
	b.cb = _on_end
	add_child(b)
	Game.delete_save(4)
	Game.rng.seed = 31337
	main = load("res://main.tscn").instantiate()
	add_child(main)
	while not DataPack.loaded():
		await get_tree().process_frame
	var coach = {"name": "QA Perf", "age": 35, "nat": "Brasil", "skin": 2, "hair": 1, "haircolor": 0, "beard": 1, "suit": 0, "rep": 5.0}
	Game.new_career(4, coach, 3, 0)
	for k in 6:
		Game.play_next(null)
		while Media.has_interview():
			Media.answer("provocar")
	# feed cheio (60 posts) para a tela social
	for k in 80:
		Media._post(["fa", "hater", "jornalista", "rival"][k % 4], "post de teste número %d com texto um pouco mais longo para quebrar linha" % k)
	main.home()
	await frames(5)
	begin("hub (parado)")
	await frames(90)
	finish()
	await screen("social", null, 90)
	await screen("social", null, 120, true)
	await screen("squad", null, 90)
	await screen("squad", null, 120, true)
	await screen("market", null, 120, true)
	await screen("transfers", null, 90, true)
	await screen("table", null, 60)
	main.home()
	await frames(5)

	# partida ao vivo: campo inteiro, sem lances
	main.go("match")
	await frames(5)
	var mv = main.body.get_child(0)
	mv.lances = false
	mv.speed = 1
	mv._start()
	var guard := 0
	while mv.state != "live" and guard < 600:
		guard += 1
		await get_tree().process_frame
	mv.sim.interactive = false
	await frames(120)   # deixa os sprites assarem (na partida real isso acontece sob a tela de carregamento)
	LanceView.people_us = 0.0
	LanceView.people_n = 0
	begin("FieldView ao vivo (22 + árbitro)")
	await frames(600)
	finish()
	print("  bonecos (_draw_people): %.2f ms por quadro" % (LanceView.people_us / 1000.0 / maxf(LanceView.people_n, 1)))
	# lances (máquina, roteiro variado) por cima da partida, como no jogo
	begin("LanceView (lances da máquina)")
	var n_l := 0
	for kind in ["goal", "save", "out", "lost", "goal", "save"]:
		var lv := LanceView.new()
		mv.sim.pending = {"side": 0, "pg": 0.3}
		lv.setup(mv.sim, n_l % 2, false)
		lv.script_kind = kind
		mv.field.visible = false
		main.overlay.add_child(lv)
		lv.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		var g2 := 0
		while lv.state != "done" and g2 < 2000:
			g2 += 1
			await get_tree().process_frame
		lv.queue_free()
		mv.field.visible = true
		n_l += 1
	await get_tree().process_frame
	finish("%d lances" % n_l)
	mv._to_end()
	await frames(5)

	var headless := DisplayServer.get_name() == "headless"
	print("\nQA PERF (%s, renderer %s) — ms: média / p95 / pior" % ["headless" if headless else "janela " + DisplayServer.get_name(),
		RenderingServer.get_video_adapter_name()])
	print("| Tela | quadros | _process | _draw | quadro total | objetos novos/quadro (média) | obs |")
	print("|---|---|---|---|---|---|---|")
	for r in rows:
		var p := stat(r["proc"])
		var d := stat(r["draw"])
		var f := stat(r["frame"])
		var om := 0.0
		for o in r["obj"]:
			om += o
		om /= maxf(r["obj"].size(), 1.0)
		print("| %s | %d | %.2f / %.2f / %.2f | %.2f / %.2f / %.2f | %.2f / %.2f / %.2f | %+.1f | %s |" % [r["name"], r["frame"].size(),
			p[0], p[1], p[2], d[0], d[1], d[2], f[0], f[1], f[2], om, r["extra"]])
	# custo de gravar o save (acontece 2-3 vezes por jogo)
	var t0 := Time.get_ticks_usec()
	for k in 5:
		Game.save()
	print("Game.save(): %.1f ms (save %.0f KB)" % [(Time.get_ticks_usec() - t0) / 5000.0, FileAccess.get_file_as_bytes(Game.SAVE_PATH % 4).size() / 1024.0])
	t0 = Time.get_ticks_usec()
	Game.load_career(4)
	print("Game.load_career(): %.1f ms" % ((Time.get_ticks_usec() - t0) / 1000.0))
	t0 = Time.get_ticks_usec()
	Game.play_next(null)
	print("Game.play_next(null) (rodada inteira + mídia + saves): %.1f ms" % ((Time.get_ticks_usec() - t0) / 1000.0))
	Game.delete_save(4)
	get_tree().quit()
