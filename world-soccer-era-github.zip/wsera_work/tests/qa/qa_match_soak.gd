extends Node
## QA soak de partidas (headless).
## Story type: Integration | Saída: stdout (resumo em production/qa/qa-report.md) | Gate: ADVISORY (soak)
## Rodar: XDG_DATA_HOME=... godot --headless --path . res://tests/qa/qa_match_soak.tscn -- live=200 field=20 sim=760
##  A) "sim": partidas simuladas (sem lances): gols por jogo, mando de campo, empates, placares extremos.
##  B) "live": partidas com lances jogados quadro a quadro (LanceView, 60 Hz): o lado do usuário joga com
##     decisões automáticas variadas, o outro lado é roteirizado. Checa sobreposição de corpos, NaN,
##     lance que nunca termina, e as estatísticas de placar com lances.
##  C) "field": as primeiras N partidas ao vivo também rodam o campo inteiro (FieldView) entre os lances.

const SKIN := 0.02
const LANCE_GUARD := 3600   ## 60 s de lance a 60 Hz sem chegar em "done" = travado

var n_live := 200
var n_field := 20
var n_sim := 760
var think := 20   ## quadros que o "usuário" leva para decidir
var force_style := -1   ## -1 = sorteia o estilo do "usuário" por lance
var problems: Array = []
var suite


func bad(msg: String) -> void:
	if problems.size() < 100:
		problems.append(msg)
	print("  PROBLEMA: ", msg)


func _args() -> void:
	for a in OS.get_cmdline_user_args():
		var kv := a.split("=")
		if kv.size() == 2:
			match kv[0]:
				"live": n_live = int(kv[1])
				"field": n_field = int(kv[1])
				"sim": n_sim = int(kv[1])
				"style": force_style = int(kv[1])
				"think": think = int(kv[1])


func new_stats() -> Dictionary:
	return {"n": 0, "goals": 0, "hg": 0, "ag": 0, "hw": 0, "d": 0, "aw": 0, "nil": 0, "max": 0, "big": 0, "scores": {}}


func add_result(st: Dictionary, hg: int, ag: int) -> void:
	st["n"] += 1
	st["goals"] += hg + ag
	st["hg"] += hg
	st["ag"] += ag
	if hg > ag: st["hw"] += 1
	elif hg < ag: st["aw"] += 1
	else: st["d"] += 1
	if hg + ag == 0: st["nil"] += 1
	st["max"] = maxi(st["max"], hg + ag)
	if hg + ag >= 8: st["big"] += 1
	var k := "%d-%d" % [hg, ag]
	st["scores"][k] = int(st["scores"].get(k, 0)) + 1


func fmt_stats(st: Dictionary) -> String:
	var n := maxf(float(st["n"]), 1.0)
	var top: Array = st["scores"].keys()
	top.sort_custom(func(a, b): return st["scores"][a] > st["scores"][b])
	return "%d jogos | %.2f gols/jogo (casa %.2f, fora %.2f) | casa %.1f%% empate %.1f%% fora %.1f%% | 0x0 %.1f%% | máx %d gols, %d jogos com 8+ | placares %s" % [
		st["n"], st["goals"] / n, st["hg"] / n, st["ag"] / n, 100.0 * st["hw"] / n, 100.0 * st["d"] / n, 100.0 * st["aw"] / n,
		100.0 * st["nil"] / n, st["max"], st["big"], str(top.slice(0, 6))]


func body_checks(w: BodyWorld, acc: Dictionary, ball: BallPhysics) -> void:
	if w == null:
		return
	var g := w.min_gap()
	acc["worst"] = minf(float(acc["worst"]), g)
	if g < -SKIN:
		acc["overlap"] += 1
	acc["frames"] += 1
	for b in w.bodies:
		if is_nan(b.pos.x) or is_nan(b.pos.y) or is_nan(b.vel.x) or is_nan(b.vel.y):
			acc["nan"] += 1
	if ball != null and (is_nan(ball.pos.x) or is_nan(ball.pos.y) or is_nan(ball.z)):
		acc["nan"] += 1
	if ball != null and (absf(ball.pos.x) > 80.0 or ball.pos.y < -30.0 or ball.pos.y > 140.0):
		acc["ball_far"] += 1


## Decisão do usuário: três estilos para cobrir mais caminhos do código.
func user_decide(lv: LanceView, style: int) -> void:
	match style:
		0:
			suite._auto_play(lv)
		1:
			# chuta logo, direção e força sorteadas
			lv._do_shot(Game.rng.randf_range(-3.5, 3.5), Game.rng.randf_range(0.2, 1.0), Game.rng.randf_range(0.3, 1.0))
		_:
			# passe para qualquer companheiro (às vezes alto), no máximo 3 vezes; depois chuta
			if lv.moments < 3 and lv.att.size() > 1 and not lv.shot_only:
				var to := Game.rng.randi_range(0, lv.att.size() - 1)
				if to == lv.carrier:
					to = (to + 1) % lv.att.size()
				lv._do_pass(to, Game.rng.randf() < 0.3)
			else:
				lv._do_shot(Game.rng.randf_range(-3.0, 3.0), 0.6, 0.6)


func run_lance(sim: MatchSim, side: int, user: bool, acc: Dictionary, lst: Dictionary) -> Dictionary:
	var lv := LanceView.new()
	lv.size = Vector2(1280, 720)
	lv.setup(sim, side, user)
	var style := Game.rng.randi_range(0, 2) if force_style < 0 else force_style
	var guard := 0
	var decide_frames := 0
	var t0 := Time.get_ticks_usec()
	while lv.state != "done" and guard < LANCE_GUARD:
		guard += 1
		if lv.state == "decide" and lv.user_ctrl:
			decide_frames += 1
			if decide_frames > think:   # o "usuário" pensa (padrão 1/3 s)
				user_decide(lv, style)
				decide_frames = 0
		var f0 := Time.get_ticks_usec()
		lv._process(1.0 / 60.0)
		var df := Time.get_ticks_usec() - f0
		lst["us_max"] = maxi(lst["us_max"], df)
		body_checks(lv.world, acc, lv.bp)
	lst["us"] += Time.get_ticks_usec() - t0
	lst["frames"] += guard
	lst["max_frames"] = maxi(lst["max_frames"], guard)
	var res: Dictionary = lv.result.duplicate()
	if lv.state != "done":
		bad("lance travado (%s, lado %d, usuário %s, estado %s, roteiro %s, %d quadros)" % [
			"partida %d-%d" % [sim.h, sim.a], side, str(user), lv.state, lv.script_kind, guard])
		res = {"kind": "travou", "pid": int(Game.club(sim.cid(side))["xi"][9])}
	var k := str(res.get("kind", "?")) + ("_pen" if res.get("pen", false) else "")
	var key := ("user_" if user else "cpu_") + k
	if user:
		var sk := "estilo%d_lado%d_%s" % [style, side, "gol" if res.get("goal", false) else "nao"]
		lst["styles"][sk] = int(lst["styles"].get(sk, 0)) + 1
	lst["kinds"][key] = int(lst["kinds"].get(key, 0)) + 1
	if not user and str(lv.script_kind) != "":
		var want: String = lv.script_kind
		var got := str(res.get("kind", ""))
		var ok: bool = got == want or (want == "penalty" and res.get("pen", false))
		if not ok:
			var mk := "%s>%s" % [want, got]
			lst["script_miss"][mk] = int(lst["script_miss"].get(mk, 0)) + 1
	if not res.has("pid"):
		bad("lance sem 'pid' no resultado: %s" % str(res))
	lv.free()
	return res


func _ready() -> void:
	_args()
	suite = load("res://tests/integration/match/test_match_balance.gd").new()
	if not DataPack.loaded():
		DataPack.import_zip("res://datapack.zip")
	var coach = {"name": "QA", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.rng.seed = 5150
	Game.new_career(5, coach, 0, 0)
	var n: int = Game.n_league()

	# ---------- A) simuladas
	var sst := new_stats()
	var t0 := Time.get_ticks_usec()
	for k in n_sim:
		var h := Game.rng.randi_range(0, n - 1)
		var a := (h + Game.rng.randi_range(1, n - 1)) % n
		var sim := MatchSim.new(h, a)
		var steps := 0
		while not sim.finished and steps < 200:
			sim.step()
			steps += 1
		if not sim.finished:
			bad("partida simulada não termina")
		add_result(sst, sim.score[0], sim.score[1])
		Game.apply_players(sim)   # energia/suspensão como num campeonato
		if k % 10 == 9:
			for c in n:
				Game.auto_lineup(c)
			for p in Game.S["players"].values():
				p["energy"] = minf(float(p["energy"]) + 28.0, 100.0)
				if int(p.get("susp", 0)) > 0:
					p["susp"] = int(p["susp"]) - 1
	var us_sim := (Time.get_ticks_usec() - t0) / float(maxi(n_sim, 1))
	print("SIM  ", fmt_stats(sst), " | %.0f us por partida" % us_sim)

	# ---------- B/C) ao vivo
	var lst := {"us": 0, "frames": 0, "us_max": 0, "max_frames": 0, "kinds": {}, "script_miss": {}, "lances": 0, "styles": {}}
	var acc := {"worst": 99.0, "overlap": 0, "frames": 0, "nan": 0, "ball_far": 0}
	var facc := {"worst": 99.0, "overlap": 0, "frames": 0, "nan": 0, "ball_far": 0}
	var lstats := new_stats()
	var fus := 0
	var fus_max := 0
	var fframes := 0
	t0 = Time.get_ticks_usec()
	for k in n_live:
		var h := Game.rng.randi_range(0, n - 1)
		var a := (h + Game.rng.randi_range(1, n - 1)) % n
		var my_side := k % 2
		var sim := MatchSim.new(h, a)
		sim.interactive = true
		var fv: FieldView = null
		if k < n_field:
			fv = FieldView.new()
			fv.size = Vector2(1280, 720)
			fv.setup_field(sim)
		var guard := 0
		while not sim.finished and guard < 200:
			guard += 1
			for e in sim.step():
				if e["type"] == "lance":
					lst["lances"] += 1
					var res := run_lance(sim, int(e["side"]), int(e["side"]) == my_side, acc, lst)
					var ev := sim.resolve_lance(res)
					if fv != null:
						fv.rebuild_teams()
						if not res.get("goal", false):
							fv.keeper_ball(1 - int(ev["side"]))
						else:
							fv.kickoff(1 - int(ev["side"]))
				elif fv != null:
					if e["type"] == "goal":
						fv.kickoff(1 - e["side"])
					elif e["type"] == "chance":
						fv.show_chance(e["side"])
					elif e["type"] in ["card", "sub"]:
						fv.rebuild_teams()
			if fv != null:
				fv.feed_minute(sim.last_side)
				for i in 50:   # ~1.2 min de jogo por segundo (velocidade normal)
					var f0 := Time.get_ticks_usec()
					fv._process(1.0 / 60.0)
					var df := Time.get_ticks_usec() - f0
					fus += df
					fus_max = maxi(fus_max, df)
					fframes += 1
					body_checks(fv.world, facc, fv.bp)
		if not sim.finished:
			bad("partida ao vivo não termina (%d-%d)" % [h, a])
		add_result(lstats, sim.score[0], sim.score[1])
		Game.apply_players(sim)
		if fv != null:
			fv.free()
		if k % 10 == 9:
			for c in n:
				Game.auto_lineup(c)
			for p in Game.S["players"].values():
				p["energy"] = minf(float(p["energy"]) + 28.0, 100.0)
				if int(p.get("susp", 0)) > 0:
					p["susp"] = int(p["susp"]) - 1
		if k % 50 == 49:
			print("  ... %d partidas ao vivo, objetos %d, memória %.1f MB" % [k + 1, Performance.get_monitor(Performance.OBJECT_COUNT),
				Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0])
	var live_s := (Time.get_ticks_usec() - t0) / 1e6
	print("LIVE ", fmt_stats(lstats))
	print("LIVE lances %d (%.1f por partida) | resultados %s" % [lst["lances"], lst["lances"] / maxf(n_live, 1.0), str(lst["kinds"])])
	print("LIVE gols do usuário por estilo (0=auto passe+canto, 1=chute imediato aleatório, 2=passes aleatórios): %s" % str(lst["styles"]))
	print("LIVE roteiro da máquina não cumprido: %s" % str(lst["script_miss"]))
	print("LIVE lance: %.0f us/quadro (lógica, média), pior quadro %d us, lance mais longo %d quadros (%.1f s)" % [
		lst["us"] / maxf(lst["frames"], 1.0), lst["us_max"], lst["max_frames"], lst["max_frames"] / 60.0])
	print("LIVE corpos nos lances: %d quadros, pior folga %.3f m, quadros com sobreposição > %.2f m: %d, NaN %d, bola longe %d" % [
		acc["frames"], acc["worst"], SKIN, acc["overlap"], acc["nan"], acc["ball_far"]])
	if fframes > 0:
		print("FIELD %d quadros: %.0f us/quadro (lógica _process, média), pior %d us | pior folga %.3f m, sobreposição %d, NaN %d, bola longe %d" % [
			fframes, fus / float(fframes), fus_max, facc["worst"], facc["overlap"], facc["nan"], facc["ball_far"]])
	print("tempo ao vivo %.1f s" % live_s)
	if acc["overlap"] > 0 or facc["overlap"] > 0:
		bad("corpos se sobrepondo: lances %d, campo %d" % [acc["overlap"], facc["overlap"]])
	if acc["nan"] > 0 or facc["nan"] > 0:
		bad("NaN na física")
	print("QA MATCH problemas: ", problems.size())
	for p in problems:
		print("   - ", p)
	Game.delete_save(5)
	get_tree().quit(1 if not problems.is_empty() else 0)
