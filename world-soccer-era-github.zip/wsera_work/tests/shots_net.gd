extends Node
## Capturas do gol: em repouso, rede estufada no gol (lance) e os dois gols do campo ao vivo.
## Rodar com tela: SHOTS_DIR=... godot --path . res://tests/shots_net.tscn
var out := ""


func shot(name: String) -> void:
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(out + "net_" + name + ".png")


func _ready() -> void:
	out = OS.get_environment("SHOTS_DIR")
	if out == "":
		out = ProjectSettings.globalize_path("res://production/qa/evidence/")
	DirAccess.make_dir_recursive_absolute(out)
	if not out.ends_with("/"):
		out += "/"
	var coach = {"name": "T", "age": 35, "nat": "Brasil", "skin": 1, "hair": 0, "haircolor": 0, "beard": 0, "suit": 0, "rep": 5.0}
	Game.rng.seed = 21
	Game.new_career(6, coach, 0, 0)
	var sim := MatchSim.new(Game.S["club"], (Game.S["club"] + 1) % 20)
	sim.minute = 30
	sim.pending = {"side": 0, "pg": 0.3}
	var lv := LanceView.new()
	lv.size = Vector2(1280, 720)
	add_child(lv)
	lv.setup(sim, 0, false)
	lv.script_kind = "goal"
	lv.set_process(false)
	var rest_done := false
	var best := 0.0
	var got_hit := false
	var guard := 0
	while lv.state != "done" and guard < 1500:
		guard += 1
		lv._process(1.0 / 60.0)
		lv.cel_t = minf(lv.cel_t, 0.0) if lv.cel_t > 0.0 else lv.cel_t   # sem a comemoração grande por cima
		await get_tree().process_frame
		if not rest_done and lv.state == "shot" and lv.bp.pos.y < 9.0:
			rest_done = true
			await shot("lance_repouso")
		if lv._net_live != null and lv.state == "end":
			var b := 0.0
			for q in lv._net_live.p:
				b = maxf(b, q.y - 2.0)
			if b > best + 0.02:
				best = b
			elif not got_hit and best > 0.2 and b < best - 0.01:
				got_hit = true   # passou do máximo: captura o quadro do pico
				await shot("lance_rede_estufada")
		if lv.state == "end" and lv.t > 2.0 and lv.t < 2.03:
			await shot("lance_bola_na_rede")
	print("NET SHOTS best bulge %.2f" % best)
	lv.queue_free()
	await get_tree().process_frame
	# campo ao vivo: câmera em cada gol
	var fv := FieldView.new()
	fv.size = Vector2(1280, 720)
	add_child(fv)
	fv.setup_field(MatchSim.new(0, 1))
	fv.set_process(false)
	for gy in [3.0, 102.0]:
		for i in 240:
			fv.bp.place(Vector2(1.0, gy))
			fv._process(1.0 / 60.0)
		await get_tree().process_frame
		await shot("campo_gol_%d" % int(gy))
	Game.delete_save(6)
	get_tree().quit()
