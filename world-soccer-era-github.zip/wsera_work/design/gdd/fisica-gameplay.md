# Física e gameplay — análise e reconstrução

Referência de qualidade de jogo: jogos de futebol 2D de celular com câmera superior (fluidez, contato físico,
bola "viva"). Nenhum recurso, nome ou arte de outro jogo é usado.

## 1. Como era (antes desta revisão)

Arquivos: `src/lance_view.gd` (lance perto do gol, com toque do jogador), `src/field_view.gd`
(partida ao vivo no campo inteiro; herda de `LanceView` e reaproveita o desenho dos bonecos),
`src/ball_physics.gd` (bola), `src/referee.gd` (regras), `assets/data/match_tuning.json` (números).

**Entidades.** Cada jogador é um `Dictionary` (`pos`, `dir`, `spd`, `ph` = fase da passada, `moving`,
`stun`, `kick`...). Não existia velocidade: `_move()` teleportava a posição até `speed * delta` na
direção do alvo — aceleração e freada instantâneas, giro de quase 180° em um quadro (só `dir` era
suavizado, para o desenho).

**Colisão.** `_separate()` empurrava pares mais próximos que 0,9 m, numa única passada, sem raio por
corpo, sem massa, sem mexer em velocidade (não havia velocidade). O árbitro não entrava. Com vários
corpos encostados a passada única deixava sobreposição; o goleiro no mergulho era movido direto
(`move_toward`) e podia atravessar quem estivesse no caminho.

**Bola.** Atrito constante no chão, arrasto linear no ar, quique só vertical. Na condução a bola era
**colada** ao pé (`bp.place(pé + dir*toque)` a cada quadro) — tanto no lance quanto no campo ao vivo.
No domínio a bola era recolocada nos pés do recebedor. A bola atravessava corpos: bloqueio, corte e
desvio eram sorteios por distância, sem contato.

**Disputas.** O bote era julgado só no fim da corrida (`_end_run`) se o marcador estivesse a < 1,6 m,
independente de ângulo ou de quem estava entre ele e a bola. Não havia proteção de bola.
Interceptação: o defensor andava até a projeção da linha do passe, sem calcular se chegava a tempo.

**Tempo.** Tudo rodava com o `delta` do quadro: o resultado mudava com a taxa de quadros (30 × 60 fps).

**Animação.** Passada vinha da distância andada (bom: sem patinar), mas sem caminhada × corrida,
sem inclinação por aceleração/curva; os bonecos são desenhados em lote (uma chamada por quadro) —
isso é preservado.

## 2. O que muda

| Sistema | Novo comportamento | Onde |
|---|---|---|
| Passo fixo | Simulação a 60 Hz com acumulador; desenho e câmera por quadro | `LanceView._process`, `FieldView._process` |
| Corpo | `vel`, raio por tipo (jogador, goleiro, árbitro), massa por físico | `LanceView._body()` |
| Movimento | Direção por *steering*: aceleração/freada limitadas, giro máximo que cai com a velocidade, chegada suave, desvio dos vizinhos (olhar à frente); quem não recebe ordem freia | `LanceView._move`, `_integrate_bodies` |
| Colisão | Separação iterativa com raios e massas; impulso inelástico na velocidade; árbitro e goleiro entram | `LanceView._collide` |
| Bola | Rolamento + arrasto quadrático (chão e ar), quique com perda e derrapagem, curva, mira por tiro iterativo (a bola chega onde foi mirada mesmo com arrasto e curva); passe calcula a força para chegar com a velocidade pedida | `BallPhysics` |
| Bola × corpo | Bola baixa bate no corpo e desvia (impulso pela normal, perda de força) | `LanceView._ball_vs_bodies` |
| Condução | Toques de verdade: a bola anda à frente e o condutor a alcança e toca de novo | `LanceView._dribble`, `FieldView` |
| Domínio | Qualidade depende de velocidade/altura da bola e do passe do jogador; domínio ruim espirra a bola | `LanceView._first_touch` |
| Disputa | Proteção (o condutor põe o corpo entre marcador e bola), bote quando o marcador alcança a bola, chance por ângulo/tempo/atributos (por trás = mais falta), errar o bote deixa o marcador para trás | `LanceView._try_tackle`, `Referee.judge_tackle` |
| Interceptação | Ponto de corte = primeiro ponto do caminho previsto da bola que o defensor alcança a tempo | `LanceView._intercept_point` |
| Animação | Caminhada × corrida pela velocidade, inclinação pela aceleração e pela curva, goleiro agachado na espera, mergulho, encaixe (bola presa) × espalmada | `LanceView._draw_player` |

Os resultados roteirizados da máquina (`script_kind`) continuam garantidos: nos lances da máquina a bola
não é desviada por corpos e a mira compensa a física.

## 3. Regras e fórmulas (como ficou)

**Passo fixo.** `STEP = 1/60 s`. `_process(delta)` acumula o tempo e roda até 6 passos por quadro;
desenho e câmera usam o `delta` do quadro. Resultado: o mesmo lance com a mesma semente dá o mesmo
resultado a 30, 60 e 120 fps (teste `test_physics_bodies.gd`, diferença 0,000 m).

**Corpo (`src/physics/body.gd`).** `pos, vel, acc, facing, radius, inv_mass, max_accel, max_decel,
turn_still, turn_run`. Raio: jogador 0,42 m, goleiro 0,5 m, árbitro 0,38 m. Massa = 72 + 0,25·desarme
(goleiro 85, árbitro 70). Aceleração = 8 + 0,03·velocidade (m/s²), freada 12 m/s².

**Movimento (`BodyWorld._integrate`).** velocidade desejada `= dir · min(vmax, √(2·0,8·freada·(d−0,04)))`
(chega freando) + desvio. Giro máximo por passo `= lerp(720°/s, 240°/s, |v|/7)·dt`; numa virada maior
que o giro, a velocidade alvo cai por `cos(ângulo restante)` (freia enquanto vira). Acelera até o alvo com
`max_accel`, freia com `max_decel`. Passada da animação `ph += distância andada · STRIDE` (sem patinar).

**Desvio.** Olha `0,45 s · |v| + 0,6 m` à frente; cada corpo no corredor (largura = soma dos raios +
0,25 m) empurra para o lado com força `3,2 · (1 − à_frente/olhar) · (folga/largura)`. Ordem com
`_press = true` (marcar a bola, receber passe, buscar bola) não desvia. O desvio de cada corpo é
recalculado a cada 2 passos (metade do time por passo).

**Colisão (`BodyWorld.collide`).** Ordena por x (varredura: só testa vizinhos), até 4 iterações de
separação ponderada pela massa; no primeiro contato, impulso inelástico `j = −(1+0,15)·vₙ/(1/m₁+1/m₂)`.
Corpo cinemático (goleiro no mergulho) não é empurrado.

**Bola (`src/ball_physics.gd`).** Ar: `a = −0,009·|v|·v − g·ẑ + curva`. Chão: `a = −(1,8 + 0,018·|v|²)`
na direção do movimento. Quique: `vz' = −0,45·vz`, `v' = 0,84·v`, a curva acaba no primeiro quique.
Passe rasteiro: força de saída para chegar com 7 m/s: `a + k·v0² = (a + k·v1²)·e^(2·k·s)`.
Chute e passe alto: mira por tiro iterativo com a mesma física (erro < 2 mm no teste).

**Bola × corpo.** Bola até 1,85 m que encosta num corpo (raio + 0,11 m) é empurrada para fora e perde a
velocidade normal (ricochete 0,35, perda 12%). Exceções: quem conduz, quem acabou de tocar, o recebedor do
passe e o goleiro (lógica de defesa). Defensor no caminho do passe: tenta o corte (chance de corte); se
erra, fica 0,5 s atrás do lance e a bola passa raspando. Chute que bate no corpo do zagueiro = travado.
Passe do jogador: o passador abre o ângulo (até 26°) para contornar o marcador já driblado.

**Condução.** Toque quando a bola está a menos de 0,75 m do pé e não corre à frente: `v_bola =
min(max(1,18·|v_condutor| + 1,25; 1,5); 9,5)`, desviado até 35% para longe do marcador a menos de
2,6 m (proteção). Fim da corrida: o condutor alcança a bola e a prende com a sola (`settle`, até 0,5 s).

**Domínio.** `erro = (0,15 + 0,035·|v_bola|)·clamp(1,35 − passe/100; 0,2; 1)`; a bola sai à frente do
recebedor a `1 + 0,06·|v_bola|` m/s mais o erro.

**Disputa.** O marcador cerca a 1,5 m da bola (lado do gol) e dá o bote depois de
`U(0,2; 0,55)·(1,6 − desarme/100)` s, quando alcança a bola (1,15 m). Proteção = o condutor entre o marcador e
a bola: `+22·proteção` na habilidade do atacante. Bote por trás: +22% de chance de falta. Errou: marcador
atordoado 0,9 s.

## 4. Animação (estado físico → pose)

Velocidade < 2,4 m/s = caminhada (passada curta, quase sem pulo); acima disso a corrida entra aos poucos
(joelho alto, braço mais solto). Inclinação pela aceleração lateral na tela. Perna arma antes do contato e
está à frente no contato (chute/passe). Domínio: pé sobe. Carrinho: corpo deitado, perna da frente
esticada. Queda: corpo deitado e levanta. Goleiro: agachado com braços abertos esperando o chute, mergulho,
encaixe (bola presa no peito) ou espalmada (bola sai para o lado). Comemorações (`e["cel"]`): 0 soco no ar
com pulo, 1 aviãozinho, 2 joelhada (de joelhos, braços abertos), 3 apontar o céu; quem perdeu põe as mãos
na cabeça.

### 4.1 Comemoração do gol (deslizada de joelhos)

Depois do gol, o autor escolhe a comemoração (sorteio visual, sem mexer no `Game.rng`): deslizada de
joelhos com `comemoracao.chance_deslizada` (0,6), senão soco no ar, aviãozinho ou apontar o céu. Ele
corre (corpo físico em sprint) para o canto da tela mais perto (`canto_x`, `canto_y`; o outro lado se a zaga,
o goleiro ou o árbitro estiver no caminho), entre `corrida_min` e `corrida_max` metros. Estados do autor
(`e["cs"]`): `run` → `slide` | `pose`, `slide` → `kneel`. Na deslizada o corpo fica sem ordem de movimento e
freia só pelo `atrito_grama_deslizada` (m/s²); ele cai na grama quando essa freada termina no ponto escolhido.
De joelhos: braços abertos para o alto, tronco para trás; o corpo fica pesado (os companheiros não o arrastam).
Rastro: duas marcas dos joelhos que somem em `vida_marca_grama` s e grama/terra levantada. Companheiros vêm
atrás dele e fecham a roda (raio `raio_roda_companheiros`, dos lados e atrás na tela, fora da frente da
deslizada) e pulam; a zaga põe as mãos na cabeça. A câmera segue o autor com `zoom_camera`. A tela grande
("GOOOOOL!!", com o boneco na mesma pose) entra `espera_tela_grande` s depois que ele para; o lance termina
em `duracao_fim_gol` s. "Pular" durante a comemoração encerra o lance; lance pulado antes do fim tem a
comemoração curta antiga (sem corrida, 2,9 s).

## 5. Visual dos bonecos (estilo chibi da arte do jogo)

Cabeça ~45% da altura, contorno escuro grosso em cada parte (forma escura maior desenhada antes do
preenchimento, no mesmo lote de triângulos), olhos pretos em pílula, sorriso branco aberto, sobrancelha
grossa, camisa com gola em V e punho na manga, meião com faixa, chuteira com detalhe colorido, cores da
camisa um pouco mais vivas (`LanceView.vivid`). Sem marcas nem patrocínio nas camisas.

Chaves do jogador (as mesmas nos menus e na partida). Quando faltam, saem do `id`:

| chave | padrão | valores |
|---|---|---|
| `look_hstyle` | `id % 7` | 0 curto espetado, 1 topete/moicano, 2 black power, 3 careca, 4 raspado degradê, 5 franja, 6 cachos longos (sempre com faixa) |
| `look_beard` | `id % 4 == 1` | barba |
| `look_skin` | `(id * 3) % 6` | índice em `LanceView.SKINS` |
| `look_hcolor` | `(id * 5) % 6` | índice em `LanceView.HAIRS` |
| `look_boots` | `"17171b"` | cor da chuteira; detalhe colorido = `BOOT_ACCENTS[id % 6]` |
| `look_headband` | `id % 9 == 4` | faixa na cabeça (estilo 6 sempre tem) |
| `look_wrist` | `id % 5 == 2` | munhequeira branca |

## 6. Ajustes (assets/data/match_tuning.json)

`bola`: rolamento, arrasto_chao, arrasto_ar_quadratico, quique, perda_no_quique, curva_chute, curva_falta.
`corpo`: raios, massa, aceleração, freada, giro parado/correndo, olhar à frente, força do desvio,
restituição, iterações, velocidade de caminhada, escala do desenho. `conducao`: alcance e força do toque,
erro do domínio. `disputa`: alcance do bote, distância de cerco, bônus de proteção, falta por trás,
atordoado, ricochete. `passe.velocidade_chegada`. `comemoracao`: ver §4.1. `goleiro.alcance_lateral` 1,15 → 1,0 e
`velocidade_por_ponto` 0,02 → 0,017: com a bola mais lenta pelo arrasto real, o goleiro defendia 46% dos
chutes nos lances simulados (antes 34%); com o ajuste, a taxa de gol volta à faixa anterior.

## 7. Critérios de aceite (verificados por teste automático)

`tests/integration/match/test_physics_bodies.gd`, `tests/unit/physics/test_ball_physics.gd`,
`tests/integration/match/test_match_balance.gd`. Capturas: `tests/shots_gameplay.tscn`.

## 7. Visual da partida (revisão "look & feel")

- **Bonecos**: figura proporcional (~3,3 cabeças: cabeça r=14,5 em 100 unidades), contorno escuro
  fino, sombra de contato + sombra do sol esticada na diagonal, número nas costas desenhado num passe
  único depois do lote. Retratos dos menus continuam chibi (`src/chibi_portrait.gd`).
- **Cache de poses**: poses comuns (parado, caminhada, trote, corrida × 12 fases × vista/lado ×
  6 fases de respiração) ficam em `e["_pcache"]` como triângulos locais + cores; por quadro só
  transforma e anexa. Poses especiais (chute, domínio, carrinho, queda, mergulho, comemoração) são
  montadas ao vivo. Cores do uniforme em `e["_cols"]`.
- **Câmera**: mola criticamente amortecida (`_spring`, ω=4,5) com antecipação de 0,35 s da bola;
  lance mostra 58 m de largura, partida ao vivo 62 m. `BODY_H` 3,15 m (lance), escala 0,95 no campo.
- **Gramado**: faixas cortadas de 9 m.
- **Cansaço**: `_stam(e)` lê `Game.stamina_factor(pid)` uma vez por minuto da partida; multiplica a
  velocidade máxima (`_spd`) e a aceleração do corpo; erros de passe/chute são divididos por ele.
