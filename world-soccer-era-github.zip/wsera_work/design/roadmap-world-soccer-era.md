# World Soccer: Era — plano de evolução

## Direção visual

Preservar a câmera superior 2D e os bonecos desenhados por código do projeto. A identidade segue verde profundo, oliva de gramado e dourado pontual. Não migrar para uma apresentação 3D nem substituir a linguagem visual por cards genéricos.

## Entregas por sistema

### Abertura e navegação
- [x] Menu inicial de abertura.
- [x] Ação de nova carreira, continuar, carreiras e datapack.
- [x] Transição animada entre menu e carreira (cortina verde com fio dourado; demais telas com esmaecimento) — `src/main.gd`.
- [x] Arte de capa original, desenhada por código (vale em qualquer resolução, desktop e mobile) — `src/title_art.gd`.

### Jogadores e animações
- [x] Primeiro passe no ciclo procedural de corrida.
- [x] Parado: respiração e balanço de braços com ritmo próprio de cada jogador.
- [x] Passe e domínio (o pé do recebedor sobe para amortecer).
- [x] Chute (perna arma para trás e o pé está à frente no contato) e cabeceio (pulo).
- [x] Desarme (carrinho), queda na falta, comemoração (pulinhos, braços para cima) e lamento (mãos na cabeça).
- [x] Goleiro: passinhos na linha, antecipação, mergulho, defesa com as mãos e recuperação depois do lance.

### Bola e partida
- [x] Efeito/curva nos chutes (mais forte na falta); a mira desconta a curva e o goleiro prevê a trajetória com ela.
- [ ] Refinar quique e desaceleração da bola no chão (mantidos os valores atuais).
- [x] Sincronizar contato do pé com o instante do chute.
- [ ] Revisar colisões e leitura visual de posse.
- [x] Efeitos discretos de rede (ondas onde a bola entrou) e torcida (papel picado nas cores de quem comemora).

### Pênaltis
- [x] Três defensores posicionados dentro do gol, atrás do goleiro.
- [x] Cena de apresentação com aproximação de câmera.
- [x] Animação de corrida do cobrador e contato com a bola.
- [x] Mergulho do goleiro com antecipação e recuperação.
- [x] Reação dos três jogadores e da torcida após gol/defesa.

### Competições e símbolos
- [x] Manter carregamento dos logos de competição a partir do datapack.
- [x] Conferir IDs e logos de todas as competições em cada país (`tests/audit_logos.gd`).
- [x] Fallback visual consistente quando um logo estiver ausente (emblema padrão em todas as telas).
- [ ] Validar escudos de clubes, uniformes e cores conflitantes (17 clubes sem imagem no pacote usam o escudo desenhado).

## Auditoria de logos (pacote que vem no APK)

- Escudos: 991 de 1008 clubes. Sem imagem no pacote: Llaneros, Beveren, Club NXT, Çorum FK, Guangzhou FC,
  Shanghai Jiading, Dalian Kuncheng, Heilongjiang Ice City, 1º de Agosto, Kabuscorp do Palanca, Malut United,
  North Carolina, York United, Valour FC, Rio Branco-PR, Hercílio Luz, Inter de Lages.
- Ligas: 45 de 58 com logo. Sem logo no pacote (usam o emblema): Liga Argentina, Premier League, Bundesliga,
  EFL Championship, 2. Bundesliga, Major League Soccer, EFL League One, EFL League Two, National League, 3. Liga,
  Primera B (Colômbia), Primera Nacional, USL Championship.
- Copas sem logo no pacote (usam o emblema): FA Cup, Carabao Cup, Hazfi Cup, Canadian Championship,
  Copa Libertadores, Champions League.

## Critério de conclusão

Uma entrega só deve ser marcada como concluída depois de abrir no Godot, percorrer a tela, testar a interação e registrar evidência visual. A qualidade final não deve ser declarada apenas por alterações de código.

Evidência desta revisão: Godot 4.5.1, `tests/run_tests.tscn` (149 verificações, 0 falhas), partida completa em
`tests/movie.tscn` sem erros, capturas em `tests/shots_tour.tscn` (menu, transição, clubes, pênalti).
