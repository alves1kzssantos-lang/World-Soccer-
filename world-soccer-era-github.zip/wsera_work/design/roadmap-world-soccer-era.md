# World Soccer: Era — plano de evolução

## Direção visual

Preservar a câmera superior 2D e os bonecos desenhados por código do projeto. A identidade segue verde profundo, oliva de gramado e dourado pontual. Não migrar para uma apresentação 3D nem substituir a linguagem visual por cards genéricos.

## Entregas por sistema

### Abertura e navegação
- [x] Menu inicial de abertura.
- [x] Ação de nova carreira, continuar, carreiras e datapack.
- [ ] Transição animada entre menu e carreira.
- [ ] Arte de capa original em resolução desktop e mobile.

### Jogadores e animações
- [x] Primeiro passe no ciclo procedural de corrida.
- [ ] Ciclo de caminhada/idle com variação individual.
- [ ] Animação de passe e domínio.
- [ ] Animação de chute e cabeceio.
- [ ] Desarme, queda, comemoração e reação.
- [ ] Goleiro: posicionamento, mergulho lateral, defesa com mãos e recuperação.

### Bola e partida
- [ ] Refinar curva, quique e desaceleração da bola.
- [ ] Sincronizar contato do pé com o instante do chute.
- [ ] Revisar colisões e leitura visual de posse.
- [ ] Efeitos discretos de impacto, rede e torcida.

### Pênaltis
- [x] Três defensores posicionados dentro do gol, atrás do goleiro.
- [ ] Cena de apresentação com aproximação de câmera.
- [ ] Animação de corrida do cobrador e contato com a bola.
- [ ] Mergulho do goleiro com antecipação e recuperação.
- [ ] Reação dos três jogadores e da torcida após gol/defesa.

### Competições e símbolos
- [x] Manter carregamento dos logos de competição a partir do datapack.
- [ ] Conferir IDs e logos de todas as competições em cada país.
- [ ] Criar fallback visual consistente quando um logo estiver ausente.
- [ ] Validar escudos de clubes, uniformes e cores conflitantes.

## Critério de conclusão

Uma entrega só deve ser marcada como concluída depois de abrir no Godot, percorrer a tela, testar a interação e registrar evidência visual. A qualidade final não deve ser declarada apenas por alterações de código.
